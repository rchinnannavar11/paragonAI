import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Calculator, ChevronRight, X, Sparkles, CheckCircle2, AlertCircle, Info, History,
  Loader2, Play, Calendar, Users, Layers, ShieldCheck, HelpCircle,
  Clock, ArrowRight, Check, Database, SlidersHorizontal, Settings, FileText, CheckSquare,
  AlertTriangle, DollarSign, TrendingUp, RefreshCw, BarChart3, ChevronDown, PlusCircle, Trash2, ShieldAlert,
  Save
} from "lucide-react";
import { toast } from "react-hot-toast";
import { cn } from "../lib/utils";
import { ProjectEstimateAsset } from "../types";

// Estimator Input Types
export interface ProjectEstimatorInputs {
  // Top-level inputs
  industry: string;
  companyName: string;
  overridingContext: string;

  // Platform tab
  dataPlatform: string; // Databricks, Microsoft Fabric, Snowflake, BigQuery, Redshift, ""
  cloudPlatform: string; // Azure, AWS, GCP, On-Prem, ""
  deploymentModel: string; // Greenfield, Enhancement, Migration, ""
  environments: string[]; // DEV, QA, UAT, PROD
  deploymentMethod: string; // Manual, IaC, Enterprise Standard, ""
  jdbcSources: number;
  apiSources: number;
  fileSources: number;
  streamingSources: number;
  saasSources: number;
  dataSize: string; // <100GB, 100GB-1TB, 1TB-10TB, >10TB, ""
  dailyGrowth: string; // Low, Medium, High, ""
  refreshFrequency: string; // Daily Batch, Near Real-Time, Real-Time, ""
  featuresDataLake: boolean;
  featuresDataWarehouse: boolean;
  featuresDataGovernance: boolean;
  featuresCiCd: boolean;
  featuresMonitoring: boolean;
  featuresDisasterRecovery: boolean;

  // Project Framework tab
  projectFramework: string; // Framework A, Framework B, Framework C, Framework D
  deliveryFramework: string; // Waterfall Framework, Agile Scrum, etc.
  deliveryMethodology: string;
  numIterations: number;
  phaseLength: string;
  testingDuration?: number;
  hypercareDuration?: number;
  goLiveDuration?: number;
  waterfallSubphaseLength?: number;

  // Project Scope & Use Case tab
  primaryUseCase: string; // Reporting, Analytics, AI/ML, Data Sharing, ""
  numUseCases: number;
  numDomains: number;
  numPipelines: number;
  transformationComplexity: string; // Simple, Moderate, Complex, ""
  migrationRequired: boolean;
  migrationYears: number;
  numDashboards: number;
  numReports: number;
  numSemanticModels: number;
  executiveReporting: boolean;
  aiFeaturesIncluded: boolean;
  numMlModels: number;
  genAiFeatures: boolean;
  ragVectorSearch: boolean;
  qualityComplexity: string; // None, Basic, Moderate, Extensive, ""
  mdmRequired: boolean;

  // Resources tab
  deliveryModel: string; // Client Led, Shared, Vendor Led, ""
  smeAvailability: string; // Low, Medium, High, ""
  teamLocation: string; // Onshore, Offshore, Hybrid, ""
  agileDelivery: boolean;
  sprintLength: string; // 1 Week, 2 Weeks, 3 Weeks, ""
  resourceSMEs: number;
  resourceEngineers: number;
  resourceBI: number;
  resourceArchitects: number;
  resourcePMs: number;
  resourceQA: number;
  resourceDevOps: number;

  // Other Considerations tab
  ssoRequired: boolean;
  rbacRequired: boolean;
  complianceRequirements: string[]; // HIPAA, PCI, SOX, GDPR
  sensitiveData: boolean;
  numStakeholderGroups: number;
  numBusinessUnits: number;
  geographicRegions: number;
  steeringCommittee: boolean;
  trainingRequired: boolean;
  numUserGroups: number;
  documentationComplexity: string; // Basic, Standard, Extensive, ""
  targetGoLiveDate: string; // YYYY-MM-DD
  projectStartDate: string; // YYYY-MM-DD
  fixedBudget: boolean;
  fixedTimeline: boolean;
}

export function getFirstMondayOfNextMonth(fromDate: Date = new Date()): string {
  const year = fromDate.getFullYear();
  const month = fromDate.getMonth(); // 0-11
  let nextMonthYear = year;
  let nextMonth = month + 1;
  if (nextMonth > 11) {
    nextMonth = 0;
    nextMonthYear += 1;
  }
  const firstDay = new Date(nextMonthYear, nextMonth, 1);
  let dayOfWeek = firstDay.getDay(); // 0 is Sunday, 1 is Monday...
  let addDays = 0;
  if (dayOfWeek === 1) {
    addDays = 0;
  } else if (dayOfWeek === 0) {
    addDays = 1;
  } else {
    addDays = 8 - dayOfWeek;
  }
  const firstMonday = new Date(nextMonthYear, nextMonth, 1 + addDays);
  const y = firstMonday.getFullYear();
  const m = String(firstMonday.getMonth() + 1).padStart(2, "0");
  const d = String(firstMonday.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function calculateGoLiveDateString(startDateStr: string, durationWeeks: number): string {
  if (!startDateStr) return "";
  const parts = startDateStr.split("-");
  if (parts.length !== 3) return "";
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10) - 1;
  const d = parseInt(parts[2], 10);
  const date = new Date(y, m, d);
  date.setDate(date.getDate() + Math.round(durationWeeks * 7));
  const finalY = date.getFullYear();
  const finalM = String(date.getMonth() + 1).padStart(2, "0");
  const finalD = String(date.getDate()).padStart(2, "0");
  return `${finalY}-${finalM}-${finalD}`;
}

export function formatReadableDate(dateStr: string): string {
  if (!dateStr) return "TBD";
  const parts = dateStr.split("-");
  if (parts.length !== 3) return dateStr;
  const y = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10) - 1;
  const d = parseInt(parts[2], 10);
  const date = new Date(y, m, d);
  if (isNaN(date.getTime())) return dateStr;
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

const defaultInputs: ProjectEstimatorInputs = {
  industry: "",
  companyName: "",
  overridingContext: "",

  dataPlatform: "",
  cloudPlatform: "",
  deploymentModel: "",
  environments: [],
  deploymentMethod: "",
  jdbcSources: 0,
  apiSources: 0,
  fileSources: 0,
  streamingSources: 0,
  saasSources: 0,
  dataSize: "",
  dailyGrowth: "",
  refreshFrequency: "",
  featuresDataLake: false,
  featuresDataWarehouse: false,
  featuresDataGovernance: false,
  featuresCiCd: false,
  featuresMonitoring: false,
  featuresDisasterRecovery: false,

  projectFramework: "A. WMP D&A MVP Foundational Build",
  deliveryFramework: "Agile Scrum Framework (Rapid sprints and design velocity)",
  deliveryMethodology: "Agile",
  numIterations: 4,
  phaseLength: "2 Weeks",
  testingDuration: 3,
  hypercareDuration: 1,
  goLiveDuration: 2,
  waterfallSubphaseLength: 4,

  primaryUseCase: "",
  numUseCases: 1,
  numDomains: 1,
  numPipelines: 1,
  transformationComplexity: "",
  migrationRequired: false,
  migrationYears: 0,
  numDashboards: 0,
  numReports: 0,
  numSemanticModels: 0,
  executiveReporting: false,
  aiFeaturesIncluded: false,
  numMlModels: 0,
  genAiFeatures: false,
  ragVectorSearch: false,
  qualityComplexity: "",
  mdmRequired: false,

  deliveryModel: "",
  smeAvailability: "",
  teamLocation: "",
  agileDelivery: false,
  sprintLength: "",
  resourceSMEs: 0,
  resourceEngineers: 0,
  resourceBI: 0,
  resourceArchitects: 0,
  resourcePMs: 0,
  resourceQA: 0,
  resourceDevOps: 0,

  ssoRequired: false,
  rbacRequired: false,
  complianceRequirements: [],
  sensitiveData: false,
  numStakeholderGroups: 1,
  numBusinessUnits: 1,
  geographicRegions: 1,
  steeringCommittee: false,
  trainingRequired: false,
  numUserGroups: 0,
  documentationComplexity: "",
  targetGoLiveDate: "",
  projectStartDate: getFirstMondayOfNextMonth(),
  fixedBudget: false,
  fixedTimeline: false,
};

const samplePresetInputs: ProjectEstimatorInputs = {
  industry: "Banking and Finance",
  companyName: "CommerceOne",
  overridingContext: "Ensure high-performance analytics query latency and full enterprise data governance controls.",

  dataPlatform: "Snowflake",
  cloudPlatform: "AWS",
  deploymentModel: "Greenfield",
  environments: ["DEV", "QA", "PROD"],
  deploymentMethod: "IaC",
  jdbcSources: 3,
  apiSources: 4,
  fileSources: 2,
  streamingSources: 1,
  saasSources: 2,
  dataSize: "1TB-10TB",
  dailyGrowth: "Medium",
  refreshFrequency: "Near Real-Time",
  featuresDataLake: true,
  featuresDataWarehouse: true,
  featuresDataGovernance: true,
  featuresCiCd: true,
  featuresMonitoring: true,
  featuresDisasterRecovery: false,

  projectFramework: "A. WMP D&A MVP Foundational Build",
  deliveryFramework: "Agile Scrum Framework (Rapid sprints and design velocity)",
  deliveryMethodology: "Agile",
  numIterations: 4,
  phaseLength: "2 Weeks",
  testingDuration: 3,
  hypercareDuration: 1,
  goLiveDuration: 2,
  waterfallSubphaseLength: 4,

  primaryUseCase: "Analytics",
  numUseCases: 3,
  numDomains: 4,
  numPipelines: 12,
  transformationComplexity: "Moderate",
  migrationRequired: true,
  migrationYears: 3,
  numDashboards: 5,
  numReports: 15,
  numSemanticModels: 3,
  executiveReporting: true,
  aiFeaturesIncluded: true,
  numMlModels: 2,
  genAiFeatures: true,
  ragVectorSearch: true,
  qualityComplexity: "Moderate",
  mdmRequired: false,

  deliveryModel: "Shared",
  smeAvailability: "Medium",
  teamLocation: "Hybrid",
  agileDelivery: true,
  sprintLength: "3 Weeks",
  resourceSMEs: 3,
  resourceEngineers: 4,
  resourceBI: 2,
  resourceArchitects: 1,
  resourcePMs: 1,
  resourceQA: 1,
  resourceDevOps: 1,

  ssoRequired: true,
  rbacRequired: true,
  complianceRequirements: ["GDPR", "SOX"],
  sensitiveData: true,
  numStakeholderGroups: 3,
  numBusinessUnits: 2,
  geographicRegions: 2,
  steeringCommittee: true,
  trainingRequired: true,
  numUserGroups: 4,
  documentationComplexity: "Standard",
  targetGoLiveDate: "2026-12-01",
  projectStartDate: getFirstMondayOfNextMonth(),
  fixedBudget: false,
  fixedTimeline: true,
};

// Result Interface
export interface GanttPhase {
  name: string;
  startWeek: number;
  durationWeeks: number;
  color: string;
  category: string;
  baseStartWeek?: number;
  baseDurationWeeks?: number;
}

export interface EstimatedProjectResult {
  durationWeeks: number;
  totalTeamSize: number;
  minCost: number;
  maxCost: number;
  phases: GanttPhase[];
  scopeSummary: string;
  assumptions: string[];
  deliverables: string[];
  resourcesPlan: { role: string; fte: number; location: string }[];
  risks: string[];
  dependencies: string[];
}

export const INDUSTRIES_LIST = [
  "Aerospace & Defense",
  "Agriculture",
  "Automotive",
  "Banking and Finance",
  "Consumer Electronics",
  "E-commerce",
  "Education",
  "Energy",
  "Entertainment",
  "FinTech",
  "Food Services Manufacturing",
  "Healthcare",
  "Insurance",
  "Logistics",
  "Manufacturing",
  "Media & Communications",
  "Mining & Metals",
  "Pharmaceuticals",
  "Real Estate",
  "Retail",
  "Software & Technology",
  "Telecommunications",
  "Transportation",
  "Travel & Hospitality",
  "Utilities"
].sort();

export const getIterationErrorType = (inputs: ProjectEstimatorInputs): "low" | "excessive" | null => {
  const pipelines = inputs.numPipelines || 1;
  const domains = inputs.numDomains || 1;
  const dashboards = inputs.numDashboards || 0;
  const aiFactor = (inputs.aiFeaturesIncluded || inputs.genAiFeatures) ? 5 : 0;
  const totalScopeScore = pipelines + domains * 3 + dashboards * 2 + aiFactor;

  let minRec = 2;
  let maxRec = 12;

  if (totalScopeScore <= 10) {
    minRec = 1;
    maxRec = 5;
  } else if (totalScopeScore <= 25) {
    minRec = 2;
    maxRec = 9;
  } else {
    minRec = 3;
    maxRec = 15;
  }

  if (inputs.numIterations < minRec) {
    return "low";
  }
  if (inputs.numIterations > maxRec) {
    return "excessive";
  }
  return null;
};

export const getIterationErrorText = (inputs: ProjectEstimatorInputs): string | null => {
  const err = getIterationErrorType(inputs);
  if (err === "low") {
    return "The selected number of iterations is too low for the estimated project scope. Increase iterations or reduce scope.";
  }
  if (err === "excessive") {
    return "The selected number of iterations appears excessive for the estimated project scope. Reduce iterations or adjust scope to improve load balancing and resource efficiency.";
  }
  return null;
};

const getPhaseActivities = (phaseName: string, inputs: ProjectEstimatorInputs): string[] => {
  const nameLower = phaseName.toLowerCase();
  
  if (nameLower.includes("sprint")) {
    return [
      "Participate in Sprint Planning to decompose, estimate, and commit to backlog items.",
      "Implement and develop core analytical pipelines, ingestion tasks, and storage layers (Build activities).",
      "Conduct systematic unit testing activities on freshly compiled data elements.",
      "Present functional sprint deliverables in the Sprint Demo showcase with key business stakeholders.",
      "Engage in backlog refinement sessions to align on specifications for future iterations."
    ];
  }
  
  if (nameLower.includes("subphase")) {
    return [
      "Execute structured build activities to model and program database objects and flows.",
      "Verify code stability through complete unit testing activities against mock and dev layers.",
      "Perform cross-layer data integration activities to stitch sources into conformed zones.",
      "Prepare documentation runbooks and artifacts for technical handoff activities."
    ];
  }

  if (nameLower.includes("discovery") || nameLower.includes("requirements")) {
    return [
      "Stakeholder interviews and current-state environment assessment.",
      `Requirements gathering for the ${inputs.numUseCases} target use cases and data ingestion needs.`,
      "Source catalog audit, schema exploration, and initial use-case prioritization.",
      "Delivery roadmap alignment, sprint goals definitions, and Agile team onboarding."
    ];
  }
  if (nameLower.includes("architecture") || nameLower.includes("design")) {
    return [
      `Target modern data architecture design for ${inputs.dataPlatform || "Lakehouse"} on ${inputs.cloudPlatform || "Cloud"}.`,
      "Enterprise security architecture mapping (identifying SSO registration and compliance layers).",
      "Network planning, firewall setup guidelines, and Dev/Test/Prod VPC isolation strategy.",
      `Conceptual and logical data modeling for the ${inputs.numDomains} business data domains.`
    ];
  }
  if (nameLower.includes("setup") || nameLower.includes("security") || nameLower.includes("infrastructure") || nameLower.includes("workspace")) {
    return [
      `Workspace provisioning and cluster setup in the selected ${inputs.cloudPlatform || "Cloud"} host.`,
      "Active Directory/SSO login synchronization and RBAC access policy configuration.",
      inputs.deploymentMethod === "IaC" 
        ? "Terraform Infrastructure-as-Code execution to build repeatable landing layers." 
        : "Manual environment configurations, resource mapping, and user group directory bindings.",
      "CI/CD release repository configurations and initial logging/monitoring alarms setup."
    ];
  }
  if (nameLower.includes("ingestion")) {
    return [
      `Source systems connection and networking rules authorization for the JDBC, API, and SaaS sources.`,
      `Design and setup of standard landing/bronze zone copy jobs to handle volume of ${inputs.dataSize || "specified size"}.`,
      "High-performance copy logic validation (incremental watermarking, full load, or partition strategies).",
      inputs.refreshFrequency.includes("Real-Time") 
        ? "Real-time stream cluster initialization, topic routing, and sub-minute ingestion handlers." 
        : "Automated daily batch execution scheduling, retries policies, and email failure notification triggers."
    ];
  }
  if (nameLower.includes("transformation") || nameLower.includes("dbt")) {
    return [
      `Execution of robust processing layers built via standard dbt configurations.`,
      `Transformation modeling of raw landing structures into clean Silver/Conformed and Gold/Dim-Fact structures.`,
      `Implementation of core schema rules mapping the complex ${inputs.transformationComplexity || "Moderate"} logic constraints.`,
      "Version controlled code deployment with pull request validations, dbt docs generation, and query performance optimizations."
    ];
  }
  if (nameLower.includes("quality") || nameLower.includes("governance")) {
    return [
      `Configuration of compliance metrics auditing for the requested standards (${inputs.complianceRequirements.length > 0 ? inputs.complianceRequirements.join(", ") : "HIPAA/PCI"}).`,
      `Master Data Management (MDM) records reconciliation and deduplication flow triggers.`,
      "Systematic data quality validation suites executing key null checks, unique constraints, and schema drift reports.",
      "Business catalog dictionary indexing, lineage maps generation, and data custodian role definitions."
    ];
  }
  if (nameLower.includes("ai") || nameLower.includes("ml") || nameLower.includes("generative") || nameLower.includes("vector")) {
    return [
      `MLOps directory setup and baseline predictive feature store calculations.`,
      inputs.genAiFeatures 
        ? "Generative AI API integration, credential storage, and prompt template parameters tuning." 
        : `Development of key pipeline hooks to support the ${inputs.numMlModels} active ML algorithms.`,
      inputs.ragVectorSearch 
        ? "Vector database configuration, text embedding pipelines, and retrieval grounding semantic index creation." 
        : "Model registration, performance logging metrics tracking, and batch scoring execution setup.",
      "Orchestration of containerized model endpoints deployment with endpoint monitoring alerts."
    ];
  }
  if (nameLower.includes("analytics") || nameLower.includes("report") || nameLower.includes("bi") || nameLower.includes("semantics")) {
    return [
      `Publishing and refreshing the requested ${inputs.numSemanticModels} centralized semantic datasets.`,
      `Development and custom visual styling of the ${inputs.numDashboards} high-fidelity interactive executive dashboard interfaces.`,
      "Development of custom row-level security definitions inside the reporting directory, matching the RBAC policy.",
      "Visual cross-filtering performance optimization, responsive layouts testing, and stakeholder view-access provisioning."
    ];
  }
  if (nameLower.includes("uat") || nameLower.includes("testing") || nameLower.includes("qa")) {
    return [
      "Facilitation of User Acceptance Testing (UAT) bug-tracking sessions with business domain SMEs.",
      "End-to-end data reconciliation check comparing reports' aggregated sums against the raw source systems.",
      "Platform penetration screening, failover cluster redundancy check, and network throughput validation.",
      "Defect remediation, logging documentation verification, and official sign-off retrieval."
    ];
  }
  if (nameLower.includes("release") || nameLower.includes("rollout") || nameLower.includes("deployment")) {
    return [
      `Production code release via standard branch merges and automated CI/CD deployment runs.`,
      "Final production environment data catch-up load running downstream gold model processing.",
      "Production-grade scheduling triggers active with real-time operations status monitor.",
      "Disaster Recovery runbooks validation and operational alerts handoff to client system administrators."
    ];
  }
  if (nameLower.includes("training") || nameLower.includes("handover")) {
    return [
      `End-user training enablement workshops held across the ${inputs.numUserGroups || 3} defined business user directories.`,
      "Handoff of final architecture diagrams, database catalogs, data lineages, and operational runbook Wiks.",
      "Consulting delivery transition retrospective review, outcome achievements sign-off, and future roadmap scoping."
    ];
  }

  // Fallback defaults
  return [
    `Implementation activities supporting ${phaseName}.`,
    "Collaborative development sessions, code check-ins, and unit testing validation.",
    "Outcome review, sprint review demonstrations, and feedback capture in project registry."
  ];
};

export function computeEstimateResult(inputs: ProjectEstimatorInputs): EstimatedProjectResult {
  // Map raw data platform options to target system checks
  const rawPlatform = inputs.dataPlatform || "";
  let mappedPlatform = rawPlatform;
  if (rawPlatform.toLowerCase().includes("bigquery") || rawPlatform.toLowerCase().includes("gcp")) {
    mappedPlatform = "BigQuery";
  } else if (rawPlatform.toLowerCase().includes("redshift") || rawPlatform.toLowerCase().includes("aws")) {
    mappedPlatform = "Redshift";
  }

  // Override inputs.dataPlatform inside this function
  inputs = {
    ...inputs,
    dataPlatform: mappedPlatform
  };

  const totalSources = inputs.jdbcSources + inputs.apiSources + inputs.fileSources + inputs.streamingSources + inputs.saasSources;
  
  // Calculate weeks baseline
  let baseWeeks = 8;
  baseWeeks += totalSources * 0.3; // more sources = longer
  baseWeeks += inputs.numPipelines * 0.15; // pipelines
  
  if (inputs.transformationComplexity === "Moderate") baseWeeks += 2;
  else if (inputs.transformationComplexity === "Complex") baseWeeks += 4;
  
  if (inputs.dataSize === "100GB-1TB") baseWeeks += 1;
  else if (inputs.dataSize === "1TB-10TB") baseWeeks += 2.5;
  else if (inputs.dataSize === ">10TB") baseWeeks += 4;
  
  if (inputs.refreshFrequency === "Near Real-Time") baseWeeks += 2;
  else if (inputs.refreshFrequency === "Real-Time") baseWeeks += 4;
  
  if (inputs.aiFeaturesIncluded) baseWeeks += 3.5;
  if (inputs.genAiFeatures) baseWeeks += 2;
  if (inputs.mdmRequired) baseWeeks += 3;
  
  baseWeeks += inputs.numDashboards * 0.4; // dashboards development
  
  // SME availability multiplier
  if (inputs.smeAvailability === "Low") baseWeeks *= 1.25;
  else if (inputs.smeAvailability === "Medium") baseWeeks *= 1.05;
  
  // Resource parameters (explicitly support edited state from the spinner)
  const saFte = inputs.resourceArchitects > 0 ? inputs.resourceArchitects : 1;
  const deFte = inputs.resourceEngineers > 0 ? inputs.resourceEngineers : Math.max(1, Math.ceil(inputs.numPipelines / 6));
  const biFte = inputs.resourceBI > 0 ? inputs.resourceBI : Math.max(1, Math.ceil(inputs.numDashboards / 4));
  const pmFte = inputs.resourcePMs > 0 ? inputs.resourcePMs : 0.5;
  const qaFte = inputs.resourceQA > 0 ? inputs.resourceQA : (totalSources > 5 ? 1 : 0.5);
  const devopsFte = inputs.resourceDevOps > 0 ? inputs.resourceDevOps : (inputs.featuresCiCd ? 0.5 : 0);
  
  // Velocity duration impact calculations (adding parallelization compressions/extensions)
  let durationFactor = 1.0;
  
  const defaultDE = Math.max(1, Math.ceil(inputs.numPipelines / 6));
  if (deFte > defaultDE) {
    durationFactor -= Math.min(0.25, (deFte - defaultDE) * 0.08); // speed up
  } else if (deFte < defaultDE && deFte > 0) {
    durationFactor += (defaultDE - deFte) * 0.15; // slow down
  }
  
  const defaultBI = Math.max(1, Math.ceil(inputs.numDashboards / 4));
  if (biFte > defaultBI) {
    durationFactor -= Math.min(0.15, (biFte - defaultBI) * 0.05);
  } else if (biFte < defaultBI && biFte > 0) {
    durationFactor += (defaultBI - biFte) * 0.10;
  }
  
  if (saFte > 1) {
    durationFactor -= Math.min(0.05, (saFte - 1) * 0.03);
  } else if (saFte === 0) {
    durationFactor += 0.20;
  }
  
  baseWeeks = Math.round(baseWeeks * durationFactor);
  baseWeeks = Math.max(4, Math.min(52, baseWeeks));
  
  // Cost calculation based on labor
  let rateMultiplier = 1.0; // Onshore baseline
  if (inputs.teamLocation === "Offshore") rateMultiplier = 0.35;
  else if (inputs.teamLocation === "Hybrid") rateMultiplier = 0.70;
  
  const saRate = 210 * rateMultiplier;
  const deRate = 165 * rateMultiplier;
  const biRate = 140 * rateMultiplier;
  const pmRate = 175 * rateMultiplier;
  const qaRate = 120 * rateMultiplier;
  const devopsRate = 155 * rateMultiplier;
  
  const weeklySA = saFte * saRate * 40;
  const weeklyDE = deFte * deRate * 40;
  const weeklyBI = biFte * biRate * 40;
  const weeklyPM = pmFte * pmRate * 40;
  const weeklyQA = qaFte * qaRate * 40;
  const weeklyDevOps = devopsFte * devopsRate * 40;
  
  const totalWeeklyCost = weeklySA + weeklyDE + weeklyBI + weeklyPM + weeklyQA + weeklyDevOps;
  const calculatedCost = totalWeeklyCost * baseWeeks;
  
  // Cost range rounded
  const minCost = Math.round((calculatedCost * 0.9) / 5000) * 5000;
  const maxCost = Math.round((calculatedCost * 1.15) / 5000) * 5000;
  
  // Phases definition
  const phases: GanttPhase[] = [];
  const isAgile = 
    (inputs.deliveryFramework || "").toLowerCase().includes("agile") || 
    (inputs.deliveryFramework || "").toLowerCase().includes("safe") ||
    inputs.deliveryMethodology === "Agile" ||
    inputs.agileDelivery;

  const sprintWeeks = 
    inputs.sprintLength === "1 Week" ? 1 : 
    inputs.sprintLength === "2 Weeks" ? 2 : 
    inputs.sprintLength === "3 Weeks" ? 3 : 
    (inputs.phaseLength && inputs.phaseLength.includes("1 Week")) ? 1 :
    (inputs.phaseLength && inputs.phaseLength.includes("2 Weeks")) ? 2 :
    (inputs.phaseLength && inputs.phaseLength.includes("3 Weeks")) ? 3 :
    4;

  let parsedPhaseLength = 4;
  if (inputs.phaseLength) {
    const val = parseInt(inputs.phaseLength);
    if (!isNaN(val)) parsedPhaseLength = val;
  }
  const waterfallSubphaseWeeks = inputs.waterfallSubphaseLength || parsedPhaseLength;

  const testingWeeks = typeof inputs.testingDuration === "number" ? inputs.testingDuration : 3;
  const hypercareWeeks = typeof inputs.hypercareDuration === "number" ? inputs.hypercareDuration : 1;
  const goLiveWeeks = typeof inputs.goLiveDuration === "number" ? inputs.goLiveDuration : 2;
  
  const fixedOverhead = 7 + testingWeeks + hypercareWeeks + goLiveWeeks;
  const calculatedBuildWeeks = Math.max(2, baseWeeks - fixedOverhead);
  const numIterations = isAgile
    ? Math.max(2, Math.ceil(calculatedBuildWeeks / sprintWeeks))
    : Math.max(2, Math.ceil(calculatedBuildWeeks / waterfallSubphaseWeeks));
  
  let finalWeeks = baseWeeks;

  const platformName = inputs.dataPlatform || "Enterprise Data Lakehouse";
  const pcloud = inputs.cloudPlatform || (
    inputs.dataPlatform === "Microsoft Fabric" ? "Azure" :
    inputs.dataPlatform === "BigQuery" ? "GCP" :
    inputs.dataPlatform === "Redshift" ? "AWS" : "Target Cloud"
  );

  // Dynamic names mapping
  const p1_discovery = inputs.dataPlatform === "Databricks" ? `1. Requirements Intake & Databricks Workspace Discovery` :
                       inputs.dataPlatform === "Microsoft Fabric" ? `1. Discovery Workshops & Microsoft Fabric Capacity Audit` :
                       inputs.dataPlatform === "Snowflake" ? `1. Snowflake Warehouse Sizing & Business Discovery` :
                       inputs.dataPlatform === "BigQuery" ? `1. GCP Tenant Discovery & BigQuery Schema Assessment` :
                       inputs.dataPlatform === "Redshift" ? `1. AWS Redshift Cluster Size & Ingestion Discovery` :
                       `1. Discovery, Use Cases & Source Schema Intake`;

  const p2_design = inputs.dataPlatform === "Databricks" ? `2. Medallion Layer Topology Design & Unity Catalog Architecture` :
                    inputs.dataPlatform === "Microsoft Fabric" ? `2. OneLake Domain Design & Fabric DirectLake Architecture` :
                    inputs.dataPlatform === "Snowflake" ? `2. Snowflake Multi-Cluster Warehouse & DB Schema Design` :
                    inputs.dataPlatform === "BigQuery" ? `2. BigQuery Partitioning, Clustering & IAM Architecture Model` :
                    inputs.dataPlatform === "Redshift" ? `2. Amazon Redshift Distribution Keys & Star Schema Blueprint` :
                    `2. Architectural Blueprint & Target Entity-Relationship Formulation`;

  const p3_setup = inputs.dataPlatform === "Databricks" ? `3. Databricks Control/Data Plane Workspace Setup (IaC)` :
                   inputs.dataPlatform === "Microsoft Fabric" ? `3. Microsoft Fabric Domain, Tenant & Capacity Configuration` :
                   inputs.dataPlatform === "Snowflake" ? `3. Snowflake Accounts, Virtual Warehouses & AD Integration Setup` :
                   inputs.dataPlatform === "BigQuery" ? `3. Google Cloud Projects, Datasets & Service Accounts Setup` :
                   inputs.dataPlatform === "Redshift" ? `3. Amazon Redshift Cluster Provisioning & VPC Security Group Configuration` :
                   `3. ${platformName} Workspace Provisioning, AD SSO & Security Policy Isolation`;

  const p4_ingestion = inputs.dataPlatform === "Databricks" ? `4. Spark Structured Streaming & Auto Loader Setup` :
                       inputs.dataPlatform === "Microsoft Fabric" ? `4. Fabric Data Factory Pipelines & Medallion Ingestion Launch` :
                       inputs.dataPlatform === "Snowflake" ? `4. Snowpipe Batch/Stream & CDC Ingestion Implementation` :
                       inputs.dataPlatform === "BigQuery" ? `4. BigQuery Data Transfer Service & REST API Ingestion` :
                       inputs.dataPlatform === "Redshift" ? `4. AWS Glue ETL Ingestion & S3 Redshift Copy Pipelines` :
                       `4. Source-to-Lake Landing Ingestion & Data Capture Streams`;

  const p5_transformation = inputs.dataPlatform === "Databricks" ? `5. Delta Live Tables (DLT) & PySpark Transformation Modeling` :
                            inputs.dataPlatform === "Microsoft Fabric" ? `5. Fabric Synapse Notebooks & SQL Analytics Endpoint Transformations` :
                            inputs.dataPlatform === "Snowflake" ? `5. Snowflake Streams, Tasks & Snowpark Data Modeling` :
                            inputs.dataPlatform === "BigQuery" ? `5. BigQuery SQL Views with dbt-bigquery Data Modeling` :
                            inputs.dataPlatform === "Redshift" ? `5. Amazon Redshift Spectrum & SQL Transformations` :
                            `5. Data Transformation Modeling & Quality Verification Processing`;

  const p6_governance = inputs.dataPlatform === "Databricks" ? `6. Databricks Unity Catalog Data Lineage & Access Auditing Setup` :
                         inputs.dataPlatform === "Microsoft Fabric" ? `6. OneLake Data Governance, Purview Audit & Sensitivity Labeling` :
                         inputs.dataPlatform === "Snowflake" ? `6. Snowflake Horizon Row/Col-Level Security & Data Tags` :
                         inputs.dataPlatform === "BigQuery" ? `6. GCP Dataplex Metadata Catalog & Row-Level Authorization Rules` :
                         inputs.dataPlatform === "Redshift" ? `6. AWS Glue Data Catalog Governance & Row-Level Security Rules` :
                         `6. Enterprise Data Governance Standards, Metadata Catalog & Policy Configuration`;

  const p7_semantic = inputs.dataPlatform === "Databricks" ? `7. Databricks SQL Endpoints & Centralized Power BI Semantic Models` :
                      inputs.dataPlatform === "Microsoft Fabric" ? `7. Fabric Direct Lake Power BI Semantic Model Construction` :
                      inputs.dataPlatform === "Snowflake" ? `7. Snowflake Centralized Semantic View & DB Shares Layer Construction` :
                      inputs.dataPlatform === "BigQuery" ? `7. Looker LookML Centralized Semantic Modeling & Metrics Layer` :
                      inputs.dataPlatform === "Redshift" ? `7. Redshift Centralized BI Views & AAS Semantic Dataset Modeling` :
                      `7. Centralized BI Semantic Modeling & Data Metrics Store Development`;

  const p8_ai = inputs.dataPlatform === "Databricks" ? `8. MLflow Model Register & Databricks Mosaic GenAI RAG Setup` :
                inputs.dataPlatform === "Microsoft Fabric" ? `8. Microsoft Fabric SynapseML Pipelines & Copilot Skill Setup` :
                inputs.dataPlatform === "Snowflake" ? `8. Snowpark Container Services AI Model Training & Cortex RAG Integration` :
                inputs.dataPlatform === "BigQuery" ? `8. BigQuery ML Model Fitting & Vertex AI GenAI LLM Pipeline Creation` :
                inputs.dataPlatform === "Redshift" ? `8. Amazon SageMaker In-DB Predict & Redshift ML Integration` :
                `8. Predictive ML Algorithms & Generative AI Vector RAG Vectorization Trails`;

  const p9_reporting = inputs.dataPlatform === "Databricks" ? `9. DirectLake Power BI & Lakehouse Dashboard Visualizations` :
                       inputs.dataPlatform === "Microsoft Fabric" ? `9. OneLake Direct Lake Interactive Power BI Executive Dashboard Creation` :
                       inputs.dataPlatform === "Snowflake" ? `9. High-Fidelity Interactive Executive BI Dashboards Design` :
                       inputs.dataPlatform === "BigQuery" ? `9. Looker/Tableau Interactive Executive Dashboard Views Generation` :
                       inputs.dataPlatform === "Redshift" ? `9. QuickSight/Tableau Interactive Executive Dashboard Views Creation` :
                       `9. High-Fidelity Centralized Dashboard & Report Workspace Deployment`;

  const p10_qa = inputs.dataPlatform === "Databricks" ? `10. Databricks SQL Query Speed Auditing & Row-Level Security Verification` :
                 inputs.dataPlatform === "Microsoft Fabric" ? `10. Fabric Capacity Optimization Audits & Active AD Security Validations` :
                 inputs.dataPlatform === "Snowflake" ? `10. Snowflake Credit Consumption Optimization & Role-Based Access Validations` :
                 inputs.dataPlatform === "BigQuery" ? `10. BigQuery Query Cost Estimation & Service Accounts Access Audits` :
                 inputs.dataPlatform === "Redshift" ? `10. Redshift Query Compiling Fine-tuning & DB User Row-Level Policy Testing` :
                 `10. Comprehensive Systems Integration Performance & Automated E2E Quality Verification`;

  const p11_release = inputs.dataPlatform === "Databricks" ? `11. Azure DevOps/GitHub Actions Dab CLI & Asset Bundles Release Configuration` :
                      inputs.dataPlatform === "Microsoft Fabric" ? `11. Fabric Git Integration, Azure DevOps Deployment Pipelines Deployment` :
                      inputs.dataPlatform === "Snowflake" ? `11. Snowflake Schemachange Git Integration & DevOps Pipeline Configuration` :
                      inputs.dataPlatform === "BigQuery" ? `11. GCP Cloud Build BigQuery IaC Terraform Deployment Runs Creation` :
                      inputs.dataPlatform === "Redshift" ? `11. AWS CodePipeline Redshift Schema Deployment & IaC Script Runs Setup` :
                      `11. Cloud DevOps Build Automation, Git Release Triggers & CI/CD Setup`;

  const p12_training = inputs.dataPlatform === "Databricks" ? `12. Databricks SQL & Notebook Workspace Handoff, Training & Runbooks Rollout` :
                       inputs.dataPlatform === "Microsoft Fabric" ? `12. Fabric Content Workspace Training, Power BI User Enablement & Handoff Runbooks` :
                       inputs.dataPlatform === "Snowflake" ? `12. Snowflake DB Custodian Admin Training & Operations Handoff Runbooks` :
                       inputs.dataPlatform === "BigQuery" ? `12. GCP BigQuery Optimization Workshops & Architecture Handoff Runbooks` :
                       inputs.dataPlatform === "Redshift" ? `12. AWS Admin Redshift Cluster Maintenance Training & Handoff Runbooks` :
                       `12. User Group Training Enablement Workshops & Final Architecture Handoff Runbooks`;

  if (inputs.projectFramework) {
    const fw = inputs.projectFramework;
    if (
      fw.startsWith("A.") || fw.includes("WMP D&A MVP Foundational Build") ||
      fw.startsWith("B.") || fw.includes("WMP D&A Data Platform Build-Out") ||
      fw.startsWith("C.") || fw.includes("Specific MVP Foundational Build") ||
      fw.startsWith("D.") || fw.includes("Specific Build-Out")
    ) {

      let accumulatedWeeks = 0;
      const isBuildOut = fw.startsWith("B.") || fw.startsWith("D.") || fw.includes("Build-Out");
      const isSpecific = fw.startsWith("C.") || fw.startsWith("D.") || fw.includes("Specific");
      
      let platPrefix = platformName;
      if (isSpecific) {
        if (platformName.toLowerCase().includes("databricks")) platPrefix = "Databricks Workspace";
        else if (platformName.toLowerCase().includes("fabric")) platPrefix = "Fabric OneLake";
        else if (platformName.toLowerCase().includes("snowflake")) platPrefix = "Snowflake Account";
      }

      // 1. Discovery and Design (3 weeks)
      let parentDiscoveryName = `${platformName} Discovery and Design`;
      if (isSpecific) {
        if (platformName.toLowerCase().includes("databricks")) {
          parentDiscoveryName = isBuildOut
            ? "Databricks Workspace Performance Optimization & Architectural Audit Discovery"
            : "Databricks Lakehouse Requirements Discovery & Unity Catalog Governance Design";
        } else if (platformName.toLowerCase().includes("fabric")) {
          parentDiscoveryName = isBuildOut
            ? "Microsoft Fabric Tenant Capacities Audit & Workspace Artifact Discovery"
            : "Microsoft Fabric OneLake Architecture, Domains & Capacity Design Workshops";
        } else if (platformName.toLowerCase().includes("snowflake")) {
          parentDiscoveryName = isBuildOut
            ? "Snowflake Virtual Warehouse Profiling, Schema Auditing & Ingestion Discovery"
            : "Snowflake Architecture Design, Role-Based Access Mapping & Discovery Workshops";
        } else {
          parentDiscoveryName = isBuildOut
            ? `${platPrefix} Scaling Discovery, Performance Auditing & Architecture Design`
            : `${platPrefix} Discovery, Enterprise Security Strategy & Core Lakehouse Design`;
        }
      } else {
        parentDiscoveryName = isBuildOut
          ? "Enterprise Data Platform Scale-Out Requirements Discovery & Architecture Validation"
          : "Discovery and Design Phase";
      }

      phases.push({
        name: parentDiscoveryName,
        startWeek: accumulatedWeeks,
        durationWeeks: 3,
        color: "bg-teal-500",
        category: "Discovery & advisory"
      });
      accumulatedWeeks += 3;

      // 2. Infrastructure Configuration (2 weeks)
      // Omit configuration for B unless specific tools are selected:
      let showInfra = true;
      if (fw.startsWith("B.") || fw.includes("WMP D&A Data Platform Build-Out")) {
        const hasGovernanceOrAI = 
          inputs.featuresDataGovernance || 
          inputs.featuresDataLake ||
          inputs.mdmRequired || 
          inputs.aiFeaturesIncluded || 
          inputs.genAiFeatures || 
          inputs.ragVectorSearch ||
          inputs.ssoRequired ||
          inputs.rbacRequired ||
          (inputs.overridingContext || "").toLowerCase().includes("purview") ||
          (inputs.overridingContext || "").toLowerCase().includes("mdm") ||
          (inputs.overridingContext || "").toLowerCase().includes("data hub") ||
          (inputs.overridingContext || "").toLowerCase().includes("ai enablement") ||
          (inputs.overridingContext || "").toLowerCase().includes("governance") ||
          (inputs.overridingContext || "").toLowerCase().includes("catalog") ||
          (inputs.overridingContext || "").toLowerCase().includes("management") ||
          (inputs.overridingContext || "").toLowerCase().includes("ai platform");

        showInfra = hasGovernanceOrAI;
      }

      if (showInfra) {
        let infraName = `${platformName} Infrastructure Configuration`;
        if (isSpecific) {
          if (platformName.toLowerCase().includes("databricks")) {
            infraName = isBuildOut
              ? "Databricks SQL Cluster Fine-tuning, Unity Catalog Scaling & Virtual Networks Config"
              : "Databricks Multi-Workspace Control Plane Configuration, VNets Peering & IaC Setup";
          } else if (platformName.toLowerCase().includes("fabric")) {
            infraName = isBuildOut
              ? "Microsoft Fabric Premium Capacities Resizing, Domain Workspace Isolation & Tenant Setup"
              : "Microsoft Fabric Domain Configuration, Dedicated Workspace Provisioning & Tenant Setup";
          } else if (platformName.toLowerCase().includes("snowflake")) {
            infraName = isBuildOut
              ? "Snowflake Virtual Compute Sizing, Network Private Link & Active SSO Integration Sync"
              : "Snowflake Enterprise Account Setup, Virtual Warehouses Configuration & Security Mapping";
          } else {
            infraName = isBuildOut
              ? `${platPrefix} Scaling Configurations, Network Routes Tunings & DevOps Pipelines Config`
              : `${platPrefix} Cloud Tenant Setup, Enterprise Security Controls Config & IAM Policy Mapping`;
          }
        } else {
          infraName = isBuildOut
            ? "Enterprise Data Platform Scaled Networking & Core Infrastructure Upgrades"
            : "Infrastructure Configuration";
        }

        phases.push({
          name: infraName,
          startWeek: accumulatedWeeks,
          durationWeeks: 2,
          color: "bg-amber-500",
          category: "Cloud SRE / DevOps"
        });
        accumulatedWeeks += 2;
      }

      // 3. Platform Build Weeks
      const finalBuildIterations = inputs.numIterations || 4;
      if (isAgile) {
        for (let i = 1; i <= finalBuildIterations; i++) {
          let runName = `Data Platform Build - Agile Sprint ${i} (${sprintWeeks}W)`;
          if (isSpecific) {
            if (platformName.toLowerCase().includes("databricks")) {
              runName = isBuildOut
                ? `Databricks PySpark Pipeline Refactoring & Gold Table Optimization - Agile Sprint ${i} (${sprintWeeks}W)`
                : `Databricks Delta Ingest & PySpark Conformed Medallion Layer pipelines - Agile Sprint ${i} (${sprintWeeks}W)`;
            } else if (platformName.toLowerCase().includes("fabric")) {
              runName = isBuildOut
                ? `Microsoft Fabric DirectLake Power BI Metrics Scaling - Agile Sprint ${i} (${sprintWeeks}W)`
                : `Microsoft Fabric Lakehouse Ingest, Synapse Pipelines Build & Power BI - Agile Sprint ${i} (${sprintWeeks}W)`;
            } else if (platformName.toLowerCase().includes("snowflake")) {
              runName = isBuildOut
                ? `Snowflake Dynamic Tables Tune-up & Snowpark Data Engineering - Agile Sprint ${i} (${sprintWeeks}W)`
                : `Snowflake Streams, Snowpipe Batches & Access Controlled Schema pipelines - Agile Sprint ${i} (${sprintWeeks}W)`;
            } else {
              runName = `${platPrefix} Build - Agile Sprint ${i} (${sprintWeeks}W)`;
            }
          } else {
            runName = isBuildOut
              ? `Enterprise Data Platform Scale-Out Pipeline Expansion - Agile Sprint ${i} (${sprintWeeks}W)`
              : `Data Platform Build - Agile Sprint ${i} (${sprintWeeks}W)`;
          }

          phases.push({
            name: runName,
            startWeek: accumulatedWeeks,
            durationWeeks: sprintWeeks,
            color: "bg-indigo-600",
            category: "Platform Build"
          });
          accumulatedWeeks += sprintWeeks;
        }
      } else {
        for (let i = 1; i <= finalBuildIterations; i++) {
          let runName = `Data Platform Build - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`;
          if (isSpecific) {
            if (platformName.toLowerCase().includes("databricks")) {
              runName = isBuildOut
                ? `Delta Lakes Dictionaries Optimization & Python ETL Transformation - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`
                : `Databricks Intake Requirements Sign-off & Delta Ingestion Pipelines - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`;
            } else if (platformName.toLowerCase().includes("fabric")) {
              runName = isBuildOut
                ? `Microsoft Fabric Workspace Shortcuts Sync & DirectLake Tuning - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`
                : `Microsoft Fabric Tenant Controls Configuration, Warehouse Models & Power BI Build - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`;
            } else if (platformName.toLowerCase().includes("snowflake")) {
              runName = isBuildOut
                ? `Snowflake Databases Optimizations & Stream Tuning - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`
                : `Snowflake Schemas Blueprinting, Snowpipe CDC Ingest & Access Mapping - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`;
            } else {
              runName = `${platPrefix} Build - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`;
            }
          } else {
            runName = isBuildOut
              ? `Enterprise Data Platform Optimizations - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`
              : `Data Platform Build - Waterfall Subphase ${i} (${waterfallSubphaseWeeks}W)`;
          }

          phases.push({
            name: runName,
            startWeek: accumulatedWeeks,
            durationWeeks: waterfallSubphaseWeeks,
            color: "bg-blue-600",
            category: "Platform Build"
          });
          accumulatedWeeks += waterfallSubphaseWeeks;
        }
      }

      // 4. Testing Phase (testingWeeks duration)
      let testingName = `${platformName} Testing`;
      if (isSpecific) {
        if (platformName.toLowerCase().includes("databricks")) {
          testingName = "Databricks Delta Live Table Quality Assertions & Query Latency Testing";
        } else if (platformName.toLowerCase().includes("fabric")) {
          testingName = "Fabric Capacity Cost Optimization Audits & Workspace Security Testing";
        } else if (platformName.toLowerCase().includes("snowflake")) {
          testingName = "Snowflake Dynamic Tables Partition Auditing & RBAC Data Masking Testing";
        } else {
          testingName = `${platPrefix} Quality Assurance Validation, Defect Logging & Query Optimization Testing`;
        }
      } else {
        testingName = isBuildOut
          ? "Enterprise Data Platform QA, Performance Tuning & Scalability Validation"
          : "Testing";
      }

      phases.push({
        name: testingName,
        startWeek: accumulatedWeeks,
        durationWeeks: testingWeeks,
        color: "bg-emerald-600",
        category: "Testing & QA"
      });
      accumulatedWeeks += testingWeeks;

      // 5. Readiness, Deployment, Operational Testing and Go-Live Phase (goLiveWeeks duration)
      let readinessName = `${platformName} Readiness, Deployment & Go-Live`;
      if (isSpecific) {
        if (platformName.toLowerCase().includes("databricks")) {
          readinessName = "Databricks Asset Bundles (DABs) Build, DevOps Release & Production Go-Live Execution";
        } else if (platformName.toLowerCase().includes("fabric")) {
          readinessName = "Fabric Deployment Pipelines Sync, Git Integration & Enterprise Production Go-Live Setup";
        } else if (platformName.toLowerCase().includes("snowflake")) {
          readinessName = "Snowflake schemachange Migration Script DevOps Release & Database Production Go-Live";
        } else {
          readinessName = `${platPrefix} Deployment Release, Cloud Runbooks Validation & Production Go-Live`;
        }
      } else {
        readinessName = isBuildOut
          ? "Data Platform Extended Release Deployment & Production Cutover Go-Live Execution"
          : "Readiness, Deployment, Operational Testing and Go-Live";
      }

      phases.push({
        name: readinessName,
        startWeek: accumulatedWeeks,
        durationWeeks: goLiveWeeks,
        color: "bg-cyan-500",
        category: "Operations & Handoff"
      });
      accumulatedWeeks += goLiveWeeks;

      // 6. Hypercare Support (hypercareWeeks)
      if (hypercareWeeks > 0) {
        let hypercareName = `${platformName} Operations Stabilisation & Hypercare Support`;
        if (isSpecific) {
          if (platformName.toLowerCase().includes("databricks")) {
            hypercareName = "Databricks Spark Cluster Performance Stabilization & Hypercare SLA Support";
          } else if (platformName.toLowerCase().includes("fabric")) {
            hypercareName = "Fabric Premium Direct Lake Capacity Monitoring & Hypercare Operations Stabilization";
          } else if (platformName.toLowerCase().includes("snowflake")) {
            hypercareName = "Snowflake Virtual Compute Consumption Governance & Hypercare Support Handoff";
          } else {
            hypercareName = `${platPrefix} Operations Stabilization, Performance Tuning & Hypercare Support`;
          }
        } else {
          hypercareName = isBuildOut
            ? "Enterprise Scaled Support Handoff & Platform Hypercare Support"
            : "Hypercare";
        }

        phases.push({
          name: hypercareName,
          startWeek: accumulatedWeeks,
          durationWeeks: hypercareWeeks,
          color: "bg-pink-600",
          category: "Operations & Handoff"
        });
        accumulatedWeeks += hypercareWeeks;
      }

      finalWeeks = accumulatedWeeks;

    } else {
      // Direct fallback inside projectFramework for any legacy Framework values
      let frameworkBaseWeeks = 14; 
      // Apply adjustments for pipelines, sources, dashboards
      if (inputs.numPipelines > 15) {
        frameworkBaseWeeks += Math.ceil((inputs.numPipelines - 15) * 0.15);
      } else if (inputs.numPipelines < 6) {
        frameworkBaseWeeks = Math.max(6, frameworkBaseWeeks - 2);
      }
      
      if (totalSources > 8) {
        frameworkBaseWeeks += Math.ceil((totalSources - 8) * 0.2);
      }

      if (inputs.numDashboards > 10) {
        frameworkBaseWeeks += Math.ceil((inputs.numDashboards - 10) * 0.15);
      }

      // Apply speed up / slow down based on total resource FTE
      const totalStaffFTE = saFte + deFte + biFte + pmFte + qaFte + devopsFte;
      const standardFTE = 5.5;
      const staffImpact = standardFTE / Math.max(2, totalStaffFTE);
      frameworkBaseWeeks = Math.round(frameworkBaseWeeks * Math.max(0.65, Math.min(1.85, staffImpact)));
      frameworkBaseWeeks = Math.max(4, Math.min(52, frameworkBaseWeeks));

      finalWeeks = frameworkBaseWeeks;
    }
  }
  else if (inputs.agileDelivery) {
    // Agile Delivery schedule - highly parallelized & streamlined overlap
    const wDiscovery = Math.max(2, Math.round(baseWeeks * 0.12));
    const wDesign = Math.max(2, Math.round(baseWeeks * 0.12));
    const wPlatform = Math.max(2, Math.round(baseWeeks * 0.15));
    const wIngestion = Math.max(2, Math.round(baseWeeks * 0.35));
    const wTransformation = Math.max(2, Math.round(baseWeeks * 0.35));
    const wGovernance = Math.max(2, Math.round(baseWeeks * 0.15));
    const wSemantics = Math.max(2, Math.round(baseWeeks * 0.20));
    const wAI = Math.max(2, Math.round(baseWeeks * 0.25));
    const wReporting = Math.max(2, Math.round(baseWeeks * 0.25));
    const wDeployment = Math.max(1, Math.round(baseWeeks * 0.12));
    const wHandoff = Math.max(1, Math.round(baseWeeks * 0.12));

    const saStart = 0;
    const saDur = wDiscovery;
    phases.push({ name: p1_discovery, startWeek: saStart, durationWeeks: saDur, color: "bg-teal-500", category: "Platform Foundation" });

    const dsStart = Math.max(1, Math.round(saDur * 0.5));
    const dsDur = wDesign;
    phases.push({ name: p2_design, startWeek: dsStart, durationWeeks: dsDur, color: "bg-sky-500", category: "Platform Foundation" });

    const stStart = Math.max(2, Math.round(saDur * 0.9));
    const stDur = wPlatform;
    phases.push({ name: p3_setup, startWeek: stStart, durationWeeks: stDur, color: "bg-indigo-505", category: "Platform Foundation" });

    const ingStart = Math.max(stStart + 1, Math.round(saDur + dsDur * 0.4));
    const ingDur = wIngestion;
    phases.push({ name: p4_ingestion, startWeek: ingStart, durationWeeks: ingDur, color: "bg-orange-500", category: "Data Engineering" });

    // Ingestion & Transformation speed/overlap is affected by deFte
    const isParallel = deFte >= 2.5;
    const transStart = isParallel ? (ingStart + 1) : (ingStart + Math.max(1, Math.round(ingDur * 0.5)));
    const transDur = wTransformation;
    phases.push({ name: p5_transformation, startWeek: transStart, durationWeeks: transDur, color: "bg-blue-600", category: "Data Engineering" });

    if (inputs.featuresDataGovernance || inputs.mdmRequired) {
      const govStart = transStart + 1;
      const govDur = wGovernance;
      phases.push({ name: p6_governance, startWeek: govStart, durationWeeks: govDur, color: "bg-violet-600", category: "Quality & Governance" });
    }

    let semStart = transStart + Math.max(1, Math.round(transDur * 0.4));
    if (inputs.numSemanticModels > 0 || inputs.numDashboards > 0) {
      const semDur = wSemantics;
      phases.push({ name: p7_semantic, startWeek: semStart, durationWeeks: semDur, color: "bg-indigo-400", category: "Analytics Development" });
    }

    if (inputs.aiFeaturesIncluded || inputs.genAiFeatures) {
      const aiStart = transStart + Math.max(1, Math.round(transDur * 0.3));
      const aiDur = wAI;
      phases.push({ name: p8_ai, startWeek: aiStart, durationWeeks: aiDur, color: "bg-pink-600", category: "Analytics Development" });
    }

    if (inputs.numDashboards > 0) {
      const repStart = (inputs.numSemanticModels > 0 || inputs.numDashboards > 0) ? (semStart + 1) : (transStart + 2);
      const repDur = wReporting;
      phases.push({ name: p9_reporting, startWeek: repStart, durationWeeks: repDur, color: "bg-amber-500", category: "Analytics Development" });
    }

    const testStart = ingStart;
    const testDur = Math.max(3, baseWeeks - testStart - 1);
    phases.push({ name: p10_qa, startWeek: testStart, durationWeeks: testDur, color: "bg-emerald-600", category: "Testing & QA" });

    const relStart = Math.max(testStart + 2, baseWeeks - wDeployment);
    const relDur = wDeployment;
    phases.push({ name: p11_release, startWeek: relStart, durationWeeks: relDur, color: "bg-cyan-500", category: "Release Management" });

    if (inputs.trainingRequired || inputs.documentationComplexity !== "Basic") {
      const trStart = Math.max(relStart, baseWeeks - wHandoff);
      const trDur = wHandoff;
      phases.push({ name: p12_training, startWeek: trStart, durationWeeks: trDur, color: "bg-gray-500", category: "Release Management" });
    }

    // Sanitize in-bound limits
    phases.forEach(phs => {
      if (phs.startWeek + phs.durationWeeks > baseWeeks) {
        phs.durationWeeks = Math.max(1, baseWeeks - phs.startWeek);
      }
      if (phs.startWeek >= baseWeeks) {
        phs.startWeek = Math.max(0, baseWeeks - 1);
        phs.durationWeeks = 1;
      }
    });

    finalWeeks = baseWeeks;
  } else {
    // Traditional Waterfall schedule - fully sequential, staggered step-by-step
    let accumulated = 0;
    const addWaterfallPhase = (name: string, percentage: number, color: string, category: string, req = true) => {
      if (!req) return;
      const d = Math.max(1, Math.round(baseWeeks * percentage));
      phases.push({
        name,
        startWeek: accumulated,
        durationWeeks: d,
        color,
        category
      });
      accumulated += d;
    };

    addWaterfallPhase(p1_discovery, 0.12, "bg-teal-500", "Discovery");
    addWaterfallPhase(p2_design, 0.10, "bg-sky-500", "Design");
    addWaterfallPhase(p3_setup, 0.08, "bg-[#E7F0F7]", "Infrastructure");
    addWaterfallPhase(p4_ingestion, 0.14, "bg-orange-500", "Data Engineering");
    addWaterfallPhase(p5_transformation, 0.16, "bg-blue-600", "Data Engineering");
    
    // Data Governance as separate phase
    addWaterfallPhase(p6_governance, 0.08, "bg-violet-600", "Quality", inputs.featuresDataGovernance || inputs.mdmRequired);
    
    // Semantic Dataset as separate phase
    addWaterfallPhase(p7_semantic, 0.10, "bg-indigo-400", "BI Work", inputs.numSemanticModels > 0 || inputs.numDashboards > 0);
    
    // AI/ML Track as separate phase
    addWaterfallPhase(p8_ai, 0.12, "bg-pink-600", "AI/ML", inputs.aiFeaturesIncluded || inputs.genAiFeatures);
    
    // Dashboard Reporting
    addWaterfallPhase(p9_reporting, 0.10, "bg-amber-500", "BI Work", inputs.numDashboards > 0);
    
    // Testing & QA
    addWaterfallPhase(p10_qa, 0.08, "bg-emerald-600", "Testing");
    
    // Release
    addWaterfallPhase(p11_release, 0.04, "bg-cyan-500", "Release");
    
    // Handover & Training
    addWaterfallPhase(p12_training, 0.05, "bg-gray-500", "Handover", inputs.trainingRequired || inputs.documentationComplexity !== "Basic");

    finalWeeks = accumulated;
  }

  const assumptions = [
    `Architecture will deploy to ${inputs.cloudPlatform || "target Cloud"} utilizing modern ${inputs.dataPlatform || "identified platform"} structures.`,
    `Client SMEs (${inputs.resourceSMEs} identified) will be available at a ${inputs.smeAvailability || "Medium"} level for design workshops.`,
    `All data sources (${totalSources} total) have active connectivity and approved network firewalls in place.`,
    `Delivery follows active Agile iterations with sprint lengths of ${inputs.sprintLength || "2 Weeks"}.`
  ];

  const deliverables = [
    "Data Platform Landing-Zone Infrastructure (IaC scripts)",
    `${totalSources} Operational Pipeline Pipelines completed`,
    "Enterprise-wide Data Catalog and Governance standards configuration",
    `${inputs.numSemanticModels} Centralized Semantic Models & ${inputs.numDashboards} interactive dashboards`,
    "SSO & RBAC security setup, documented compliance audits",
    "Disaster Recovery runbooks and Training artifacts for handoff"
  ];

  if (inputs.aiFeaturesIncluded) {
    deliverables.push(`${inputs.numMlModels} active ML models packaged and registered in Model registry`);
  }
  if (inputs.rbacRequired) {
    assumptions.push("SSO & Active Directory integrations are authenticated under client IT directories.");
  }

  const resourcesPlan = [
    { role: "Solution Architect", fte: saFte, location: inputs.teamLocation || "Onshore" },
    { role: "Data Engineer(s)", fte: deFte, location: inputs.teamLocation || "Onshore" },
    { role: "BI Developer(s)", fte: biFte, location: inputs.teamLocation || "Onshore" },
    { role: "Analytics Quality Engineer", fte: qaFte, location: inputs.teamLocation || "Onshore" },
    { role: "Project Manager/Agile Lead", fte: pmFte, location: inputs.teamLocation || "Onshore" }
  ];

  if (devopsFte > 0) {
    resourcesPlan.push({ role: "DevOps Engineer", fte: devopsFte, location: inputs.teamLocation || "Onshore" });
  }

  const risks = [
    inputs.fixedBudget ? "High Risk: Fixed Budget constraint could curtail MVP features if pipelines hit complex security gates." : "Budget: Flexible budget allows pipeline scaling.",
    inputs.fixedTimeline ? `High Risk: Fixed Go-Live schedule places severe pressure on ${inputs.numPipelines} pipelines development.` : "Timeline: Adaptive delivery with iterative rollouts.",
    inputs.smeAvailability === "Low" ? "High Risk: Extremely low SME availability can significantly delay sign-offs and discovery inputs." : "SMEs: Adequate business stakeholder commitment is budgeted."
  ];

  const dependencies = [
    "Infrastructure and Cloud Access provisioned within Week 2",
    "Source data definitions and schema credentials made available by customer IT team in Week 1",
    "Prompt feedback loops from business domain stakeholders during analytics review cycles"
  ];

  phases.forEach(phs => {
    if (phs.baseStartWeek === undefined) {
      phs.baseStartWeek = phs.startWeek;
    }
    if (phs.baseDurationWeeks === undefined) {
      phs.baseDurationWeeks = phs.durationWeeks;
    }
  });

  return {
    durationWeeks: finalWeeks,
    totalTeamSize: parseFloat((saFte + deFte + biFte + pmFte + qaFte + devopsFte).toFixed(1)),
    minCost,
    maxCost,
    phases,
    scopeSummary: `${inputs.dataPlatform} complete implementation of ${inputs.numPipelines} pipelines across ${inputs.numDomains} domains, providing ${inputs.numDashboards} unified dashboards and AI capabilities.`,
    assumptions,
    deliverables,
    resourcesPlan,
    risks,
    dependencies
  };
}

interface ProjectEstimatorViewProps {
  setActiveTab?: (tab: string) => void;
  currentProjectId?: string | null;
  currentProject?: any;
  projectEstimateAssets?: ProjectEstimateAsset[];
  setProjectEstimateAssets?: React.Dispatch<React.SetStateAction<ProjectEstimateAsset[]>>;
  loadedProjectEstimateInputs?: any | null;
  setLoadedProjectEstimateInputs?: (inputs: any | null) => void;
  globalCompanyName?: string;
  globalIndustry?: string;
}

export function ProjectEstimatorView({
  setActiveTab,
  currentProjectId,
  currentProject,
  projectEstimateAssets = [],
  setProjectEstimateAssets,
  loadedProjectEstimateInputs,
  setLoadedProjectEstimateInputs,
  globalCompanyName,
  globalIndustry
}: ProjectEstimatorViewProps = {}) {
  const [colWidths, setColWidths] = useState({
    phaseName: 280,
    category: 180,
    weeks: 140
  });

  const handleMouseDown = (colKey: keyof typeof colWidths, e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startWidth = colWidths[colKey];
    
    const handleMouseMove = (mouseEvent: MouseEvent) => {
      const deltaX = mouseEvent.clientX - startX;
      setColWidths(prev => ({
        ...prev,
        [colKey]: Math.max(100, startWidth + deltaX)
      }));
    };
    
    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
    
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  const [ganttColWidth, setGanttColWidth] = useState(200);

  const handleGanttMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startWidth = ganttColWidth;
    
    const handleMouseMove = (mouseEvent: MouseEvent) => {
      const deltaX = mouseEvent.clientX - startX;
      setGanttColWidth(Math.max(120, Math.min(450, startWidth + deltaX)));
    };
    
    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
    
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  const [inputs, setInputs] = useState<ProjectEstimatorInputs>(defaultInputs);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);
  const [activeAssetId, setActiveAssetId] = useState<string | null>(null);
  const iterationErrorText = getIterationErrorText(inputs);
  const [activeGroup, setActiveGroup] = useState<"platform" | "scope" | "framework" | "resources" | "other" | null>(null);
  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [currentProgressMsg, setCurrentProgressMsg] = useState("");
  const [result, setResult] = useState<EstimatedProjectResult | null>(null);

  // Active drag state for Gantt bars
  const [activeDrag, setActiveDrag] = useState<{
    phaseIndex: number;
    type: "move" | "resize";
    initialMouseX: number;
    initialStartWeek: number;
    initialDurationWeeks: number;
  } | null>(null);

  const timelineTrackRef = useRef<HTMLDivElement | null>(null);

  const startDrag = (phaseIndex: number, type: "move" | "resize", e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!result) return;
    setActiveDrag({
      phaseIndex,
      type,
      initialMouseX: e.clientX,
      initialStartWeek: result.phases[phaseIndex].startWeek,
      initialDurationWeeks: result.phases[phaseIndex].durationWeeks
    });
  };

  const mapRoleToPhaseIndices = (role: string, totalPhases: number): number[] => {
    const indices: number[] = [];
    if (role.toLowerCase().includes("architect")) {
      // SA is active during Discovery, Design, Infrastructure Setup
      indices.push(0, 1);
      if (totalPhases > 2) indices.push(2);
    } else if (role.toLowerCase().includes("engineer")) {
      // DEs work on data ingestion & transform phases (indices 2, 3, 4, 5 etc. - middle of project)
      for (let i = 2; i < totalPhases - 3; i++) {
        indices.push(i);
      }
    } else if (role.toLowerCase().includes("bi")) {
      // BI Developers are in Semantic & Report writing phases at end (e.g. index total-5, total-4, total-3)
      if (totalPhases > 4) {
        indices.push(totalPhases - 5, totalPhases - 4);
      }
    } else if (role.toLowerCase().includes("quality") || role.toLowerCase().includes("qa")) {
      // QA Engineer is in Testing (total-3 or total-2)
      if (totalPhases > 3) indices.push(totalPhases - 3);
    } else if (role.toLowerCase().includes("manager") || role.toLowerCase().includes("pm")) {
      // Project Manager is across all phases
      for (let i = 0; i < totalPhases; i++) {
        indices.push(i);
      }
    } else if (role.toLowerCase().includes("devops")) {
      // DevOps is in Setup (2) and Release (total-2)
      if (totalPhases > 2) indices.push(2);
      if (totalPhases > 2) indices.push(totalPhases - 2);
    }
    return indices;
  };

  const keyToInitialFte = (role: string, currentInputs: ProjectEstimatorInputs): number => {
    const key = roleToInputKeyMap[role];
    if (key) {
      const val = currentInputs[key];
      if (typeof val === "number" && val > 0) return val;
    }
    // Fallback if not specified or 0
    if (role === "Solution Architect") return 1;
    if (role === "Data Engineer(s)") return Math.max(1, Math.ceil(currentInputs.numPipelines / 6));
    if (role === "BI Developer(s)") return Math.max(1, Math.ceil(currentInputs.numDashboards / 4));
    if (role === "Analytics Quality Engineer") {
      const totalSources = currentInputs.jdbcSources + currentInputs.apiSources + currentInputs.fileSources + currentInputs.streamingSources + currentInputs.saasSources;
      return totalSources > 5 ? 1 : 0.5;
    }
    if (role === "Project Manager/Agile Lead") return 0.5;
    if (role === "DevOps Engineer") return currentInputs.featuresCiCd ? 0.5 : 0;
    return 0.5;
  };

  useEffect(() => {
    if (!activeDrag || !result) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!timelineTrackRef.current) return;
      
      const rect = timelineTrackRef.current.getBoundingClientRect();
      const trackWidth = rect.width;
      if (trackWidth <= 0) return;

      const weekPixels = trackWidth / result.durationWeeks;
      const deltaX = e.clientX - activeDrag.initialMouseX;
      const deltaWeeks = Math.round(deltaX / weekPixels);

      if (deltaWeeks === 0) return;

      const updatedPhases = result.phases.map((p, i) => {
        if (i !== activeDrag.phaseIndex) return { ...p };

        if (activeDrag.type === "move") {
          const newStart = Math.max(0, activeDrag.initialStartWeek + deltaWeeks);
          return { ...p, startWeek: newStart };
        } else {
          const newDur = Math.max(1, activeDrag.initialDurationWeeks + deltaWeeks);
          return { ...p, durationWeeks: newDur };
        }
      });

      // Recalculate duration & resources
      const newDurationWeeks = Math.max(4, Math.max(...updatedPhases.map(p => p.startWeek + p.durationWeeks)));

      const updatedResourcesPlan = result.resourcesPlan.map(res => {
        const matchingIndices = mapRoleToPhaseIndices(res.role, updatedPhases.length);
        let sumOriginal = 0;
        let sumCurrent = 0;

        matchingIndices.forEach(idx => {
          const p = updatedPhases[idx];
          if (p) {
            sumOriginal += p.baseDurationWeeks ?? p.durationWeeks;
            sumCurrent += p.durationWeeks;
          }
        });

        let ratio = 1.0;
        if (sumCurrent > 0 && sumOriginal > 0) {
          ratio = sumOriginal / sumCurrent;
        }

        const baseFte = keyToInitialFte(res.role, inputs);
        const scaledFte = Math.max(0.1, Math.min(10, Math.round(baseFte * ratio * 10) / 10));

        return {
          ...res,
          fte: scaledFte
        };
      });

      // Recalculate billing cost based on locations
      let rateMultiplier = 1.0;
      if (inputs.teamLocation === "Offshore") rateMultiplier = 0.35;

      const saRate = 210 * rateMultiplier;
      const deRate = 165 * rateMultiplier;
      const biRate = 140 * rateMultiplier;
      const pmRate = 150 * rateMultiplier;
      const qaRate = 120 * rateMultiplier;
      const devopsRate = 155 * rateMultiplier;

      let totalWeeklyCost = 0;
      updatedResourcesPlan.forEach(res => {
        let rate = deRate;
        if (res.role === "Solution Architect") rate = saRate;
        else if (res.role === "Data Engineer(s)") rate = deRate;
        else if (res.role === "BI Developer(s)") rate = biRate;
        else if (res.role === "Analytics Quality Engineer") rate = qaRate;
        else if (res.role === "Project Manager/Agile Lead") rate = pmRate;
        else if (res.role === "DevOps Engineer") rate = devopsRate;

        totalWeeklyCost += res.fte * rate * 40;
      });

      const calculatedCost = totalWeeklyCost * newDurationWeeks;
      const minCost = Math.round((calculatedCost * 0.9) / 5000) * 5000;
      const maxCost = Math.round((calculatedCost * 1.15) / 5000) * 5000;

      setResult({
        ...result,
        durationWeeks: newDurationWeeks,
        phases: updatedPhases,
        resourcesPlan: updatedResourcesPlan,
        minCost,
        maxCost,
        totalTeamSize: parseFloat(updatedResourcesPlan.reduce((acc, r) => acc + r.fte, 0).toFixed(1))
      });
      setHasUnsavedChanges(true);
    };

    const handleMouseUp = () => {
      setActiveDrag(null);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [activeDrag, result, inputs]);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Link modification updates directly to the computed outputs live!
  useEffect(() => {
    if (result) {
      setResult(computeEstimateResult(inputs));
    }
  }, [inputs]);

  // Synchronize targetGoLiveDate with calculated Go-Live date
  useEffect(() => {
    if (inputs.projectStartDate && result && result.durationWeeks) {
      const calculatedDate = calculateGoLiveDateString(inputs.projectStartDate, result.durationWeeks);
      if (inputs.targetGoLiveDate !== calculatedDate) {
        setInputs(prev => ({
          ...prev,
          targetGoLiveDate: calculatedDate
        }));
      }
    }
  }, [inputs.projectStartDate, result?.durationWeeks]);

  // Handle loading project estimate from BD Assets
  useEffect(() => {
    if (loadedProjectEstimateInputs) {
      setInputs(loadedProjectEstimateInputs);
      setResult(computeEstimateResult(loadedProjectEstimateInputs));
      if (setLoadedProjectEstimateInputs) {
        setLoadedProjectEstimateInputs(null);
      }
    }
  }, [loadedProjectEstimateInputs, setLoadedProjectEstimateInputs]);

  const roleToInputKeyMap: Record<string, keyof ProjectEstimatorInputs> = {
    "Solution Architect": "resourceArchitects",
    "Data Engineer(s)": "resourceEngineers",
    "BI Developer(s)": "resourceBI",
    "Analytics Quality Engineer": "resourceQA",
    "Project Manager/Agile Lead": "resourcePMs",
    "DevOps Engineer": "resourceDevOps",
  };

  const handleFteChange = (role: string, val: number) => {
    const key = roleToInputKeyMap[role];
    if (key) {
      const updatedVal = Math.max(0, parseFloat(val.toFixed(1)));
      setInputs(prev => ({ ...prev, [key]: updatedVal }));
      setHasUnsavedChanges(true);
    }
  };

  const handleHoursPerWkChange = (role: string, val: number) => {
    const key = roleToInputKeyMap[role];
    if (key) {
      const calculatedFte = Math.max(0, parseFloat((val / 40).toFixed(2)));
      setInputs(prev => ({ ...prev, [key]: calculatedFte }));
      setHasUnsavedChanges(true);
    }
  };

  const handleTotalHoursChange = (role: string, val: number) => {
    const key = roleToInputKeyMap[role];
    if (key && result) {
      const weeks = result.durationWeeks || 8;
      const calculatedFte = Math.max(0, parseFloat((val / (40 * weeks)).toFixed(2)));
      setInputs(prev => ({ ...prev, [key]: calculatedFte }));
      setHasUnsavedChanges(true);
    }
  };

  // Summaries calculation
  const getPlatformSummary = () => {
    if (!inputs.dataPlatform) return "";
    const totalSources = inputs.jdbcSources + inputs.apiSources + inputs.fileSources + inputs.streamingSources + inputs.saasSources;
    const parts = [
      `Platform: ${inputs.dataPlatform} (${inputs.cloudPlatform || "Cloud Host"})`,
      `Model: ${inputs.deploymentModel || "Greenfield"} | ${inputs.deploymentMethod || "Manual"}`,
      `Sources: ${totalSources} total | Cap: ${inputs.dataSize || "<100GB"}`
    ].filter(Boolean);
    return parts.join("\n");
  };

  const getScopeSummary = () => {
    if (!inputs.primaryUseCase) return "";
    const aiText = inputs.aiFeaturesIncluded ? `Predictive AI (${inputs.numMlModels} ML Models)` : "No AI Models Included";
    const parts = [
      `Use Case: ${inputs.primaryUseCase} (${inputs.numUseCases} total)`,
      `Pipelines: ${inputs.numPipelines} (${inputs.transformationComplexity || "Simple"} Complexity)`,
      `BI Plan: ${inputs.numDashboards} Dashboards | ${aiText}`
    ].filter(Boolean);
    return parts.join("\n");
  };

  const getResourcesSummary = () => {
    if (!inputs.deliveryModel) return "";
    const staffPools = [
      inputs.resourceArchitects > 0 ? `${inputs.resourceArchitects} SA` : "",
      inputs.resourceEngineers > 0 ? `${inputs.resourceEngineers} DE` : "",
      inputs.resourceBI > 0 ? `${inputs.resourceBI} BI` : ""
    ].filter(Boolean).join(" / ");

    const parts = [
      `Delivery: ${inputs.deliveryModel} (${inputs.teamLocation || "Hybrid"})`,
      `Approach: ${inputs.agileDelivery ? `Agile Scrum (${inputs.sprintLength || "2 Weeks"})` : "Waterfall Model"}`,
      `Commitment: ${inputs.smeAvailability || "Medium"} SME | Staff: [${staffPools || "Advisory"}]`
    ].filter(Boolean);
    return parts.join("\n");
  };

  const getFrameworkSummary = () => {
    if (!inputs.projectFramework) return "";
    const parts = [
      `Project Framework: ${inputs.projectFramework}`,
      `Delivery Framework: ${inputs.deliveryFramework ? inputs.deliveryFramework.split('(')[0].trim() : ""}`,
      `Method: ${inputs.deliveryMethodology}`,
      `Sprints: ${inputs.numIterations} iterative loops`
    ];
    return parts.join("\n");
  };

  const getOtherSummary = () => {
    const parts = [
      `Security: ${[inputs.ssoRequired ? "SSO" : "", inputs.rbacRequired ? "RBAC" : ""].filter(Boolean).join("+") || "Basic Direct Authentication"}`,
      `Target timeline: ${inputs.targetGoLiveDate || "TBD Target Go-Live Calendar"}`,
      `Audits: ${inputs.complianceRequirements.length > 0 ? inputs.complianceRequirements.join(", ") : "No compliance rules"}`
    ];
    return parts.join("\n");
  };

  // Completion statuses
  const isPlatformGreen = () => !!inputs.dataPlatform;
  const isScopeGreen = () => !!inputs.primaryUseCase;
  const isFrameworkGreen = () => !!inputs.projectFramework && !!inputs.deliveryFramework;
  const isResourcesGreen = () => !!inputs.deliveryModel;
  const isOtherGreen = () => !!inputs.targetGoLiveDate || inputs.complianceRequirements.length > 0 || inputs.ssoRequired || inputs.rbacRequired || inputs.fixedBudget || inputs.fixedTimeline;

  const allGroupsGreen = isPlatformGreen() && isScopeGreen() && isFrameworkGreen() && isResourcesGreen() && isOtherGreen();

  // Load Presets for testing
  const loadPreset = () => {
    const companyToUse = (globalCompanyName && globalCompanyName.trim()) || (currentProject?.companyName && currentProject.companyName.trim()) || "SpaceX";
    const industryToUse = (globalIndustry && globalIndustry.trim()) || (currentProject?.industry && currentProject.industry.trim()) || "Aerospace & Defense";

    const loadedInputs = {
      ...samplePresetInputs,
      companyName: companyToUse,
      industry: industryToUse,
    };
    setInputs(loadedInputs);
    toast.success(`Loaded Enterprise Data Platform case study values for ${companyToUse} (${industryToUse})!`);
  };

  const clearInputs = () => {
    setInputs(defaultInputs);
    setActiveGroup(null);
    setIsSubmenuOpen(false);
    setResult(null);
    toast.success("Cleared estimator parameters.");
  };

  // Time-lapse during generation simulation
  useEffect(() => {
    if (isGenerating) {
      setElapsedTime(0);
      timerRef.current = setInterval(() => {
        setElapsedTime((prev) => parseFloat((prev + 0.1).toFixed(1)));
      }, 100);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isGenerating]);

  // Loading message cycling
  useEffect(() => {
    if (isGenerating) {
      const messages = [
        "Analyzing source connections & landing throughput...",
        "Evaluating dbt transformations and layer complexities...",
        "Formulating engineering resource constraints & sprint velocities...",
        "Assessing compliance overhead & RBAC matrix profiles...",
        "Mapping custom Gantt schedule timelines...",
        "Finalizing high-precision resource allocation plans..."
      ];
      setCurrentProgressMsg(messages[0]);
      const msgInterval = setInterval(() => {
        setCurrentProgressMsg((prev) => {
          const idx = messages.indexOf(prev);
          return messages[(idx + 1) % messages.length];
        });
      }, 700);
      return () => clearInterval(msgInterval);
    }
  }, [isGenerating]);

  // Handle estimation trigger
  const triggerGenerate = () => {
    if (iterationErrorText) {
      toast.error(iterationErrorText, { duration: 5000 });
      return;
    }
    setIsGenerating(true);
    setResult(null);

    // Simulate complete process (typically AI or robust calc)
    setTimeout(() => {
      const totalSources = inputs.jdbcSources + inputs.apiSources + inputs.fileSources + inputs.streamingSources + inputs.saasSources;
      
      // Calculate and feed initial synthesized baselines so they sync into adjustable left/right state
      const computedSa = inputs.resourceArchitects || 1;
      const computedDe = inputs.resourceEngineers || Math.max(1, Math.ceil(inputs.numPipelines / 6));
      const computedBi = inputs.resourceBI || Math.max(1, Math.ceil(inputs.numDashboards / 4));
      const computedPm = inputs.resourcePMs || 0.5;
      const computedQa = inputs.resourceQA || (totalSources > 5 ? 1 : 0.5);
      const computedDevops = inputs.resourceDevOps || (inputs.featuresCiCd ? 0.5 : 0);

      // Mutate inputs so the values are editable right away and are aligned
      const updatedInputs = {
        ...inputs,
        resourceArchitects: computedSa,
        resourceEngineers: computedDe,
        resourceBI: computedBi,
        resourcePMs: computedPm,
        resourceQA: computedQa,
        resourceDevOps: computedDevops
      };

      setInputs(updatedInputs);
      const computedResult = computeEstimateResult(updatedInputs);
      setResult(computedResult);
      setIsGenerating(false);
      setHasUnsavedChanges(false);
      toast.success("Project Estimate formulated successfully!");

      if (setProjectEstimateAssets) {
        const titleName = `${updatedInputs.companyName || "Client"} - ${updatedInputs.projectFramework} Implementation Plan`;
        const newId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15);
        const newAsset: ProjectEstimateAsset = {
          id: newId,
          projectId: currentProjectId || "",
          assetName: titleName,
          createdAt: new Date().toISOString(),
          inputs: { ...updatedInputs },
          result: computedResult
        };
        setActiveAssetId(newId);
        setProjectEstimateAssets(prev => {
          const filtered = (prev || []).filter(a => a.assetName !== titleName);
          return [newAsset, ...filtered];
        });
      }
    }, 2800);
  };

  const handleSaveEstimate = () => {
    if (!result || !setProjectEstimateAssets) return;
    
    setProjectEstimateAssets(prev => {
      const exists = prev.some(a => a.id === activeAssetId);
      if (activeAssetId && exists) {
        return prev.map(a => {
          if (a.id === activeAssetId) {
            return {
              ...a,
              inputs: { ...inputs },
              result: { ...result }
            };
          }
          return a;
        });
      } else {
        const titleName = `${inputs.companyName || "Client"} - ${inputs.projectFramework} Implementation Plan`;
        const matchingAsset = prev.find(a => a.assetName === titleName && a.projectId === currentProjectId);
        if (matchingAsset) {
          setActiveAssetId(matchingAsset.id);
          return prev.map(a => {
            if (a.id === matchingAsset.id) {
              return {
                ...a,
                inputs: { ...inputs },
                result: { ...result }
              };
            }
            return a;
          });
        } else {
          const newId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 11);
          const newAsset: ProjectEstimateAsset = {
            id: newId,
            projectId: currentProjectId || "",
            assetName: titleName,
            createdAt: new Date().toISOString(),
            inputs: { ...inputs },
            result: { ...result }
          };
          setActiveAssetId(newId);
          return [newAsset, ...prev];
        }
      }
    });

    setHasUnsavedChanges(false);
    toast.success("Changes saved to BD Assets successfully!");
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden font-sans text-slate-800 bg-slate-50/50">
      
      {/* Top action helper link bar */}
      <div className="bg-white border-b border-slate-200 px-6 py-3.5 shrink-0 flex items-center justify-between text-xs font-black text-slate-500 uppercase tracking-widest relative z-[45] shadow-sm select-none">
        <div className="flex items-center gap-2">
          <Calculator size={15} className="text-indigo-650 shrink-0" />
          <span className="text-slate-800 font-bold">WMP Data Platform Estimation Workspace</span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            type="button"
            onClick={loadPreset}
            className="text-indigo-650 hover:text-indigo-800 flex items-center gap-1.5 transition-colors cursor-pointer hover:underline"
            title="Load the consulting DW case study presets"
          >
            <Sparkles size={13} className="text-amber-500 shrink-0" />
            <span>Load Demo Case Study</span>
          </button>
          <span className="text-slate-200 font-normal">|</span>
          <button 
            type="button"
            onClick={clearInputs}
            className="text-slate-400 hover:text-red-650 flex items-center gap-1.5 transition-colors cursor-pointer hover:underline"
          >
            <X size={13} className="shrink-0" />
            <span>Reset Inputs</span>
          </button>

        </div>
      </div>

      {/* Main split workarea */}
      <div className="flex-1 flex flex-row relative min-h-0 w-full overflow-hidden bg-white lg:h-[calc(100vh-185px)] lg:max-h-[calc(100vh-185px)]">
        
        {/* LEFT PROMPT PANE - Styled exactly like Prompt card used in Platform Estimates with Paragon AI Header and layout */}
        <div className="w-[325px] min-w-[325px] border-r border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden shrink-0 relative z-30 select-none font-sans">
          <div className="py-2.5 bg-[#E7F0F7] border-b border-slate-300 px-4 shrink-0 flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal size={14} className="text-slate-800" />
              <span className="text-xs font-black uppercase tracking-wider text-slate-800">
                1. Prompt Settings
              </span>
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-between min-h-0 p-4">
            {/* Direct dynamic layout container with scrolling */}
            <div className="flex-1 flex flex-col gap-3 overflow-y-auto pr-1">
              
              {/* Top-Level fields: Industry & Company Name */}
              <div className="grid grid-cols-1 gap-2 bg-white p-2.5 rounded-lg border border-slate-200 shadow-sm shrink-0">
                <div>
                  <label className="text-[10px] font-black tracking-wider text-slate-500 uppercase block mb-1">Industry</label>
                  <select
                    value={inputs.industry}
                    onChange={(e) => setInputs(prev => ({ ...prev, industry: e.target.value }))}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-sky-500 bg-slate-50 text-slate-800 font-bold cursor-pointer"
                  >
                    <option value="">Select Industry</option>
                    {INDUSTRIES_LIST.map((ind) => (
                      <option key={ind} value={ind}>
                        {ind}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black tracking-wider text-slate-500 uppercase block mb-1">Company Name</label>
                  <input
                    type="text"
                    value={inputs.companyName}
                    onChange={(e) => setInputs(prev => ({ ...prev, companyName: e.target.value }))}
                    placeholder="Enter company..."
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-sky-500 bg-slate-50 text-slate-800 font-bold"
                  />
                </div>
              </div>

              {/* Group 1: Platform */}
              <button
                type="button"
                onClick={() => {
                  setActiveGroup("platform");
                  setIsSubmenuOpen(true);
                }}
                className={cn(
                  "w-full flex-1 min-h-[70px] p-2.5 border text-left flex flex-col justify-between transition-all rounded-lg relative group shadow-sm cursor-pointer select-none",
                  activeGroup === "platform" 
                    ? "bg-[#E7F0F7] border-slate-350 text-slate-900 shadow-md ring-2 ring-indigo-500/10 hover:bg-[#d6e5ef]" 
                    : isPlatformGreen()
                      ? "bg-emerald-50 border-emerald-200 text-slate-850 hover:bg-emerald-100/50 hover:border-emerald-300"
                      : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300"
                )}
              >
                <div className="flex items-start justify-between w-full shrink-0">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Database size={15} className={cn("shrink-0", activeGroup === "platform" ? "text-indigo-650" : isPlatformGreen() ? "text-emerald-650" : "text-slate-400")} />
                    <span className="text-xs font-black uppercase tracking-wider">1. Platform</span>
                  </div>
                  {isPlatformGreen() && (
                    <CheckCircle2 size={13} className={activeGroup === "platform" ? "text-emerald-605" : "text-emerald-600 fill-emerald-600/10"} />
                  )}
                </div>
                <div className={cn(
                  "text-[9.5px] font-semibold leading-normal tracking-wide text-left mt-1.5 overflow-hidden flex-1",
                  activeGroup === "platform" ? "text-slate-800" : isPlatformGreen() ? "text-slate-500 font-bold" : "text-slate-400"
                )}>
                  {isPlatformGreen() ? (
                    <div className="whitespace-pre-line leading-normal">{getPlatformSummary()}</div>
                  ) : (
                    "Configure lakehouse technologies, source systems topology, growth rates, & features."
                  )}
                </div>
              </button>

              {/* Group 2: Scope & Use Case */}
              <button
                type="button"
                onClick={() => {
                  setActiveGroup("scope");
                  setIsSubmenuOpen(true);
                }}
                className={cn(
                  "w-full flex-1 min-h-[70px] p-2.5 border text-left flex flex-col justify-between transition-all rounded-lg relative group shadow-sm cursor-pointer select-none",
                  activeGroup === "scope" 
                    ? "bg-[#E7F0F7] border-slate-350 text-slate-900 shadow-md ring-2 ring-indigo-500/10 hover:bg-[#d6e5ef]" 
                    : isScopeGreen()
                      ? "bg-emerald-50 border-emerald-200 text-slate-850 hover:bg-emerald-100/50 hover:border-emerald-300"
                      : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300"
                )}
              >
                <div className="flex items-start justify-between w-full shrink-0">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Layers size={15} className={cn("shrink-0", activeGroup === "scope" ? "text-indigo-650" : isScopeGreen() ? "text-emerald-650" : "text-slate-400")} />
                    <span className="text-xs font-black uppercase tracking-wider">2. Scope & Use Cases</span>
                  </div>
                  {isScopeGreen() && (
                    <CheckCircle2 size={13} className={activeGroup === "scope" ? "text-emerald-605" : "text-emerald-600 fill-emerald-600/10"} />
                  )}
                </div>
                <div className={cn(
                  "text-[9.5px] font-semibold leading-normal tracking-wide text-left mt-1.5 overflow-hidden flex-1",
                  activeGroup === "scope" ? "text-slate-800" : isScopeGreen() ? "text-slate-500 font-bold" : "text-slate-400"
                )}>
                  {isScopeGreen() ? (
                    <div className="whitespace-pre-line leading-normal">{getScopeSummary()}</div>
                  ) : (
                    "Specify transformation complexities, historical scopes, AI/ML features, and quality constraints."
                  )}
                </div>
              </button>

              {/* Group 3: Delivery Framework */}
              <button
                type="button"
                onClick={() => {
                  setActiveGroup("framework");
                  setIsSubmenuOpen(true);
                }}
                className={cn(
                  "w-full flex-1 min-h-[70px] p-2.5 border text-left flex flex-col justify-between transition-all rounded-lg relative group shadow-sm cursor-pointer select-none",
                  activeGroup === "framework" 
                    ? "bg-[#E7F0F7] border-slate-350 text-slate-900 shadow-md ring-2 ring-indigo-500/10 hover:bg-[#d6e5ef]" 
                    : isFrameworkGreen()
                      ? "bg-emerald-50 border-emerald-200 text-slate-850 hover:bg-emerald-100/50 hover:border-emerald-300"
                      : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300"
                )}
              >
                <div className="flex items-start justify-between w-full shrink-0">
                  <div className="flex items-center gap-1.5 font-bold">
                    <SlidersHorizontal size={14} className={cn("shrink-0", activeGroup === "framework" ? "text-indigo-650" : isFrameworkGreen() ? "text-emerald-650" : "text-slate-400")} />
                    <span className="text-xs font-black uppercase tracking-wider">3. Delivery Framework</span>
                  </div>
                  {isFrameworkGreen() && (
                    <CheckCircle2 size={13} className={activeGroup === "framework" ? "text-emerald-605" : "text-emerald-600 fill-emerald-600/10"} />
                  )}
                </div>
                <div className={cn(
                  "text-[9.5px] font-semibold leading-normal tracking-wide text-left mt-1.5 overflow-hidden flex-1",
                  activeGroup === "framework" ? "text-slate-800" : isFrameworkGreen() ? "text-slate-500 font-bold" : "text-slate-400"
                )}>
                  {isFrameworkGreen() ? (
                    <div className="whitespace-pre-line leading-normal">{getFrameworkSummary()}</div>
                  ) : (
                    "Select standard architecture templates, sprint duration intervals & iteration methodologies."
                  )}
                </div>
              </button>

              {/* Group 4: Resources */}
              <button
                type="button"
                onClick={() => {
                  setActiveGroup("resources");
                  setIsSubmenuOpen(true);
                }}
                className={cn(
                  "w-full flex-1 min-h-[70px] p-2.5 border text-left flex flex-col justify-between transition-all rounded-lg relative group shadow-sm cursor-pointer select-none",
                  activeGroup === "resources" 
                    ? "bg-[#E7F0F7] border-slate-350 text-slate-900 shadow-md ring-2 ring-indigo-500/10 hover:bg-[#d6e5ef]" 
                    : isResourcesGreen()
                      ? "bg-emerald-50 border-emerald-200 text-slate-850 hover:bg-emerald-100/50 hover:border-emerald-300"
                      : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300"
                )}
              >
                <div className="flex items-start justify-between w-full shrink-0">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Users size={15} className={cn("shrink-0", activeGroup === "resources" ? "text-indigo-650" : isResourcesGreen() ? "text-emerald-650" : "text-slate-400")} />
                    <span className="text-xs font-black uppercase tracking-wider">4. Resources</span>
                  </div>
                  {isResourcesGreen() && (
                    <CheckCircle2 size={13} className={activeGroup === "resources" ? "text-emerald-605" : "text-emerald-600 fill-emerald-600/10"} />
                  )}
                </div>
                <div className={cn(
                  "text-[9.5px] font-semibold text-left mt-1.5 overflow-hidden flex-1",
                  activeGroup === "resources" ? "text-slate-800" : isResourcesGreen() ? "text-slate-500 font-bold" : "text-slate-400"
                )}>
                  {isResourcesGreen() ? (
                    <div className="whitespace-pre-line leading-normal">{getResourcesSummary()}</div>
                  ) : (
                    "Detail SME commitments, project engineering staffing pools, agile models, & sprint cadence."
                  )}
                </div>
              </button>

              {/* Group 5: Other Considerations */}
              <button
                type="button"
                onClick={() => {
                  setActiveGroup("other");
                  setIsSubmenuOpen(true);
                }}
                className={cn(
                  "w-full flex-1 min-h-[70px] p-2.5 border text-left flex flex-col justify-between transition-all rounded-lg relative group shadow-sm cursor-pointer select-none",
                  activeGroup === "other" 
                    ? "bg-[#E7F0F7] border-slate-350 text-slate-900 shadow-md ring-2 ring-indigo-500/10 hover:bg-[#d6e5ef]" 
                    : isOtherGreen()
                      ? "bg-emerald-50 border-emerald-200 text-slate-850 hover:bg-emerald-100/50 hover:border-emerald-300"
                      : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300"
                )}
              >
                <div className="flex items-start justify-between w-full shrink-0">
                  <div className="flex items-center gap-1.5 font-bold">
                    <ShieldCheck size={15} className={cn("shrink-0", activeGroup === "other" ? "text-indigo-650" : isOtherGreen() ? "text-emerald-650" : "text-slate-400")} />
                    <span className="text-xs font-black uppercase tracking-wider">5. Other Considerations</span>
                  </div>
                  {isOtherGreen() && (
                    <CheckCircle2 size={13} className={activeGroup === "other" ? "text-emerald-605" : "text-emerald-600 fill-emerald-600/10"} />
                  )}
                </div>
                <div className={cn(
                  "text-[9.5px] font-semibold leading-normal tracking-wide text-left mt-1.5 overflow-hidden flex-1",
                  activeGroup === "other" ? "text-slate-800" : isOtherGreen() ? "text-slate-500 font-bold" : "text-slate-400"
                )}>
                  {isOtherGreen() ? (
                    <div className="whitespace-pre-line leading-normal">{getOtherSummary()}</div>
                  ) : (
                    "Declare SSO security constraints, compliance regulations, governance tiers, & go-live targets."
                  )}
                </div>
              </button>

              {/* Additional Context Field */}
              <div className="mt-2 shrink-0 bg-white p-2.5 rounded-lg border border-slate-200 shadow-sm">
                <label className="text-[10px] font-black tracking-wider text-slate-500 uppercase block mb-1">
                  Additional or Overriding Context
                </label>
                <textarea
                  value={inputs.overridingContext}
                  onChange={(e) => setInputs(prev => ({ ...prev, overridingContext: e.target.value }))}
                  placeholder="Specify overriding details, SLA targets, or context templates..."
                  className="w-full text-xs px-2.5 py-1.5 border border-slate-200 rounded focus:outline-none focus:ring-1 focus:ring-sky-500 bg-slate-50 text-slate-800 font-bold min-h-[50px] max-h-[100px] overflow-y-auto leading-normal"
                />
              </div>

              {/* BD Assets Pane */}
              <div className="mt-4 pt-4 border-t border-slate-250 shrink-0">
                <div className="flex items-center justify-between mb-3 shrink-0">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                    <History size={12} className="text-indigo-600" />
                    BD Assets
                  </h3>
                  <span className="bg-indigo-50 text-indigo-600 border-none font-black text-[9px] uppercase tracking-widest px-2.5 py-0.5 rounded-full select-none shrink-0 leading-none">
                    {projectEstimateAssets.filter(a => a.projectId === currentProjectId).length} Project Estimates
                  </span>
                </div>
                
                <div className="space-y-2">
                  {projectEstimateAssets.filter(a => a.projectId === currentProjectId).length === 0 ? (
                    <div className="p-4 text-center bg-white border border-dashed border-slate-200 rounded-lg">
                      <Database size={16} className="mx-auto text-slate-350 mb-1.5" />
                      <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">No Project Estimates</p>
                      <p className="text-[8px] text-slate-400 mt-1 font-medium italic">Estimates appear here when you save.</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[180px] overflow-y-auto no-scrollbar pr-1">
                      {projectEstimateAssets.filter(a => a.projectId === currentProjectId).map((asset) => (
                        <div 
                          key={asset.id}
                          className="group p-2.5 bg-white border border-slate-200 rounded hover:border-indigo-500 hover:shadow-sm transition-all cursor-pointer relative overflow-hidden"
                          onClick={() => {
                            setInputs(asset.inputs);
                            setResult(computeEstimateResult(asset.inputs));
                            setActiveAssetId(asset.id);
                            setHasUnsavedChanges(false);
                            toast.success(`Loaded project estimate: ${asset.assetName}`);
                          }}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="space-y-0.5 min-w-0 flex-1">
                              <h4 className="text-[9.5px] font-extrabold text-slate-900 uppercase truncate leading-tight">
                                {asset.assetName}
                              </h4>
                              <div className="flex items-center gap-1 text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none">
                                <span className="font-mono text-indigo-600 font-extrabold shrink-0">{asset.result?.durationWeeks || "??"} Weeks</span>
                                <span>•</span>
                                <span className="truncate">{asset.inputs?.dataPlatform || "N/A"}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-all">
                              {/* Rename Button */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const newName = window.prompt("Rename this saved estimate:", asset.assetName);
                                  if (newName !== null && newName.trim() !== "") {
                                    if (setProjectEstimateAssets) {
                                      setProjectEstimateAssets(prev => prev.map(a => a.id === asset.id ? { ...a, assetName: newName.trim() } : a));
                                    }
                                    toast.success("Estimate renamed");
                                  }
                                }}
                                className="h-5 w-5 hover:bg-slate-50 border border-transparent hover:border-slate-200 text-slate-400 hover:text-indigo-650 rounded flex items-center justify-center transition p-0 cursor-pointer"
                                title="Rename Estimate"
                              >
                                <RefreshCw size={9} />
                              </button>

                              {/* Delete Button */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (setProjectEstimateAssets) {
                                    setProjectEstimateAssets(prev => prev.filter(a => a.id !== asset.id));
                                  }
                                  toast.success("Estimate deleted");
                                }}
                                className="h-5 w-5 hover:bg-slate-50 border border-transparent hover:border-slate-200 text-slate-400 hover:text-red-650 rounded flex items-center justify-center transition p-0 cursor-pointer"
                                title="Delete Estimate"
                              >
                                <Trash2 size={9} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

            </div>
          </div>

          {/* GENERATE ESTIMATE BUTTON */}
          <div className="pt-4 border-t border-slate-200 bg-slate-50/50 p-4 shrink-0">
            <button
              type="button"
              onClick={triggerGenerate}
              disabled={!allGroupsGreen || isGenerating || !!iterationErrorText}
              className={cn(
                "w-full h-11 rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer relative overflow-hidden",
                allGroupsGreen && !isGenerating && !iterationErrorText
                  ? "bg-indigo-600 hover:bg-indigo-500 text-white active:scale-[0.98]"
                  : "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
              )}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="animate-spin text-slate-500 shrink-0" size={15} />
                  <span>Synthesizing Model...</span>
                </>
              ) : (
                <>
                  <Calculator size={14} className="shrink-0" />
                  <span>Generate Plan</span>
                </>
              )}
            </button>
            <div className="mt-2 text-[9px] font-black uppercase tracking-widest text-center flex items-center justify-center gap-1 leading-normal w-full overflow-hidden">
              {iterationErrorText ? (
                <span className="text-red-600 animate-pulse px-1.5 py-0.5 bg-red-50 border border-red-100 rounded text-[8.5px] max-w-full text-center truncate">
                  {iterationErrorText}
                </span>
              ) : allGroupsGreen ? (
                <span className="text-emerald-600 animate-pulse">Configuration Set & Verified</span>
              ) : (
                <span className="text-slate-400">Complete all groups above</span>
              )}
            </div>
          </div>
        </div>

        {/* SLIDING SUBMENU PROMPT PANE */}
        <AnimatePresence>
          {isSubmenuOpen && activeGroup && (
            <motion.div
              initial={{ x: -250, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -250, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 180 }}
              className="absolute top-0 bottom-0 left-[325px] h-full w-[325px] bg-white border-r border-l border-slate-300 shadow-2xl z-[41] flex flex-col overflow-hidden"
            >
              {/* SLIDING Header */}
              <div className="p-4 border-b border-slate-150 bg-slate-50 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-1.5">
                  <SlidersHorizontal size={14} className="text-indigo-600" />
                  <span className="text-xs font-black uppercase tracking-widest text-slate-900">
                    {activeGroup === "platform" ? "1. Platform Subprompts" : 
                     activeGroup === "scope" ? "2. Scope & Use Cases" : 
                     activeGroup === "framework" ? "3. Project Framework" : 
                     activeGroup === "resources" ? "4. Resource Staffing" : 
                     "5. Other Considerations"}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSubmenuOpen(false)}
                  className="p-1.5 hover:bg-slate-200 rounded-md text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <X size={15} />
                </button>
              </div>

              {/* SLIDING Scroll Content */}
              <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-5 text-slate-800">
                
                {/* 1. PLATFORM INPUTS */}
                {activeGroup === "platform" && (
                  <>
                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pb-1 border-b border-slate-100">PLATFORM SELECTION</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Data Platform Selection</label>
                        <select 
                          value={inputs.dataPlatform} 
                          onChange={(e) => setInputs(prev => ({ ...prev, dataPlatform: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white text-slate-800 focus:ring-1 focus:ring-sky-500 focus:outline-none"
                        >
                          <option value="">-- Select Platform --</option>
                          <option value="Databricks">Databricks</option>
                          <option value="Snowflake">Snowflake</option>
                          <option value="Microsoft Fabric">Microsoft Fabric</option>
                          <option value="AWS Native Data Services">AWS Native Data Services</option>
                          <option value="GCP Data Services">GCP Data Services</option>
                          <option value="Dremio">Dremio</option>
                          <option value="Starburst/Trino">Starburst/Trino</option>
                          <option value="ClickHouse Cloud">ClickHouse Cloud</option>
                          <option value="Firebolt">Firebolt</option>
                          <option value="SingleStore">SingleStore</option>
                          <option value="Cloudera Data Platform (CDP)">Cloudera Data Platform (CDP)</option>
                          <option value="Oracle Autonomous Data Warehouse / HeatWave">Oracle Autonomous Data Warehouse / HeatWave</option>
                          <option value="SAP Datasphere + HANA Cloud">SAP Datasphere + HANA Cloud</option>
                          <option value="Tinybird">Tinybird</option>
                          <option value="Open Lakehouse Stack (Iceberg, Spark, Trino, dbt, Airbyte, Dagster, Grafana)">Open Lakehouse Stack (Iceberg, Spark, Trino, dbt, Airbyte, Dagster, Grafana)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Cloud Host</label>
                        <select 
                          value={inputs.cloudPlatform} 
                          onChange={(e) => setInputs(prev => ({ ...prev, cloudPlatform: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Select Cloud Provider --</option>
                          <option value="Azure">Microsoft Azure</option>
                          <option value="AWS">Amazon Web Services (AWS)</option>
                          <option value="GCP">Google Cloud Platform (GCP)</option>
                          <option value="On-Prem">Enterprise On-Premises</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Deployment Model</label>
                        <div className="grid grid-cols-3 gap-2 mt-1">
                          {["Greenfield", "Enhancement", "Migration"].map(mod => (
                            <button
                              key={mod}
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, deploymentModel: mod }))}
                              className={cn(
                                "py-1.5 border text-[9px] font-black uppercase text-center rounded-lg transition-all",
                                inputs.deploymentModel === mod 
                                  ? "bg-indigo-600 border-indigo-700 text-white shadow-sm" 
                                  : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                              )}
                            >
                              {mod}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Environments Required</label>
                        <div className="flex gap-1 mt-1">
                          {["DEV", "QA", "UAT", "PROD"].map(env => {
                            const hasEnv = inputs.environments.includes(env);
                            return (
                              <button
                                key={env}
                                type="button"
                                onClick={() => setInputs(prev => ({
                                  ...prev,
                                  environments: hasEnv 
                                    ? prev.environments.filter(e => e !== env) 
                                    : [...prev.environments, env]
                                }))}
                                className={cn(
                                  "flex-1 py-1 px-1 rounded-md border text-[9px] font-black uppercase tracking-wider transition-all",
                                  hasEnv
                                    ? "bg-indigo-50 border-indigo-200 text-indigo-700 shadow-inner"
                                    : "bg-white text-slate-400 border-slate-250 hover:bg-slate-50"
                                )}
                              >
                                {env}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">IAC Deployment Strategy</label>
                        <select 
                          value={inputs.deploymentMethod} 
                          onChange={(e) => setInputs(prev => ({ ...prev, deploymentMethod: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Deployment Method --</option>
                          <option value="Manual">Manual Deployment</option>
                          <option value="IaC">Infrastructure-as-Code (Terraform)</option>
                          <option value="Enterprise Standard">Enterprise Standard (CI/CD Automated)</option>
                        </select>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">SOURCE SYSTEMS</h3>
                    <div className="space-y-3.5">
                      {[
                        { label: "Number of JDBC Sources", key: "jdbcSources" as keyof ProjectEstimatorInputs },
                        { label: "Number of API Sources", key: "apiSources" as keyof ProjectEstimatorInputs },
                        { label: "Number of File Sources", key: "fileSources" as keyof ProjectEstimatorInputs },
                        { label: "Number of Streaming Sources", key: "streamingSources" as keyof ProjectEstimatorInputs },
                        { label: "Number of SaaS Sources", key: "saasSources" as keyof ProjectEstimatorInputs },
                      ].map(src => (
                        <div key={src.label} className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-slate-650 tracking-wider uppercase">{src.label}</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.max(0, (prev[src.key] as number) - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs[src.key] as number}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.min(100, (prev[src.key] as number) + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">DATA VOLUME</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Estimated Data Size</label>
                        <select 
                          value={inputs.dataSize} 
                          onChange={(e) => setInputs(prev => ({ ...prev, dataSize: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Select Capacity --</option>
                          <option value="<100GB">&lt; 100 GB</option>
                          <option value="100GB-1TB">100 GB - 1 TB</option>
                          <option value="1TB-10TB">1 TB - 10 TB</option>
                          <option value=">10TB">&gt; 10 TB</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Daily Data Growth</label>
                        <select 
                          value={inputs.dailyGrowth} 
                          onChange={(e) => setInputs(prev => ({ ...prev, dailyGrowth: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Growth Target --</option>
                          <option value="Low">Low (&lt; 10GB/mo)</option>
                          <option value="Medium">Medium (10GB - 100GB/mo)</option>
                          <option value="High">High (&gt; 100GB/mo)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Refresh Frequency</label>
                        <select 
                          value={inputs.refreshFrequency} 
                          onChange={(e) => setInputs(prev => ({ ...prev, refreshFrequency: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Frequency CADENCE --</option>
                          <option value="Daily Batch">Daily Batch</option>
                          <option value="Near Real-Time">Near Real-Time (Micro-batch)</option>
                          <option value="Real-Time">Real-Time Streaming</option>
                        </select>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">PLATFORM FEATURES</h3>
                    <div className="grid grid-cols-1 gap-2">
                      {[
                        { label: "Data Lake Required?", key: "featuresDataLake" as keyof ProjectEstimatorInputs },
                        { label: "Data Warehouse Required?", key: "featuresDataWarehouse" as keyof ProjectEstimatorInputs },
                        { label: "Data Governance Required?", key: "featuresDataGovernance" as keyof ProjectEstimatorInputs },
                        { label: "CI/CD Orchestration Required?", key: "featuresCiCd" as keyof ProjectEstimatorInputs },
                        { label: "Monitoring & Alerting?", key: "featuresMonitoring" as keyof ProjectEstimatorInputs },
                        { label: "Disaster Recovery Strategy?", key: "featuresDisasterRecovery" as keyof ProjectEstimatorInputs },
                      ].map(feat => (
                        <div key={feat.label} className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                          <span className="text-[10px] font-bold text-slate-650 uppercase">{feat.label}</span>
                          <div className="flex gap-0.5">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [feat.key]: true }))}
                              className={cn(
                                "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                                inputs[feat.key] === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400 hover:text-slate-600"
                              )}
                            >
                              Yes
                            </button>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [feat.key]: false }))}
                              className={cn(
                                "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                                inputs[feat.key] === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400 hover:text-slate-600"
                              )}
                            >
                              No
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}

                {/* 2. PROJECT SCOPE & USE CASES */}
                {activeGroup === "scope" && (
                  <>
                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pb-1 border-b border-slate-100">Objectives & Pipelines</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Primary Deliverable Use Case</label>
                        <select 
                          value={inputs.primaryUseCase} 
                          onChange={(e) => setInputs(prev => ({ ...prev, primaryUseCase: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Use Case Type --</option>
                          <option value="Reporting">Interactive Reporting</option>
                          <option value="Analytics">Advanced Self-Serve Analytics</option>
                          <option value="AI/ML">AI / Machine Learning (Predictive)</option>
                          <option value="Data Sharing">Secure External Data Sharing</option>
                        </select>
                      </div>

                      {[
                        { label: "Number of Use Cases", key: "numUseCases" as keyof ProjectEstimatorInputs, max: 20, min: 1 },
                        { label: "Number of Data Domains", key: "numDomains" as keyof ProjectEstimatorInputs, max: 50, min: 1 },
                        { label: "Number of Data Pipelines", key: "numPipelines" as keyof ProjectEstimatorInputs, max: 100, min: 1 }
                      ].map(src => (
                        <div key={src.label} className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-slate-650 tracking-wider uppercase">{src.label}</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.max(src.min, (prev[src.key] as number) - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs[src.key] as number}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.min(src.max, (prev[src.key] as number) + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Transformation Complexity</label>
                        <div className="grid grid-cols-3 gap-2 mt-1">
                          {["Simple", "Moderate", "Complex"].map(c => (
                            <button
                              key={c}
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, transformationComplexity: c }))}
                              className={cn(
                                "py-1.5 border text-[9px] font-black uppercase text-center rounded-lg transition-all",
                                inputs.transformationComplexity === c 
                                  ? "bg-indigo-600 border-indigo-700 text-white shadow-sm" 
                                  : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                              )}
                            >
                              {c}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Historical Migration?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, migrationRequired: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.migrationRequired === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400 hover:text-slate-600"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, migrationRequired: false, migrationYears: 0 }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.migrationRequired === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400 hover:text-slate-600"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>

                      {inputs.migrationRequired && (
                        <div className="flex items-center justify-between ml-4 pl-4 border-l border-slate-200">
                          <label className="text-[10px] font-bold text-slate-550 uppercase">Years of History</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, migrationYears: Math.max(0, prev.migrationYears - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs.migrationYears}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, migrationYears: Math.min(10, prev.migrationYears + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">Analytics & Models</h3>
                    <div className="space-y-3">
                      {[
                        { label: "Number of Dashboards", key: "numDashboards" as keyof ProjectEstimatorInputs, max: 50 },
                        { label: "Number of Reports", key: "numReports" as keyof ProjectEstimatorInputs, max: 100 },
                        { label: "Number of Semantic Models", key: "numSemanticModels" as keyof ProjectEstimatorInputs, max: 20 }
                      ].map(src => (
                        <div key={src.label} className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-slate-650 tracking-wider uppercase">{src.label}</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.max(0, (prev[src.key] as number) - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs[src.key] as number}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.min(src.max, (prev[src.key] as number) + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase font-sans">Executive Reports?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, executiveReporting: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.executiveReporting === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, executiveReporting: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.executiveReporting === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">AI / MACHINE LEARNING</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Enable AI Predictive?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, aiFeaturesIncluded: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.aiFeaturesIncluded === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, aiFeaturesIncluded: false, numMlModels: 0 }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.aiFeaturesIncluded === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>

                      {inputs.aiFeaturesIncluded && (
                        <div className="flex items-center justify-between ml-4 pl-4 border-l border-slate-200">
                          <label className="text-[10px] font-bold text-slate-550 uppercase">Number of ML Models</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, numMlModels: Math.max(0, prev.numMlModels - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50-important rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs.numMlModels}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, numMlModels: Math.min(20, prev.numMlModels + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50-important rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      )}

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Generative AI Features?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, genAiFeatures: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.genAiFeatures === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, genAiFeatures: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.genAiFeatures === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">RAG / Vector Architecture?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, ragVectorSearch: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.ragVectorSearch === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, ragVectorSearch: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.ragVectorSearch === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">DATA QUALITY & MDM</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">DQ Rule Complexity</label>
                        <select 
                          value={inputs.qualityComplexity} 
                          onChange={(e) => setInputs(prev => ({ ...prev, qualityComplexity: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Rule Tiers --</option>
                          <option value="None">None</option>
                          <option value="Basic">Basic (Validation on Nulls/Types)</option>
                          <option value="Moderate">Moderate (dbt tests & constraints)</option>
                          <option value="Extensive">Extensive (Anomalies & smart scanning)</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Master Data Management?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, mdmRequired: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.mdmRequired === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, mdmRequired: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.mdmRequired === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* 3. DELIVERY FRAMEWORK INPUTS */}
                {activeGroup === "framework" && (
                  <>
                    <h3 className="text-[10px] uppercase font-black tracking-widest text-[#2B5B84] pb-1 border-b border-slate-200">DELIVERY FRAMEWORK</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Project Framework</label>
                        <select 
                          value={inputs.projectFramework} 
                          onChange={(e) => setInputs(prev => ({ ...prev, projectFramework: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white text-slate-800 focus:ring-1 focus:ring-sky-500 focus:outline-none"
                        >
                          <option value="">-- Select Project Framework --</option>
                          <option value="A. WMP D&A MVP Foundational Build">A. WMP D&A MVP Foundational Build</option>
                          <option value="B. WMP D&A Data Platform Build-Out">B. WMP D&A Data Platform Build-Out</option>
                          <option value="C. Data Platform Specific MVP Foundational Build">C. Data Platform Specific MVP Foundational Build</option>
                          <option value="D. Data Platform Specific Build-Out">D. Data Platform Specific Build-Out</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Delivery Framework</label>
                        <select 
                          value={inputs.deliveryFramework} 
                          onChange={(e) => setInputs(prev => ({ ...prev, deliveryFramework: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white text-slate-800 focus:ring-1 focus:ring-sky-500 focus:outline-none"
                        >
                          <option value="">-- Select Delivery Framework --</option>
                          <option value="Waterfall Framework (Sequential structured modeling)">Waterfall Framework (Sequential structured modeling)</option>
                          <option value="Agile Scrum Framework (Rapid sprints and design velocity)">Agile Scrum Framework (Rapid sprints and design velocity)</option>
                          <option value="Hybrid SAFe Framework (Coordinated multi-team value streams)">Hybrid SAFe Framework (Coordinated multi-team value streams)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Delivery Methodology</label>
                        <select 
                          value={inputs.deliveryMethodology} 
                          onChange={(e) => setInputs(prev => ({ ...prev, deliveryMethodology: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white text-slate-800 focus:ring-1 focus:ring-sky-500 focus:outline-none"
                        >
                          <option value="">-- Select Methodology --</option>
                          <option value="Co-Delivery Model (Blended agile product organization)">Co-Delivery Model (Blended agile product organization)</option>
                          <option value="Turnkey Partner (Full solution engineering ownership)">Turnkey Partner (Full solution engineering ownership)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Number of Iterations or Sprints</label>
                        <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-155">
                          <span className="text-[10px] font-bold text-slate-600 uppercase">Sprints Amount</span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, numIterations: Math.max(1, prev.numIterations - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs.numIterations}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, numIterations: Math.min(20, prev.numIterations + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* RENDER ITERATION ERROR IN REAL TIME */}
                        {iterationErrorText && (
                          <div className="mt-2 text-[10px] leading-normal font-semibold text-red-600 bg-red-50 border border-red-200 rounded p-2 flex items-start gap-1 p-2.5">
                            <AlertTriangle size={12} className="text-red-500 shrink-0 mt-0.5" />
                            <span>{iterationErrorText}</span>
                          </div>
                        )}
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Phase Length (Weeks)</label>
                        <select 
                          value={inputs.phaseLength} 
                          onChange={(e) => setInputs(prev => ({ ...prev, phaseLength: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white text-slate-800 focus:ring-1 focus:ring-sky-500 focus:outline-none"
                        >
                          <option value="1 Week (Micro sprints)">1 Week (Micro sprints)</option>
                          <option value="2 Weeks (Standard corporate delivery cycle)">2 Weeks (Standard corporate delivery cycle)</option>
                          <option value="3 Weeks (Extended validation schedules)">3 Weeks (Extended validation schedules)</option>
                          <option value="4 Weeks (Waterfall gating model)">4 Weeks (Waterfall gating model)</option>
                        </select>
                      </div>
                    </div>
                  </>
                )}

                {/* 4. RESOURCE INPUTS */}
                {activeGroup === "resources" && (
                  <>
                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pb-1 border-b border-slate-100 mb-2">TIMELINE CONSTRAINTS</h3>
                    <div className="space-y-3 mb-4 bg-slate-50 border border-slate-200 p-2.5 rounded-lg">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] font-bold text-slate-550 block mb-1 uppercase">Project Start Date</label>
                          <input
                            type="date"
                            value={inputs.projectStartDate}
                            onChange={(e) => setInputs(prev => ({ ...prev, projectStartDate: e.target.value }))}
                            className="w-full text-xs font-bold border border-slate-300 rounded p-1.5 bg-white scale-95"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-550 block mb-1 uppercase">Target Go-Live Date</label>
                          <input
                            type="date"
                            value={inputs.targetGoLiveDate}
                            onChange={(e) => setInputs(prev => ({ ...prev, targetGoLiveDate: e.target.value }))}
                            className="w-full text-xs font-bold border border-slate-300 rounded p-1.5 bg-slate-100 scale-95 font-medium cursor-not-allowed"
                            disabled
                          />
                        </div>
                      </div>
                      <div className="text-[9px] font-bold uppercase text-slate-400 text-center select-none leading-none">
                        Calculated based on {result ? result.durationWeeks : 8} Weeks Duration
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pb-1 border-b border-slate-100">TEAM COMPOSITION</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Delivery Execution Model</label>
                        <select 
                          value={inputs.deliveryModel} 
                          onChange={(e) => setInputs(prev => ({ ...prev, deliveryModel: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Delivery Model --</option>
                          <option value="Client Led">Client Led (Vendor Advisory)</option>
                          <option value="Shared">Shared Co-delivery (Blended)</option>
                          <option value="Vendor Led">Vendor Led (Turnkey Architecture)</option>
                        </select>
                      </div>

                      {[
                        { label: "Business SMEs Available", key: "resourceSMEs" as keyof ProjectEstimatorInputs },
                        { label: "Data Engineers Allocated", key: "resourceEngineers" as keyof ProjectEstimatorInputs },
                        { label: "BI Developers Count", key: "resourceBI" as keyof ProjectEstimatorInputs },
                        { label: "Solution Architects (FTE)", key: "resourceArchitects" as keyof ProjectEstimatorInputs },
                        { label: "Project Managers / PMO", key: "resourcePMs" as keyof ProjectEstimatorInputs },
                        { label: "QA Analysts", key: "resourceQA" as keyof ProjectEstimatorInputs },
                        { label: "DevOps/SRE Resources", key: "resourceDevOps" as keyof ProjectEstimatorInputs }
                      ].map(src => (
                        <div key={src.label} className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-slate-650 tracking-wider uppercase">{src.label}</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.max(0, (prev[src.key] as number) - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs[src.key] as number}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.min(20, (prev[src.key] as number) + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">AVAILABILITY & Cadence</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Subject Matter Commitment</label>
                        <select 
                          value={inputs.smeAvailability} 
                          onChange={(e) => setInputs(prev => ({ ...prev, smeAvailability: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- SME Commitment --</option>
                          <option value="Low">Low (&lt; 5 hrs/week per SME - HIGH RISK)</option>
                          <option value="Medium">Medium (10 - 20 hrs/week)</option>
                          <option value="High">High (Fully dedicated - MVP Ready)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Team Sourcing Location</label>
                        <select 
                          value={inputs.teamLocation} 
                          onChange={(e) => setInputs(prev => ({ ...prev, teamLocation: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Staff Location --</option>
                          <option value="Onshore">Onshore (US Local Consultant pool)</option>
                          <option value="Offshore">Offshore (High Savings, High overhead)</option>
                          <option value="Hybrid">Hybrid Blended (Strong Delivery ratio)</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Agile Scrum Delivery?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, agileDelivery: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.agileDelivery === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400 animate-pulse"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, agileDelivery: false, sprintLength: "" }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.agileDelivery === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>

                      {inputs.agileDelivery && (
                        <div>
                          <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Sprint Iteration Length</label>
                          <div className="grid grid-cols-3 gap-2 mt-1">
                            {["1 Week", "2 Weeks", "3 Weeks"].map(mod => (
                              <button
                                key={mod}
                                type="button"
                                onClick={() => setInputs(prev => ({ ...prev, sprintLength: mod }))}
                                className={cn(
                                  "py-1.5 border text-[9px] font-black uppercase text-center rounded-lg transition-all",
                                  inputs.sprintLength === mod 
                                    ? "bg-indigo-600 border-indigo-700 text-white" 
                                    : "bg-white border-slate-200 text-slate-600"
                                )}
                              >
                                {mod}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* 4. OTHER CONSIDERATIONS */}
                {activeGroup === "other" && (
                  <>
                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pb-1 border-b border-slate-100">SECURITY & COMPLIANCE</h3>
                    <div className="space-y-3">
                      {[
                        { label: "SSO Integration Required?", key: "ssoRequired" as keyof ProjectEstimatorInputs },
                        { label: "Role-Based Security (RBAC)?", key: "rbacRequired" as keyof ProjectEstimatorInputs },
                        { label: "Sensitive / PI Data Included?", key: "sensitiveData" as keyof ProjectEstimatorInputs },
                      ].map(sec => (
                        <div key={sec.label} className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                          <span className="text-[10px] font-bold text-slate-650 uppercase">{sec.label}</span>
                          <div className="flex gap-0.5">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [sec.key]: true }))}
                              className={cn(
                                "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                                inputs[sec.key] === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                              )}
                            >
                              Yes
                            </button>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [sec.key]: false }))}
                              className={cn(
                                "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                                inputs[sec.key] === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                              )}
                            >
                              No
                            </button>
                          </div>
                        </div>
                      ))}

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Compliance Overhead Audits</label>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {["HIPAA", "PCI-DSS", "SOX", "GDPR"].map(comp => {
                            const hasComp = inputs.complianceRequirements.includes(comp);
                            return (
                              <button
                                key={comp}
                                type="button"
                                onClick={() => setInputs(prev => ({
                                  ...prev,
                                  complianceRequirements: hasComp 
                                    ? prev.complianceRequirements.filter(c => c !== comp) 
                                    : [...prev.complianceRequirements, comp]
                                }))}
                                className={cn(
                                  "px-2 py-1 text-[9px] font-bold border uppercase text-center rounded-lg transition-all",
                                  hasComp 
                                    ? "bg-indigo-600 border-indigo-700 text-white shadow-sm" 
                                    : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                                )}
                              >
                                {comp}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">COMPLEXITY & GOVERNANCE</h3>
                    <div className="space-y-3.5">
                      {[
                        { label: "Number of Stakeholder Groups", key: "numStakeholderGroups" as keyof ProjectEstimatorInputs },
                        { label: "Number of Business Units", key: "numBusinessUnits" as keyof ProjectEstimatorInputs },
                        { label: "Geographic Regions Supported", key: "geographicRegions" as keyof ProjectEstimatorInputs }
                      ].map(src => (
                        <div key={src.label} className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-slate-650 tracking-wider uppercase">{src.label}</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.max(1, (prev[src.key] as number) - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs[src.key] as number}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, [src.key]: Math.min(20, (prev[src.key] as number) + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 hover:bg-slate-100 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      ))}

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Active Steering Committee?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, steeringCommittee: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.steeringCommittee === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, steeringCommittee: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.steeringCommittee === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">CHANGE MANAGEMENT</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">End-User Training Required?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, trainingRequired: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.trainingRequired === true ? "bg-indigo-600 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, trainingRequired: false, numUserGroups: 0 }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.trainingRequired === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>

                      {inputs.trainingRequired && (
                        <div className="flex items-center justify-between ml-4 pl-4 border-l border-slate-200">
                          <label className="text-[10px] font-bold text-slate-550 uppercase">Number of User Groups</label>
                          <div className="flex items-center gap-1 shadow-sm">
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, numUserGroups: Math.max(0, prev.numUserGroups - 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 rounded-l-md"
                            >
                              -
                            </button>
                            <span className="w-10 text-center text-xs font-black font-mono border-y border-slate-250 py-0.5 leading-none bg-white">
                              {inputs.numUserGroups}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInputs(prev => ({ ...prev, numUserGroups: Math.min(20, prev.numUserGroups + 1) }))}
                              className="w-6 h-6 border border-slate-250 bg-slate-50 flex items-center justify-center font-bold text-slate-500 rounded-r-md"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      )}

                      <div>
                        <label className="text-[10px] font-bold text-slate-550 uppercase block mb-1">Documentation Complexity</label>
                        <select 
                          value={inputs.documentationComplexity} 
                          onChange={(e) => setInputs(prev => ({ ...prev, documentationComplexity: e.target.value }))}
                          className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                        >
                          <option value="">-- Doc Complexity --</option>
                          <option value="Basic">Basic Runbooks</option>
                          <option value="Standard">Standard (Wikis + Architecture charts)</option>
                          <option value="Extensive">Extensive (Data Lineages + Governed Handover)</option>
                        </select>
                      </div>
                    </div>

                    <h3 className="text-[10px] uppercase font-black tracking-widest text-slate-400 pt-3 pb-1 border-b border-slate-100">PROJECT CONSTRAINTS</h3>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] font-bold text-slate-550 block mb-1 uppercase">Project Start Date</label>
                          <input
                            type="date"
                            value={inputs.projectStartDate}
                            onChange={(e) => setInputs(prev => ({ ...prev, projectStartDate: e.target.value }))}
                            className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-white"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-550 block mb-1 uppercase">Target Go-Live Date</label>
                          <input
                            type="date"
                            value={inputs.targetGoLiveDate}
                            onChange={(e) => setInputs(prev => ({ ...prev, targetGoLiveDate: e.target.value }))}
                            className="w-full text-xs font-bold border border-slate-300 rounded-lg p-2 bg-slate-100 font-medium cursor-not-allowed"
                            disabled
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Fixed Budget Project?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, fixedBudget: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.fixedBudget === true ? "bg-indigo-650 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, fixedBudget: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.fixedBudget === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 bg-slate-50 px-2 rounded-lg border border-slate-150">
                        <span className="text-[10px] font-bold text-slate-650 uppercase">Fixed Hard Timeline?</span>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, fixedTimeline: true }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.fixedTimeline === true ? "bg-indigo-650 text-white" : "bg-white text-slate-400"
                            )}
                          >
                            Yes
                          </button>
                          <button
                            type="button"
                            onClick={() => setInputs(prev => ({ ...prev, fixedTimeline: false }))}
                            className={cn(
                              "px-2 py-0.5 text-[9px] font-black rounded uppercase transition-all",
                              inputs.fixedTimeline === false ? "bg-slate-200 text-slate-600" : "bg-white text-slate-400"
                            )}
                          >
                            No
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}

              </div>

              {/* SLIDING Bottom Close bar */}
              <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-end shrink-0">
                <button
                  type="button"
                  onClick={() => setIsSubmenuOpen(false)}
                  className="px-4 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 text-[10px] font-black uppercase tracking-wider transition-all"
                >
                  Save & Close
                </button>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

        {/* RIGHT OUTPUT PANE */}
        <div className="flex-1 bg-white flex flex-col h-full overflow-hidden border-l border-slate-300 shrink-0 relative select-none font-sans">
          
          <div 
            style={{ backgroundColor: '#E7F0F7' }}
            className="py-2.5 border-b border-slate-300 px-4 shrink-0 flex flex-row items-center justify-between"
          >
            <div className="flex items-center gap-2 min-w-0 flex-1 mr-4">
              <CheckSquare size={14} className="text-slate-800 shrink-0" />
              <span className="text-xs font-black uppercase tracking-wider text-slate-800 truncate">
                {inputs.companyName 
                  ? `${inputs.companyName}: ${inputs.cloudPlatform || (inputs.dataPlatform === "Microsoft Fabric" ? "Azure" : inputs.dataPlatform === "BigQuery" ? "GCP" : inputs.dataPlatform === "Redshift" ? "AWS" : "Target Cloud")} ${inputs.dataPlatform || "D&A Platform"} - ${inputs.projectFramework || "Framework"}`
                  : "5. Project Estimates"
                }
              </span>
            </div>
            
            {/* 1.15 MINIFIED COPY SUMMARY BUTTON - UPPER RIGHT HEADER AREA */}
            {!isGenerating && result && (
              <div className="flex items-center gap-2 shrink-0">
                {hasUnsavedChanges && (
                  <button
                    type="button"
                    onClick={handleSaveEstimate}
                    className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-[9px] font-black uppercase tracking-widest rounded border border-indigo-600 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm animate-in fade-in zoom-in duration-200"
                  >
                    <Save size={12} className="text-white animate-pulse" />
                    <span>Save Estimate</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    const text = `WMP Data Platform Estimate\n=================================\nCompany: ${inputs.companyName || "Client"}\nIndustry: ${inputs.industry || "N/A"}\nPlatform: ${inputs.dataPlatform} (${inputs.cloudPlatform})\nProject Framework: ${inputs.projectFramework}\nMethodology: ${inputs.deliveryMethodology}\nDuration: ${result.durationWeeks} Weeks\nTeam Size: ${result.totalTeamSize} FTEs\n`;
                    navigator.clipboard.writeText(text);
                    toast.success("Summary copied to Clipboard!");
                  }}
                  className="px-3 py-1 bg-white hover:bg-slate-50 text-slate-800 text-[9px] font-black uppercase tracking-widest rounded border border-slate-300 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm"
                >
                  <FileText size={12} className="text-indigo-650" />
                  <span>Copy Summary</span>
                </button>
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar relative select-text">
          <AnimatePresence mode="wait">
            
            {/* 1. EMPTY STATE CONTAINER */}
            {!isGenerating && !result && (
              <motion.div 
                key="empty-state"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="flex-1 flex flex-col items-center justify-center p-8 lg:p-16 text-center max-w-2xl mx-auto space-y-8"
              >
                <div className="relative">
                  <div 
                    style={{ backgroundColor: '#E7F0F7' }}
                    className="w-24 h-24 rounded-[2rem] flex items-center justify-center text-slate-700 border border-slate-200 shadow-xl relative animate-bounce duration-4000"
                  >
                    <Calculator size={48} className="relative z-10" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-slate-500 rounded-full border-2 border-white flex items-center justify-center animate-pulse">
                    <Sparkles size={10} className="text-white" />
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
                    Data Platform Estimation Workspace
                  </h3>
                  <p className="text-slate-500 text-sm leading-relaxed max-w-md mx-auto font-medium">
                    Complete the prompt groups on the left to generate a high-level project estimate, timeline, Gantt chart, and scope summary.
                  </p>
                </div>

                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-150 text-left w-full grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="text-[10px] font-black uppercase text-slate-400">INPUT COVERAGE</div>
                    <div className="flex gap-1 animate-pulse">
                      {["Platform", "Scope", "Framework", "Team", "Others"].map((grp, idx) => {
                        const activeMap = [isPlatformGreen(), isScopeGreen(), isFrameworkGreen(), isResourcesGreen(), isOtherGreen()][idx];
                        return (
                          <div 
                            key={grp}
                            className={cn(
                              "flex-1 h-2 rounded-full transition-all duration-300",
                              activeMap ? "bg-emerald-500" : "bg-slate-200"
                            )}
                            title={`${grp}: ${activeMap ? "Completed" : "Unset"}`}
                          />
                        );
                      })}
                    </div>
                  </div>
                  <div className="space-y-1 text-right">
                    <div className="text-[10px] font-black uppercase text-slate-400">READY TO GENERATE</div>
                    <div className="text-xs font-extrabold text-slate-800">
                      {allGroupsGreen ? "100% Configured" : "Awaiting values"}
                    </div>
                  </div>
                </div>

                {!allGroupsGreen && (
                  <div 
                    style={{ backgroundColor: '#E7F0F7' }}
                    className="flex items-center gap-2 border border-slate-200 p-3.5 rounded-xl justify-center text-xs font-semibold text-slate-700 w-full hover:border-slate-300 transition"
                  >
                    <Info size={16} className="shrink-0 text-slate-500" />
                    <span>Want to preview instantly? Run the <button type="button" onClick={loadPreset} className="font-extrabold underline decoration-2 cursor-pointer hover:text-slate-900">Demo Case Study</button> to pre-fill.</span>
                  </div>
                )}
              </motion.div>
            )}

            {/* 2. LOADING STATE CONTAINER */}
            {isGenerating && (
              <motion.div 
                key="loading-state"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white"
              >
                <div className="space-y-8 animate-in fade-in-50 duration-500 max-w-md">
                  <div className="w-20 h-20 border-r-2 border-indigo-600 border-t-2 animate-spin rounded-full mx-auto flex items-center justify-center p-1.5">
                    <div className="w-full h-full bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600">
                      <Calculator size={26} className="animate-pulse" />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-lg font-black text-slate-950 uppercase tracking-wide">
                      Formulating Project Estimate
                    </h4>
                    <p className="text-slate-500 text-xs font-medium max-w-sm mx-auto leading-relaxed h-8">
                      {currentProgressMsg}
                    </p>
                  </div>

                  {/* Time lapse container */}
                  <div className="space-y-1.5">
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                      ELAPSED CALCULATION TIME
                    </div>
                    <div className="text-lg font-mono font-black text-indigo-600 bg-slate-50 rounded-xl px-4 py-2 border border-slate-100 inline-block">
                      {elapsedTime.toFixed(1)}s
                    </div>
                  </div>
                </div>
              </motion.div>
            )}            {/* 3. FINAL RESULTS STATE */}
            {!isGenerating && result && (
              <motion.div 
                key="results-display"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-4 lg:p-6 space-y-6"
              >
                
                {/* 1. PROJECT SUMMARY BANNER - Light theme light-blue, absolutely NO navy blue or cost references */}
                <div 
                  style={{ backgroundColor: 'rgb(231, 240, 247)' }}
                  className="text-slate-800 p-4 py-3.5 rounded border border-slate-300 shadow-sm relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 select-text"
                >
                  {/* Backdrop accents */}
                  <div className="absolute inset-0 bg-[radial-gradient(#000000_0.8px,transparent_0.8px)] [background-size:16px_16px] opacity-[0.03]" />
                  
                  <div className="relative z-10 space-y-2 max-w-xl">
                    <div className="inline-flex items-center gap-1.5 bg-[#4FBA5B]/10 px-2.5 py-1 rounded border border-[#4FBA5B]/30 text-[9px] font-black uppercase tracking-wider text-emerald-800">
                      <Sparkles size={11} className="text-emerald-600" />
                      Estimator Synthesized Model
                    </div>
                    <h3 className="text-lg font-black uppercase tracking-tight text-slate-900">
                      Platform Implementation Plan
                    </h3>
                    <p className="text-slate-600 text-xs leading-relaxed font-bold">
                      Calculated duration based on {inputs.numPipelines} pipelines across {inputs.numDomains} business data domains with a blended staffing model using {inputs.dataPlatform}.
                    </p>
                  </div>

                  <div className="relative z-10 flex items-center gap-3 bg-white border border-slate-200 px-4 py-2.5 rounded-sm self-stretch justify-between md:self-auto min-w-[280px] shadow-sm font-sans">
                    <div className="space-y-0.5 text-center flex-1 border-r border-slate-200 pr-3">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Duration</span>
                      <span className="text-sm font-mono font-black text-emerald-600">{result.durationWeeks} Weeks</span>
                    </div>
                    <div className="space-y-0.5 text-center flex-1 border-r border-slate-200 pr-3 pl-1">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Lakehouse</span>
                      <span className="text-xs font-black text-sky-600 tracking-wide block truncate">{inputs.dataPlatform}</span>
                    </div>
                    <div className="space-y-0.5 text-center flex-1 pl-1">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Team Size</span>
                      <span className="text-sm font-mono font-black text-indigo-600">{result.totalTeamSize} FTEs</span>
                    </div>
                  </div>
                </div>

                {/* 1.1 Project Narrative Executive Synthesis - Replacing Estimated Scope, Use cases & Velocity cards */}
                <div className="bg-slate-50 p-5 rounded border border-slate-200 shadow-sm space-y-2 select-text leading-relaxed text-xs">
                  <div className="text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">Project Synthesis Narrative</div>
                  <p className="text-slate-700 font-medium leading-relaxed">
                    This initiative, under the project title <strong className="text-indigo-600 font-bold">{inputs.companyName || "Client"} {inputs.dataPlatform} Implementation</strong>, outlines a highly performant and secure data intelligence platform deployment. The scope of this deployment centers on <strong className="text-slate-900 font-black">{inputs.dataPlatform}</strong> acting as the core platform, hosted on the secure <strong className="text-indigo-600 font-black">{inputs.cloudPlatform || "Cloud Server"}</strong> cloud layer within the <strong className="text-slate-950 font-black">{inputs.industry || "Target Portfolio"}</strong> sector.
                  </p>
                  <p className="text-slate-700 font-medium leading-relaxed">
                    The functional implementation timeline integrates <strong className="text-slate-900 font-black">{inputs.numPipelines} pipelines</strong> spanning <strong className="text-slate-900 font-black">{inputs.numDomains} business data domains</strong> and incorporates <strong className="text-slate-900 font-black">{inputs.numDashboards} custom interactive use-case dashboards</strong>. This scope is delivered according to the structured <strong className="text-indigo-700 font-bold">{inputs.projectFramework}</strong> framework with high-velocity cadence utilizing a <strong className="text-slate-900 font-black">{inputs.deliveryMethodology} {inputs.agileDelivery ? " overlapped sprint" : " sequential gating"}</strong> methodology.
                  </p>
                  <p className="text-slate-700 font-medium leading-relaxed">
                    In total, the full end-to-end lifecycle spans an estimated <strong className="text-emerald-600 font-bold">{result.durationWeeks} Weeks</strong> of delivery duration, staffed by a blended delivery team of <strong className="text-indigo-650 font-bold">{result.totalTeamSize} FTEs</strong>.
                    {inputs.overridingContext && (
                      <span className="block mt-2 pt-2 border-t border-slate-250 text-slate-500 italic text-[11px] font-semibold">
                        Additional directives & background: "{inputs.overridingContext}"
                      </span>
                    )}
                  </p>
                </div>

                {/* 2. GRAPHICAL GANTT CHART SECTION - Absolutely NO navy blue */}
                <div className="space-y-3.5 select-text">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-100 pb-2">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-800 flex items-center gap-1.5">
                      <BarChart3 size={15} className="text-indigo-600" />
                      PROJECT TIMELINE & GANTT CONFIGURATION CALENDAR
                    </h4>
                    <div className="flex items-center gap-3 shrink-0">
                      {/* Project Start Date Calendar Control */}
                      <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 hover:border-slate-300 px-2.5 py-1 rounded shadow-sm">
                        <Calendar size={13} className="text-indigo-650 shrink-0" />
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Start Date:</span>
                        <input
                          type="date"
                          value={inputs.projectStartDate}
                          onChange={(e) => {
                            setInputs(prev => ({ ...prev, projectStartDate: e.target.value }));
                            setHasUnsavedChanges(true);
                          }}
                          className="text-xs font-extrabold text-slate-800 bg-transparent border-none p-0 outline-none focus:ring-0 leading-none cursor-pointer w-[120px] select-none"
                        />
                      </div>
                      <span className="text-[9px] font-mono font-bold bg-indigo-50 text-indigo-800 px-2.5 py-0.5 rounded-full uppercase">
                        {inputs.agileDelivery ? "Agile Overlapping Cadence" : "Waterfall Sequential Phases"}
                      </span>
                    </div>
                  </div>

                  {/* High Quality Gantt Layout container */}
                  <div className="bg-slate-50 rounded border border-slate-200 p-5 overflow-x-auto shadow-sm">
                    <div className="min-w-[650px] space-y-4">
                      {/* Gantt Header Numbers */}
                      <div 
                        className="grid border-b border-slate-200 pb-2 text-[10px] font-black text-slate-400 uppercase tracking-widest relative"
                        style={{ gridTemplateColumns: `${ganttColWidth}px 1fr` }}
                      >
                        <div className="flex justify-between items-center pr-3.5 relative">
                          <span className="truncate">Phase Breakdown</span>
                          {/* Resizer Handle */}
                          <div 
                            onMouseDown={handleGanttMouseDown}
                            className="absolute right-0 top-0 bottom-0 w-2 h-full cursor-col-resize hover:bg-slate-300 bg-slate-200/60 rounded transition-colors flex items-center justify-center group z-10"
                            title="Drag to resize first column"
                          >
                            <div className="w-[3px] h-3 bg-slate-400 rounded-sm group-hover:bg-slate-600" />
                          </div>
                        </div>
                        <div className="flex justify-between px-1">
                          {Array.from({ length: Math.ceil(result.durationWeeks) }).map((_, i) => (
                            <span key={i} className="w-6 text-center font-mono text-[9px]">WK {i + 1}</span>
                          ))}
                        </div>
                      </div>
 
                      {/* Gantt Rows */}
                      <div className="space-y-3">
                        {(() => {
                          const targetGoLiveIdx = result.phases.findIndex(p => 
                            p.name.toLowerCase().includes("readiness") || 
                            p.name.toLowerCase().includes("deployment") || 
                            p.name.toLowerCase().includes("go-live") || 
                            p.name.toLowerCase().includes("go live")
                          );
                          const showIndicatorIdx = targetGoLiveIdx !== -1 ? targetGoLiveIdx : (result.phases.length > 1 ? result.phases.length - 2 : result.phases.length - 1);

                          return result.phases.map((phs, idx) => {
                            const startPct = (phs.startWeek / result.durationWeeks) * 100;
                            const widthPct = (phs.durationWeeks / result.durationWeeks) * 100;
                            const weeksToEstimate = phs.startWeek + phs.durationWeeks;
                            const milestoneDate = calculateGoLiveDateString(inputs.projectStartDate, weeksToEstimate);
                            
                            return (
                              <div 
                                key={phs.name} 
                                className="grid items-center text-xs"
                                style={{ gridTemplateColumns: `${ganttColWidth}px 1fr` }}
                              >
                                <span className="font-extrabold text-slate-800 truncate pr-4 flex items-center gap-1.5" title={phs.name}>
                                  <span className="w-5 h-5 rounded bg-indigo-50 flex items-center justify-center font-bold text-[9px] text-indigo-650 shrink-0 select-none">
                                    {idx + 1}
                                  </span>
                                  <span className="truncate select-none">{phs.name}</span>
                                </span>
                                <div 
                                  ref={idx === 0 ? timelineTrackRef : null}
                                  className="h-6.5 w-full bg-slate-100/70 border border-slate-200/50 rounded-sm relative shadow-inner flex items-center select-none"
                                >
                                  <div 
                                    className={cn(
                                      "absolute rounded-sm h-[85%] flex items-center justify-center font-mono font-black text-[9px] text-white border border-black/10 select-none",
                                      phs.color,
                                      activeDrag?.phaseIndex === idx 
                                        ? "opacity-90 ring-2 ring-indigo-500 ring-offset-1 z-30 cursor-grabbing" 
                                        : "cursor-grab active:cursor-grabbing hover:brightness-105 transition-all shadow-sm"
                                    )}
                                    style={{
                                      left: `${startPct}%`,
                                      width: `${widthPct}%`
                                    }}
                                    onMouseDown={(e) => startDrag(idx, "move", e)}
                                  >
                                    {phs.durationWeeks}W
  
                                    {/* Resize Handle on Right Edge */}
                                    <div 
                                      className="absolute right-0 top-0 bottom-0 w-2.5 cursor-ew-resize hover:bg-white/20 active:bg-white/40 flex items-center justify-center group/handle rounded-r z-20"
                                      onMouseDown={(e) => {
                                        e.stopPropagation();
                                        startDrag(idx, "resize", e);
                                      }}
                                      title="Drag handle to lengthen or shorten phase"
                                    >
                                      <div className="w-[1.5px] h-3 bg-white/40 group-hover/handle:bg-white/85 rounded-sm" />
                                    </div>
                                  </div>
  
                                  {idx === showIndicatorIdx && (
                                    <div 
                                      className="absolute z-40 flex flex-col items-center select-none"
                                      style={{ 
                                        left: `${startPct + widthPct}%`,
                                        transform: 'translateX(-50%)'
                                      }}
                                    >
                                      {/* Vertical indicator line and callout text */}
                                      <div className="relative flex flex-col items-center">
                                        {/* Milestone capsule above the bar */}
                                        <div 
                                          className="absolute bottom-6 bg-slate-800 text-white border border-slate-700 rounded px-2.5 py-1 text-[8.5px] font-black uppercase tracking-wider shadow-lg flex items-center gap-1.5 whitespace-nowrap z-50 text-slate-100"
                                          style={{
                                            transform: (startPct + widthPct) > 85 ? 'translateX(-40%)' : ((startPct + widthPct) < 15 ? 'translateX(40%)' : 'none')
                                          }}
                                        >
                                          <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping shrink-0" />
                                          <span>GO-LIVE: {formatReadableDate(milestoneDate)}</span>
                                        </div>
                                        {/* Arrowhead line */}
                                        <div className="w-[2px] h-9 bg-slate-800 -mt-2.5 relative">
                                          {/* Drop shadow pin head */}
                                          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-800 rotate-45 border-r border-b border-black/15" />
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          });
                        })()}
                      </div>
                    </div>
                  </div>
                </div>
 
                {/* 3. PHASE BREAKDOWN RESIZABLE TABLE */}
                <div className="space-y-4">
                  <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2">
                    <Layers size={15} className="text-indigo-600" />
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">
                      3. Operational Phase Breakdown Table (Resizable Columns)
                    </h4>
                  </div>
                  
                  <div className="bg-white border border-slate-200 rounded shadow-sm overflow-hidden select-text text-slate-800">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse table-fixed">
                        <thead className="bg-[#0F172A] text-slate-200 uppercase font-black text-[9px] tracking-widest">
                          <tr>
                            <th 
                              className="p-3 border-r border-[#1E293B] relative select-none"
                              style={{ width: colWidths.phaseName }}
                            >
                              Phase Name
                              <div 
                                onMouseDown={(e) => handleMouseDown("phaseName", e)}
                                className="absolute top-0 right-0 h-full w-2 cursor-col-resize hover:bg-sky-500/50 transition-colors"
                              />
                            </th>
                            <th 
                              className="p-3 border-r border-[#1E293B] relative select-none"
                              style={{ width: colWidths.category }}
                            >
                              Sourcing Category / Track
                              <div 
                                onMouseDown={(e) => handleMouseDown("category", e)}
                                className="absolute top-0 right-0 h-full w-2 cursor-col-resize hover:bg-sky-500/50 transition-colors"
                              />
                            </th>
                            <th 
                              className="p-3 relative select-none"
                              style={{ width: colWidths.weeks }}
                            >
                              Planned Weeks Block
                              <div 
                                onMouseDown={(e) => handleMouseDown("weeks", e)}
                                className="absolute top-0 right-0 h-full w-2 cursor-col-resize hover:bg-sky-500/50 transition-colors"
                              />
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-250 text-slate-705 font-extrabold bg-white">
                          {result.phases.map((phs, idx) => {
                            let category = "Core SRE / Platform Team";
                            if (phs.name.toLowerCase().includes("ingest") || phs.name.toLowerCase().includes("integration")) {
                              category = "Data Engineering Taskforce";
                            } else if (phs.name.toLowerCase().includes("bi") || phs.name.toLowerCase().includes("dashboard") || phs.name.toLowerCase().includes("semantic")) {
                              category = "Business Intelligence & Custom Apps Layer";
                            } else if (phs.name.toLowerCase().includes("govern") || phs.name.toLowerCase().includes("secur") || phs.name.toLowerCase().includes("final")) {
                              category = "Governance, Security & Operations Committees";
                            } else if (phs.name.toLowerCase().includes("plan") || phs.name.toLowerCase().includes("discover") || phs.name.toLowerCase().includes("design")) {
                              category = "Advisory Group & Core Architects";
                            }
                            
                            return (
                              <tr key={phs.name + idx} className="hover:bg-slate-50/70 transition-all font-semibold">
                                <td className="p-3 font-extrabold text-slate-900 break-words whitespace-normal border-r border-slate-200">
                                  <div className="flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                                    <span>{phs.name}</span>
                                  </div>
                                </td>
                                <td className="p-3 text-slate-600 font-semibold break-words whitespace-normal border-r border-slate-200">
                                  {category}
                                </td>
                                <td className="p-3 text-slate-705 font-mono font-black break-words whitespace-normal">
                                  Weeks {phs.startWeek + 1} – {phs.startWeek + phs.durationWeeks} ({phs.durationWeeks}W duration)
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-400 font-semibold italic">
                    💡 Hover & drag the vertical borders in the header row to resize the column widths dynamically.
                  </p>
                </div>

                {/* 4 & 5. TWO-COLUMN SPLIT SECTION: ACTIVITY DESCRIPTIONS & STAFFING PLAN */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 items-start">
                  
                  {/* Left Column: Gantt Activity Descriptions listed vertically like a workplan */}
                  <div className="space-y-4 bg-slate-50 border border-slate-200 rounded p-6 shadow-sm">
                    <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2 mb-2">
                      <FileText size={16} className="text-indigo-600" />
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">
                        4. Gantt Activity Descriptions
                      </h4>
                    </div>
                    
                    <div className="space-y-5">
                      {result.phases.map((phs, idx) => {
                        const acts = getPhaseActivities(phs.name, inputs);
                        return (
                          <div key={phs.name + idx} className="bg-white border border-slate-200 p-4 rounded-sm shadow-sm space-y-2.5">
                            <div className="flex items-center gap-2 border-b border-slate-100 pb-1.5">
                              <span className="w-5 h-5 rounded bg-indigo-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                                {idx + 1}
                              </span>
                              <h5 className="text-xs font-black text-slate-800 uppercase tracking-tight truncate">
                                {phs.name}
                              </h5>
                            </div>
                            <ul className="space-y-2 pl-1">
                              {acts.map((act, aIdx) => (
                                <li key={aIdx} className="text-[10px] text-slate-600 font-semibold leading-relaxed flex items-start gap-1.5">
                                  <span className="text-indigo-600 font-bold shrink-0 select-none">•</span>
                                  <span>{act}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right Column: Consulting Resources Staffing Plan */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-1.5 border-b border-indigo-100 pb-2">
                      <Users size={16} className="text-indigo-600" />
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">
                        5. Consulting Resources Staffing Plan
                      </h4>
                    </div>
                    
                    <div className="bg-slate-50 border border-slate-200 rounded overflow-hidden shadow-sm p-4 space-y-4">
                      
                      <div className="text-[10px] font-black text-slate-450 uppercase tracking-widest pb-1 border-b border-slate-200">
                        Synthesized Resource Pool
                      </div>

                      <div className="bg-white border border-slate-150 rounded-sm overflow-hidden shadow-sm">
                        <table className="w-full text-left text-xs text-slate-850">
                          <thead className="bg-[#0F172A] border-b border-slate-200 text-slate-200 uppercase font-black text-[9px] tracking-widest">
                            <tr>
                              <th className="p-3">Staff Role</th>
                              <th className="p-3 text-center">FTE</th>
                              <th className="p-3 text-center">Hours/Wk</th>
                              <th className="p-3 text-center">Total Hours</th>
                              <th className="p-3">Sourcing Profile</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-150 text-slate-800 font-extrabold pb-1">
                            {result.resourcesPlan.map((res, i) => {
                              const hoursPerWk = Math.round(res.fte * 40 * 10) / 10;
                              const totalHours = Math.round(res.fte * 40 * result.durationWeeks);
                              return (
                                <tr key={res.role + i} className="hover:bg-slate-50/50 transition">
                                  <td className="p-3 flex items-center gap-2 font-black text-slate-755">
                                    <Users size={12} className="text-indigo-600 shrink-0" />
                                    <span className="truncate max-w-[130px] md:max-w-none" title={res.role}>{res.role}</span>
                                  </td>
                                  
                                  {/* 1. FTE Spinner */}
                                  <td className="p-2 text-center bg-slate-50/30">
                                    <div className="inline-flex items-center justify-center gap-1 bg-white border border-slate-200 rounded p-0.5 shadow-sm">
                                      <button
                                        type="button"
                                        onClick={() => handleFteChange(res.role, Math.max(0, res.fte - 0.1))}
                                        className="w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 transition font-black text-xs shrink-0 cursor-pointer"
                                        title="-0.1 FTE"
                                      >
                                        -
                                      </button>
                                      <input
                                        type="number"
                                        value={parseFloat(res.fte.toFixed(1))}
                                        step="0.1"
                                        min="0"
                                        onChange={(e) => handleFteChange(res.role, parseFloat(e.target.value) || 0)}
                                        className="w-10 text-center font-mono font-black text-indigo-700 bg-transparent border-none p-0 text-xs focus:outline-none focus:ring-0 select-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => handleFteChange(res.role, res.fte + 0.1)}
                                        className="w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 transition font-black text-xs shrink-0 cursor-pointer"
                                        title="+0.1 FTE"
                                      >
                                        +
                                      </button>
                                    </div>
                                  </td>

                                  {/* 2. Hours/Wk Spinner */}
                                  <td className="p-2 text-center">
                                    <div className="inline-flex items-center justify-center gap-1 bg-white border border-slate-200 rounded p-0.5 shadow-sm">
                                      <button
                                        type="button"
                                        onClick={() => handleHoursPerWkChange(res.role, Math.max(0, hoursPerWk - 4))}
                                        className="w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 transition font-black text-xs shrink-0 cursor-pointer"
                                        title="-4 Hours"
                                      >
                                        -
                                      </button>
                                      <input
                                        type="number"
                                        value={Math.round(hoursPerWk)}
                                        step="1"
                                        min="0"
                                        onChange={(e) => handleHoursPerWkChange(res.role, parseInt(e.target.value) || 0)}
                                        className="w-10 text-center font-mono font-bold text-slate-600 bg-transparent border-none p-0 text-xs focus:outline-none focus:ring-0 select-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => handleHoursPerWkChange(res.role, hoursPerWk + 4)}
                                        className="w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 transition font-black text-xs shrink-0 cursor-pointer"
                                        title="+4 Hours"
                                      >
                                        +
                                      </button>
                                    </div>
                                  </td>

                                  {/* 3. Total Hours Spinner */}
                                  <td className="p-2 text-center">
                                    <div className="inline-flex items-center justify-center gap-1 bg-white border border-slate-200 rounded p-0.5 shadow-sm">
                                      <button
                                        type="button"
                                        onClick={() => handleTotalHoursChange(res.role, Math.max(0, totalHours - Math.round(result.durationWeeks * 4)))}
                                        className="w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 transition font-black text-xs shrink-0 cursor-pointer"
                                        title={`-${Math.round(result.durationWeeks * 4)} Hours`}
                                      >
                                        -
                                      </button>
                                      <input
                                        type="number"
                                        value={totalHours}
                                        step="10"
                                        min="0"
                                        onChange={(e) => handleTotalHoursChange(res.role, parseInt(e.target.value) || 0)}
                                        className="w-12 text-center font-mono font-black text-emerald-650 bg-transparent border-none p-0 text-xs focus:outline-none focus:ring-0 select-all [-moz-appearance:_textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                      />
                                      <button
                                        type="button"
                                        onClick={() => handleTotalHoursChange(res.role, totalHours + Math.round(result.durationWeeks * 4))}
                                        className="w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 transition font-black text-xs shrink-0 cursor-pointer"
                                        title={`+${Math.round(result.durationWeeks * 4)} Hours`}
                                      >
                                        +
                                      </button>
                                    </div>
                                  </td>

                                  <td className="p-3 text-slate-500 font-semibold text-[10.5px] whitespace-nowrap">{res.location} Deployment</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      <div className="bg-indigo-50/40 p-4 rounded-sm border border-indigo-100 flex items-start gap-2.5">
                        <Info size={15} className="text-indigo-600 shrink-0 mt-0.5" />
                        <div className="text-[10px] text-slate-600 font-semibold leading-normal">
                          Regional resource rates and travel schedules are dynamically bound to client location configurations. See direct sourcing profiles for offshore/onshore blend targets. All hours estimate sums correspond strictly to the configured duration of <strong className="text-indigo-700">{result.durationWeeks} weeks</strong>.
                        </div>
                      </div>

                    </div>
                  </div>

                </div>

                {/* 6. STATIC PRICING GUIDANCE REFERENCE PANEL */}
                <div className="bg-[#0F172A] text-slate-200 border border-slate-800 rounded p-6 shadow-xl relative overflow-hidden select-text text-slate-100">
                  {/* Subtle vector accents */}
                  <div className="absolute top-0 right-0 w-44 h-44 bg-indigo-600/10 rounded-full blur-3xl" />
                  
                  <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5 mb-3.5">
                    <ShieldCheck size={16} className="text-sky-400 shrink-0" />
                    <h4 className="text-xs font-black uppercase tracking-widest text-[#4FBA5B]">
                      Pricing Guidance
                    </h4>
                  </div>
                  
                  <p className="text-xs text-slate-300 font-semibold leading-relaxed whitespace-pre-line text-justify">
                    Pricing for this project is determined based on the specialized expert staffing model configured in the Left Prompt Pane. All rate structures, blended sizing options, regional discount schemes, and sub-tier travel/expense distributions are calculated directly within the firm's central WMP Pricing Tool. For exact contract pricing and detailed resource billing rates, please initiate an integrated workflow session with your designated Business Development representative or the global Sourcing Operations desk. This workspace is strictly scoped for technical, functional, and chronological delivery estimation.
                  </p>
                </div>

              </motion.div>
            )}

          </AnimatePresence>
          </div>
        </div>

      </div>

    </div>
  );
}
