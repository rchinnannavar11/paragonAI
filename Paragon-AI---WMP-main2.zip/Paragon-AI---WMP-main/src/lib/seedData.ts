import { TableModel, Project, ColumnDefinition } from "../types";

const createColumn = (
  name: string,
  businessName: string,
  datatype: string = "VARCHAR",
  size: string = "50",
  isPk: boolean = false,
  fkTo: string = "",
  description: string = ""
): ColumnDefinition => ({
  columnName: name,
  businessName,
  description: description || `The ${businessName.toLowerCase()} attribute.`,
  datatype,
  size,
  isPk,
  fkTo,
  isNullable: !isPk,
  defaultValue: "",
  exampleValues: ""
});

export const getSeedData = (projectId: string): TableModel[] => {
  const models: TableModel[] = [];
  const now = new Date().toISOString();

  const createDim = (name: string, columns: ColumnDefinition[], description: string): TableModel => ({
    id: `seed-${name}-${Math.random().toString(36).substr(2, 9)}`,
    projectId,
    tableName: name,
    tableType: 'Dimension',
    industry: 'Banking and Finance',
    companyName: 'Demo DW Bank',
    modelComplexity: 'Advanced',
    description,
    columns,
    createdAt: now
  });

  // 1. dim_account
  models.push(createDim('dim_account', [
    createColumn('dw_key', 'Account Key', 'BIGINT', '20', true),
    createColumn('account_id', 'Account ID', 'VARCHAR', '50'),
    createColumn('account_name', 'Account Name', 'VARCHAR', '100'),
    createColumn('account_type', 'Account Type', 'VARCHAR', '50'),
    createColumn('account_status', 'Account Status', 'VARCHAR', '20'),
    createColumn('open_date', 'Open Date', 'DATE', ''),
    createColumn('close_date', 'Close Date', 'DATE', ''),
    createColumn('currency_code', 'Currency Code', 'VARCHAR', '3')
  ], 'Dimension table for financial accounts.'));

  // 2. dim_customer
  models.push(createDim('dim_customer', [
    createColumn('dw_key', 'Customer Key', 'BIGINT', '20', true),
    createColumn('customer_id', 'Customer ID', 'VARCHAR', '50'),
    createColumn('first_name', 'First Name', 'VARCHAR', '50'),
    createColumn('last_name', 'Last Name', 'VARCHAR', '50'),
    createColumn('email', 'Email Address', 'VARCHAR', '100'),
    createColumn('phone_number', 'Phone Number', 'VARCHAR', '20'),
    createColumn('customer_segment', 'Customer Segment', 'VARCHAR', '50'),
    createColumn('risk_score', 'Risk Score', 'INT', '')
  ], 'Dimension table for customers.'));

  // 3. dim_partner
  models.push(createDim('dim_partner', [
    createColumn('dw_key', 'Partner Key', 'BIGINT', '20', true),
    createColumn('partner_id', 'Partner ID', 'VARCHAR', '50'),
    createColumn('partner_name', 'Partner Name', 'VARCHAR', '100'),
    createColumn('partner_type', 'Partner Type', 'VARCHAR', '50'),
    createColumn('partnership_date', 'Partnership Date', 'DATE', '')
  ], 'Dimension table for business partners.'));

  // 4. dim_product
  models.push(createDim('dim_product', [
    createColumn('dw_key', 'Product Key', 'BIGINT', '20', true),
    createColumn('product_id', 'Product ID', 'VARCHAR', '50'),
    createColumn('product_name', 'Product Name', 'VARCHAR', '100'),
    createColumn('category', 'Category', 'VARCHAR', '50'),
    createColumn('sub_category', 'Sub Category', 'VARCHAR', '50'),
    createColumn('brand', 'Brand', 'VARCHAR', '50')
  ], 'Dimension table for products.'));

  // 5. dim_transaction_header
  models.push(createDim('dim_transaction_header', [
    createColumn('dw_key', 'Header Key', 'BIGINT', '20', true),
    createColumn('transaction_id', 'Transaction ID', 'VARCHAR', '50'),
    createColumn('source_system', 'Source System', 'VARCHAR', '50'),
    createColumn('batch_id', 'Batch ID', 'VARCHAR', '50'),
    createColumn('entry_mode', 'Entry Mode', 'VARCHAR', '20')
  ], 'Dimension table for transaction header details.'));

  // 6. dim_network
  models.push(createDim('dim_network', [
    createColumn('dw_key', 'Network Key', 'BIGINT', '20', true),
    createColumn('network_id', 'Network ID', 'VARCHAR', '50'),
    createColumn('network_name', 'Network Name', 'VARCHAR', '100'),
    createColumn('network_type', 'Network Type', 'VARCHAR', '50')
  ], 'Dimension table for payment networks.'));

  // 7. dim_channel
  models.push(createDim('dim_channel', [
    createColumn('dw_key', 'Channel Key', 'BIGINT', '20', true),
    createColumn('channel_id', 'Channel ID', 'VARCHAR', '50'),
    createColumn('channel_name', 'Channel Name', 'VARCHAR', '100'),
    createColumn('channel_type', 'Channel Type', 'VARCHAR', '50')
  ], 'Dimension table for transaction channels (Online, ATM, POS, etc.).'));

  // 8. dim_case
  models.push(createDim('dim_case', [
    createColumn('dw_key', 'Case Key', 'BIGINT', '20', true),
    createColumn('case_id', 'Case ID', 'VARCHAR', '50'),
    createColumn('case_type', 'Case Type', 'VARCHAR', '50'),
    createColumn('priority', 'Priority', 'VARCHAR', '20'),
    createColumn('assigned_to', 'Assigned To', 'VARCHAR', '100')
  ], 'Dimension table for fraud investigation cases.'));

  // 9. dim_status
  models.push(createDim('dim_status', [
    createColumn('dw_key', 'Status Key', 'BIGINT', '20', true),
    createColumn('status_code', 'Status Code', 'VARCHAR', '20'),
    createColumn('status_description', 'Status Description', 'VARCHAR', '100'),
    createColumn('status_category', 'Status Category', 'VARCHAR', '50')
  ], 'Dimension table for various status codes.'));

  // 10. dim_time
  models.push(createDim('dim_time', [
    createColumn('dw_key', 'Time Key', 'BIGINT', '20', true),
    createColumn('full_date', 'Full Date', 'DATE', ''),
    createColumn('day_of_week', 'Day of Week', 'VARCHAR', '20'),
    createColumn('month', 'Month', 'VARCHAR', '20'),
    createColumn('quarter', 'Quarter', 'VARCHAR', '2'),
    createColumn('year', 'Year', 'INT', '')
  ], 'Time dimension table for temporal analysis.'));

  // 11. dim_employee
  models.push(createDim('dim_employee', [
    createColumn('dw_key', 'Employee Key', 'BIGINT', '20', true),
    createColumn('employee_id', 'Employee ID', 'VARCHAR', '50'),
    createColumn('first_name', 'First Name', 'VARCHAR', '50'),
    createColumn('last_name', 'Last Name', 'VARCHAR', '50'),
    createColumn('department', 'Department', 'VARCHAR', '50'),
    createColumn('role', 'Role', 'VARCHAR', '50')
  ], 'Dimension table for employees.'));

  // 12. dim_verification
  models.push(createDim('dim_verification', [
    createColumn('dw_key', 'Verification Key', 'BIGINT', '20', true),
    createColumn('verification_id', 'Verification ID', 'VARCHAR', '50'),
    createColumn('verification_type', 'Verification Type', 'VARCHAR', '50'),
    createColumn('verification_result', 'Verification Result', 'VARCHAR', '50')
  ], 'Dimension table for identity verification events.'));

  // 13. dim_counterparty
  models.push(createDim('dim_counterparty', [
    createColumn('dw_key', 'Counterparty Key', 'BIGINT', '20', true),
    createColumn('counterparty_id', 'Counterparty ID', 'VARCHAR', '50'),
    createColumn('counterparty_name', 'Counterparty Name', 'VARCHAR', '100'),
    createColumn('country', 'Country', 'VARCHAR', '50')
  ], 'Dimension table for transaction counterparties.'));

  // 14. dim_geography
  models.push(createDim('dim_geography', [
    createColumn('dw_key', 'Geography Key', 'BIGINT', '20', true),
    createColumn('city', 'City', 'VARCHAR', '50'),
    createColumn('state', 'State', 'VARCHAR', '50'),
    createColumn('country', 'Country', 'VARCHAR', '50'),
    createColumn('postal_code', 'Postal Code', 'VARCHAR', '20'),
    createColumn('region', 'Region', 'VARCHAR', '50')
  ], 'Dimension table for geographical locations.'));

  // 15. dim_reason
  models.push(createDim('dim_reason', [
    createColumn('dw_key', 'Reason Key', 'BIGINT', '20', true),
    createColumn('reason_code', 'Reason Code', 'VARCHAR', '20'),
    createColumn('reason_description', 'Reason Description', 'VARCHAR', '100'),
    createColumn('reason_category', 'Reason Category', 'VARCHAR', '50')
  ], 'Dimension table for reason codes (e.g., fraud reason, decline reason).'));

  // 16. dim_settlement
  models.push(createDim('dim_settlement', [
    createColumn('dw_key', 'Settlement Key', 'BIGINT', '20', true),
    createColumn('settlement_id', 'Settlement ID', 'VARCHAR', '50'),
    createColumn('settlement_method', 'Settlement Method', 'VARCHAR', '50'),
    createColumn('currency', 'Currency', 'VARCHAR', '3')
  ], 'Dimension table for settlement details.'));

  // 17. dim_credit
  models.push(createDim('dim_credit', [
    createColumn('dw_key', 'Credit Key', 'BIGINT', '20', true),
    createColumn('credit_id', 'Credit ID', 'VARCHAR', '50'),
    createColumn('credit_limit', 'Credit Limit', 'DECIMAL', '18,2'),
    createColumn('credit_score', 'Credit Score', 'INT', '')
  ], 'Dimension table for credit-related attributes.'));

  // 18. dim_tax
  models.push(createDim('dim_tax', [
    createColumn('dw_key', 'Tax Key', 'BIGINT', '20', true),
    createColumn('tax_id', 'Tax ID', 'VARCHAR', '50'),
    createColumn('tax_type', 'Tax Type', 'VARCHAR', '50'),
    createColumn('tax_rate', 'Tax Rate', 'DECIMAL', '5,2')
  ], 'Dimension table for tax details.'));

  // 19. dim_stage
  models.push(createDim('dim_stage', [
    createColumn('dw_key', 'Stage Key', 'BIGINT', '20', true),
    createColumn('stage_id', 'Stage ID', 'VARCHAR', '50'),
    createColumn('stage_name', 'Stage Name', 'VARCHAR', '50'),
    createColumn('stage_order', 'Stage Order', 'INT', '')
  ], 'Dimension table for process stages.'));

  // 20. dim_issue
  models.push(createDim('dim_issue', [
    createColumn('dw_key', 'Issue Key', 'BIGINT', '20', true),
    createColumn('issue_id', 'Issue ID', 'VARCHAR', '50'),
    createColumn('issue_type', 'Issue Type', 'VARCHAR', '50'),
    createColumn('severity', 'Severity', 'VARCHAR', '20')
  ], 'Dimension table for issues or incidents.'));

  // Fact Table: fact_fraud_transaction
  models.push({
    id: `seed-fact_fraud_transaction-${Math.random().toString(36).substr(2, 9)}`,
    projectId,
    tableName: 'fact_fraud_transaction',
    tableType: 'Fact',
    industry: 'Banking and Finance',
    companyName: 'Demo DW Bank',
    modelComplexity: 'Advanced',
    subjectArea: 'Fraud Monitoring and Detection',
    factType: 'Transaction',
    relatedDimensions: [
      'dim_account', 'dim_customer', 'dim_partner', 'dim_transaction_header', 
      'dim_network', 'dim_case', 'dim_time', 'dim_employee'
    ],
    description: 'Fact table capturing transaction details for fraud monitoring and detection.',
    columns: [
      createColumn('dw_transaction_header_key', 'Transaction Key', 'BIGINT', '20', false, 'dim_transaction_header'),
      createColumn('dw_account_key', 'Account Key', 'BIGINT', '20', false, 'dim_account'),
      createColumn('dw_customer_key', 'Customer Key', 'BIGINT', '20', false, 'dim_customer'),
      createColumn('dw_partner_key', 'Partner Key', 'BIGINT', '20', false, 'dim_partner'),
      createColumn('dw_network_key', 'Network Key', 'BIGINT', '20', false, 'dim_network'),
      createColumn('dw_case_key', 'Case Key', 'BIGINT', '20', false, 'dim_case'),
      createColumn('dw_employee_key', 'Employee Key', 'BIGINT', '20', false, 'dim_employee'),
      createColumn('dw_time_key', 'Time Key', 'BIGINT', '20', false, 'dim_time'),
      createColumn('transaction_amount', 'Transaction Amount', 'DECIMAL', '18,2'),
      createColumn('fraud_score', 'Fraud Score', 'DECIMAL', '5,2'),
      createColumn('is_fraud', 'Is Fraud', 'BOOLEAN', ''),
      createColumn('is_flagged', 'Is Flagged', 'BOOLEAN', ''),
      createColumn('detection_latency_ms', 'Detection Latency (ms)', 'INT', '')
    ],
    createdAt: now
  });

  return models;
};
