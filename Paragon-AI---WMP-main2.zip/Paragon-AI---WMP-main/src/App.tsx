/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as React from "react";
const { useState, useEffect, useMemo, useCallback, useRef } = React;
import { motion, AnimatePresence } from "motion/react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid,
  Tooltip as ChartTooltip, 
  ResponsiveContainer,
  BarChart as ReBarChart,
  Bar as ReBar,
  Cell as ReCell,
  LineChart as ReLineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell
} from 'recharts';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { toPng } from 'html-to-image';
import { 
  Eraser,
  Key,
  Database, 
  Plus, 
  History, 
  Download, 
  Trash2, 
  Loader2, 
  Table as TableIcon,
  ChevronRight,
  Info,
  Check,
  X,
  Copy,
  FileText,
  BookOpen,
  Layers,
  Layout,
  Share2,
  ArrowRight,
  FolderKanban,
  Settings2,
  Sparkles,
  Search,
  Gem,
  Edit3,
  Building2,
  LayoutDashboard,
  BarChart3,
  PieChart,
  LineChart,
  Activity,
  ArrowUpRight,
  ArrowRightLeft,
  Zap,
  Upload,
  Filter,
  PanelLeftClose,
  PanelLeftOpen,
  Image,
  User,
  Users,
  Megaphone,
  TrendingUp,
  TrendingDown,
  UserCheck,
  Cpu,
  Truck,
  ShieldCheck,
  Coins,
  Wallet,
  Globe,
  Briefcase,
  Calculator,
  Target,
  Award,
  ZapOff,
  Rocket,
  FileBarChart,
  FileSpreadsheet,
  RotateCcw,
  PenTool,
  PenLine,
  Link2,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Lock,
  MapPin,
  ShieldAlert,
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Move,
  Menu,
  BarChart,
  CreditCard,
  Banknote,
  ArrowUpLeft,
  ArrowDownLeft,
  ArrowDownRight,
  Heart,
  Box,
  Package,
  Workflow,
  HardDrive,
  Cloud,
  Terminal,
  Ship,
  Plane,
  Navigation,
  FileCheck,
  DollarSign,
  Gavel,
  Network,
  Swords,
  Handshake,
  Lightbulb,
  Flag,
  Compass,
  Presentation,
  BarChart4,
  Landmark,
  Smile,
  Factory,
  Server,
  ImageIcon,
  Anchor,
  Scale,
  Brain,
  Pin,
  AreaChart as LucideAreaChart,
  Speech,
  Calendar,
  Clock,
  Wifi,
  MessageSquare,
  MessagesSquare,
  Save,
  HelpCircle,
  BrainCircuit,
  Files,
  Minus,
  Boxes,
  Binary,
  Glasses,
  Eye,
  Settings,
  PlusCircle,
  ChevronUp,
  ChevronDown,
  RefreshCw,
  Bot,
  CheckSquare,
  Send,
  ListTodo,
} from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  generateTableModel, 
  generateTableModels, 
  generateDashboardModel, 
  generateSTTMMapping, 
  generateCompanyOpportunities, 
  generateGapRegistry,
  generateGapRegistryChunked,
  enrichGapRegistryWithMentions,
  generateTranscriptTable,
  getTickerSuggestions, 
  updateCompanyProfileForTicker, 
  generateTranscriptTableChunked,
  generatePlatformEstimates,
  generateProjectMeetingSummary,
  askProjectManagerAssistant,
  type CompanyProfilePart 
} from "@/lib/gemini";
import { TableModel, ColumnDefinition, Project, DashboardModel, STTMMapping, CompanyProfile, MDPOpportunity, TickerMatch, GapRegistryItem, GapRegistryAsset, Persona, Transcript, TranscriptSegment, PlatformEstimateResult, MermaidHighlight, LakehousePlatform, CloudProvider, BatchFrequency, PlatformEstimateAsset, PlatformEstimateInput, Environment, PlatformScenario, AdvancedQuestionnaire, SampleDashboard, ProjectEstimateAsset, ProjectMeetingSummary, ProjectActionItem, PMAssistantMessage, RAIDItem } from "./types";
import { SampleDashboardView } from "./components/SampleDashboardView";
import { ConceptualArchitecture } from "./components/ConceptualArchitecture";
import { ProjectEstimatorView } from "./components/ProjectEstimatorView";
import { PlatformComparisonMatrixView } from "./components/PlatformComparisonMatrixView";
import * as XLSX from "xlsx";
import mammoth from "mammoth";
import { cn } from "@/lib/utils";
import { toast, Toaster } from "react-hot-toast";
import { getSeedData } from "@/lib/seedData";
import mermaid from 'mermaid';

const getStringHash = (str: string) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return hash.toString();
};

const INDUSTRIES = [
  "Aerospace & Defense",
  "Agriculture",
  "Automotive",
  "Banking and Finance",
  "Consumer Electronics",
  "E-commerce",
  "Education",
  "Energy",
  "Entertainment",
  "FinTech",
  "Food Services Manufacturing",
  "Healthcare",
  "Insurance",
  "Logistics",
  "Manufacturing",
  "Media & Communications",
  "Mining & Metals",
  "Pharmaceuticals",
  "Real Estate",
  "Retail",
  "Software & Technology",
  "Telecommunications",
  "Transportation",
  "Travel & Hospitality",
  "Utilities"
].sort();

// Persona type moved to src/types.ts

const PERSONA_CONFIG: Record<Persona, { fullLabel: string, shortLabel: string, tabs: { value: string, label: string, icon: any }[] }> = {
  architect: {
    fullLabel: "Data Architect",
    shortLabel: "DATA ARCHITECT.",
    tabs: [
      { value: 'dimension', label: 'Dimension', icon: Layers },
      { value: 'fact', label: 'Fact', icon: TableIcon },
      { value: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { value: 'sttm', label: 'STTM', icon: ArrowRightLeft },
      { value: 'assets', label: 'Project Assets', icon: FolderKanban },
    ]
  },
  data_analyst: {
    fullLabel: "Data Analyst",
    shortLabel: "DATA ANALYST.",
    tabs: [
      { value: 'transcripts', label: 'Transcripts', icon: MessagesSquare },
      { value: 'gap-registry', label: 'Gap Registry', icon: FileBarChart },
      { value: 'assets-data-analyst', label: 'Analyst Assets', icon: FolderKanban },
    ]
  },
  analyst: {
    fullLabel: "Business Analyst",
    shortLabel: "ANALYST.",
    tabs: [
      { value: 'opps', label: 'MDP Opportunities', icon: Sparkles },
      { value: 'usecases', label: 'Use Cases', icon: Briefcase },
      { value: 'bi-dashboards', label: 'BI Dashboards', icon: BarChart3 },
    ]
  },
  bd: {
    fullLabel: "Business Development Professional",
    shortLabel: "BD PROFESSIONAL.",
    tabs: [
      { value: 'opps', label: 'MDP Opportunities', icon: Sparkles },
      { value: 'usecases', label: 'Use Cases', icon: Briefcase },
      { value: 'bi-dashboards', label: 'BI Dashboards', icon: BarChart3 },
      { value: 'platform-comparison', label: 'Platform Comparison', icon: Boxes },
      { value: 'estimates-platform', label: 'Platform Estimates', icon: Database },
      { value: 'estimates-project', label: 'Project Estimates', icon: Calculator },
    ]
  },
  project_manager: {
    fullLabel: "Project Manager",
    shortLabel: "PROJECT MANAGER.",
    tabs: [
      { value: 'transcript-library', label: 'Transcript Library', icon: MessagesSquare },
      { value: 'project-status-slide-maker', label: 'Project Status Slide Maker', icon: Presentation },
      { value: 'project-raid-log', label: 'Project RAID Log', icon: ShieldAlert },
    ]
  }
};

const FACT_TYPES = [
  "Transaction",
  "Periodic Snapshot",
  "Accumulating Snapshot",
  "Aggregate"
];

const formatMarketValuation = (val: string | undefined): string => {
  if (!val || val === 'N/A') return 'N/A';
  
  const numericMatch = val.match(/[\d.]+/);
  if (!numericMatch) return val;
  
  const numericStr = numericMatch[0];
  const rawValue = parseFloat(numericStr);
  if (isNaN(rawValue)) return val;

  // Detect existing suffix (T, B, M)
  const cleanVal = val.toUpperCase();
  let finalValue = rawValue;

  if (cleanVal.includes('T')) finalValue = rawValue * 1e12;
  else if (cleanVal.includes('B')) finalValue = rawValue * 1e9;
  else if (cleanVal.includes('M')) finalValue = rawValue * 1e6;
  else if (rawValue < 1e6) {
    // Check if there's any hint it might be billion but missing B (e.g. "2.4")
    if (rawValue < 1000 && (cleanVal.includes('VALUATION') || cleanVal.includes('MARKET'))) {
       // Risk of misinterpretation, but usually Gemini returnssuffixes
    }
  }

  if (finalValue >= 1e12) {
    return `$${(finalValue / 1e12).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} Trillion`;
  }
  if (finalValue >= 1e9) {
    return `$${(finalValue / 1e9).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} Billion`;
  }
  if (finalValue >= 1e6) {
    return `$${(finalValue / 1e6).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })} Million`;
  }

  return `$${finalValue.toLocaleString()}`;
};

const StockChart = ({ ticker, companyName }: { ticker: string, companyName: string }) => {
  const data = useMemo(() => {
    const points = [];
    const basePrice = (ticker.charCodeAt(0) * 2) + 50;
    const volatility = 0.08;
    let currentPrice = basePrice;
    
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    for (let i = 0; i < 24; i++) {
      const year = i < 12 ? '24' : '25';
      const monthIndex = i % 12;
      currentPrice = currentPrice * (1 + (Math.random() - 0.45) * volatility);
      points.push({
        name: `${months[monthIndex]} '${year}`,
        price: parseFloat(currentPrice.toFixed(2)),
      });
    }
    return points;
  }, [ticker]);

  const isUp = data[data.length - 1].price > data[0].price;

  return (
    <div className="space-y-3">
      <div className="flex items-end justify-between px-1">
        <div className="flex flex-col">
          <span className="text-xs font-black text-slate-400 uppercase tracking-[0.15em]">{ticker} • 2YR VIEW</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 tracking-tighter leading-none">${data[data.length - 1].price}</span>
            <span className={cn("text-sm font-bold flex items-center", isUp ? "text-emerald-600" : "text-rose-600")}>
              {isUp ? <TrendingUp size={14} className="mr-1" /> : <TrendingDown size={14} className="mr-1" />}
              {((Math.abs(data[data.length - 1].price - data[0].price) / data[0].price) * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
      
      <div className="h-[150px] w-full bg-slate-50/50 rounded-2xl p-2 border border-slate-200/50 relative group overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-white/50 to-transparent pointer-events-none" />
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={isUp ? "#10b981" : "#f43f5e"} stopOpacity={0.2}/>
                <stop offset="95%" stopColor={isUp ? "#10b981" : "#f43f5e"} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <ChartTooltip 
              contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '11px', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              itemStyle={{ color: isUp ? '#10b981' : '#f43f5e', fontWeight: 'bold' }}
              labelStyle={{ fontWeight: 'black', textTransform: 'uppercase', fontSize: '10px', color: '#64748b' }}
            />
            <XAxis 
              dataKey="name" 
              hide={false} 
              axisLine={false} 
              tickLine={false} 
              tick={{ fontSize: 9, fill: '#94a3b8', fontWeight: 600 }}
              interval={5}
              dy={5}
            />
            <Area 
              type="monotone" 
              dataKey="price" 
              stroke={isUp ? "#10b981" : "#f43f5e"} 
              fillOpacity={1} 
              fill="url(#colorPrice)" 
              strokeWidth={2.5}
              animationDuration={1500}
            />
            <XAxis dataKey="name" hide />
            <YAxis hide domain={['auto', 'auto']} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="flex justify-between px-2 text-[8px] font-black text-slate-400 uppercase tracking-[0.2em]">
        <span>Jan '24</span>
        <span>Jun '24</span>
        <span>Jan '25</span>
        <span>Jun '25</span>
      </div>
    </div>
  );
};

const OpportunityIcon = ({ 
  type, 
  title = "", 
  description = "", 
  className, 
  size = 20, 
  index = 0,
  accentClass
}: { 
  type: string, 
  title?: string, 
  description?: string, 
  className?: string, 
  size?: number, 
  index?: number,
  accentClass?: string
}) => {
  const t = type.toLowerCase();
  const text = (title + " " + description).toLowerCase();
  
  // High-Specificity Matching based on Title/Description
  if (text.includes('prediction') || text.includes('predictive') || text.includes('forecast')) 
    return <Activity size={size} className={cn(accentClass || "text-emerald-500", className)} />;
  if (text.includes('automation') || text.includes('workflow') || text.includes('streamline')) 
    return <Zap size={size} className={cn(accentClass || "text-orange-500", className)} />;
  if (text.includes('intelligence') || text.includes('cognitive') || text.includes('brain') || text.includes('ai')) 
    return <Brain size={size} className={cn(accentClass || "text-purple-500", className)} />;
  if (text.includes('security') || text.includes('protection') || text.includes('compliance') || text.includes('shield')) 
    return <ShieldCheck size={size} className={cn(accentClass || "text-indigo-500", className)} />;
  if (text.includes('growth') || text.includes('expansion') || text.includes('scale')) 
    return <TrendingUp size={size} className={cn(accentClass || "text-emerald-600", className)} />;
  if (text.includes('customer') || text.includes('retention') || text.includes('churn') || text.includes('loyalty')) 
    return <Users size={size} className={cn(accentClass || "text-blue-500", className)} />;
  if (text.includes('revenue') || text.includes('sales') || text.includes('profit')) 
    return <BarChart4 size={size} className={cn(accentClass || "text-rose-500", className)} />;
  if (text.includes('risk') || text.includes('threat') || text.includes('alert')) 
    return <ShieldAlert size={size} className={cn(accentClass || "text-amber-500", className)} />;
  if (text.includes('cloud') || text.includes('infrastructure') || text.includes('saas')) 
    return <Cloud size={size} className={cn(accentClass || "text-sky-500", className)} />;
  if (text.includes('data') || text.includes('warehouse') || text.includes('lake') || text.includes('storage')) 
    return <Database size={size} className={cn(accentClass || "text-blue-600", className)} />;
  if (text.includes('search') || text.includes('discovery') || text.includes('find')) 
    return <Search size={size} className={cn(accentClass || "text-slate-500", className)} />;
  if (text.includes('money') || text.includes('finance') || text.includes('cost') || text.includes('spend')) 
    return <Coins size={size} className={cn(accentClass || "text-emerald-500", className)} />;
  if (text.includes('global') || text.includes('international') || text.includes('region')) 
    return <Globe size={size} className={cn(accentClass || "text-blue-500", className)} />;
  if (text.includes('innovat') || text.includes('new') || text.includes('spark')) 
    return <Lightbulb size={size} className={cn(accentClass || "text-yellow-500", className)} />;
  if (text.includes('efficiency') || text.includes('performance') || text.includes('speed')) 
    return <Rocket size={size} className={cn(accentClass || "text-orange-600", className)} />;

  // Category Fallbacks with Variety
  if (t.includes('finance') || t.includes('money') || t.includes('loan') || t.includes('banking')) {
    const icons = [<Coins key="1" />, <CreditCard key="2" />, <Wallet key="3" />, <Banknote key="4" />, <Landmark key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-emerald-500", className) });
  }
  if (t.includes('people') || t.includes('customer') || t.includes('client') || t.includes('user')) {
    const icons = [<Users key="1" />, <UserCheck key="2" />, <Heart key="3" />, <Sparkles key="4" />, <Smile key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-blue-500", className) });
  }
  if (t.includes('growth') || t.includes('sales') || t.includes('revenue')) {
    const icons = [<TrendingUp key="1" />, <BarChart3 key="2" />, <LineChart key="3" />, <PieChart key="4" />, <LucideAreaChart key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-rose-500", className) });
  }
  if (t.includes('ops') || t.includes('operations') || t.includes('supply')) {
    const icons = [<Settings2 key="1" />, <Box key="2" />, <Package key="3" />, <Workflow key="4" />, <Factory key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-orange-500", className) });
  }
  if (t.includes('it') || t.includes('tech') || t.includes('security')) {
    const icons = [<Cpu key="1" />, <HardDrive key="2" />, <Cloud key="3" />, <Terminal key="4" />, <Server key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-indigo-500", className) });
  }
  if (t.includes('marketing') || t.includes('advertising')) {
    const icons = [<Megaphone key="1" />, <Zap key="2" />, <Target key="3" />, <Globe key="4" />, <ImageIcon key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-purple-500", className) });
  }
  if (t.includes('transport') || t.includes('logistics') || t.includes('truck')) {
    const icons = [<Truck key="1" />, <Ship key="2" />, <Plane key="3" />, <Navigation key="4" />, <Anchor key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-amber-500", className) });
  }
  if (t.includes('legal') || t.includes('shield') || t.includes('compliance')) {
    const icons = [<ShieldCheck key="1" />, <FileCheck key="2" />, <Gavel key="3" />, <Lock key="4" />, <Scale key="5" />];
    return React.cloneElement(icons[index % icons.length] as React.ReactElement, { size, className: cn(accentClass || "text-slate-500", className) });
  }
  
  return <Sparkles size={size} className={cn(accentClass || "text-primary", className)} />;
};

const SWOTItemIcon = ({ text, size = 12 }: { text: string, size?: number }) => {
  const t = text.toLowerCase();
  
  if (t.includes('revenue') || t.includes('margin') || t.includes('profit') || t.includes('growth') || t.includes('sales')) 
    return <TrendingUp size={size} className="text-emerald-500" />;
  if (t.includes('cost') || t.includes('expense') || t.includes('spend') || t.includes('burn')) 
    return <TrendingDown size={size} className="text-rose-500" />;
  if (t.includes('risk') || t.includes('vulnerabilit') || t.includes('threat') || t.includes('exposure') || t.includes('danger')) 
    return <AlertTriangle size={size} className="text-amber-500" />;
  if (t.includes('security') || t.includes('data') || t.includes('compliance') || t.includes('governance')) 
    return <ShieldCheck size={size} className="text-indigo-500" />;
  if (t.includes('customer') || t.includes('client') || t.includes('market') || t.includes('people') || t.includes('user')) 
    return <Users size={size} className="text-blue-500" />;
  if (t.includes('efficiency') || t.includes('operat') || t.includes('process') || t.includes('automat')) 
    return <Zap size={size} className="text-orange-500" />;
  if (t.includes('tech') || t.includes('platform') || t.includes('it') || t.includes('digital') || t.includes('infra')) 
    return <Cpu size={size} className="text-purple-500" />;
  if (t.includes('asset') || t.includes('valua') || t.includes('capit') || t.includes('resource') || t.includes('investment')) 
    return <Gem size={size} className="text-cyan-500" />;
  if (t.includes('brand') || t.includes('reputa') || t.includes('aware') || t.includes('loyal')) 
    return <Heart size={size} className="text-pink-500" />;
    
  if (t.includes('competition') || t.includes('rival') || t.includes('market share') || t.includes('competitor')) 
    return <Swords size={size} className="text-red-500" />;
  if (t.includes('partner') || t.includes('alliance') || t.includes('collabora')) 
    return <Handshake size={size} className="text-teal-500" />;
  if (t.includes('global') || t.includes('internation') || t.includes('expansion') || t.includes('geographic')) 
    return <Globe size={size} className="text-sky-600" />;
  if (t.includes('innovation') || t.includes('creativ') || t.includes('patent') || t.includes('research') || t.includes('r&d')) 
    return <Lightbulb size={size} className="text-yellow-500" />;
    
  // Default diverse icons for general bullets
  const icons = [
    <CheckCircle2 key="1" className="text-sky-500" />,
    <Target key="2" className="text-indigo-500" />,
    <Layers key="3" className="text-slate-400" />,
    <Sparkles key="4" className="text-amber-400" />,
    <Flag key="5" className="text-orange-400" />,
    <Compass key="6" className="text-blue-400" />,
    <Award key="7" className="text-yellow-600" />,
    <Activity key="8" className="text-emerald-500" />
  ];
  const charSum = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return React.cloneElement(icons[charSum % icons.length] as React.ReactElement, { size });
};

const NumberInput = ({ value, onChange, min = 0, label, icon: Icon }: { value: number, onChange: (v: number) => void, min?: number, label: string, icon: any }) => {
  return (
    <div className="space-y-1 bg-white/50 p-1.5 rounded-lg border border-slate-100 shadow-sm flex flex-col group">
      <div className="flex items-center gap-1">
        <Icon size={10} className="text-primary" />
        <Label className="text-[8px] font-black uppercase tracking-widest text-slate-400 leading-none">{label}</Label>
      </div>
      <div className="flex items-center gap-1 mt-1">
        <Input 
          type="number"
          min={min}
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value) || 0)}
          className="h-7 flex-1 bg-white text-center text-[11px] font-bold border-slate-200 rounded-lg py-0 shadow-inner [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus-visible:ring-0"
        />
        <div className="flex flex-col gap-0.5">
          <button 
            onClick={() => onChange(value + 1)}
            type="button"
            className="p-0.5 hover:bg-slate-100 rounded text-slate-400 hover:text-primary transition-colors"
          >
            <ChevronUp size={10} />
          </button>
          <button 
            onClick={() => onChange(Math.max(min, value - 1))}
            type="button"
            className="p-0.5 hover:bg-slate-100 rounded text-slate-400 hover:text-primary transition-colors"
          >
            <ChevronDown size={10} />
          </button>
        </div>
      </div>
    </div>
  );
};

const ArchitectureSynthesisLoading = () => {
  const [activeStage, setActiveStage] = useState(0);
  const stages = [
    "Analyzing Source Volumes...",
    "Benchmarking PAYG Rates...",
    "High-Efficiency Compute Synthesis...",
    "Optimizing Compute Profiles...",
    "Benchmark Optimization Analysis...",
    "Factoring Environment Overheads...",
    "Finalizing Comparison Matrix..."
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveStage((prev) => (prev + 1) % stages.length);
    }, 2500);
    return () => clearInterval(timer);
  }, [stages.length]);

  return (
    <div className="flex flex-col items-center justify-center space-y-12 py-24 relative overflow-hidden h-full min-h-[600px] bg-slate-50/50 rounded-[2rem]">
      <div className="absolute inset-0 opacity-[0.03]" 
           style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #000 1px, transparent 0)', backgroundSize: '24px 24px' }} />
      
      <div className="relative">
        <div className="relative w-72 h-72 flex items-center justify-center">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-[0.5px] border-primary/20 rounded-full border-t-primary/60"
          />
          <motion.div 
            animate={{ scale: [1, 1.05, 1], rotate: -360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-8 border-[0.5px] border-primary/10 rounded-full border-b-primary/40 shadow-sm"
          />
          
          <div className="flex items-end gap-1.5 h-16 mb-4">
            {[0.4, 0.7, 0.5, 0.9, 0.6, 0.8, 0.4].map((h, i) => (
              <motion.div
                key={i}
                initial={{ height: 0 }}
                animate={{ height: [`${h*100}%`, `${(h+0.1)*100}%`, `${h*100}%`] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1, ease: "easeInOut" }}
                className="w-1.5 bg-primary/40 rounded-full"
              />
            ))}
          </div>

          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex flex-col items-center">
               <motion.div 
                animate={{ scale: [1, 1.1, 1], opacity: [0.8, 1, 0.8] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="bg-white p-6 rounded-3xl shadow-2xl border border-primary/10 relative z-10"
              >
                <Calculator className="text-primary" size={48} />
              </motion.div>
              
              {[
                { icon: DollarSign, pos: '-top-4 -left-4', delay: 0 },
                { icon: TrendingUp, pos: '-bottom-4 -right-4', delay: 0.5 },
                { icon: Database, pos: 'top-1/2 -right-12 -translate-y-1/2', delay: 1 },
                { icon: Cloud, pos: 'top-1/2 -left-12 -translate-y-1/2', delay: 1.5 },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    y: [0, -10, 0],
                    opacity: [0.3, 1, 0.3],
                    scale: [0.8, 1, 0.8]
                  }}
                  transition={{ duration: 3, repeat: Infinity, delay: item.delay }}
                  className={cn("absolute text-primary/40", item.pos)}
                >
                  <item.icon size={20} />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="text-center space-y-6 max-w-sm z-10">
        <div className="space-y-2">
          <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tighter leading-none">
            Architecting Your Estimate
          </h3>
          <p className="text-[10px] font-black uppercase tracking-[0.3em] text-primary bg-primary/5 py-1 px-4 rounded-full inline-block">
            High-Reasoning Synthesis Engine
          </p>
        </div>
        
        <div className="h-8 flex flex-col items-center justify-center overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.p 
              key={activeStage}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              className="text-slate-500 text-[11px] font-bold uppercase tracking-widest italic"
            >
              {stages[activeStage]}
            </motion.p>
          </AnimatePresence>
        </div>
        
        <div className="w-48 h-1 bg-slate-200 rounded-full overflow-hidden mx-auto mt-4">
          <motion.div 
            animate={{ x: [-200, 200] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
            className="w-24 h-full bg-primary"
          />
        </div>
      </div>
    </div>
  );
};

const ThinkingManLoading = () => {
  return (
    <div className="flex flex-col items-center justify-center space-y-16 py-24 relative overflow-hidden">
      {/* Background Technical Grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
        style={{ 
          backgroundImage: `radial-gradient(circle at 2px 2px, #000 1px, transparent 0)`,
          backgroundSize: '40px 40px' 
        }} 
      />

      <div className="relative w-80 h-80 flex items-center justify-center">
        {/* Outer Rotating Gear-like Architecture */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 border-2 border-dashed border-primary/20 rounded-full"
        />
        
        {/* Inner Synthesis Planes */}
        <div className="relative w-48 h-48">
          {/* Plane 1: Infrastructure */}
          <motion.div 
            animate={{ 
              rotateX: [60, 60, 60],
              rotateY: [0, 360],
              z: [0, 50, 0]
            }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-2 border-primary/30 rounded-xl bg-primary/5 flex items-center justify-center"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <Layers className="text-primary/40" size={60} />
          </motion.div>
          
          {/* Plane 2: Logic/Logic */}
          <motion.div 
            animate={{ 
              rotateX: [60, 60, 60],
              rotateY: [360, 0],
              z: [25, -25, 25]
            }}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-2 border-primary/20 rounded-xl bg-white/50 backdrop-blur-sm shadow-xl flex items-center justify-center"
            style={{ transformStyle: 'preserve-3d' }}
          >
            <BrainCircuit className="text-primary" size={80} />
          </motion.div>

          {/* Floating Data Symbols */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ 
                opacity: [0, 1, 0],
                scale: [0.5, 1.2, 0.5],
                y: [-100, -250],
                x: Math.sin(i) * 150
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity, 
                delay: i * 0.7,
                ease: "easeOut"
              }}
              className="absolute left-1/2 top-1/2 -ml-4 -mt-4 text-primary/40 font-mono font-black"
            >
              {i % 2 === 0 ? <Binary size={24} /> : <span className="text-xl">$</span>}
            </motion.div>
          ))}
        </div>

        {/* Technical HUD Elements around the center */}
        <div className="absolute inset-4 border border-primary/10 rounded-full animate-pulse" />
        <div className="absolute -inset-8 border-t-2 border-primary/10 rounded-full animate-spin [animation-duration:8s]" />
      </div>

      <div className="text-center space-y-4 z-10">
        <h3 className="text-4xl font-black text-slate-900 uppercase tracking-tighter mix-blend-multiply">Generating Platform Estimates</h3>
        <div className="flex flex-col items-center gap-2">
          <p className="text-slate-500 text-[14px] font-bold uppercase tracking-widest flex items-center justify-center gap-3">
            <span className="flex h-2.5 w-2.5 rounded-full bg-primary animate-ping" />
            Synthesizing Architecture Benchmarks
          </p>
          <div className="flex gap-4 pt-4">
            <Badge variant="outline" className="text-[10px] uppercase font-black tracking-widest border-slate-200 text-slate-400 px-3">Compute Interpolation</Badge>
            <Badge variant="outline" className="text-[10px] uppercase font-black tracking-widest border-slate-200 text-slate-400 px-3">Storage Layering</Badge>
            <Badge variant="outline" className="text-[10px] uppercase font-black tracking-widest border-slate-200 text-slate-400 px-3">PAYG Validation</Badge>
          </div>
        </div>
      </div>
    </div>
  );
};

const MonocleLoading = () => {
  return (
    <div className="flex flex-col items-center justify-center space-y-8 py-12">
      <div className="relative w-40 h-20 flex items-center justify-center">
        {/* Left Monocle */}
        <motion.div
          animate={{
            x: [-10, 10, -10],
            rotate: [0, 5, -5, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute left-8 w-16 h-16 border-4 border-primary rounded-full shadow-[0_0_15px_rgba(var(--primary),0.2)] bg-primary/5"
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full border-2 border-primary/20 animate-pulse" />
        </motion.div>
        
        {/* Right Monocle */}
        <motion.div
          animate={{
            x: [10, -10, 10],
            rotate: [0, -5, 5, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute right-8 w-16 h-16 border-4 border-primary rounded-full shadow-[0_0_15px_rgba(var(--primary),0.2)] bg-primary/5"
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full border-2 border-primary/20 animate-pulse" />
        </motion.div>
        
        {/* Bridge */}
        <motion.div 
          animate={{
            width: [40, 60, 40],
          }}
          transition={{
             duration: 3,
             repeat: Infinity,
             ease: "easeInOut"
          }}
          className="h-1 bg-primary rounded-full z-0 mx-auto"
        />
      </div>
      <div className="text-center space-y-2">
        <h3 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Analyzing Market Landscape...</h3>
        <p className="text-slate-500 text-xs font-medium">Gemini is scrutinizing company data with sophisticated accuracy.</p>
      </div>
    </div>
  );
};

const MUTED_COLORS = [
  'bg-emerald-50/40 border-emerald-100/60',
  'bg-blue-50/40 border-blue-100/60',
  'bg-purple-50/40 border-purple-100/60',
  'bg-amber-50/40 border-amber-100/60',
  'bg-rose-50/40 border-rose-100/60',
  'bg-indigo-50/40 border-indigo-100/60',
  'bg-cyan-50/40 border-cyan-100/60',
  'bg-teal-50/40 border-teal-100/60',
];

const CARD_THEMES = [
  { text: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', accent: 'text-emerald-500', icon: 'text-emerald-500' },
  { text: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100', accent: 'text-blue-500', icon: 'text-blue-500' },
  { text: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-100', accent: 'text-purple-500', icon: 'text-purple-500' },
  { text: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', accent: 'text-amber-500', icon: 'text-amber-500' },
  { text: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-100', accent: 'text-rose-500', icon: 'text-rose-500' },
  { text: 'text-indigo-600', bg: 'bg-indigo-50', border: 'border-indigo-100', accent: 'text-indigo-500', icon: 'text-indigo-500' },
  { text: 'text-cyan-600', bg: 'bg-cyan-50', border: 'border-cyan-100', accent: 'text-cyan-500', icon: 'text-cyan-500' },
  { text: 'text-teal-600', bg: 'bg-teal-50', border: 'border-teal-100', accent: 'text-teal-500', icon: 'text-teal-500' },
];

const OpportunityCard: React.FC<{ opp: MDPOpportunity; index: number; onToggle: (id: string) => void }> = ({ opp, index, onToggle }) => {
  const colorClass = MUTED_COLORS[index % MUTED_COLORS.length];
  const theme = CARD_THEMES[index % CARD_THEMES.length];

  // Extract background and border for the icon container from MUTED_COLORS pattern
  const iconContainerTheme = (() => {
    const t = opp.iconType.toLowerCase();
    if (t.includes('finance') || t.includes('money') || t.includes('loan') || t.includes('banking')) return "bg-emerald-100/50 border-emerald-200";
    if (t.includes('people') || t.includes('customer') || t.includes('client') || t.includes('user')) return "bg-blue-100/50 border-blue-200";
    if (t.includes('growth') || t.includes('sales') || t.includes('revenue')) return "bg-rose-100/50 border-rose-200";
    if (t.includes('ops') || t.includes('operations') || t.includes('supply')) return "bg-orange-100/50 border-orange-200";
    if (t.includes('it') || t.includes('tech') || t.includes('security')) return "bg-indigo-100/50 border-indigo-200";
    if (t.includes('marketing') || t.includes('advertising')) return "bg-purple-100/50 border-purple-200";
    if (t.includes('transport') || t.includes('logistics') || t.includes('truck')) return "bg-amber-100/50 border-amber-200";
    if (t.includes('legal') || t.includes('shield') || t.includes('compliance')) return "bg-slate-100/50 border-slate-200";
    return "bg-slate-100/50 border-slate-200 transition-all";
  })();

  return (
    <Card className={cn(
      "relative transition-all duration-300 group overflow-hidden h-full flex flex-col shadow-sm hover:shadow-lg border-2",
      colorClass,
      opp.selected ? "ring-4 ring-primary ring-offset-0 border-primary shadow-xl" : "border-slate-200"
    )}>
      <div className="absolute top-4 right-4 z-10 transition-transform group-hover:scale-110">
        <Checkbox 
          checked={opp.selected} 
          onCheckedChange={() => onToggle(opp.id)}
          className="h-7 w-7 rounded-lg border-2 border-slate-400 data-[state=checked]:bg-primary data-[state=checked]:border-primary shadow-md backdrop-blur-sm"
        />
      </div>
      
      <CardHeader className="pb-3 pt-6 px-6">
        <div className="flex items-start gap-4">
          <div className={cn(
            "w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center border shadow-sm group-hover:shadow-md transition-all",
            iconContainerTheme
          )}>
            <OpportunityIcon 
              type={opp.iconType} 
              title={opp.title}
              description={opp.businessCase}
              size={28} 
              index={index} 
              accentClass={theme.accent}
            />
          </div>
          <div className="space-y-1 pt-1 pr-16 text-left">
            <div className="flex items-center gap-2 mb-1">
              {opp.linkedSwotIndex !== undefined && (
                  <Tooltip>
                    <TooltipTrigger 
                      render={(triggerProps) => (
                        <div {...triggerProps} className={cn(
                          "flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest shadow-md cursor-help border transition-all hover:shadow-lg",
                          opp.linkType === 'direct' ? "bg-red-600 text-white border-red-700" : "bg-orange-400 text-slate-900 border-orange-500"
                        )}>
                          <span className="w-4 h-4 rounded-full bg-black/20 flex items-center justify-center font-black text-[10px]">
                            {opp.linkedSwotIndex + 1}
                          </span>
                          <span>SWOT {opp.linkType}</span>
                        </div>
                      )}
                    />
                    <TooltipContent className="bg-slate-900 text-white border-none p-2 rounded-lg text-[9px] font-medium">
                      Directly powers Strategic Opportunity #{opp.linkedSwotIndex + 1}
                    </TooltipContent>
                  </Tooltip>
              )}
            </div>
            <h3 className="text-lg font-black text-slate-900 leading-[1.2] tracking-tight">
              {opp.title}
            </h3>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-5 pb-6 px-6 flex-1 text-left">
        <div className="space-y-2">
          <p className="text-sm text-slate-600 leading-relaxed font-medium">
            {opp.businessCase}
          </p>
        </div>
        
        <div className={cn("p-4 rounded-2xl border transition-all group-hover:bg-white shadow-sm ring-1 ring-slate-950/[0.02] bg-white/80", theme.border)}>
          <div className="flex items-center gap-2.5 mb-2">
            <div className={cn("p-1.5 rounded-lg", theme.bg)}>
              <TrendingUp size={16} className={theme.accent} />
            </div>
            <span className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-500">Value Proposition</span>
          </div>
          <p className="text-sm text-slate-700 font-semibold italic border-l-2 border-primary/20 pl-3 py-1">
            {opp.roi}
          </p>
        </div>
        
        <div className="space-y-4 mt-auto">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className={cn("p-1 rounded-md", theme.bg)}>
                <Layers size={10} className={theme.accent} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Dimensions</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {opp.dimensions.map((dim, idx) => (
                <Badge key={idx} variant="outline" className={cn("text-[10px] font-mono py-0.5 px-2 bg-white/80 border-slate-200 whitespace-nowrap shadow-xs uppercase", theme.text)}>
                  {dim}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className={cn("p-1 rounded-md", theme.bg)}>
                <Network size={10} className={theme.accent} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Key Entities</span>
            </div>
            <div className="flex flex-wrap gap-1.5 overflow-hidden">
              {opp.facts.map((fact, idx) => (
                <Badge key={idx} variant="secondary" className={cn("text-[9px] font-mono py-0.5 px-2 bg-white/50 border-slate-100 break-all leading-tight max-w-full", theme.text)}>
                  {fact}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const COLORS = ['#1e3a8a', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#bfdbfe'];

const AssetCounts = ({ 
  dims, 
  facts, 
  sttms, 
  dashboards,
  className,
  variant = "default"
}: { 
  dims: number, 
  facts: number, 
  sttms: number, 
  dashboards: number,
  className?: string,
  variant?: "default" | "compact"
}) => (
  <div className={cn(
    variant === "compact" ? "flex items-center justify-between gap-1 mt-1 px-1" : "grid grid-cols-2 gap-2 mt-2", 
    className
  )}>
    <div className={cn(
      "flex items-center gap-1.5 rounded-xl transition-all",
      variant === "compact" ? "bg-transparent border-none p-0 flex-1 justify-start" : "bg-primary/5 border border-primary/10 p-1.5"
    )}>
      <div className={cn(
        "rounded-full flex items-center justify-center shrink-0 shadow-sm",
        variant === "compact" ? "size-5 bg-primary text-white" : "w-5 h-5 bg-primary/10 text-primary"
      )}>
        <Layout size={variant === "compact" ? 10 : 10} />
      </div>
      <div className="flex flex-col">
        <span className={cn("font-black text-slate-900 leading-tight", variant === "compact" ? "text-[10px]" : "text-[10px]")}>{dims}</span>
        {variant !== "compact" && <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 leading-none">Dims</span>}
      </div>
    </div>
    
    <div className={cn(
      "flex items-center gap-1.5 rounded-xl transition-all",
      variant === "compact" ? "bg-transparent border-none p-0 flex-1 justify-start" : "bg-blue-50 border border-blue-100 p-1.5"
    )}>
      <div className={cn(
        "rounded-full flex items-center justify-center shrink-0 shadow-sm",
        variant === "compact" ? "size-5 bg-blue-600 text-white" : "w-5 h-5 bg-blue-100 text-blue-600"
      )}>
        <Database size={variant === "compact" ? 10 : 10} />
      </div>
      <div className="flex flex-col">
        <span className={cn("font-black text-slate-900 leading-tight", variant === "compact" ? "text-[10px]" : "text-[10px]")}>{facts}</span>
        {variant !== "compact" && <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 leading-none">Facts</span>}
      </div>
    </div>
    
    <div className={cn(
      "flex items-center gap-1.5 rounded-xl transition-all",
      variant === "compact" ? "bg-transparent border-none p-0 flex-1 justify-start " : "bg-emerald-50 border border-emerald-100 p-1.5"
    )}>
      <div className={cn(
        "rounded-full flex items-center justify-center shrink-0 shadow-sm",
        variant === "compact" ? "size-5 bg-emerald-600 text-white" : "w-5 h-5 bg-emerald-100 text-emerald-600"
      )}>
        <ArrowRightLeft size={variant === "compact" ? 10 : 10} />
      </div>
      <div className="flex flex-col">
        <span className={cn("font-black text-slate-900 leading-tight", variant === "compact" ? "text-[10px]" : "text-[10px]")}>{sttms}</span>
        {variant !== "compact" && <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 leading-none">STTMs</span>}
      </div>
    </div>
    
    <div className={cn(
      "flex items-center gap-1.5 rounded-xl transition-all",
      variant === "compact" ? "bg-transparent border-none p-0 flex-1 justify-start " : "bg-amber-50 border border-amber-100 p-1.5"
    )}>
      <div className={cn(
        "rounded-full flex items-center justify-center shrink-0 shadow-sm",
        variant === "compact" ? "size-5 bg-amber-600 text-white" : "w-5 h-5 bg-amber-100 text-amber-600"
      )}>
        <LayoutDashboard size={variant === "compact" ? 10 : 10} />
      </div>
      <div className="flex flex-col">
        <span className={cn("font-black text-slate-900 leading-tight", variant === "compact" ? "text-[10px]" : "text-[10px]")}>{dashboards}</span>
        {variant !== "compact" && <span className="text-[7px] font-bold uppercase tracking-wider text-slate-400 leading-none">Dashs</span>}
      </div>
    </div>
  </div>
);

const STTMStatusIcon = ({ status }: { status: 'C' | 'P' | 'I' }) => {
  const configs = {
    C: { icon: CheckCircle2, color: "text-emerald-500 bg-emerald-50", label: "Complete", desc: "All target columns mapped (excl. keys/audit)" },
    P: { icon: AlertCircle, color: "text-amber-500 bg-amber-50", label: "Partial", desc: "Mapping in progress, some columns matched" },
    I: { icon: XCircle, color: "text-red-500 bg-red-50", label: "Incomplete", desc: "No columns matched yet" }
  };
  
  const config = configs[status];
  const Icon = config.icon;
  
  return (
    <Tooltip>
        <TooltipTrigger 
          render={(triggerProps) => (
            <div {...triggerProps} className={cn("w-5 h-5 rounded-full flex items-center justify-center transition-all", config.color)}>
              <span className="text-[9px] font-black">{status}</span>
            </div>
          )}
        />
        <TooltipContent className="bg-slate-900 text-white border-none p-2 rounded-xl">
          <div className="space-y-1">
            <p className="font-black text-[10px] uppercase tracking-widest flex items-center gap-1.5">
              <Icon size={12} className={config.color.split(' ')[0]} />
              {config.label}
            </p>
            <p className="text-[9px] text-slate-400 leading-tight max-w-[150px]">{config.desc}</p>
          </div>
        </TooltipContent>
      </Tooltip>
  );
};

const DashboardView = React.memo(({ 
  dashboard, 
  filters, 
  setFilters,
  companyName
}: { 
  dashboard: DashboardModel, 
  filters: Record<string, string>,
  setFilters: React.Dispatch<React.SetStateAction<Record<string, string>>>,
  companyName: string
}) => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 bg-white p-8 rounded-xl border border-slate-400">
      {/* Visual Dashboard Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-slate-100">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-slate-500">
            <LayoutDashboard size={16} />
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">Dashboard Simulator</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-primary uppercase tracking-widest mb-1">{companyName || "Analytics Platform"}</span>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">{dashboard.name}</h2>
          </div>
          <p className="text-slate-500 text-sm max-w-2xl font-medium leading-relaxed">{dashboard.description}</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="bg-slate-50 text-slate-600 border-slate-200 font-bold px-3 py-1">
            <Database size={12} className="mr-2" />
            Star Schema Verified
          </Badge>
          <Badge variant="outline" className="bg-slate-50 text-slate-600 border-slate-200 font-bold px-3 py-1">
            <Image size={12} className="mr-2" />
            Static Assets
          </Badge>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center gap-4 py-4">
        {dashboard.filters.map(filter => (
          <div key={filter.id} className="flex flex-col gap-1.5">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest ml-1">{filter.label}</span>
            <Select 
              value={filters[filter.id] || ""} 
              onValueChange={(val) => setFilters(prev => ({ ...prev, [filter.id]: val }))}
            >
              <SelectTrigger className="w-[180px] bg-white border-slate-400 text-slate-900 h-9 rounded-md font-medium text-xs">
                <div className="flex items-center gap-2">
                  <Filter size={12} className="text-slate-400" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                {filter.options.map(opt => (
                  <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ))}
        <div className="ml-auto">
          <Button variant="outline" size="sm" className="h-9 gap-2 border-transparent text-slate-600 font-bold hover:bg-slate-50 transition-all">
            <Download size={14} />
            Export Data
          </Button>
        </div>
      </div>

      {/* Widgets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
        {dashboard.widgets.map((widget, idx) => (
          <Card 
            key={widget.id} 
            className={cn(
              "bg-white border-slate-200 shadow-sm overflow-hidden flex flex-col transition-all",
              widget.type === 'table' ? "lg:col-span-12" : widget.type === 'metric' ? "lg:col-span-3" : "lg:col-span-6"
            )}
          >
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0 border-b border-slate-50">
              <CardTitle className="text-[10px] font-bold text-slate-500 tracking-wider flex items-center gap-2">
                {widget.type === 'metric' && <Activity size={14} className="text-slate-400" />}
                {widget.type === 'chart' && widget.chartType === 'bar' && <BarChart3 size={14} className="text-slate-400" />}
                {widget.type === 'chart' && widget.chartType === 'line' && <LineChart size={14} className="text-slate-400" />}
                {widget.type === 'chart' && widget.chartType === 'pie' && <PieChart size={14} className="text-slate-400" />}
                {widget.type === 'chart' && widget.chartType === 'area' && <Sparkles size={14} className="text-slate-400" />}
                {widget.type === 'table' && <Database size={14} className="text-slate-400" />}
                {widget.type === 'image' && <Image size={14} className="text-slate-400" />}
                {widget.title}
              </CardTitle>
              <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-300">
                <Info size={10} />
              </Button>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-hidden">
              {widget.imageUrl ? (
                <div className="w-full h-[300px] relative bg-slate-50">
                  <img 
                    src={widget.imageUrl} 
                    alt={widget.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
                </div>
              ) : widget.type === 'metric' ? (
                <div className="h-full flex flex-col justify-center p-6">
                  <div className="text-4xl font-bold text-slate-900 tracking-tight mb-1">
                    {widget.metricValue || '0'}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-emerald-600 font-bold">+12.5%</span>
                    <span className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">{widget.metricLabel || 'vs last period'}</span>
                  </div>
                </div>
              ) : widget.type === 'chart' ? (
                <div className="h-[300px] w-full relative p-6">
                  {!widget.data || widget.data.length === 0 ? (
                    <div className="absolute inset-0 flex items-center justify-center text-slate-400 text-xs italic">
                      No data available
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height={300}>
                      {widget.chartType === 'bar' ? (
                        <ReBarChart data={widget.data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                          <XAxis 
                            dataKey="name" 
                            stroke="#94a3b8" 
                            fontSize={10} 
                            tickLine={false} 
                            axisLine={false} 
                            dy={10}
                          />
                          <YAxis 
                            stroke="#94a3b8" 
                            fontSize={10} 
                            tickLine={false} 
                            axisLine={false} 
                          />
                          <ChartTooltip 
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '4px', fontSize: '12px' }}
                            isAnimationActive={false}
                          />
                          <ReBar dataKey="value" fill="#334155" radius={[2, 2, 0, 0]} barSize={24} isAnimationActive={false} />
                        </ReBarChart>
                      ) : widget.chartType === 'line' ? (
                        <ReLineChart data={widget.data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                          <XAxis 
                            dataKey="name" 
                            stroke="#94a3b8" 
                            fontSize={10} 
                            tickLine={false} 
                            axisLine={false} 
                            dy={10}
                          />
                          <YAxis 
                            stroke="#94a3b8" 
                            fontSize={10} 
                            tickLine={false} 
                            axisLine={false} 
                          />
                          <ChartTooltip 
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '4px', fontSize: '12px' }}
                            isAnimationActive={false}
                          />
                          <Line type="monotone" dataKey="value" stroke="#334155" strokeWidth={2} dot={{ r: 3, fill: '#334155' }} activeDot={{ r: 5 }} isAnimationActive={false} />
                        </ReLineChart>
                      ) : widget.chartType === 'area' ? (
                        <AreaChart data={widget.data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id={`color${idx}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#334155" stopOpacity={0.1}/>
                              <stop offset="95%" stopColor="#334155" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                          <XAxis 
                            dataKey="name" 
                            stroke="#94a3b8" 
                            fontSize={10} 
                            tickLine={false} 
                            axisLine={false} 
                            dy={10}
                          />
                          <YAxis 
                            stroke="#94a3b8" 
                            fontSize={10} 
                            tickLine={false} 
                            axisLine={false} 
                          />
                          <ChartTooltip 
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '4px', fontSize: '12px' }}
                            isAnimationActive={false}
                          />
                          <Area type="monotone" dataKey="value" stroke="#334155" strokeWidth={2} fillOpacity={1} fill={`url(#color${idx})`} isAnimationActive={false} />
                        </AreaChart>
                      ) : (
                        <RePieChart>
                          <Pie
                            data={widget.data}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={4}
                            dataKey="value"
                            isAnimationActive={false}
                          >
                            {widget.data.map((_, index) => (
                              <ReCell key={`cell-${index}`} fill={['#0f172a', '#334155', '#64748b', '#94a3b8'][index % 4]} />
                            ))}
                          </Pie>
                          <ChartTooltip 
                            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '4px', fontSize: '12px' }}
                            isAnimationActive={false}
                          />
                        </RePieChart>
                      )}
                    </ResponsiveContainer>
                  )}
                </div>
              ) : (
                <div className="mt-2 border border-slate-100 rounded-md overflow-hidden p-6">
                  {!widget.data || widget.data.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs italic">
                      No table data available
                    </div>
                  ) : (
                    <Table>
                      <TableHeader className="bg-slate-50">
                        <TableRow className="hover:bg-transparent border-slate-100">
                          {widget.columns?.map(col => (
                            <TableHead key={col} className="text-[9px] font-bold uppercase tracking-widest text-slate-500 py-2">{col}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {widget.data.slice(0, 5).map((row, i) => (
                          <TableRow key={i} className="border-slate-50 hover:bg-slate-50/50">
                            {widget.columns?.map(col => (
                              <TableCell key={col} className="text-[11px] text-slate-600 py-2">{row[col]}</TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
});

const STTMView = React.memo(({ 
  mapping, 
  targetTable, 
  viewMode,
  elapsedTime = 0,
  onCopy,
  onExportCSV,
  onExportExcel,
  onClearMapping,
  onDelete
}: { 
  mapping: STTMMapping, 
  targetTable: TableModel, 
  viewMode: 'target-to-source' | 'source-to-target',
  elapsedTime?: number,
  onCopy?: () => void,
  onExportCSV?: () => void,
  onExportExcel?: () => void,
  onClearMapping?: (targetColumnName: string) => void,
  onDelete?: () => void
}) => {
  const targetCols = targetTable.columns;
  
  const getSourceForTarget = (targetColName: string) => {
    return mapping.mappings.find(m => m.targetColumnName === targetColName)?.source;
  };

  const renderTargetCells = (col: any, isLast: boolean) => {
    const isAudit = col.columnName.startsWith('sys_');
    const isKey = col.isPk || col.fkTo;
    const dividerClass = isLast ? "border-r-4 border-slate-800" : "border-r border-slate-100";
    
    return (
      <>
        <TableCell className={cn(
          "font-mono text-[9px] py-1 px-3 transition-colors",
          col.isPk ? "text-primary font-bold bg-primary/5" : (targetTable.tableType === 'Fact' && col.fkTo) ? "text-slate-900 font-black bg-white" : "text-slate-600 font-medium bg-white",
          "border-r border-slate-100 h-8"
        )}>
          <div className="flex items-center gap-1.5">
            {col.isPk ? <Key size={10} className="text-primary" /> : col.fkTo ? <Link2 size={10} className="text-blue-600" /> : <div className="w-[10px]" />}
            {col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName}
          </div>
        </TableCell>
        <TableCell className={cn("text-[10px] font-bold py-1 px-3 border-r border-slate-100 h-8", col.isPk ? "bg-primary/5 text-slate-900" : isKey ? "bg-white text-slate-900" : isAudit ? "bg-white text-slate-400" : "bg-white text-slate-600")}>{col.businessName}</TableCell>
        <TableCell className={cn("text-[9px] leading-tight py-1 px-3 border-r border-slate-100 max-w-[150px] truncate bg-white h-8", isAudit ? "text-slate-300" : "text-slate-500")} title={col.description}>{col.description}</TableCell>
        <TableCell className={cn("py-1 px-3 border-r border-slate-100 bg-white h-8")}>
          <Badge variant="outline" className="font-mono text-[8px] h-4 bg-white border-slate-200 text-slate-400 px-1">{col.datatype}</Badge>
        </TableCell>
        <TableCell className={cn("text-[9px] text-slate-500 font-mono py-1 px-3 border-r border-slate-100 bg-white h-8")}>{col.size}</TableCell>
        <TableCell className={cn("text-center py-1 px-3 border-r border-slate-100 h-8", col.isPk ? "bg-primary/5" : "bg-white")}>
          {col.isPk ? (
            <Badge className="bg-primary text-white border-none text-[8px] font-black h-3.5 px-1 p-0 flex items-center justify-center">PK</Badge>
          ) : (
            <span className="text-slate-300">—</span>
          )}
        </TableCell>
        <TableCell className={cn("py-1 px-3 border-r border-slate-100 bg-white h-8")}>
          {col.fkTo ? (
            <div className="flex items-center gap-1.5 text-blue-600">
              <Link2 size={9} />
              <span className="text-[9px] font-bold font-mono">{col.fkTo}</span>
            </div>
          ) : (
            <span className="text-slate-300">—</span>
          )}
        </TableCell>
        <TableCell className={cn("text-center py-1 px-3 border-r border-slate-100 bg-white h-8")}>
          <span className={cn(
            "text-[8px] font-black uppercase tracking-widest",
            col.isNullable ? "text-slate-400" : "text-slate-600"
          )}>
            {col.isNullable ? 'YES' : 'NO'}
          </span>
        </TableCell>
        <TableCell className={cn("py-1 px-3 text-[9px] text-slate-500 font-mono border-r border-slate-100 bg-white h-8")}>{col.defaultValue || <span className="text-slate-300">—</span>}</TableCell>
        <TableCell className={cn("py-1 px-3 text-[9px] text-slate-500 font-mono italic bg-white h-8", dividerClass)}>{col.exampleValues || 'N/A'}</TableCell>
      </>
    );
  };

  const renderSourceCells = (source: any, isLast: boolean, targetColumnName: string) => {
    const dividerClass = isLast ? "border-r-4 border-slate-800" : "border-r border-slate-100";
    return (
      <>
        <TableCell className={cn("bg-white text-[9px] py-1 px-3 text-slate-600 border-r border-slate-100 font-mono h-8")}>{source?.sourceSystem || <span className="text-slate-300">—</span>}</TableCell>
        <TableCell className={cn("bg-white text-[9px] py-1 px-3 text-slate-600 border-r border-slate-100 font-mono h-8")}>{source?.sourceSchema || <span className="text-slate-300">—</span>}</TableCell>
        <TableCell className={cn("bg-white text-[9px] py-1 px-3 text-slate-600 border-r border-slate-100 font-mono h-8")}>{source?.sourceTable || <span className="text-slate-300">—</span>}</TableCell>
        <TableCell className={cn("bg-white text-[9px] py-1 px-3 font-bold text-slate-900 border-r border-slate-100 font-mono h-8")}>{source?.sourceFieldName || <span className="text-slate-300">—</span>}</TableCell>
        <TableCell className={cn("bg-white text-[9px] py-1 px-3 border-r border-slate-100 h-8")}>
           <Badge variant="outline" className="font-mono text-[8px] h-4 bg-white border-slate-200 text-slate-400 px-1">{source?.sourceDatatype || 'N/A'}</Badge>
        </TableCell>
        <TableCell className={cn("bg-white text-[9px] py-1 px-3 text-slate-600 font-medium relative group leading-tight h-8", dividerClass)}>
          <div className="flex items-center justify-between gap-2 max-w-[200px]">
            <span className="truncate">{source?.etlRules || ''}</span>
            {onClearMapping && source && (source.sourceFieldName || source.sourceTable) && (
              <Button
                variant="ghost"
                size="icon"
                className="h-5 w-5 text-slate-300 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all rounded-md"
                onClick={() => onClearMapping(targetColumnName)}
                title="Clear Mapping"
              >
                <Eraser size={10} />
              </Button>
            )}
          </div>
        </TableCell>
      </>
    );
  };

  return (
    <div className="w-full bg-white rounded-xl border border-slate-400 shadow-sm overflow-hidden">
      <div className="bg-slate-50 p-6 border-b border-slate-200 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-xl text-primary">
            <ArrowRightLeft size={20} />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 tracking-tight uppercase">Mapping: {targetTable.tableName}</h3>
            <p className="text-xs text-slate-500 font-medium">Source-to-Target Mapping Definitions</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {!mapping.isGenerating && (
            <div className="flex items-center gap-1 mr-2 px-1.5 py-1 bg-white rounded-lg border border-slate-200 shadow-sm">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 text-slate-500 hover:text-primary hover:bg-slate-50 transition-all rounded-md"
                onClick={onCopy}
                title="Copy STTM to Clipboard"
              >
                <Copy size={14} />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 text-slate-500 hover:text-emerald-600 hover:bg-slate-50 transition-all rounded-md"
                onClick={onExportCSV}
                title="Export to CSV"
              >
                <FileText size={14} />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 text-slate-500 hover:text-blue-600 hover:bg-slate-50 transition-all rounded-md"
                onClick={onExportExcel}
                title="Export to Excel"
              >
                <TableIcon size={14} />
              </Button>
              {onDelete && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-7 w-7 text-slate-500 hover:text-red-600 hover:bg-slate-50 transition-all rounded-md"
                  onClick={onDelete}
                  title="Delete Mapping"
                >
                  <Trash2 size={14} />
                </Button>
              )}
            </div>
          )}
          {mapping.isGenerating && (
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-end">
                <span className="text-[10px] font-black text-primary uppercase tracking-widest animate-pulse">Mapping in Progress...</span>
                <span className="text-[9px] font-mono text-slate-400">{elapsedTime}s elapsed</span>
              </div>
              <div className="w-32 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-primary"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 30, ease: "linear" }}
                />
              </div>
            </div>
          )}
          <Badge className={cn(
            "border-none px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase",
            mapping.isGenerating ? "bg-amber-500 text-white" : "bg-emerald-500 text-white"
          )}>
            {mapping.isGenerating ? 'Generating' : 'Mapped'}
          </Badge>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="border-b-4 border-slate-800">
            <TableRow className="hover:bg-transparent border-none">
              {viewMode === 'target-to-source' ? (
                <>
                  <TableHead colSpan={10} className="bg-emerald-100/50 text-emerald-900 text-[10px] font-black tracking-widest text-center border-r-4 border-slate-800 py-3">Target</TableHead>
                  <TableHead colSpan={6} className="bg-orange-100/50 text-orange-900 text-[10px] font-black tracking-widest text-center py-3">Source</TableHead>
                </>
              ) : (
                <>
                  <TableHead colSpan={6} className="bg-orange-100/50 text-orange-900 text-[10px] font-black tracking-widest text-center border-r-4 border-slate-800 py-3">Source</TableHead>
                  <TableHead colSpan={10} className="bg-emerald-100/50 text-emerald-900 text-[10px] font-black tracking-widest text-center py-3">Target</TableHead>
                </>
              )}
            </TableRow>
            <TableRow className="hover:bg-transparent border-none">
              {viewMode === 'target-to-source' ? (
                <>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Col Name</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Display Name</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Description</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Datatype</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Size</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">PK</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">FK To</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">NULL?</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Default</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r-4 border-slate-800">Example</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">System</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Schema</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Table</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Field</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Datatype</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80">ETL Rules</TableHead>
                </>
              ) : (
                <>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">System</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Schema</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Table</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Field</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r border-orange-100">Datatype</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-orange-700 bg-orange-50/80 border-r-4 border-slate-800">ETL Rules</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Col Name</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Display Name</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Description</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Datatype</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Size</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">PK</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">FK To</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">NULL?</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80 border-r border-emerald-100">Default</TableHead>
                  <TableHead className="text-[9px] font-bold tracking-widest text-emerald-700 bg-emerald-50/80">Example</TableHead>
                </>
              )}
            </TableRow>
          </TableHeader>
          <TableBody>
            {targetCols.map((col, i) => {
              const source = getSourceForTarget(col.columnName);
              return (
                <TableRow key={i} className="border-slate-100 hover:bg-slate-50/30 transition-colors h-8">
                  {viewMode === 'target-to-source' ? (
                    <>
                      {renderTargetCells(col, true)}
                      {renderSourceCells(source, false, col.columnName)}
                    </>
                  ) : (
                    <>
                      {renderSourceCells(source, true, col.columnName)}
                      {renderTargetCells(col, false)}
                    </>
                  )}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
});

const StepIcon = ({ number, active }: { number: number, active: boolean }) => (
  <div className={cn(
    "w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black transition-all duration-300",
    active ? "bg-white text-primary shadow-sm" : "bg-slate-200 text-slate-500"
  )}>
    {number}
  </div>
);

const HistoryItem = React.memo(({ 
  item, 
  isActive, 
  isMapped,
  onClick, 
  onDelete,
  onShowSTTM,
  onDeleteSTTM,
  showDelete = true
}: { 
  item: TableModel, 
  isActive: boolean, 
  isMapped: boolean,
  onClick: () => void, 
  onDelete: (e: React.MouseEvent) => void,
  onShowSTTM?: (e: React.MouseEvent) => void,
  onDeleteSTTM?: (e: React.MouseEvent) => void,
  showDelete?: boolean
}) => (
  <div 
    className={cn(
      "group p-3 rounded-xl border transition-all cursor-pointer relative flex items-center justify-between",
      isActive 
        ? "bg-primary border-primary shadow-lg shadow-primary/20" 
        : "bg-white border-slate-200 hover:border-primary/50 hover:bg-slate-50"
    )}
    onClick={onClick}
  >
    <div className="flex items-center gap-3 overflow-hidden">
      <div className={cn(
        "w-9 h-9 rounded-lg flex items-center justify-center shrink-0 shadow-sm relative",
        isActive ? "bg-white/20 text-white" : "bg-slate-100 text-primary"
      )}>
        {item.tableType === 'Dimension' ? <Layout size={16} /> : <Database size={16} />}
      </div>
      <div className="flex flex-col overflow-hidden">
        <span className={cn(
          "text-xs font-black truncate tracking-tight",
          isActive ? "text-white" : "text-slate-900"
        )}>
          {item.tableName}
        </span>
        <div className="flex items-center gap-1.5">
          <Badge className={cn(
            "text-[8px] px-1 h-3.5 font-black uppercase tracking-widest",
            isActive ? "bg-white/20 text-white border-transparent" : "bg-primary/10 text-primary border-transparent"
          )}>
            {item.tableType === 'Dimension' ? 'DIM' : 'FACT'}
          </Badge>
          <span className={cn(
            "text-[9px] font-bold truncate",
            isActive ? "text-blue-100" : "text-slate-400"
          )}>
            {item.industry}
          </span>
        </div>
      </div>
    </div>
    <div className="flex items-center gap-2 relative z-30">
      {isMapped && (
        <div className="flex items-center gap-2 mr-2">
          <STTMStatusIcon status={isActive ? 'C' : item.sttmStatus || 'I'} />
          <div className="h-4 w-px bg-slate-200" />
        </div>
      )}
      {isMapped && (
        <div className="flex items-center gap-1">
          <button 
            onClick={onShowSTTM}
            className={cn(
              "p-1.5 rounded-md transition-all cursor-pointer",
              isActive ? "bg-white/20 text-white" : "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"
            )}
            title="View STTM Mapping"
          >
            <ArrowRightLeft size={12} />
          </button>
          <button 
            onClick={onDeleteSTTM}
            className={cn(
              "p-1.5 rounded-md transition-all cursor-pointer opacity-0 group-hover:opacity-100",
              isActive ? "hover:bg-white/20 text-white" : "hover:bg-red-50 text-slate-400 hover:text-red-600"
            )}
            title="Delete STTM Mapping"
          >
            <Trash2 size={12} />
          </button>
        </div>
      )}
      {showDelete && (
        <button 
          onClick={onDelete}
          className={cn(
            "opacity-0 group-hover:opacity-100 p-1.5 rounded-md transition-all cursor-pointer",
            isActive ? "hover:bg-white/20 text-white" : "hover:bg-red-50 text-slate-400 hover:text-red-600"
          )}
          title="Delete"
        >
          <Trash2 size={12} />
        </button>
      )}
    </div>
  </div>
));

const DashboardItem = React.memo(({ 
  dash, 
  isActive, 
  onClick, 
  onDelete,
  showDelete = true
}: { 
  dash: DashboardModel, 
  isActive: boolean, 
  onClick: () => void, 
  onDelete: (e: React.MouseEvent) => void,
  showDelete?: boolean
}) => (
  <div 
    className={cn(
      "group p-3 rounded-xl border transition-all cursor-pointer relative flex items-center justify-between",
      isActive 
        ? "bg-primary border-primary shadow-lg shadow-primary/20" 
        : "bg-white border-slate-200 hover:border-primary/50 hover:bg-slate-50"
    )}
    onClick={onClick}
  >
    <div className="flex items-center gap-3 overflow-hidden">
      <div className={cn(
        "w-9 h-9 rounded-lg flex items-center justify-center shrink-0 shadow-sm",
        isActive ? "bg-white/20 text-white" : "bg-slate-100 text-primary"
      )}>
        <LayoutDashboard size={16} />
      </div>
      <div className="flex flex-col overflow-hidden">
        <span className={cn(
          "text-xs font-black truncate tracking-tight",
          isActive ? "text-white" : "text-slate-900"
        )}>
          {dash.name}
        </span>
        <div className="flex items-center gap-1.5">
          <Badge className={cn(
            "text-[8px] px-1 h-3.5 font-black uppercase tracking-widest",
            isActive ? "bg-white/20 text-white border-transparent" : "bg-emerald-500/20 text-emerald-600 border-transparent"
          )}>
            LIVE
          </Badge>
          <span className={cn(
            "text-[9px] font-bold truncate",
            isActive ? "text-blue-100" : "text-slate-400"
          )}>
            Simulator
          </span>
        </div>
      </div>
    </div>
    {showDelete && (
      <button 
        onClick={onDelete}
        className={cn(
          "opacity-0 group-hover:opacity-100 p-1.5 rounded-md transition-all relative z-30 cursor-pointer",
          isActive ? "hover:bg-white/20 text-white" : "hover:bg-red-50 text-slate-400 hover:text-red-600"
        )}
        title="Delete"
      >
        <Trash2 size={12} />
      </button>
    )}
  </div>
));

const STTMItem = React.memo(({ 
  mapping, 
  targetTable,
  isActive, 
  onClick, 
  onDelete,
  sttmStatus
}: { 
  mapping: STTMMapping, 
  targetTable: TableModel,
  isActive: boolean, 
  onClick: () => void, 
  onDelete: (e: React.MouseEvent) => void,
  sttmStatus?: 'C' | 'P' | 'I'
}) => (
  <div 
    className={cn(
      "group p-3 rounded-xl border transition-all cursor-pointer relative flex items-center justify-between",
      isActive 
        ? "bg-emerald-600 border-emerald-600 shadow-lg shadow-emerald-200" 
        : "bg-white border-slate-200 hover:border-emerald-500/50 hover:bg-emerald-50/30"
    )}
    onClick={onClick}
  >
    <div className="flex items-center gap-3 overflow-hidden">
      <div className={cn(
        "w-9 h-9 rounded-lg flex items-center justify-center shrink-0 shadow-sm relative",
        isActive ? "bg-white/20 text-white" : "bg-emerald-100 text-emerald-600"
      )}>
        <ArrowRightLeft size={16} />
      </div>
      <div className="flex flex-col overflow-hidden">
        <span className={cn(
          "text-xs font-black truncate tracking-tight",
          isActive ? "text-white" : "text-slate-900"
        )}>
          STTM: {targetTable.tableName}
        </span>
        <div className="flex items-center gap-1.5">
          <Badge className={cn(
            "text-[8px] px-1.5 h-3.5 font-black uppercase tracking-widest",
            isActive ? "bg-white/20 text-white border-transparent" : "bg-emerald-100 text-emerald-700 border-transparent"
          )}>
            MAPPING
          </Badge>
          <span className={cn(
            "text-[9px] font-bold truncate",
            isActive ? "text-emerald-100" : "text-slate-400"
          )}>
            {targetTable.industry}
          </span>
        </div>
      </div>
    </div>
    <div className="flex items-center gap-2 relative z-30">
      {sttmStatus && (
        <>
          <STTMStatusIcon status={sttmStatus} />
          <div className="h-4 w-px bg-slate-200" />
        </>
      )}
      <button 
        onClick={onDelete}
        className={cn(
          "opacity-0 group-hover:opacity-100 p-1.5 rounded-md transition-all cursor-pointer",
          isActive ? "hover:bg-white/20 text-white" : "hover:bg-red-50 text-slate-400 hover:text-red-600"
        )}
        title="Delete Mapping"
      >
        <Trash2 size={12} />
      </button>
    </div>
  </div>
));

// Star Schema Diagram Component (ERD Style)
const StarSchemaDiagram = ({ 
  factTable, 
  dimensions, 
  onTableClick, 
  selectedTableId 
}: { 
  factTable: TableModel, 
  dimensions: TableModel[], 
  onTableClick?: (table: TableModel) => void,
  selectedTableId?: string
}) => {
  if (!factTable || !factTable.columns) return null;

  const exportToMermaid = () => {
    let mermaid = "erDiagram\n";
    
    // Add Fact Table
    const factName = (factTable.tableName || 'FactTable').replace(/\s+/g, '_');
      mermaid += `    ${factName} {\n`;
      factTable.columns.forEach(col => {
        const type = (col.datatype || 'VARCHAR').split('(')[0];
        let colName = (col.columnName || 'column').replace(/\s+/g, '_');
        if (colName.toLowerCase() === 'dw_id') colName = 'dw_key';
        mermaid += `        ${type} ${colName} ${col.isPk ? 'PK' : col.fkTo ? 'FK' : ''}\n`;
      });
      mermaid += "    }\n";

      // Add Dimensions and Relationships
      dimensions.forEach(dim => {
        if (!dim || !dim.tableName || !dim.columns) return;
        const dimName = dim.tableName.replace(/\s+/g, '_');
        mermaid += `    ${dimName} {\n`;
        dim.columns.forEach(col => {
          const type = (col.datatype || 'VARCHAR').split('(')[0];
          let colName = (col.columnName || 'column').replace(/\s+/g, '_');
          if (colName.toLowerCase() === 'dw_id') colName = 'dw_key';
          mermaid += `        ${type} ${colName} ${col.isPk ? 'PK' : ''}\n`;
        });
        mermaid += "    }\n";
      
      // Relationship
      mermaid += `    ${factName} }|--|| ${dimName} : "links to"\n`;
    });

    const blob = new Blob([mermaid], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${factTable.tableName}_ERD.mermaid`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyDiagramToClipboard = async () => {
    const element = document.getElementById(`star-schema-${factTable.id}`);
    if (!element) return;

    try {
      // Hide buttons temporarily for a clean screenshot
      const buttons = element.querySelectorAll('button');
      buttons.forEach(b => (b as HTMLElement).style.visibility = 'hidden');
      
      const dataUrl = await toPng(element, { 
        backgroundColor: '#ffffff',
        quality: 1,
        pixelRatio: 2 // High quality
      });
      
      // Restore buttons
      buttons.forEach(b => (b as HTMLElement).style.visibility = 'visible');

      const response = await fetch(dataUrl);
      const blob = await response.blob();
      
      if (typeof window.ClipboardItem !== "undefined") {
        const item = new ClipboardItem({ "image/png": blob });
        await navigator.clipboard.write([item]);
        toast.success("ERD Image copied to clipboard!");
      } else {
        // Fallback for browsers that don't support ClipboardItem
        toast.error("Clipboard Image API not supported in this browser.");
      }
    } catch (err) {
      console.error('Error copying ERD image:', err);
      toast.error("Failed to copy image to clipboard");
    }
  };

  return (
    <div 
      id={`star-schema-${factTable.id}`}
      className="w-full bg-white rounded-xl p-8 mb-8 border border-slate-200 shadow-sm relative overflow-hidden"
    >
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-slate-100 rounded-lg">
            <Database size={18} className="text-slate-600" />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Technical View</span>
            <span className="text-lg font-bold text-slate-900 tracking-tight">
              ERD: {factTable.tableName}
            </span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={exportToMermaid}
            className="text-[10px] font-bold uppercase tracking-wider h-8 gap-2 border-slate-200"
          >
            <Download size={14} />
            Export to Lucidchart/Visio (Mermaid)
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={copyDiagramToClipboard}
            className="text-[10px] font-bold uppercase tracking-wider h-8 gap-2 border-slate-200"
          >
            <Copy size={14} />
            Copy Image
          </Button>
        </div>
      </div>

      <div className="relative flex flex-col items-center">
        <div className="flex flex-wrap justify-center items-center gap-16 lg:gap-24">
          {/* Dimensions Left */}
          <div className="flex flex-col gap-8">
            {dimensions.slice(0, Math.ceil(dimensions.length / 2)).map((dim, i) => (
              <motion.div 
                key={dim.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="relative"
              >
                <div 
                  onClick={() => onTableClick?.(dim)}
                  className={cn(
                    "bg-white border-2 rounded-sm w-48 shadow-sm overflow-hidden group transition-all cursor-pointer relative",
                    selectedTableId === dim.id ? "border-primary border-4 ring-8 ring-primary/20 z-30 scale-105" : "border-slate-800 hover:border-primary"
                  )}
                >
                  <div className={cn(
                    "p-2 flex items-center gap-2 transition-colors",
                    selectedTableId === dim.id ? "bg-primary text-white" : "bg-slate-800 text-white group-hover:bg-primary"
                  )}>
                    <Layout size={12} />
                    <span className="text-[10px] font-bold uppercase tracking-wider truncate">{dim.tableName}</span>
                  </div>
                  <div className="p-2 space-y-1">
                    {(dim.columns || []).filter(c => (c.isPk || c.columnName.toLowerCase().includes('id') || c.columnName.toLowerCase().includes('key')) && !c.columnName.startsWith('sys_')).map(col => {
                      const displayName = col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName;
                      return (
                        <div key={col.columnName} className="flex items-center justify-between text-[9px] border-b border-slate-100 last:border-0 pb-1">
                          <div className="flex items-center gap-1.5">
                            {col.isPk ? <Key size={8} className="text-slate-600" /> : <Link2 size={8} className="text-slate-400" />}
                            <span className="text-slate-900 font-mono font-medium text-[8px]">{displayName}</span>
                          </div>
                          <span className="text-[7px] font-bold text-slate-400 uppercase">{(col.datatype || 'VARCHAR').split('(')[0]}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                {/* Connector Line */}
                <div className="absolute top-1/2 -right-16 lg:-right-24 w-16 lg:w-24 h-px bg-slate-400">
                  <div className="absolute left-0 -top-1 w-2 h-2 border border-slate-400 bg-white rotate-45" />
                  <div className="absolute right-0 -top-2 flex flex-col gap-0.5">
                    <div className="w-3 h-px bg-slate-400 rotate-45" />
                    <div className="w-3 h-px bg-slate-400 -rotate-45" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Fact Table (Center) */}
          <motion.div 
            initial={{ scale: 0.98, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative z-20 cursor-pointer"
            onClick={() => onTableClick?.(factTable)}
          >
            <div className={cn(
              "bg-white border-2 rounded-sm w-64 shadow-md overflow-hidden transition-all relative z-40",
              selectedTableId === factTable.id ? "border-primary border-4 ring-8 ring-primary/20 scale-105" : "border-slate-900"
            )}>
              <div className={cn(
                "p-3 flex items-center justify-center gap-2 transition-colors",
                selectedTableId === factTable.id ? "bg-primary text-white" : "bg-slate-900 text-white"
              )}>
                <Layers size={16} />
                <h4 className="text-xs font-bold uppercase tracking-widest">{factTable.tableName}</h4>
              </div>
                  <div className="p-3 space-y-3">
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Keys</span>
                      {(factTable.columns || []).filter(c => (c.isPk || c.fkTo) && c.columnName !== 'dw_key').map(col => {
                        const displayName = col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName;
                        return (
                          <div key={col.columnName} className="flex items-center justify-between text-[10px] border-b border-slate-100 pb-1">
                            <div className="flex items-center gap-2">
                              {col.isPk ? <Key size={10} className="text-slate-600" /> : <ArrowRight size={10} className="text-slate-400" />}
                              <span className="text-slate-900 font-mono font-black text-[8px]">{displayName}</span>
                            </div>
                            <span className="text-[7px] font-bold text-slate-400">{col.isPk ? 'PK' : 'FK'}</span>
                          </div>
                        );
                      })}
                    </div>
                
                <div className="space-y-1">
                  <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Measures</span>
                  {(factTable.columns || []).filter(c => !c.isPk && !c.fkTo && !c.columnName.startsWith('sys_')).slice(0, 6).map(col => (
                    <div key={col.columnName} className="flex items-center justify-between text-[9px] border-b border-slate-50 pb-1">
                      <span className="text-slate-600 font-mono text-[8px]">{col.columnName}</span>
                      <span className="text-[7px] text-slate-400 font-bold uppercase">{(col.datatype || 'VARCHAR').split('(')[0]}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Dimensions Right */}
          <div className="flex flex-col gap-8">
            {dimensions.slice(Math.ceil(dimensions.length / 2)).map((dim, i) => (
              <motion.div 
                key={dim.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: (i + dimensions.length/2) * 0.05 }}
                className="relative"
              >
                {/* Connector Line */}
                <div className="absolute top-1/2 -left-16 lg:-left-24 w-16 lg:w-24 h-px bg-slate-400">
                  <div className="absolute right-0 -top-1 w-2 h-2 border border-slate-400 bg-white rotate-45" />
                  <div className="absolute left-0 -top-2 flex flex-col gap-0.5">
                    <div className="w-3 h-px bg-slate-400 rotate-45" />
                    <div className="w-3 h-px bg-slate-400 -rotate-45" />
                  </div>
                </div>
                <div 
                  onClick={() => onTableClick?.(dim)}
                  className={cn(
                    "bg-white border-2 rounded-sm w-48 shadow-sm overflow-hidden group transition-all cursor-pointer relative",
                    selectedTableId === dim.id ? "border-primary border-4 ring-8 ring-primary/20 z-30 scale-105" : "border-slate-800 hover:border-primary"
                  )}
                >
                  <div className={cn(
                    "p-2 flex items-center gap-2 transition-colors",
                    selectedTableId === dim.id ? "bg-primary text-white" : "bg-slate-800 text-white group-hover:bg-primary"
                  )}>
                    <Layout size={12} />
                    <span className="text-[10px] font-bold uppercase tracking-wider truncate">{dim.tableName}</span>
                  </div>
                  <div className="p-2 space-y-1">
                    {(dim.columns || []).filter(c => (c.isPk || c.columnName.toLowerCase().includes('id') || c.columnName.toLowerCase().includes('key')) && !c.columnName.startsWith('sys_')).map(col => {
                      const displayName = col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName;
                      return (
                        <div key={col.columnName} className="flex items-center justify-between text-[9px] border-b border-slate-100 last:border-0 pb-1">
                          <div className="flex items-center gap-1.5">
                            {col.isPk ? <Key size={8} className="text-slate-600" /> : <Link2 size={8} className="text-slate-400" />}
                            <span className="text-slate-900 font-mono font-medium text-[8px]">{displayName}</span>
                          </div>
                          <span className="text-[7px] font-bold text-slate-400 uppercase">{(col.datatype || 'VARCHAR').split('(')[0]}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * Documentation & Visual Guide Component
 */
const DocumentationDialog = ({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[90vw] sm:max-w-[90vw] lg:max-w-6xl w-full h-[92vh] p-0 overflow-hidden rounded-[2.5rem] border-none shadow-2xl bg-white text-slate-900 border-slate-200">
        <div className="flex flex-col h-full bg-white relative">
          {/* Header */}
          <div className="px-8 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white shadow-lg">
                <BookOpen size={18} />
              </div>
              <div>
                <h3 className="font-black text-slate-900 tracking-tight text-lg uppercase tracking-wider">Solution Documentation</h3>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Version 1.3 • Visual Interface Callouts</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="rounded-full h-10 w-10 text-slate-400 hover:text-slate-900 hover:bg-slate-100 transition-colors">
              <X size={20} />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-0 scroll-smooth custom-scrollbar">
            <div className="p-8 md:p-16 space-y-24 max-w-5xl mx-auto pb-40">
              {/* Hero Section */}
              <div className="relative overflow-hidden rounded-[3rem] bg-slate-900 p-12 md:p-24 text-white shadow-2xl">
                <div className="absolute top-0 right-0 -mr-20 -mt-20 h-96 w-96 rounded-full bg-primary/30 blur-[120px]" />
                <div className="absolute bottom-0 left-0 -ml-20 -mb-20 h-96 w-96 rounded-full bg-blue-600/20 blur-[120px]" />
                
                <div className="relative z-10 max-w-2xl">
                  <Badge className="mb-8 bg-primary text-white border-none px-5 py-2 text-[11px] font-black uppercase tracking-[0.2em] shadow-lg shadow-primary/20">
                    Onboarding Guide
                  </Badge>
                  <h1 className="mb-8 text-6xl md:text-7xl font-black text-white tracking-tighter leading-[0.85]">
                    Mastering <br/><span className="text-primary tracking-widest uppercase">Asset Builder</span>
                  </h1>
                  <p className="text-xl text-slate-200 font-medium leading-relaxed max-w-xl">
                    A comprehensive walk-through of the interface, core concepts, and data architect workflows for the Modern Data Platform.
                  </p>
                </div>
              </div>

              {/* Interface Callout Map (Visual Guide Section) */}
              <section id="visual-guide" className="space-y-12 bg-slate-50/80 rounded-[3rem] p-12 border border-slate-200 shadow-inner">
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="flex h-14 w-14 items-center justify-center rounded-[1.5rem] bg-slate-900 text-white shadow-2xl">
                      <Search size={28} />
                    </div>
                    <div>
                      <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase">Visual Interface Callouts</h2>
                      <p className="text-slate-500 font-bold italic text-sm">Your roadmap to the primary application zones.</p>
                    </div>
                  </div>
                  <Separator className="bg-slate-200 h-0.5" />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
                  {/* Visual Simulation */}
                  <div className="relative bg-white border-2 border-slate-300 rounded-[2.5rem] p-8 shadow-[0_35px_60px_-15px_rgba(0,0,0,0.1)] overflow-hidden aspect-[16/10]">
                    <div className="w-full h-full flex flex-col gap-4">
                      {/* Top Bar */}
                      <div className="h-10 bg-slate-900 rounded-xl flex items-center px-6 justify-between relative">
                        <div className="w-28 h-2.5 bg-slate-700 rounded-full relative">
                          <div className="absolute -top-10 left-0 w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-sm font-black text-white shadow-xl border-4 border-white ring-8 ring-red-600/10">3</div>
                        </div>
                        <div className="w-20 h-2.5 bg-slate-700 rounded-full relative">
                          <div className="absolute -top-10 right-0 w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-sm font-black text-white shadow-xl border-4 border-white ring-8 ring-red-600/10">4</div>
                        </div>
                      </div>
                      
                      <div className="flex-1 flex gap-4">
                        {/* Sidebar */}
                        <div className="w-20 bg-slate-800 rounded-[1.5rem] p-3 space-y-6 relative">
                          <div className="h-14 rounded-full bg-slate-700 flex items-center justify-center relative">
                            <div className="absolute -top-3 -right-3 w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-sm font-black text-white shadow-xl border-4 border-white ring-8 ring-red-600/10">1</div>
                            <User size={24} className="text-slate-400" />
                          </div>
                          <div className="space-y-3">
                             <div className="h-8 bg-slate-700 rounded-lg relative">
                                <div className="absolute top-2 -right-5 w-8 h-8 bg-red-600 rounded-full flex items-center justify-center text-[10px] font-black text-white shadow-xl border-4 border-white ring-8 ring-red-600/10">2</div>
                             </div>
                             <div className="h-8 bg-slate-700 rounded-lg opacity-50" />
                          </div>
                        </div>
                        
                        {/* Content area */}
                        <div className="flex-1 flex flex-col gap-4">
                          <div className="flex-1 grid grid-cols-12 gap-4">
                            <div className="col-span-4 bg-slate-100 border border-slate-200 rounded-3xl relative p-6">
                               <div className="w-full h-5 bg-slate-200 rounded-full mb-3" />
                               <div className="w-3/4 h-4 bg-slate-200/50 rounded-full" />
                               <div className="absolute top-3 right-3 w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-sm font-black text-white shadow-xl border-4 border-white ring-8 ring-red-600/10">5</div>
                            </div>
                            <div className="col-span-8 bg-white border border-slate-200 rounded-3xl relative p-6 flex flex-col gap-4">
                               <div className="w-full flex justify-between">
                                 <div className="w-40 h-8 bg-slate-100 rounded-lg" />
                                 <div className="w-20 h-8 bg-primary/10 rounded-lg" />
                               </div>
                               <div className="flex-1 border-4 border-dashed border-slate-50 rounded-2xl flex items-center justify-center">
                                  <Share2 className="text-slate-100" size={60} />
                               </div>
                               <div className="absolute top-3 right-3 w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-sm font-black text-white shadow-xl border-4 border-white ring-8 ring-red-600/10">6</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Descriptions */}
                  <div className="space-y-8">
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase mb-6 flex items-center gap-3">
                      <div className="w-2 h-8 bg-primary rounded-full" />
                      Key Interface Zones
                    </h3>
                    <div className="grid grid-cols-1 gap-5">
                      {[
                        { num: '1', title: 'Persona Selector', desc: 'Determines your active workspace feature-set (Architect, Analyst, BD).' },
                        { num: '2', title: 'Navigation Tabs', desc: 'Direct access to your current role\'s primary assets and modeling tools.' },
                        { num: '3', title: 'Project Context', desc: 'The global selector for managing, creating, and naming your data projects.' },
                        { num: '4', title: 'Export & Backup', desc: 'Download your comprehensive model to Excel or save local JSON state backups.' },
                        { num: '5', title: 'Controls Panel', desc: 'The input area for generation settings, raw context, and AI research triggers.' },
                        { num: '6', title: 'Visualization stage', desc: 'Interactive star schemas, data tables, and dynamic registry visualizations.' },
                      ].map((item) => (
                        <div key={item.num} className="flex gap-6 items-start group p-4 rounded-2xl hover:bg-white transition-colors border border-transparent hover:border-slate-200 hover:shadow-sm">
                          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-red-600 text-white font-black text-lg shadow-xl group-hover:scale-110 transition-transform border-4 border-white ring-8 ring-red-600/10">{item.num}</div>
                          <div className="space-y-1">
                            <h4 className="font-black text-lg text-slate-900 tracking-tight uppercase tracking-wide">{item.title}</h4>
                            <p className="text-sm text-slate-600 font-bold leading-relaxed">{item.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              {/* Operations & Best Practices */}
              <section className="space-y-20">
                <div className="text-center space-y-6">
                  <Badge className="bg-slate-100 text-slate-900 px-4 py-1.5 font-black uppercase tracking-[0.2em] mb-4">Operations Blueprint</Badge>
                  <h2 className="text-5xl font-black text-slate-900 tracking-tighter uppercase">Step-by-Step Mastery</h2>
                  <p className="text-slate-500 max-w-2xl mx-auto font-bold text-lg">Follow this exact sequence to go from zero to a technical platform specification.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                  <div className="bg-slate-50 p-12 rounded-[3.5rem] border border-slate-200 shadow-sm relative group overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 group-hover:bg-primary/10 transition-colors" />
                    <div className="w-16 h-16 flex items-center justify-center bg-slate-900 text-white rounded-3xl mb-8 font-black text-2xl shadow-xl">01</div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase mb-6">Discovery</h3>
                    <p className="text-sm text-slate-600 font-bold leading-relaxed">
                      Define Industry and Company. Use **Opportunity Generation** to research the domain and set the foundation for your data model.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-12 rounded-[3.5rem] border border-slate-200 shadow-sm relative group overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16 group-hover:bg-blue-500/10 transition-colors" />
                    <div className="w-16 h-16 flex items-center justify-center bg-slate-900 text-white rounded-3xl mb-8 font-black text-2xl shadow-xl">02</div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase mb-6">Modeling</h3>
                    <p className="text-sm text-slate-600 font-bold leading-relaxed">
                      Build **Dimensions** followed by **Facts**. The system ensures Star Schema integrity by managing surrogate keys and table joins.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-12 rounded-[3.5rem] border border-slate-200 shadow-sm relative group overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-16 -mt-16 group-hover:bg-emerald-500/10 transition-colors" />
                    <div className="w-16 h-16 flex items-center justify-center bg-slate-900 text-white rounded-3xl mb-8 font-black text-2xl shadow-xl">03</div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase mb-6">Refining</h3>
                    <p className="text-sm text-slate-600 font-bold leading-relaxed">
                      Generate **STTM mappings** to define where source data comes from and how it transforms into your target star schema tables.
                    </p>
                  </div>
                </div>
              </section>

              {/* Persona Workflows */}
              <section className="bg-slate-900 rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(59,130,246,0.1),transparent)]" />
                <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
                  <div className="space-y-8">
                      <h2 className="text-4xl md:text-5xl font-black tracking-tighter leading-tight uppercase">Customized <span className="text-primary">Workflows</span> per Persona</h2>
                      <p className="text-slate-200 text-lg leading-relaxed font-bold">
                        The interface adapts to your role, showing only the tools you need for your current phase of the project.
                      </p>
                     <div className="space-y-4">
                        <div className="flex items-center gap-4 group">
                          <div className="h-2 w-2 rounded-full bg-primary" />
                          <span className="text-xs font-black uppercase tracking-widest">Architect: Technical Core Modeling</span>
                        </div>
                        <div className="flex items-center gap-4 group">
                          <div className="h-2 w-2 rounded-full bg-blue-500" />
                          <span className="text-xs font-black uppercase tracking-widest">Analyst: Gaps & Source Analysis</span>
                        </div>
                        <div className="flex items-center gap-4 group">
                          <div className="h-2 w-2 rounded-full bg-emerald-500" />
                          <span className="text-xs font-black uppercase tracking-widest">Analyst: Requirements & Business Value</span>
                        </div>
                     </div>
                  </div>
                  <div className="space-y-4">
                    <Card className="bg-white/10 border-white/20 p-6 rounded-2xl backdrop-blur-md">
                      <h4 className="text-white font-black uppercase text-xs tracking-widest mb-2">Did you know?</h4>
                      <p className="text-xs text-slate-200 leading-relaxed font-bold italic">You can export the entire architectural model to a professional Multi-Sheet Excel workbook directly from the header controls.</p>
                    </Card>
                    <Card className="bg-white/10 border-white/20 p-6 rounded-2xl backdrop-blur-md">
                      <h4 className="text-white font-black uppercase text-xs tracking-widest mb-2">Starred Gaps</h4>
                      <p className="text-xs text-slate-200 leading-relaxed font-bold italic">Items added to the Gap Registry in Analyst mode are visible to Architects to help them refine the target star schema.</p>
                    </Card>
                  </div>
                </div>
              </section>
            </div>
          </div>

          {/* Footer */}
          <div className="px-8 py-6 border-t border-slate-100 flex items-center justify-between bg-slate-50">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">© 2026 Paragon AI • v1.4</p>
            <Button 
                onClick={() => onOpenChange(false)}
                className="bg-slate-900 text-white hover:bg-slate-800 rounded-xl px-12 h-10 font-black uppercase tracking-[0.2em] text-[10px]"
              >
                Close Documentation
              </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const AdvancedQuestionnaireDialog = ({ 
  isOpen, 
  onClose, 
  data, 
  onChange, 
  onSave, 
  onClear,
  hasChanges
}: { 
  isOpen: boolean, 
  onClose: () => void, 
  data: AdvancedQuestionnaire, 
  onChange: (field: keyof AdvancedQuestionnaire, value: string) => void,
  onSave: () => void,
  onClear: () => void,
  hasChanges: boolean
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const sections = [
    {
      title: '1. Platform & Architecture',
      items: [
        { id: 'currentPlatforms', label: '1a. What data platforms and BI tools are currently in use?', placeholder: 'e.g., Teradata, Snowflake, Power BI...' },
        { id: 'hostingClouds', label: '1b. Which cloud(s) host the environment?', placeholder: 'e.g., Azure, AWS, GCP, Hybrid...' },
        { id: 'centralizedOrBu', label: '1c. Is the environment centralized or business-unit specific?', placeholder: 'e.g., Central IT, Federated, BU Managed...' },
        { id: 'envCount', label: '1d. How many environments exist (Dev/Test/Prod/DR)?', placeholder: 'e.g., 4: Dev, QA, Prod, DR...' },
      ]
    },
    {
      title: '2. Data Volumes & Storage',
      items: [
        { id: 'totalVolume', label: '2a. What is the current total data volume (TB/PB)?', placeholder: 'e.g., 500 TB total...' },
        { id: 'growthRate', label: '2b. What is the annual data growth rate?', placeholder: 'e.g., 20% growth per year...' },
        { id: 'activeVsArchived', label: '2c. How much data is actively queried vs archived?', placeholder: 'e.g., 30% Active, 70% Archived...' },
        { id: 'retentionBackup', label: '2d. What are the retention and backup requirements?', placeholder: 'e.g., 7 years retention, geo-redundant...' },
      ]
    },
    {
      title: '3. Data Ingestion & Integration',
      items: [
        { id: 'sourceSystemCount', label: '3a. How many source systems feed the platform?', placeholder: 'e.g., 15 JDBC, 5 API, 2 Streaming...' },
        { id: 'batchVsRealtime', label: '3b. What percentage of workloads are batch vs real-time?', placeholder: 'e.g., 80% Batch / 20% Real-time...' },
        { id: 'dailyIngestionVolume', label: '3c. What is the daily ingestion volume?', placeholder: 'e.g., 2 GB per day...' },
        { id: 'cdcStreaming', label: '3d. Are CDC/streaming integrations required?', placeholder: 'e.g., Debezium CDC for SQL DBs...' },
      ]
    },
    {
      title: '4. Compute & Processing',
      items: [
        { id: 'primaryWorkloads', label: '4a. What are the primary workloads (Reporting, ETL/ELT, Data Science/AI)?', placeholder: 'e.g., Reporting 60%, ETL 30%, AI 10%...' },
        { id: 'peakUsage', label: '4b. What are peak usage/concurrency patterns?', placeholder: 'e.g., 8 AM - 11 AM, ~50 concurrent users...' },
        { id: 'steadyVsVariable', label: '4c. Are workloads steady-state or highly variable?', placeholder: 'e.g., Variable during month-end close...' },
        { id: 'gpuAiReqs', label: '4d. Any GPU or advanced AI requirements?', placeholder: 'e.g., NVIDIA A100 for LLM fine-tuning...' },
      ]
    },
    {
      title: '5. BI & Consumption',
      items: [
        { id: 'totalBiUsers', label: '5a. How many total BI users?', placeholder: 'e.g., 250 Total BI users...' },
        { id: 'userBreakdown', label: '5b. What is the breakdown of viewers vs developers/power users?', placeholder: 'e.g., 200 Viewers, 50 Developers...' },
        { id: 'dashboardCount', label: '5c. How many dashboards/reports exist?', placeholder: 'e.g., 15 Operational Dashboards, 5 Executive Scorecards...' },
        { id: 'refreshFrequency', label: '5d. How frequently are reports refreshed?', placeholder: 'e.g., Hourly for ops, daily for finance...' },
      ]
    },
    {
      title: '6. Governance & Security',
      items: [
        { id: 'complianceReqs', label: '6a. Are there regulatory or compliance requirements?', placeholder: 'e.g., HIPAA compliant, SOX audited...' },
        { id: 'piiData', label: '6b. Is sensitive/PII data involved?', placeholder: 'e.g., Masking for PII, row-level security for HR data...' },
        { id: 'governanceTools', label: '6c. Are formal governance/catalog/lineage tools required?', placeholder: 'e.g., Microsoft Purview for cataloging...' },
        { id: 'drReplication', label: '6d. What are the DR and replication requirements?', placeholder: 'e.g., Cross-region replication for PROD...' },
      ]
    },
    {
      title: '7. Operating Model & Support',
      items: [
        { id: 'supportModel', label: '7a. What is the support model (internal vs managed services)?', placeholder: 'e.g., Internal IT for L1/L2...' },
        { id: 'support24x7', label: '7b. Is 24x7 support required?', placeholder: 'e.g., Yes for PROD environments...' },
        { id: 'teamSize', label: '7c. How large is the current data/analytics team?', placeholder: 'e.g., 4 Data Engineers, 2 BI Devs...' },
        { id: 'licensingAgreements', label: '7d. Are there existing enterprise/vendor licensing agreements?', placeholder: 'e.g., Microsoft EA with Azure credits...' },
      ]
    },
    {
      title: '8. Carveout / TSA-Specific',
      items: [
        { id: 'sharedWithParent', label: '8a. Are platforms shared with the parent company?', placeholder: 'e.g., Shared Azure client with parent co...' },
        { id: 'duplicateEnvs', label: '8b. Will temporary duplicate environments/licenses be needed?', placeholder: 'e.g., Yes, 3 months of overlap required...' },
        { id: 'day1Data', label: '8c. What data must transition on Day 1?', placeholder: 'e.g., Last 2 years of sales data...' },
        { id: 'tsaDuration', label: '8d. How long will TSA services remain in place?', placeholder: 'e.g., 6 months remaining on TSA...' },
      ]
    },
    {
      title: '9. Pricing & Spend',
      items: [
        { id: 'currentSpend', label: '9a. Current monthly cloud or platform spend (if known)?', placeholder: 'e.g., $15,000 / month...' },
        { id: 'pricingModel', label: '9b. Preferred pricing model (Consumption-based vs. Capacity-based)?', placeholder: 'e.g., Consumption (PAYG) preferred...' },
      ]
    }
  ];

  return (
    <>
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="max-w-[90vw] sm:max-w-4xl max-h-[90vh] flex flex-col p-0 border-none rounded-[2.5rem] overflow-hidden shadow-3xl bg-white text-slate-900">
          <DialogHeader className="p-8 pb-4 border-b border-slate-100 flex-shrink-0 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <DialogTitle className="text-2xl font-black text-slate-900 tracking-tight uppercase flex items-center gap-3 leading-none">
                  <div className="p-2 bg-primary/10 rounded-xl">
                    <FileBarChart size={24} className="text-primary" />
                  </div>
                  Advanced Questionnaire Prompt
                </DialogTitle>
                <DialogDescription className="text-slate-500 font-bold uppercase text-[10px] tracking-widest pl-12">
                  Detailed architectural requirements for platform estimation
                </DialogDescription>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowClearConfirm(true)}
                  className="h-9 px-4 rounded-xl border-slate-200 text-slate-400 hover:text-red-600 hover:bg-red-50 text-[10px] font-black uppercase tracking-widest gap-2"
                >
                  <Eraser size={14} />
                  Clear
                </Button>
                <Button 
                  onClick={onSave}
                  className="h-9 px-6 rounded-xl bg-primary text-white hover:bg-primary/90 text-[10px] font-black uppercase tracking-widest gap-2"
                >
                  <Save size={14} />
                  Save Changes
                </Button>
              </div>
            </div>
          </DialogHeader>

          <ScrollArea className="flex-1 overflow-y-auto p-6">
            <div className="flex flex-col space-y-6 max-w-3xl mx-auto">
              {sections.map((section, sIdx) => (
                <div key={sIdx} className="space-y-4">
                  <div className="space-y-1">
                    <h3 className="text-lg font-black text-slate-900 tracking-tight uppercase border-b border-slate-100 pb-1">
                      {section.title}
                    </h3>
                  </div>
                  <div className="space-y-4 pl-2">
                    {section.items.map((q) => (
                      <div key={q.id} className="space-y-1 group">
                        <div className="flex items-center justify-between">
                          <Label className="text-[11pt] font-normal text-slate-700 transition-colors">
                            {q.label}
                          </Label>
                        </div>
                        <Textarea 
                          placeholder={q.placeholder}
                          rows={3}
                          className="bg-white border-slate-200 text-[11pt] font-normal text-slate-700 min-h-[80px] w-full rounded-lg shadow-sm focus:ring-primary/20 focus:border-primary/40 transition-all placeholder:text-slate-400 placeholder:font-normal placeholder:italic p-3"
                          value={data[q.id as keyof AdvancedQuestionnaire] || ''}
                          onChange={(e) => onChange(q.id as keyof AdvancedQuestionnaire, e.target.value)}
                        />
                      </div>
                    ))}
                  </div>
                  {sIdx < sections.length - 1 && <div className="border-t border-dashed border-slate-200 pt-2" />}
                </div>
              ))}
            </div>
            <div className="h-8" />
          </ScrollArea>

          <DialogFooter className="p-6 border-t border-slate-100 flex-shrink-0 bg-slate-50/50 flex justify-between items-center sm:justify-between">
            <div className="flex gap-2 items-center">
              <div className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Autosave enabled on dialog exit</span>
            </div>
            <Button 
              onClick={onClose}
              variant="outline"
              className="px-10 h-11 rounded-2xl bg-white border-slate-200 shadow-sm text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all"
            >
              Close Window
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showClearConfirm} onOpenChange={setShowClearConfirm}>
        <DialogContent className="max-w-md bg-white border-slate-200 p-8 rounded-[2rem] text-center space-y-4">
          <div className="w-16 h-16 bg-red-50 text-red-600 rounded-[1.5rem] flex items-center justify-center mx-auto border border-red-100">
            <Trash2 size={32} />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Clear Questionnaire?</h3>
            <p className="text-slate-500 font-medium">This will permanently delete all open-text responses in this dialog. This action cannot be undone.</p>
          </div>
          <div className="flex gap-4 pt-4">
            <Button variant="outline" className="flex-1 h-12 rounded-2xl font-black uppercase text-[10px]" onClick={() => setShowClearConfirm(false)}>Cancel</Button>
            <Button variant="destructive" className="flex-1 h-12 rounded-2xl font-black uppercase text-[10px] bg-red-600" onClick={() => { onClear(); setShowClearConfirm(false); }}>Yes, Clear All</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

mermaid.initialize({
  startOnLoad: true,
  theme: 'base',
  fontFamily: 'Inter, system-ui, sans-serif',
  fontSize: 16,
  themeVariables: {
    primaryColor: '#eff6ff',
    primaryTextColor: '#1e40af',
    primaryBorderColor: '#2563eb',
    secondaryColor: '#faf5ff',
    tertiaryColor: '#f0fdf4',
    mainBkg: '#ffffff',
    nodeBorder: '#e2e8f0',
    clusterBkg: '#f8fafc',
    clusterBorder: '#cbd5e1',
    lineColor: '#64748b',
    fontFamily: 'Inter, system-ui, sans-serif'
  },
  flowchart: {
    padding: 20,
    useMaxWidth: false,
    htmlLabels: true,
    curve: 'basis'
  }
});

const Mermaid = ({ chart }: { chart: string }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);
  const [isPanning, setIsPanning] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (ref.current && chart) {
      try {
        mermaid.render(`mermaid-${Math.random().toString(36).substr(2, 9)}`, chart).then((result) => {
          if (ref.current) {
            ref.current.innerHTML = result.svg;
            const svg = ref.current.querySelector('svg');
            if (svg) {
              svg.style.maxWidth = 'none';
              svg.style.width = '100%';
              svg.style.height = 'auto';
            }
          }
        });
      } catch (err) {
        console.error("Mermaid error:", err);
      }
    }
  }, [chart]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsPanning(true);
    setStartPos({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning) return;
    setPosition({
      x: e.clientX - startPos.x,
      y: e.clientY - startPos.y
    });
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  return (
    <div className="relative w-full group overflow-hidden bg-slate-50 rounded-2xl border border-slate-200 shadow-inner h-[600px] select-none">
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex flex-col gap-1 bg-white p-1 shadow-xl rounded-xl border border-slate-200">
          <button 
            onClick={() => setScale(s => Math.min(s + 0.2, 4))} 
            className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-colors tooltip"
            title="Zoom In"
          >
            <ZoomIn size={20} />
          </button>
          <button 
            onClick={() => setScale(s => Math.max(s - 0.2, 0.4))} 
            className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-colors"
            title="Zoom Out"
          >
            <ZoomOut size={20} />
          </button>
          <div className="h-px bg-slate-100 mx-1" />
          <button 
            onClick={() => { setScale(1); setPosition({ x: 0, y: 0 }); }} 
            className="p-2 hover:bg-slate-50 rounded-lg text-slate-600 transition-colors"
            title="Reset View"
          >
            <Maximize2 size={20} />
          </button>
        </div>
      </div>

      <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 bg-white/80 backdrop-blur shadow-sm rounded-full border border-slate-200 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
        <Move size={12} />
        <span>Drag to pan • Scroll to Zoom</span>
      </div>

      <div 
        className="w-full h-full overflow-hidden cursor-grab active:cursor-grabbing flex items-center justify-center"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={(e) => {
          const delta = e.deltaY * -0.001;
          setScale(s => Math.min(Math.max(s + delta, 0.4), 4));
        }}
      >
        <div 
          ref={ref} 
          style={{ 
            transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
            transformOrigin: 'center'
          }}
          className="transition-transform duration-75 ease-out w-full flex justify-center"
        />
      </div>
    </div>
  );
};

export default function App() {
  // Project State
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProjectId, setCurrentProjectId] = useState<string>("");
  const [newProjectName, setNewProjectName] = useState("");
  const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false);
  const [isRenameDialogOpen, setIsRenameDialogOpen] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  // Shared State
  const [industry, setIndustry] = useState<string>("");
  const [companyName, setCompanyName] = useState<string>("");
  
  // Dimension State
  const [dimTableName, setDimTableName] = useState<string>("");
  const [dimComplexity, setDimComplexity] = useState<'Basic' | 'Advanced'>('Basic');
  const [dimSpecialInstructions, setDimSpecialInstructions] = useState<string>("");
  
  // Fact State
  const [factTableName, setFactTableName] = useState<string>("");
  const [factComplexity, setFactComplexity] = useState<'Basic' | 'Advanced'>('Basic');
  const [subjectArea, setSubjectArea] = useState<string>("");
  const [factType, setFactType] = useState<string>("Transaction");
  const [aggregateGrain, setAggregateGrain] = useState<string>("");
  const [selectedDimensions, setSelectedDimensions] = useState<string[]>([]);
  const [factSpecialInstructions, setFactSpecialInstructions] = useState<string>("");
  
  // Dashboard State
  const [dashboards, setDashboards] = useState<DashboardModel[]>([]);
  const [currentDashboard, setCurrentDashboard] = useState<DashboardModel | null>(null);
  const [dashboardName, setDashboardName] = useState("");
  const [dashboardTheme, setDashboardTheme] = useState<'Surprise Me!' | 'Custom'>('Surprise Me!');
  const [customDashboardDesc, setCustomDashboardDesc] = useState("");
  const [selectedStarSchemaId, setSelectedStarSchemaId] = useState("");
  const [dashboardFilters, setDashboardFilters] = useState<Record<string, string>>({});
  const [isSidebarVisible, setIsSidebarVisible] = useState(true);
  const [isDocumentationDialogOpen, setIsDocumentationDialogOpen] = useState(false);
  const [persona, setPersona] = useState<Persona>('architect');
  const [defaultPersona, setDefaultPersona] = useState<Persona | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const dashboardTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const transcriptDateRef = useRef<HTMLInputElement>(null);

  // STTM State
  const [sttmMappings, setSttmMappings] = useState<STTMMapping[]>([]);
  const [sttmViewMode, setSttmViewMode] = useState<'target-to-source' | 'source-to-target'>('target-to-source');
  const [selectedSttmAssetId, setSelectedSttmAssetId] = useState<string>("");
  const [sourceDefinitions, setSourceDefinitions] = useState<string>("");
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  // MDP Opportunities State
  const [oppAdditionalContext, setOppAdditionalContext] = useState("");
  const [oppFiles, setOppFiles] = useState<{name: string, type: string, data: string}[]>([]);
  const [oppCount, setOppCount] = useState(6);
  const [selectedTicker, setSelectedTicker] = useState<string>("");
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(null);
  const [profileCache, setProfileCache] = useState<Record<string, CompanyProfile>>({});
  const [potentialTickers, setPotentialTickers] = useState<TickerMatch[]>([]);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [isSearchingTicker, setIsSearchingTicker] = useState(false);

  // Data Analyst / Gap Registry State
  const [wmpTeam, setWmpTeam] = useState<string>("");
  const [selectedTranscriptsForGap, setSelectedTranscriptsForGap] = useState<string[]>([]);
  const [selectedWmpAttendees, setSelectedWmpAttendees] = useState<string[]>([]);

  const [meetingTranscript, setMeetingTranscript] = useState<string>("");
  const [selectedStarTable, setSelectedStarTable] = useState<TableModel | null>(null);
  const [gapRegistryMode, setGapRegistryMode] = useState<'Overwrite' | 'Append'>('Append');
  const [gapRegistryItems, setGapRegistryItems] = useState<GapRegistryItem[]>([]);
  const [gapRegistryAssets, setGapRegistryAssets] = useState<GapRegistryAsset[]>([]);
  const [uploadedGapFiles, setUploadedGapFiles] = useState<File[]>([]);
  const [isGeneratingGapRegistry, setIsGeneratingGapRegistry] = useState(false);
  const [gapRegistryProgress, setGapRegistryProgress] = useState<{current: number, total: number}>({current: 0, total: 0});
  const [processedGapContentHashes, setProcessedGapContentHashes] = useState<Set<string>>(new Set());
  const [selectedGapItem, setSelectedGapItem] = useState<GapRegistryItem | null>(null);
  const [isRecordViewerOpen, setIsRecordViewerOpen] = useState(false);
  const [selectedDiagram, setSelectedDiagram] = useState<{ 
    platform: string; 
    chart: string; 
    highlights?: MermaidHighlight[];
    platformDetails?: PlatformEstimateResult;
    inputs?: PlatformEstimateInput;
  } | null>(null);
  const [diagramViewMode, setDiagramViewMode] = useState<"visual" | "mermaid">("visual");

  useEffect(() => {
    if (selectedDiagram) {
      setDiagramViewMode("visual");
    }
  }, [selectedDiagram]);
  const gapRegistryScrollRef = useRef<HTMLDivElement>(null);

  // Transcript State
  const [transcripts, setTranscripts] = useState<Transcript[]>([]);
  const [transcriptIndustry, setTranscriptIndustry] = useState<string>("");
  const [transcriptCompanyName, setTranscriptCompanyName] = useState<string>("");
  const [transcriptDate, setTranscriptDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [transcriptTime, setTranscriptTime] = useState<string>("09:00");
  const [transcriptContent, setTranscriptContent] = useState<string>("");
  const [rawTranscriptContent, setRawTranscriptContent] = useState<string>("");
  const [isProcessingTranscript, setIsProcessingTranscript] = useState(false);
  const [transcriptProgress, setTranscriptProgress] = useState<{current: number, total: number}>({current: 0, total: 0});
  const [currentTranscript, setCurrentTranscript] = useState<Transcript | null>(null);
  const [transcriptCustomName, setTranscriptCustomName] = useState<string>("");
  const [isEditingTranscriptName, setIsEditingTranscriptName] = useState(false);
  const [editingTranscriptNameVal, setEditingTranscriptNameVal] = useState("");

  // Extract all unique attendees from selected transcripts for WMP Team identification
  const availableAttendees = useMemo(() => {
    const attendees = new Set<string>();
    selectedTranscriptsForGap.forEach(id => {
      const t = transcripts.find(trans => trans.id === id);
      if (t) {
        t.segments.forEach(s => {
          if (s.speaker && s.speaker.trim()) {
            attendees.add(s.speaker.trim());
          }
        });
      }
    });
    return Array.from(attendees).sort();
  }, [selectedTranscriptsForGap, transcripts]);

  const HOURS = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);

  const MDP_COMPONENTS = [
    'Delta Lake Storage',
    'Multi-hop Architecture (Bronze, Silver, Gold)',
    'Lakehouse (Delta Lake + Data Warehouse)',
    'Data Hub',
    'Semantic Layer',
    'BI Tool',
    'MS Purview',
    'Code Repository (GitHub/Azure DevOps)',
    'AI Workspace'
  ];

  const [gapRegistryColWidths, setGapRegistryColWidths] = useState<{ [key: string]: number }>({
    id: 110,
    gapType: 90,
    painPoint: 320,
    entity: 140,
    reportedBy: 140,
    date: 100,
    category: 140,
    wmpComments: 350,
    directQuotations: 400,
    interviewee: 140,
    meetingWorkshop: 150,
    priority: 80,
    maturityArea: 160,
    mentions: 180,
    totalMentions: 110
  });

  const handleResize = (id: string, width: number) => {
    setGapRegistryColWidths(prev => ({
      ...prev,
      [id]: Math.max(width, 80)
    }));
  };

  const scrollToCorner = (corner: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right') => {
    if (!gapRegistryScrollRef.current) return;
    const { scrollWidth, scrollHeight, clientWidth, clientHeight } = gapRegistryScrollRef.current;
    
    let left = 0;
    let top = 0;
    
    if (corner === 'top-right' || corner === 'bottom-right') {
      left = scrollWidth - clientWidth;
    }
    if (corner === 'bottom-left' || corner === 'bottom-right') {
      top = scrollHeight - clientHeight;
    }
    
    gapRegistryScrollRef.current.scrollTo({ left, top, behavior: 'smooth' });
  };

  // Auto-set Gap Registry mode based on existing items
  useEffect(() => {
    if (gapRegistryItems.length === 0) {
      setGapRegistryMode('Overwrite');
    } else {
      setGapRegistryMode('Append');
    }
  }, [gapRegistryItems.length]);

  const [loading, setLoading] = useState(false);
  const [generationStartTime, setGenerationStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [currentModel, setCurrentModel] = useState<TableModel | null>(null);
  const [history, setHistory] = useState<TableModel[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("dimension");

  useEffect(() => {
    if (currentModel) {
      setSelectedStarTable(currentModel);
    }
  }, [currentModel]);
  const [assetSubTab, setAssetSubTab] = useState<string>("schema");
  const [selectedUseCaseOppId, setSelectedUseCaseOppId] = useState<string | null>(null);
  const [isSidebarScrollable, setIsSidebarScrollable] = useState(false);
  const sidebarScrollRef = useRef<HTMLDivElement>(null);

  const [isEstimatorPaneExpanded, setIsEstimatorPaneExpanded] = useState(true);
  
  // Platform Estimate State
  const [selectedPlatforms, setSelectedPlatforms] = useState<LakehousePlatform[]>(['Databricks', 'Snowflake', 'Microsoft Fabric']);
  const [directSourcesCount, setDirectSourcesCount] = useState<number>(3);
  const [streamingSourcesCount, setStreamingSourcesCount] = useState<number>(0);
  const [streamingPayloadSize, setStreamingPayloadSize] = useState<number>(0);
  const [apiConnectionsCount, setApiConnectionsCount] = useState<number>(0);
  const [flatFilesCount, setFlatFilesCount] = useState<number>(0);
  const [bronzeSize, setBronzeSize] = useState<number>(10);
  const [preferredCloud, setPreferredCloud] = useState<CloudProvider>('Azure');
  const [batchFrequency, setBatchFrequency] = useState<BatchFrequency>('Nightly (Once)');
  const [realtimeFrequency, setRealtimeFrequency] = useState<number>(500);
  const [selectedEnvironments, setSelectedEnvironments] = useState<Environment[]>(['DEV']);
  const [selectedComponents, setSelectedComponents] = useState<string[]>([
    'Delta Lake Storage',
    'Multi-hop Architecture (Bronze, Silver, Gold)',
    'Lakehouse (Delta Lake + Data Warehouse)'
  ]);
  const [biToolChoice, setBiToolChoice] = useState<'Power BI Premium' | 'Power BI Pro (50 users)' | 'Tableau (50 users)'>('Power BI Premium');
  const [platformEstimates, setPlatformEstimates] = useState<PlatformEstimateResult[]>([]);
  const [isGeneratingEstimates, setIsGeneratingEstimates] = useState(false);
  const [platformEstimateAssets, setPlatformEstimateAssets] = useState<PlatformEstimateAsset[]>([]);
  const [projectEstimateAssets, setProjectEstimateAssets] = useState<ProjectEstimateAsset[]>([]);
  const [loadedProjectEstimateInputs, setLoadedProjectEstimateInputs] = useState<any | null>(null);
  
  // Platform Scenario State
  const [currentScenarioId, setCurrentScenarioId] = useState<string | null>(null);
  const [scenarioName, setScenarioName] = useState("[Provide Scenario Name]");
  const [specialInstructions, setSpecialInstructions] = useState("");
  const [lastGeneratedAt, setLastGeneratedAt] = useState<string | null>(null);
  const [isAdvancedQuestionnaireOpen, setIsAdvancedQuestionnaireOpen] = useState(false);
  const [advancedQuestionnaire, setAdvancedQuestionnaire] = useState<AdvancedQuestionnaire>({});
  const [hasUnsavedQuestionnaireChanges, setHasUnsavedQuestionnaireChanges] = useState(false);

  // BD BI Dashboards State
  const [selectedBDUseCases, setSelectedBDUseCases] = useState<string[]>([]);
  const [numDashboards, setNumDashboards] = useState<number>(5);
  const [bdDashboards, setBdDashboards] = useState<SampleDashboard[]>([]);
  const [selectedBDDashboardId, setSelectedBDDashboardId] = useState<string | null>(null);
  const [bdDashboardTheme, setBdDashboardTheme] = useState<'Surprise Me!' | 'Custom'>('Surprise Me!');
  const [bdCustomDashboardDesc, setBdCustomDashboardDesc] = useState<string>("");
  const [isGeneratingBDDashboards, setIsGeneratingBDDashboards] = useState(false);
  const [bdGenerationTimer, setBdGenerationTimer] = useState(0);
  const [bdGenerationStatus, setBdGenerationStatus] = useState("");

  useEffect(() => {
    if (activeTab === 'bi-dashboards') {
      setCurrentDashboard(null);
      setCurrentModel(null);
    }
  }, [activeTab]);

  // Reset BD Dashboard selection when persona or project changes
  useEffect(() => {
    setSelectedBDDashboardId(null);
  }, [persona, currentProjectId]);

  useEffect(() => {
    if (selectedBDDashboardId) {
      setCurrentDashboard(null);
      setCurrentModel(null);
    }
  }, [selectedBDDashboardId]);

  const currentProjectScenarios = useMemo(() => {
    const proj = projects.find(p => p.id === currentProjectId);
    return proj?.platformScenarios || [];
  }, [projects, currentProjectId]);

  const activeScenario = useMemo(() => {
    return currentProjectScenarios.find(s => s.id === currentScenarioId);
  }, [currentProjectScenarios, currentScenarioId]);

  const handleAddScenario = () => {
    const nextNum = currentProjectScenarios.length + 1;
    const newName = nextNum === 1 ? "[Provide Scenario Name]" : `Scenario ${nextNum}`;
    const newId = crypto.randomUUID();
    
    const newScenario: PlatformScenario = {
      id: newId,
      name: newName,
      projectId: currentProjectId,
      inputs: {
        selectedPlatforms,
        directSources: directSourcesCount,
        streamingSources: streamingSourcesCount,
        streamingPayloadMB: streamingPayloadSize,
        apiConnections: apiConnectionsCount,
        flatFiles: flatFilesCount,
        bronzeSizeTB: bronzeSize,
        cloudProvider: preferredCloud,
        batchFrequency,
        realtimeFrequencyMS: realtimeFrequency,
        environments: selectedEnvironments,
        selectedComponents: selectedComponents,
        biToolChoice: biToolChoice,
        specialInstructions: specialInstructions,
        advancedQuestionnaire: {}
      },
      results: [],
      createdAt: new Date().toISOString(),
      companyName: companyName || '',
      industry: industry || ''
    };

    setProjects(prev => prev.map(p => {
      if (p.id === currentProjectId) {
        return { ...p, platformScenarios: [...(p.platformScenarios || []), newScenario] };
      }
      return p;
    }));
    
    setCurrentScenarioId(newId);
    setScenarioName(newName);
    setAdvancedQuestionnaire({});
    setHasUnsavedQuestionnaireChanges(false);
    setPlatformEstimates([]);
    setLastGeneratedAt(null);
    toast.success(`Scenario "${newName}" created.`);
  };

  const handleSwitchScenario = (id: string) => {
    const scenario = currentProjectScenarios.find(s => s.id === id);
    if (scenario) {
      setCurrentScenarioId(id);
      setScenarioName(scenario.name);
      setSelectedPlatforms(scenario.inputs.selectedPlatforms);
      setDirectSourcesCount(scenario.inputs.directSources);
      setStreamingSourcesCount(scenario.inputs.streamingSources);
      setStreamingPayloadSize(scenario.inputs.streamingPayloadMB);
      setApiConnectionsCount(scenario.inputs.apiConnections);
      setFlatFilesCount(scenario.inputs.flatFiles);
      setBronzeSize(scenario.inputs.bronzeSizeTB);
      setPreferredCloud(scenario.inputs.cloudProvider);
      setBatchFrequency(scenario.inputs.batchFrequency);
      setRealtimeFrequency(scenario.inputs.realtimeFrequencyMS);
      setSelectedEnvironments(scenario.inputs.environments);
      setSelectedComponents(scenario.inputs.selectedComponents || [
        'Delta Lake Storage',
        'Multi-hop Architecture (Bronze, Silver, Gold)',
        'Lakehouse (Delta Lake + Data Warehouse)'
      ]);
      setBiToolChoice(scenario.inputs.biToolChoice || 'Power BI Premium');
      setSpecialInstructions(scenario.inputs.specialInstructions || "");
      setAdvancedQuestionnaire(scenario.inputs.advancedQuestionnaire || {});
      setHasUnsavedQuestionnaireChanges(false);
      setPlatformEstimates(scenario.results);
      setLastGeneratedAt(scenario.createdAt); // We'll keep track of when it was last generated
    }
  };

  const handleDeleteScenario = (id: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id === currentProjectId) {
        const filtered = (p.platformScenarios || []).filter(s => s.id !== id);
        return { ...p, platformScenarios: filtered };
      }
      return p;
    }));
    
    if (currentScenarioId === id) {
      setCurrentScenarioId(null);
      setScenarioName("[Provide Scenario Name]");
      setPlatformEstimates([]);
      setLastGeneratedAt(null);
    }
    toast.success("Scenario deleted.");
  };

  const handleUpdateScenarioName = (newName: string) => {
    setScenarioName(newName);
    if (currentScenarioId) {
      setProjects(prev => prev.map(p => {
        if (p.id === currentProjectId) {
          const updated = (p.platformScenarios || []).map(s => 
            s.id === currentScenarioId ? { ...s, name: newName } : s
          );
          return { ...p, platformScenarios: updated };
        }
        return p;
      }));
    }
  };

  const handleSavePlatformEstimate = () => {
    if (!currentProjectId || platformEstimates.length === 0) return;

    const newAsset: PlatformEstimateAsset = {
      id: Math.random().toString(36).substring(2, 11),
      projectId: currentProjectId,
      companyName: companyName || 'Client',
      industry: industry || 'Technology',
      scenarioName: scenarioName,
      inputs: {
        selectedPlatforms,
        directSources: directSourcesCount,
        streamingSources: streamingSourcesCount,
        streamingPayloadMB: streamingPayloadSize,
        apiConnections: apiConnectionsCount,
        flatFiles: flatFilesCount,
        bronzeSizeTB: bronzeSize,
        cloudProvider: preferredCloud,
        batchFrequency,
        realtimeFrequencyMS: realtimeFrequency,
        environments: selectedEnvironments
      },
      results: platformEstimates,
      createdAt: new Date().toISOString()
    };

    setPlatformEstimateAssets(prev => [...prev, newAsset]);
    toast.success("Platform estimate saved to project assets.");
  };

  // Project Manager Persona State
  const [pmMeetingSummaries, setPmMeetingSummaries] = useState<ProjectMeetingSummary[]>(() => {
    const saved = localStorage.getItem('pm_meeting_summaries');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error('Failed to parse pm_meeting_summaries', e); }
    }
    return [];
  });
  useEffect(() => {
    localStorage.setItem('pm_meeting_summaries', JSON.stringify(pmMeetingSummaries));
  }, [pmMeetingSummaries]);

  const [currentPMSummary, setCurrentPMSummary] = useState<ProjectMeetingSummary | null>(null);

  const [pmAssistantMessages, setPmAssistantMessages] = useState<PMAssistantMessage[]>(() => {
    const saved = localStorage.getItem('pm_assistant_messages');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { console.error('Failed to parse pm_assistant_messages', e); }
    }
    return [{
      id: "welcome-1",
      role: "assistant",
      content: "Hello! I am your AI Project Manager Assistant. Ask me anything about your project's meeting summaries, open action items, risks, or key decisions.",
      timestamp: new Date().toISOString()
    }];
  });
  useEffect(() => {
    localStorage.setItem('pm_assistant_messages', JSON.stringify(pmAssistantMessages));
  }, [pmAssistantMessages]);

  const [pmAssistantInput, setPmAssistantInput] = useState("");
  const [isGeneratingPMSummary, setIsGeneratingPMSummary] = useState(false);
  const [isAskingPMAssistant, setIsAskingPMAssistant] = useState(false);

  // PM Ingestion Form State
  const [pmMeetingTitle, setPmMeetingTitle] = useState("");
  const [pmMeetingDate, setPmMeetingDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [pmMeetingTime, setPmMeetingTime] = useState("");
  const [pmNextMeetingDateTime, setPmNextMeetingDateTime] = useState("");
  const [pmMeetingObjective, setPmMeetingObjective] = useState("");
  const [pmAttendeesInput, setPmAttendeesInput] = useState("");
  const [pmTranscriptText, setPmTranscriptText] = useState("");
  const [pmActionItemFilterStatus, setPmActionItemFilterStatus] = useState<"All" | "Open" | "In Progress" | "Completed">("All");
  const [pmActionItemSearch, setPmActionItemSearch] = useState("");

  // Repository Filters State
  const [repoSearchQuery, setRepoSearchQuery] = useState("");
  const [repoOwnerFilter, setRepoOwnerFilter] = useState("All Owners");
  const [repoDueDateFilter, setRepoDueDateFilter] = useState("All Dates");
  const [repoStatusFilter, setRepoStatusFilter] = useState("All Statuses");

  // RAID Log State
  const [raidSearchQuery, setRaidSearchQuery] = useState("");
  const [raidTypeFilter, setRaidTypeFilter] = useState<string>("All");
  const [raidStatusFilter, setRaidStatusFilter] = useState<string>("All");
  const [raidLogItems, setRaidLogItems] = useState<RAIDItem[]>([
    {
      id: 'RAID-001',
      type: 'Risk',
      title: 'MDP Architecture Latency Overhead',
      description: 'New microservices event layer may introduce latency spikes for real-time reporting APIs.',
      impact: 'High',
      status: 'Open',
      owner: 'David Chen',
      targetDate: '2026-08-15'
    },
    {
      id: 'RAID-002',
      type: 'Issue',
      title: 'Legacy Staging Data Pipeline Schema Mismatch',
      description: 'Source ERP staging tables missing updated customer hierarchy fields required for dimensional modeling.',
      impact: 'High',
      status: 'In Progress',
      owner: 'Mark Miller',
      targetDate: '2026-07-30'
    },
    {
      id: 'RAID-003',
      type: 'Dependency',
      title: 'Cloud Data Warehouse Cross-Region IAM Provisioning',
      description: 'Security & IAM team approval required for cross-region Cloud SQL database replication setup.',
      impact: 'Medium',
      status: 'In Progress',
      owner: 'Sarah Jenkins',
      targetDate: '2026-08-05'
    },
    {
      id: 'RAID-004',
      type: 'Assumption',
      title: 'QA Staging Environment Sizing Mirroring',
      description: 'Assumed QA staging environment will mirror production cluster sizing during load testing phase.',
      impact: 'Low',
      status: 'Open',
      owner: 'DevOps Team',
      targetDate: '2026-08-10'
    }
  ]);

  // Dynamically extract unique action item owners & attendees across all saved summaries
  const allActionItemOwners = useMemo(() => {
    const ownersSet = new Set<string>();
    pmMeetingSummaries.forEach(s => {
      (s.actionItems || []).forEach(ai => {
        if (ai.owner && ai.owner.trim() && ai.owner !== 'Unassigned') {
          ownersSet.add(ai.owner.trim());
        }
      });
      (s.attendees || []).forEach(att => {
        if (att && att.trim()) {
          ownersSet.add(att.trim());
        }
      });
    });
    return Array.from(ownersSet).sort();
  }, [pmMeetingSummaries]);

  // Filtered Repository Meeting Summaries
  const filteredRepoSummaries = useMemo(() => {
    return pmMeetingSummaries.filter(s => {
      if (s.projectId && currentProjectId && s.projectId !== currentProjectId) return false;

      if (repoSearchQuery.trim()) {
        const q = repoSearchQuery.toLowerCase();
        const matchTitle = (s.title || s.meetingTitle || "").toLowerCase().includes(q);
        const matchSummary = (s.executiveSummary || "").toLowerCase().includes(q);
        const matchAttendees = (s.attendees || []).some(a => a.toLowerCase().includes(q));
        const matchDecisions = (s.keyDecisions || s.keyItems || []).some(d => d.toLowerCase().includes(q));
        const matchActions = (s.actionItems || []).some(a => a.description.toLowerCase().includes(q) || a.owner.toLowerCase().includes(q));
        if (!matchTitle && !matchSummary && !matchAttendees && !matchDecisions && !matchActions) return false;
      }

      if (repoOwnerFilter !== "All Owners") {
        const ownerLower = repoOwnerFilter.toLowerCase();
        const hasOwnerInAction = (s.actionItems || []).some(ai => ai.owner.toLowerCase().includes(ownerLower));
        const hasAttendee = (s.attendees || []).some(att => att.toLowerCase().includes(ownerLower));
        if (!hasOwnerInAction && !hasAttendee) return false;
      }

      if (repoStatusFilter === "Human Verified" && !s.isHumanConfirmed) return false;
      if (repoStatusFilter === "Needs Review" && s.isHumanConfirmed) return false;

      if (repoDueDateFilter === "Has Next Sync" && !s.nextMeeting && !s.nextMeetingDate) return false;
      if (repoDueDateFilter === "Due Soon / Pending Tasks") {
        const hasPending = (s.actionItems || []).some(ai => ai.status !== "Completed");
        if (!hasPending) return false;
      }

      return true;
    });
  }, [pmMeetingSummaries, currentProjectId, repoSearchQuery, repoOwnerFilter, repoStatusFilter, repoDueDateFilter]);

  // Human-in-the-Loop Refinement State
  const [hitlNextMeetingDate, setHitlNextMeetingDate] = useState("");
  const [hitlAttendees, setHitlAttendees] = useState<string[]>([]);
  const [hitlNewAttendeeInput, setHitlNewAttendeeInput] = useState("");

  useEffect(() => {
    if (currentPMSummary) {
      setHitlNextMeetingDate(currentPMSummary.nextMeetingDate || currentPMSummary.nextMeeting || "");
      setHitlAttendees(currentPMSummary.attendees || []);
    }
  }, [currentPMSummary]);

  const handleSaveHumanConfirmation = (
    summaryId: string, 
    updatedAttendees: string[], 
    updatedNextMeetingDate: string
  ) => {
    setPmMeetingSummaries(prev => prev.map(s => {
      if (s.id !== summaryId) return s;
      const updated: ProjectMeetingSummary = {
        ...s,
        attendees: updatedAttendees,
        nextMeeting: updatedNextMeetingDate,
        nextMeetingDate: updatedNextMeetingDate,
        nextSteps: updatedNextMeetingDate ? [updatedNextMeetingDate] : (s.nextSteps || []),
        isHumanConfirmed: true
      };
      return updated;
    }));

    if (currentPMSummary && currentPMSummary.id === summaryId) {
      setCurrentPMSummary(prev => prev ? ({
        ...prev,
        attendees: updatedAttendees,
        nextMeeting: updatedNextMeetingDate,
        nextMeetingDate: updatedNextMeetingDate,
        nextSteps: updatedNextMeetingDate ? [updatedNextMeetingDate] : (prev.nextSteps || []),
        isHumanConfirmed: true
      }) : null);
    }
    toast.success("Human verification saved! Attendees and next meeting date updated.");
  };

  const handleGeneratePMSummary = async () => {
    if (!pmTranscriptText.trim()) {
      toast.error("Please enter or upload a meeting transcript.");
      return;
    }
    setIsGeneratingPMSummary(true);
    setError(null);
    try {
      const res = await generateProjectMeetingSummary(
        pmTranscriptText,
        {
          meetingTitle: pmMeetingTitle || "Project Meeting",
          meetingDate: pmMeetingDate || new Date().toISOString().split('T')[0],
          companyName: companyName || "Project",
          industry: industry || "General",
          userAttendees: pmAttendeesInput ? pmAttendeesInput.split(',').map(a => a.trim()).filter(Boolean) : []
        }
      );
      
      const summary: ProjectMeetingSummary = {
        id: crypto.randomUUID(),
        projectId: currentProjectId,
        title: res.meetingTitle || pmMeetingTitle || "Project Meeting",
        meetingTitle: res.meetingTitle || pmMeetingTitle || "Project Meeting",
        date: res.meetingDate || pmMeetingDate || new Date().toISOString().split('T')[0],
        meetingDate: res.meetingDate || pmMeetingDate || new Date().toISOString().split('T')[0],
        meetingTime: pmMeetingTime || "",
        meetingObjective: pmMeetingObjective || "",
        nextMeetingDateTime: pmNextMeetingDateTime || res.nextMeeting || "",
        companyName: companyName || "Project",
        industry: industry || "General",
        attendees: (res.attendees && res.attendees.length > 0) ? res.attendees : (pmAttendeesInput ? pmAttendeesInput.split(',').map(a => a.trim()).filter(Boolean) : ["Unassigned"]),
        recapNotes: res.recapNotes || [],
        executiveSummary: res.recapNotes?.join('\n\n') || "Meeting processed.",
        keyItems: res.keyItems || [],
        keyDecisions: res.keyItems || [],
        actionItems: (res.actionItems || []).map((item, idx) => ({
          id: `item-${Date.now()}-${idx}`,
          description: item.description,
          owner: item.owner || 'Unassigned',
          dueDate: item.dueDate || 'TBD',
          status: (item.status as any) || 'Open',
          priority: (item.priority as any) || 'Medium',
          category: item.category,
          notes: item.notes
        })),
        nextMeeting: res.nextMeeting || pmNextMeetingDateTime || "None scheduled / TBD",
        nextMeetingDate: res.nextMeeting || pmNextMeetingDateTime || "",
        nextSteps: res.nextMeeting ? [res.nextMeeting] : (pmNextMeetingDateTime ? [pmNextMeetingDateTime] : []),
        clarificationsNeeded: res.clarificationsNeeded || [],
        createdAt: new Date().toISOString(),
        isHumanConfirmed: false
      };

      setPmMeetingSummaries(prev => [summary, ...prev]);
      setCurrentPMSummary(summary);
      setActiveTab('transcript-library');
      toast.success("Meeting summary generated! Scrolling down to active summary workbench...");
      setTimeout(() => {
        document.getElementById('active-summary-workbench')?.scrollIntoView({ behavior: 'smooth' });
      }, 200);
    } catch (e: any) {
      console.error(e);
      toast.error(e.message || "Failed to generate meeting summary.");
    } finally {
      setIsGeneratingPMSummary(false);
    }
  };

  const handleAskPMAssistant = async (overrideQuestion?: string) => {
    const query = overrideQuestion || pmAssistantInput;
    if (!query.trim()) return;
    const userMsg: PMAssistantMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: query,
      timestamp: new Date().toISOString()
    };
    setPmAssistantMessages(prev => [...prev, userMsg]);
    if (!overrideQuestion) setPmAssistantInput("");
    setIsAskingPMAssistant(true);

    try {
      const projSummaries = pmMeetingSummaries.filter(s => !s.projectId || s.projectId === currentProjectId);
      const summaryContextStr = projSummaries.map(s => `
MEETING: ${s.title} (${s.date})
Attendees: ${s.attendees.join(', ')}
Executive Summary: ${s.executiveSummary}
Key Decisions: ${s.keyDecisions.join('; ')}
Action Items: ${s.actionItems.map(a => `${a.description} [Owner: ${a.owner}, Status: ${a.status}, Due: ${a.dueDate}]`).join('; ')}
`).join('\n---\n');

      const reply = await askProjectManagerAssistant(
        summaryContextStr || "No meeting summaries recorded yet.",
        pmTranscriptText || "",
        query
      );

      const assistantMsg: PMAssistantMessage = {
        id: `msg-${Date.now() + 1}`,
        role: "assistant",
        content: reply,
        timestamp: new Date().toISOString()
      };
      setPmAssistantMessages(prev => [...prev, assistantMsg]);
    } catch (e: any) {
      console.error(e);
      toast.error("Failed to get response from PM Assistant.");
    } finally {
      setIsAskingPMAssistant(false);
    }
  };

  const handleToggleActionItemStatus = (summaryId: string, actionItemId: string) => {
    setPmMeetingSummaries(prev => prev.map(s => {
      if (s.id !== summaryId) return s;
      const updated = s.actionItems.map(item => {
        if (item.id !== actionItemId) return item;
        const nextStatus = item.status === "Completed" ? "Open" : item.status === "Open" ? "In Progress" : "Completed";
        return { ...item, status: nextStatus as any };
      });
      return { ...s, actionItems: updated };
    }));
    if (currentPMSummary && currentPMSummary.id === summaryId) {
      setCurrentPMSummary(prev => {
        if (!prev) return null;
        const updated = prev.actionItems.map(item => {
          if (item.id !== actionItemId) return item;
          const nextStatus = item.status === "Completed" ? "Open" : item.status === "Open" ? "In Progress" : "Completed";
          return { ...item, status: nextStatus as any };
        });
        return { ...prev, actionItems: updated };
      });
    }
  };

  const handleDeletePMSummary = (summaryId: string) => {
    setPmMeetingSummaries(prev => prev.filter(s => s.id !== summaryId));
    if (currentPMSummary?.id === summaryId) {
      setCurrentPMSummary(null);
    }
    toast.success("Meeting summary removed.");
  };

  // Set persona from project default when switching projects
  useEffect(() => {
    if (currentProjectId && projects.length > 0) {
      // Reset views when switching projects
      setCurrentModel(null);
      setCurrentTranscript(null);
      setSelectedSttmAssetId("");
      setCurrentDashboard(null);
      setSelectedStarTable(null);
      setSelectedGapItem(null);
      setGapRegistryItems([]);
      setSelectedTranscriptsForGap([]);
      setSelectedWmpAttendees([]);
      setTranscriptContent("");
      setRawTranscriptContent("");
      setMeetingTranscript("");
      setProcessedGapContentHashes(new Set());
      
      const proj = projects.find(p => p.id === currentProjectId);
      if (proj) {
        // Sync local context from project
        if (proj.companyName) {
          setCompanyName(proj.companyName);
          setTranscriptCompanyName(proj.companyName);
        } else {
          setCompanyName("");
          setTranscriptCompanyName("");
        }

        if (proj.industry) {
          setIndustry(proj.industry);
          setTranscriptIndustry(proj.industry);
        } else {
          setIndustry("");
          setTranscriptIndustry("");
        }

        if (proj.defaultPersona) {
          setPersona(proj.defaultPersona);
          const availableTabs = PERSONA_CONFIG[proj.defaultPersona].tabs.map(t => t.value);
          if (!availableTabs.includes(activeTab)) {
            setActiveTab(availableTabs[0]);
          }
        } else {
          // Default to architect but ensure activeTab is valid
          setPersona('architect');
          const architectTabs = PERSONA_CONFIG.architect.tabs.map(t => t.value);
          if (!architectTabs.includes(activeTab)) {
            setActiveTab('dimension');
          }
        }
      }
    }
  }, [currentProjectId]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      setGenerationStartTime(Date.now());
      setElapsedTime(0);
      interval = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    } else {
      setGenerationStartTime(null);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleCancel = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    if (dashboardTimeoutRef.current) {
      clearTimeout(dashboardTimeoutRef.current);
      dashboardTimeoutRef.current = null;
    }
    setLoading(false);
    setError("Operation cancelled by user.");
  }, []);

  const getRelatedDimensions = useCallback((factModel: TableModel | null) => {
    if (!factModel) return [];
    
    // Get all potential tables related to this fact
    const relatedNames = [
      ...(factModel.relatedDimensions || []),
      ...(factModel.columns || [])
        .filter(c => c.fkTo)
        .map(c => c.fkTo!)
    ];
    
    // Find unique names
    const uniqueRelatedNames = Array.from(new Set(relatedNames));
    
    // Find best version of each from history or current project scope
    return uniqueRelatedNames.map(name => {
      const candidates = history.filter(h => h && h.tableName === name && h.projectId === currentProjectId);
      if (candidates.length === 0) {
        // Fallback to any project if not found in current (rare)
        const anyCandidates = history.filter(h => h && h.tableName === name);
        if (anyCandidates.length === 0) return null;
        return [...anyCandidates].sort((a, b) => (b.columns?.length || 0) - (a.columns?.length || 0))[0];
      }
      // Sort candidates by columns length descending and take first (most complete)
      return [...candidates].sort((a, b) => (b.columns?.length || 0) - (a.columns?.length || 0))[0];
    }).filter(dim => dim !== null) as TableModel[];
  }, [history, currentProjectId]);

  // Persistence Flag
  const isLoaded = useRef(false);
  const hasSeeded = useRef(false);

  useEffect(() => {
    document.title = "Paragon AI";
  }, []);

  // Load projects, history, and dashboards from localStorage
  useEffect(() => {
    const savedProjects = localStorage.getItem("dw_modeler_projects");
    const savedHistory = localStorage.getItem("dw_modeler_history");
    const savedDashboards = localStorage.getItem("dw_modeler_dashboards");
    const savedSttmMappings = localStorage.getItem("dw_modeler_sttm_mappings");
    const savedCurrentProjectId = localStorage.getItem("dw_modeler_current_project_id");
    
    if (savedProjects) {
      try {
        let parsed = JSON.parse(savedProjects);
        
        // One-time migration/fix for project names and ensure uniqueness of Demo DW
        let migrationChanged = false;
        let demoDWFound = false;
        parsed = parsed.filter((p: Project) => {
          if (p.name === "Shearer's Food's Project" || p.name === "ConmerceOne") {
            migrationChanged = true;
            p.name = "CommerceOne";
          }
          
          if (p.name === "CommmerceOne MDP" || p.name === "Default Project" || p.name === "CommerceOne MDP" || p.name === "CommerceOne" || p.name === "Demo DW") {
            if (demoDWFound) {
              migrationChanged = true;
              return false; // Remove duplicate Demo DWs
            }
            demoDWFound = true;
            if (p.name !== "Demo DW" && p.name !== "CommerceOne") {
              migrationChanged = true;
              p.name = "Demo DW";
              p.description = "Standard Data Warehouse Model for Enterprise Analytics";
            }
            return true;
          }
          return true;
        });

        if (!demoDWFound) {
          migrationChanged = true;
          parsed.unshift({
            id: crypto.randomUUID(),
            name: "Demo DW",
            description: "Standard Data Warehouse Model for Enterprise Analytics",
            createdAt: new Date().toISOString()
          });
        }

        if (migrationChanged) {
          localStorage.setItem("dw_modeler_projects", JSON.stringify(parsed));
        }

        setProjects(parsed);
        if (savedCurrentProjectId && parsed.some((p: Project) => p.id === savedCurrentProjectId)) {
          setCurrentProjectId(savedCurrentProjectId);
        } else if (parsed.length > 0) {
          setCurrentProjectId(parsed[0].id);
        }
      } catch (e) {
        console.error("Failed to load projects", e);
      }
    } else {
      // Initialize with a default project if none exist
      const defaultProject: Project = {
        id: crypto.randomUUID(),
        name: "Demo DW",
        description: "Standard Data Warehouse Model for Enterprise Analytics",
        createdAt: new Date().toISOString()
      };
      setProjects([defaultProject]);
      setCurrentProjectId(defaultProject.id);
      
      // Seed immediately for the default project
      const seedModels = getSeedData(defaultProject.id);
      setHistory(seedModels);
      hasSeeded.current = true;
    }

    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }

    if (savedDashboards) {
      try {
        setDashboards(JSON.parse(savedDashboards));
      } catch (e) {
        console.error("Failed to load dashboards", e);
      }
    }

    if (savedSttmMappings) {
      try {
        setSttmMappings(JSON.parse(savedSttmMappings));
      } catch (e) {
        console.error("Failed to load STTM mappings", e);
      }
    }

    const savedGapRegistry = localStorage.getItem("dw_modeler_gap_registry");
    if (savedGapRegistry) {
      try {
        setGapRegistryItems(JSON.parse(savedGapRegistry));
      } catch (e) {
        console.error("Failed to load gap registry", e);
      }
    }

    const savedGapRegistryAssets = localStorage.getItem("dw_modeler_gap_registry_assets");
    if (savedGapRegistryAssets) {
      try {
        setGapRegistryAssets(JSON.parse(savedGapRegistryAssets));
      } catch (e) {
        console.error("Failed to load gap registry assets", e);
      }
    }

    const savedTranscripts = localStorage.getItem("dw_modeler_transcripts");
    if (savedTranscripts) {
      try {
        setTranscripts(JSON.parse(savedTranscripts));
      } catch (e) {
        console.error("Failed to load transcripts", e);
      }
    }

    const savedDefaultPersona = localStorage.getItem("dw_modeler_default_persona");
    if (savedDefaultPersona) {
      try {
        const personaVal = savedDefaultPersona as Persona;
        setDefaultPersona(personaVal);
        setPersona(personaVal);
        
        // Ensure activeTab is valid for the persona
        const availableTabs = PERSONA_CONFIG[personaVal].tabs.map(t => t.value);
        const savedActiveTab = localStorage.getItem("dw_modeler_active_tab");
        if (savedActiveTab && availableTabs.includes(savedActiveTab)) {
          setActiveTab(savedActiveTab);
        } else {
          setActiveTab(availableTabs[0]);
        }
      } catch (e) {
        console.error("Failed to load default persona", e);
      }
    }

    isLoaded.current = true;
  }, []);

  // Seeding Logic for Demo DW
  useEffect(() => {
    if (isLoaded.current) {
      // Find Demo DW
      const demoDWProject = projects.find(p => p.name === "Demo DW");
      
      if (demoDWProject) {
        // 3. Robust Seeding: If history is empty or outdated for THIS project, seed it
        const projectHistory = history.filter(h => h.projectId === demoDWProject.id);
        const isOutdated = projectHistory.length < 21 || projectHistory.some(h => h.companyName !== "Demo DW Bank");
        
        if (isOutdated) {
          const seedModels = getSeedData(demoDWProject.id);
          const advancedSeedModels = seedModels.map(m => ({ ...m, modelComplexity: 'Advanced' as const }));
          
          setHistory(prev => {
            // Remove old seed models for this project to avoid duplicates/stale data
            const filteredPrev = prev.filter(h => h.projectId !== demoDWProject.id);
            return [...advancedSeedModels, ...filteredPrev];
          });
          console.log("Re-seeded Demo DW project with 21 models.");
        }
      }
    }
  }, [isLoaded.current, projects, history]);

  // Auto-save all assets to localStorage
  useEffect(() => {
    if (isLoaded.current) {
      localStorage.setItem("dw_modeler_projects", JSON.stringify(projects));
      localStorage.setItem("dw_modeler_history", JSON.stringify(history));
      localStorage.setItem("dw_modeler_sttm_mappings", JSON.stringify(sttmMappings));
      localStorage.setItem("dw_modeler_dashboards", JSON.stringify(dashboards));
      localStorage.setItem("dw_modeler_gap_registry", JSON.stringify(gapRegistryItems));
      localStorage.setItem("dw_modeler_gap_registry_assets", JSON.stringify(gapRegistryAssets));
      localStorage.setItem("dw_modeler_transcripts", JSON.stringify(transcripts));
      if (defaultPersona) {
        localStorage.setItem("dw_modeler_default_persona", defaultPersona);
      }
    }
  }, [history, dashboards, sttmMappings, projects, gapRegistryItems, gapRegistryAssets, defaultPersona]);

  // Reset scenario state when project changes
  useEffect(() => {
    if (currentProjectId) {
      const proj = projects.find(p => p.id === currentProjectId);
      const scenarios = proj?.platformScenarios || [];
      // When project changes, we reset the active scenario state to clean slate
      setCurrentScenarioId(null);
      setScenarioName("[Provide Scenario Name]");
      setPlatformEstimates([]);
      setLastGeneratedAt(null);
    }
  }, [currentProjectId]);

  // Save current project ID to localStorage
  useEffect(() => {
    if (isLoaded.current && currentProjectId) {
      localStorage.setItem("dw_modeler_current_project_id", currentProjectId);
    }
  }, [currentProjectId]);

  useEffect(() => {
    if (isAdvancedQuestionnaireOpen) {
      setAdvancedQuestionnaire(prev => {
        const newData = { ...prev };
        // Prefill from prompts
        if (!newData.hostingClouds) newData.hostingClouds = preferredCloud;
        if (!newData.envCount) newData.envCount = selectedEnvironments.join(', ');
        
        // Count sources
        const totalSources = directSourcesCount + apiConnectionsCount + flatFilesCount + streamingSourcesCount;
        if (!newData.sourceSystemCount) newData.sourceSystemCount = `${totalSources} Sources (${directSourcesCount} JDBC, ${apiConnectionsCount} SaaS, ${flatFilesCount} Files, ${streamingSourcesCount} Streaming)`;
        
        if (!newData.totalVolume) newData.totalVolume = `${bronzeSize} TB`;
        if (!newData.batchVsRealtime) newData.batchVsRealtime = streamingSourcesCount > 0 ? "Mixed / Hybrid (Real-time enabled)" : "Predominantly Batch";
        if (!newData.dailyIngestionVolume) newData.dailyIngestionVolume = streamingPayloadSize > 0 ? `${streamingPayloadSize} MB/day streaming payload` : "";
        if (!newData.primaryWorkloads) newData.primaryWorkloads = selectedComponents.join(', ');
        if (!newData.totalBiUsers) newData.totalBiUsers = biToolChoice.includes('users') ? '50 users' : 'Enterprise Capacity';

        return newData;
      });
    }
  }, [isAdvancedQuestionnaireOpen, preferredCloud, selectedEnvironments, directSourcesCount, apiConnectionsCount, flatFilesCount, streamingSourcesCount, bronzeSize, streamingPayloadSize, selectedComponents, biToolChoice]);

  const handleAdvancedQuestionnaireChange = (field: keyof AdvancedQuestionnaire, value: string) => {
    setAdvancedQuestionnaire(prev => ({ ...prev, [field]: value }));
    setHasUnsavedQuestionnaireChanges(true);

    // Sync back to standard prompts if applicable
    if (field === 'hostingClouds') {
      const clouds: CloudProvider[] = ['Azure', 'AWS', 'GCP'];
      const foundCloud = clouds.find(c => value.toLowerCase().includes(c.toLowerCase()));
      if (foundCloud) setPreferredCloud(foundCloud);
    }
    if (field === 'envCount') {
      const envs: Environment[] = ['DEV', 'QA', 'PROD'];
      const foundEnvs = envs.filter(e => value.toUpperCase().includes(e));
      if (foundEnvs.length > 0) setSelectedEnvironments(foundEnvs);
    }
    if (field === 'totalVolume') {
      const match = value.match(/(\d+(\.\d+)?)\s*(TB|GB)/i);
      if (match) {
        let val = parseFloat(match[1]);
        if (match[3].toUpperCase() === 'GB') val = val / 1024;
        setBronzeSize(Math.round(val * 10) / 10);
      }
    }
  };

  const handleSaveAdvancedQuestionnaire = () => {
    if (!currentScenarioId) {
      // Create a scenario if none exists
      handleAddScenario();
      // handleAddScenario will update projects state, we'll need to update it again or wait for effect
      // But for simplicity, we'll just update the projects state here if we have no scenario id
      // Actually handleAddScenario sets currentScenarioId, which we can check
    }

    setProjects(prev => prev.map(p => {
      if (p.id === currentProjectId) {
        const scenarios = p.platformScenarios || [];
        const updated = scenarios.map(s => {
          if (s.id === currentScenarioId || (!currentScenarioId && s === scenarios[scenarios.length - 1])) {
            return {
              ...s,
              inputs: {
                ...s.inputs,
                advancedQuestionnaire: advancedQuestionnaire
              }
            };
          }
          return s;
        });
        return { ...p, platformScenarios: updated };
      }
      return p;
    }));
    
    setHasUnsavedQuestionnaireChanges(false);
    toast.success("Advanced questionnaire saved to scenario.");
  };

  const handleCloseAdvancedQuestionnaire = () => {
    if (hasUnsavedQuestionnaireChanges) {
      handleSaveAdvancedQuestionnaire();
    }
    setIsAdvancedQuestionnaireOpen(false);
  };

  const handleClearAdvancedQuestionnaire = () => {
    setAdvancedQuestionnaire({});
    setHasUnsavedQuestionnaireChanges(true);
    toast.success("Questionnaire cleared.");
  };

  const handleExportPlatformEstimatesToExcel = async () => {
    if (platformEstimates.length === 0) {
      toast.error("No estimates to export.");
      return;
    }

    const toastId = toast.loading("Generating professional Excel architecture model...");
    
    try {
      const workbook = new ExcelJS.Workbook();
      workbook.creator = 'Paragon AI';
      workbook.lastModifiedBy = 'Paragon AI';
      workbook.created = new Date();
      
      const sheet = workbook.addWorksheet('Comparison Board');
      
      // Setup Columns
      sheet.columns = [
        { header: 'Platform Name', key: 'platform', width: 25 },
        { header: 'Environment', key: 'env', width: 15 },
        { header: 'Service Item', key: 'service', width: 35 },
        { header: 'Technical Assumption', key: 'assumption', width: 60 },
        { header: 'Monthly Cost (USD)', key: 'cost', width: 18 },
        { header: 'Annual Cost (USD)', key: 'annual', width: 18 },
        { header: 'Complexity Rating', key: 'complexity', width: 18 },
        { header: 'Strategic recommendation', key: 'recommendation', width: 80 }
      ];

      // Style header
      const headerRow = sheet.getRow(1);
      headerRow.font = { bold: true, color: { argb: 'FFFFFF' }, size: 11 };
      headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '0F172A' } };
      headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
      headerRow.height = 30;

      // Add Data
      platformEstimates.forEach(p => {
        p.detailedMonthlyBreakdown.forEach(item => {
          const env = ['DEV', 'QA', 'PROD'].find(e => item.service.toUpperCase().startsWith(e + ":")) || 'Shared';
          const serviceName = item.service.includes(':') ? item.service.split(':')[1].trim() : item.service;
          
          const row = sheet.addRow({
            platform: p.platformName,
            env: env,
            service: serviceName,
            assumption: item.assumption,
            cost: item.monthlyCost,
            annual: item.monthlyCost * 12,
            complexity: p.complexity,
            recommendation: p.recommendation
          });

          // Style the cost columns as currency
          row.getCell('cost').numFmt = '"$"#,##0.00';
          row.getCell('annual').numFmt = '"$"#,##0.00';
        });
        
        // Add a blank separator row between platforms
        sheet.addRow({});
      });

      // Conditional formatting for complexity
      sheet.eachRow((row, rowNumber) => {
        if (rowNumber > 1) {
          const complexityCell = row.getCell('complexity');
          if (complexityCell.value === 'High') {
            complexityCell.font = { color: { argb: 'B91C1C' }, bold: true };
          } else if (complexityCell.value === 'Medium') {
            complexityCell.font = { color: { argb: 'B45309' }, bold: true };
          } else if (complexityCell.value === 'Low') {
            complexityCell.font = { color: { argb: '047857' }, bold: true };
          }
        }
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, `ParagonEstimates_${scenarioName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.xlsx`);
      
      toast.dismiss(toastId);
      toast.success("Excel Architecture Model exported successfully!");
    } catch (e) {
      console.error(e);
      toast.dismiss(toastId);
      toast.error("Failed to generate Excel export.");
    }
  };

  const exportToCSV = (model: TableModel) => {
    const headers = ["Column Name", "Business Name", "Datatype", "Size", "PK", "FK To", "Nullable", "Default Value", "Example Values", "Description"];
    const rows = model.columns.map(col => [
      `"${col.columnName}"`,
      `"${col.businessName}"`,
      `"${col.datatype}"`,
      `"${col.size}"`,
      col.isPk ? "YES" : "NO",
      `"${col.fkTo || ""}"`,
      col.isNullable ? "YES" : "NO",
      `"${col.defaultValue || ""}"`,
      `"${col.exampleValues || ""}"`,
      `"${col.description}"`
    ]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, `${model.tableName}_model.csv`);
  };

  const exportToExcel = (model: TableModel) => {
    const headers = ["Column Name", "Business Name", "Datatype", "Size", "PK", "FK To", "Nullable", "Default Value", "Example Values", "Description"];
    const rows = model.columns.map(col => [
      col.columnName,
      col.businessName,
      col.datatype,
      col.size,
      col.isPk ? "YES" : "NO",
      col.fkTo || "",
      col.isNullable ? "YES" : "NO",
      col.defaultValue || "",
      col.exampleValues || "",
      col.description
    ]);
    
    const worksheet = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Model");
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, `${model.tableName}_model.xlsx`);
  };

  const exportProjectToExcel = async () => {
    if (!currentProject) return;
    
    const toastId = toast.loading("Exporting complete project data (this may take a few seconds)...");
    
    try {
      const workbook = new ExcelJS.Workbook();
      workbook.creator = 'Paragon';
      workbook.lastModifiedBy = 'Paragon';
      workbook.created = new Date();
      
      const projectHistory = history.filter(h => h.projectId === currentProject.id);
      
      // 1. Dimensions
      projectHistory.filter(h => h.tableType === 'Dimension').forEach(dim => {
        const sheetName = `DIM_${dim.tableName.replace(/[^a-zA-Z0-9_\u4e00-\u9fa5]/g, '_')}`.substring(0, 31);
        const sheet = workbook.addWorksheet(sheetName);
        sheet.getRow(1).values = ['Column Name', 'Business Name', 'Datatype', 'Size', 'PK', 'FK To', 'Nullable', 'Default Value', 'Example Values', 'Description'];
        sheet.getRow(1).font = { bold: true };
        sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E7FF' } };
        
        dim.columns.forEach((col, idx) => {
          sheet.getRow(idx + 2).values = [
            col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName,
            col.businessName,
            col.datatype,
            col.size,
            col.isPk ? 'YES' : 'NO',
            col.fkTo || '',
            col.isNullable ? 'YES' : 'NO',
            col.defaultValue || '',
            col.exampleValues || '',
            col.description
          ];
        });
        sheet.columns.forEach(column => { column.width = 20; });
      });

      // 2. Facts (with Diagram)
      for (const fact of projectHistory.filter(h => h.tableType === 'Fact')) {
        const sheetName = `FACT_${fact.tableName.replace(/[^a-zA-Z0-9_\u4e00-\u9fa5]/g, '_')}`.substring(0, 31);
        const sheet = workbook.addWorksheet(sheetName);
        sheet.getRow(1).values = ['Column Name', 'Business Name', 'Datatype', 'Size', 'PK', 'FK To', 'Nullable', 'Default Value', 'Example Values', 'Description'];
        sheet.getRow(1).font = { bold: true };
        sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF1F5F9' } };
        
        fact.columns.forEach((col, idx) => {
          sheet.getRow(idx + 2).values = [
            col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName,
            col.businessName,
            col.datatype,
            col.size,
            col.isPk ? 'YES' : 'NO',
            col.fkTo || '',
            col.isNullable ? 'YES' : 'NO',
            col.defaultValue || '',
            col.exampleValues || '',
            col.description
          ];
        });
        sheet.columns.forEach(column => { column.width = 20; });

        // Add Diagram if visible
        const erdId = `star-schema-${fact.id}`;
        const erdElement = document.getElementById(erdId);
        if (erdElement) {
          try {
            const dataUrl = await toPng(erdElement, { backgroundColor: '#ffffff', quality: 1 });
            const imageId = workbook.addImage({
              base64: dataUrl,
              extension: 'png',
            });
            sheet.addImage(imageId, {
              tl: { col: 0, row: fact.columns.length + 4 },
              ext: { width: 1200, height: 800 }
            });
          } catch (imgErr) {
            console.error("Failed to capture ERD for Excel", imgErr);
          }
        }
      }

      // 3. STTMs
      sttmMappings.filter(m => projectHistory.some(h => h.id === m.targetTableId || h.id === m.tableId)).forEach(mapping => {
        const targetTable = history.find(h => h.id === mapping.targetTableId || h.id === mapping.tableId);
        if (!targetTable) return;
        
        const sheetName = `STTM_${targetTable.tableName.replace(/[^a-zA-Z0-9_\u4e00-\u9fa5]/g, '_')}`.substring(0, 31);
        const sheet = workbook.addWorksheet(sheetName);
        const headers = [
          "Target Column", "Target Display Name", "Target Datatype", "Target Size", "PK", "FK To", "Nullable",
          "Source System", "Source Schema", "Source Table", "Source Field", "Source Datatype", "ETL Rules"
        ];
        sheet.getRow(1).values = headers;
        sheet.getRow(1).font = { bold: true };
        sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD1FAE5' } };

        targetTable.columns.forEach((col, idx) => {
          const m = mapping.mappings.find(map => map.targetColumnName === col.columnName);
          sheet.getRow(idx + 2).values = [
            col.columnName.toLowerCase() === 'dw_id' ? 'dw_key' : col.columnName,
            col.businessName,
            col.datatype,
            col.size,
            col.isPk ? 'YES' : 'NO',
            col.fkTo || "",
            col.isNullable ? 'YES' : 'NO',
            m?.source.sourceSystem || "",
            m?.source.sourceSchema || "",
            m?.source.sourceTable || "",
            m?.source.sourceFieldName || "",
            m?.source.sourceDatatype || "",
            m?.source.etlRules || ""
          ];
        });
        sheet.columns.forEach(column => { column.width = 20; });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, `ProjectMasterExport_${currentProject.name.replace(/\s+/g, '_')}.xlsx`);
      toast.success("Project Master Export successful!", { id: toastId });
    } catch (error) {
      console.error("Excel Export Error:", error);
      toast.error("Failed to export complete project. Ensure diagrams are loaded in Assets tab first.", { id: toastId });
    }
  };

  const extractDateTimeFromText = (text: string) => {
    // Look for patterns like M/D/YYYY or YYYY-MM-DD
    const dateRegex = /(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})|(\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2})/;
    // Look for patterns like HH:MM AM/PM or HH:MM
    const timeRegex = /(\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)?)/;

    const dateMatch = text.match(dateRegex);
    const timeMatch = text.match(timeRegex);

    let extractedDate = "";
    let extractedTime = "";

    if (dateMatch) {
      const rawDate = dateMatch[0];
      try {
        const dateObj = new Date(rawDate);
        if (!isNaN(dateObj.getTime())) {
          extractedDate = dateObj.toISOString().split('T')[0];
        }
      } catch (e) {}
    }

    if (timeMatch) {
      const rawTime = timeMatch[0].toUpperCase();
      // Try to find a matching hour in our HOURS constant
      const cleanTime = rawTime.replace(/\s+/g, '');
      const hourPart = cleanTime.split(':')[0];
      const isPM = cleanTime.includes('PM');
      let hourNum = parseInt(hourPart);
      
      if (isPM && hourNum < 12) hourNum += 12;
      if (!isPM && hourNum === 12) hourNum = 0;
      
      const formattedHour = hourNum.toString().padStart(2, '0') + ":00";
      if (HOURS.includes(formattedHour)) {
        extractedTime = formattedHour;
      }
    }
    
    return { date: extractedDate, time: extractedTime };
  };

  const handleSaveTranscriptName = () => {
    if (editingTranscriptNameVal.trim() && currentTranscript) {
      const updated = { ...currentTranscript, name: editingTranscriptNameVal.trim() };
      setTranscripts(prev => prev.map(t => t.id === currentTranscript.id ? updated : t));
      setCurrentTranscript(updated);
    }
    setIsEditingTranscriptName(false);
  };

  const processTranscript = async () => {
    const contentToProcess = rawTranscriptContent || transcriptContent;
    if (!contentToProcess.trim() || (contentToProcess.startsWith('Transcript:') && !rawTranscriptContent)) {
      setError("Please provide transcript content to process.");
      return;
    }

    setLoading(true);
    setError(null);
    setIsProcessingTranscript(true);
    setActiveTab('transcripts');

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const result = await generateTranscriptTableChunked(
        transcriptIndustry || industry,
        transcriptCompanyName || companyName,
        transcriptDate,
        transcriptTime,
        contentToProcess,
        (curr, tot) => setTranscriptProgress({ current: curr, total: tot }),
        controller.signal
      );

      const compName = transcriptCompanyName || companyName;
      const compAcronym = compName.split(/\s+/).map(word => word[0]).join('').toUpperCase().substring(0, 3) || compName.substring(0, 3).toUpperCase();
      const dateFormatted = transcriptDate.replace(/-/g, '');
      const formattedName = transcriptCustomName.trim() || `${compAcronym}-${dateFormatted}-${transcriptTime}`;

      const newTranscript: Transcript = {
        ...result,
        id: crypto.randomUUID(),
        projectId: currentProjectId || 'default',
        industry: transcriptIndustry || industry,
        companyName: compName,
        name: formattedName,
        date: transcriptDate,
        time: transcriptTime,
        createdAt: new Date().toISOString(),
      };

      setTranscripts(prev => [newTranscript, ...prev]);
      setCurrentTranscript(newTranscript);
      setTranscriptContent(""); 
      setRawTranscriptContent("");
      setTranscriptCustomName("");
      toast.success("Transcript processed successfully!");
    } catch (error: any) {
      if (error.name === 'AbortError') return;
      console.error("Transcript processing failed", error);
      setError("Failed to process transcript. Please try again.");
      toast.error("Transcript processing failed");
    } finally {
      setIsProcessingTranscript(false);
      setLoading(false);
      abortControllerRef.current = null;
    }
  };

  const exportTranscriptToExcel = (transcript: Transcript) => {
    const headers = ["Speaker", "Dialogue", "Timestamp"];
    const rows = transcript.segments.map(s => [s.speaker, s.text, s.timestamp]);
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Transcript");
    XLSX.writeFile(wb, `${transcript.name}_transcript.xlsx`);
  };

  const exportTranscriptToWord = (transcript: Transcript) => {
    let content = `TRANSCRIPT ANALYSIS: ${transcript.name}\n`;
    content += `Description: ${transcript.description}\n`;
    content += `Meeting Date: ${transcript.date}, ${transcript.time}\n`;
    content += `Attendees: ${transcript.attendees.join(', ')}\n\n`;
    content += `DIALOGUE:\n`;
    
    transcript.segments.forEach(s => {
      content += `-----------------------------------\n`;
      content += `[${s.timestamp}] ${s.speaker}:\n`;
      content += `${s.text}\n`;
    });
    
    const blob = new Blob([content], { type: 'application/msword' });
    saveAs(blob, `${transcript.name}_transcript.doc`);
  };

  const exportToWord = (model: TableModel) => {
    let content = `DATA MODEL OVERVIEW: ${model.tableName}\n`;
    content += `Type: ${model.tableType}\n`;
    content += `Industry: ${model.industry}\n`;
    content += `Description: ${model.description}\n\n`;
    content += `COLUMNS:\n`;
    
    model.columns.forEach(col => {
      content += `-----------------------------------\n`;
      content += `Column: ${col.columnName} (${col.businessName})\n`;
      content += `Datatype: ${col.datatype}(${col.size})\n`;
      content += `PK: ${col.isPk ? 'Yes' : 'No'}, Nullable: ${col.isNullable ? 'Yes' : 'No'}\n`;
      content += `Description: ${col.description}\n`;
    });
    
    const blob = new Blob([content], { type: 'application/msword' });
    saveAs(blob, `${model.tableName}_model.doc`);
  };

  const copyTableToClipboard = (model: TableModel) => {
    const headers = ["Column Name", "Display Name", "Datatype", "Size", "PK", "FK To", "Nullable", "Default Value", "Example Values", "Description"];
    const rows = model.columns.map(col => [
      col.columnName,
      col.businessName,
      col.datatype,
      col.size,
      col.isPk ? "YES" : "NO",
      col.fkTo || "",
      col.isNullable ? "YES" : "NO",
      col.defaultValue || "",
      col.exampleValues || "",
      col.description
    ]);
    
    const tableText = [headers, ...rows].map(row => row.join("\t")).join("\n");
    copyToClipboard(tableText);
  };

  const exportSTTMToCSV = (mapping: STTMMapping, targetTable: TableModel) => {
    const headers = [
      "Target Column", "Target Display Name", "Target Datatype", "Target Size", "PK", "FK To", "Nullable",
      "Source System", "Source Schema", "Source Table", "Source Field", "Source Datatype", "ETL Rules"
    ];
    
    const rows = targetTable.columns.map(col => {
      const m = mapping.mappings.find(map => map.targetColumnName === col.columnName);
      return [
        `"${col.columnName}"`,
        `"${col.businessName}"`,
        `"${col.datatype}"`,
        `"${col.size}"`,
        col.isPk ? "YES" : "NO",
        `"${col.fkTo || ""}"`,
        col.isNullable ? "YES" : "NO",
        `"${m?.source.sourceSystem || ""}"`,
        `"${m?.source.sourceSchema || ""}"`,
        `"${m?.source.sourceTable || ""}"`,
        `"${m?.source.sourceFieldName || ""}"`,
        `"${m?.source.sourceDatatype || ""}"`,
        `"${m?.source.etlRules || ""}"`
      ];
    });

    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, `${targetTable.tableName}_STTM.csv`);
  };

  const exportSTTMToExcel = (mapping: STTMMapping, targetTable: TableModel) => {
    const headers = [
      "Target Column", "Target Display Name", "Target Datatype", "Target Size", "PK", "FK To", "Nullable",
      "Source System", "Source Schema", "Source Table", "Source Field", "Source Datatype", "ETL Rules"
    ];
    
    const rows = targetTable.columns.map(col => {
      const m = mapping.mappings.find(map => map.targetColumnName === col.columnName);
      return [
        col.columnName,
        col.businessName,
        col.datatype,
        col.size,
        col.isPk ? "YES" : "NO",
        col.fkTo || "",
        col.isNullable ? "YES" : "NO",
        m?.source.sourceSystem || "",
        m?.source.sourceSchema || "",
        m?.source.sourceTable || "",
        m?.source.sourceFieldName || "",
        m?.source.sourceDatatype || "",
        m?.source.etlRules || ""
      ];
    });

    const worksheet = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "STTM");
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, `${targetTable.tableName}_STTM.xlsx`);
  };

  const copySTTMToClipboard = (mapping: STTMMapping, targetTable: TableModel) => {
    const headers = [
      "Target Column", "Target Display Name", "Target Datatype", "Target Size", "PK", "FK To", "Nullable",
      "Source System", "Source Schema", "Source Table", "Source Field", "Source Datatype", "ETL Rules"
    ];
    
    const rows = targetTable.columns.map(col => {
      const m = mapping.mappings.find(map => map.targetColumnName === col.columnName);
      return [
        col.columnName,
        col.businessName,
        col.datatype,
        col.size,
        col.isPk ? "YES" : "NO",
        col.fkTo || "",
        col.isNullable ? "YES" : "NO",
        m?.source.sourceSystem || "",
        m?.source.sourceSchema || "",
        m?.source.sourceTable || "",
        m?.source.sourceFieldName || "",
        m?.source.sourceDatatype || "",
        m?.source.etlRules || ""
      ];
    });

    const tableText = [headers, ...rows].map(row => row.join("\t")).join("\n");
    copyToClipboard(tableText);
  };

  const exportProjectBackup = () => {
    const backupData = {
      projects,
      history,
      sttmMappings,
      dashboards,
      gapRegistryItems,
      gapRegistryAssets,
      transcripts,
      defaultPersona,
      projectEstimateAssets,
      version: "1.2",
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DW_Modeler_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Project backup exported successfully!");
  };

  const getSTTMStatus = useCallback((targetModel: TableModel) => {
    const mapping = sttmMappings.find(m => m.targetTableId === targetModel.id || m.tableId === targetModel.id);
    if (!mapping || !mapping.mappings || mapping.mappings.length === 0) return 'I';
    
    // Audit columns check logic matching STTMView
    const colsToMap = targetModel.columns.filter(c => !c.isPk && !c.columnName.startsWith('sys_'));
    if (colsToMap.length === 0) return 'C';
    
    const mappedCols = mapping.mappings.filter(m => {
      const isTargetToMap = colsToMap.some(c => c.columnName === m.targetColumnName);
      return isTargetToMap && m.source && (m.source.sourceFieldName || m.source.sourceTable);
    });
    
    if (mappedCols.length === 0) return 'I';
    if (mappedCols.length >= colsToMap.length) return 'C';
    return 'P';
  }, [sttmMappings]);

  const importProjectBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);
        
        if (data.projects && Array.isArray(data.projects)) {
          setProjects(data.projects);
          if (data.history) setHistory(data.history);
          if (data.sttmMappings) setSttmMappings(data.sttmMappings);
          if (data.dashboards) setDashboards(data.dashboards);
          if (data.gapRegistryItems) setGapRegistryItems(data.gapRegistryItems);
          if (data.gapRegistryAssets) setGapRegistryAssets(data.gapRegistryAssets);
          if (data.transcripts) setTranscripts(data.transcripts);
          if (data.projectEstimateAssets) {
            setProjectEstimateAssets(data.projectEstimateAssets);
          } else {
            setProjectEstimateAssets([]);
          }
          if (data.defaultPersona) {
            setDefaultPersona(data.defaultPersona);
            setPersona(data.defaultPersona);
          }
          
          if (data.projects.length > 0) {
            setCurrentProjectId(data.projects[0].id);
          }
          
          toast.success("Project backup imported successfully!");
        } else {
          toast.error("Invalid backup file format.");
        }
      } catch (error) {
        console.error("Import failed", error);
        toast.error("Failed to import backup file.");
      }
    };
    reader.readAsText(file);
  };

  const readFileAsText = async (file: File): Promise<string> => {
    const fileName = file.name.toLowerCase();
    try {
      if (file.type.startsWith('text/') || fileName.endsWith('.txt') || fileName.endsWith('.csv') || fileName.endsWith('.text')) {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.onerror = () => resolve("");
          reader.readAsText(file);
        });
      } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
        const buffer = await file.arrayBuffer();
        const data = new Uint8Array(buffer);
        const workbook = XLSX.read(data, { type: 'array' });
        let text = "";
        workbook.SheetNames.forEach(sheetName => {
          const sheet = workbook.Sheets[sheetName];
          const json = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
          text += `\nSheet: ${sheetName}\n`;
          if (Array.isArray(json)) {
            json.forEach(row => {
              if (row && Array.isArray(row) && row.length > 0) {
                const rowText = row.map(cell => {
                  if (cell === null || cell === undefined) return "";
                  if (typeof cell === 'object') {
                    try {
                      return JSON.stringify(cell);
                    } catch {
                      return String(cell);
                    }
                  }
                  return String(cell);
                }).join(" | ");
                if (rowText.trim()) {
                  text += rowText + "\n";
                }
              }
            });
          }
        });
        return text;
      } else if (fileName.endsWith('.docx')) {
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        return result.value;
      }
    } catch (err) {
      console.error("Error reading file:", fileName, err);
      return `--- ERROR READING ${fileName} ---`;
    }
    return "";
  };

  const handleGenerateGapRegistry = useCallback(async () => {
    if (isGeneratingGapRegistry) return;

    if (!industry || !companyName) {
      setError("Please ensure Industry and Company Name are provided.");
      return;
    }

    if (selectedTranscriptsForGap.length === 0 && !meetingTranscript.trim() && uploadedGapFiles.length === 0) {
      setError("Please provide a meeting transcript, select existing ones, or upload a document to analyze.");
      return;
    }

    if (gapRegistryMode !== 'Append') {
      setLoading(true);
    }
    setError(null);
    setElapsedTime(0);
    setIsGeneratingGapRegistry(true);
    setActiveTab('gap-registry');

    const controller = new AbortController();
    abortControllerRef.current = controller;

    const newHashes = gapRegistryMode === 'Overwrite' ? new Set<string>() : new Set(processedGapContentHashes);
    const isExpanding = gapRegistryMode === 'Append';
    
    try {
      // Clear architectural selections to ensure specialized Data Analyst view shows
      setCurrentModel(null);
      setCurrentDashboard(null);
      
      let finalTranscript = "";
      const localNewHashes = new Set<string>();

      // Process selected transcripts
      if (selectedTranscriptsForGap.length > 0) {
        selectedTranscriptsForGap.forEach(id => {
          const t = transcripts.find(trans => trans.id === id);
          if (t) {
            let transcriptText = "";
            let addedLines = false;
            t.segments.forEach(s => {
              const line = `[${s.timestamp}] ${s.speaker}: ${s.text}`;
              const hash = getStringHash(line);
              
              // If expanding, we might want to re-process to find things the AI missed the first time
              // but we still want to avoid redundant processing of the exact same lines if possible.
              // However, the user specifically asked for EXHAUSTIVE reprocessing.
              // We will ONLY skip if we already found some items in the EXACT SAME transcript run?
              // Actually, removing this check for transcripts entirely when Append is selected 
              // for a specific session to fulfill "reprocessed" request.
              if (isExpanding || (!newHashes.has(hash) && !localNewHashes.has(hash))) {
                if (!addedLines) {
                  transcriptText = `--- TRANSCRIPT: ${t.name} ---\n`;
                  addedLines = true;
                }
                transcriptText += line + "\n";
                localNewHashes.add(hash);
              }
            });
            if (addedLines) {
              finalTranscript += transcriptText + "\n";
            }
          }
        });
      }
      
      // Process manual transcript if provided
      if (meetingTranscript.trim()) {
        const lines = meetingTranscript.split('\n');
        let newManualTranscript = "";
        lines.forEach(line => {
          const trimmedLine = line.trim();
          if (!trimmedLine) return;
          const hash = getStringHash(trimmedLine);
          if (isExpanding || (!newHashes.has(hash) && !localNewHashes.has(hash))) {
            newManualTranscript += line + "\n";
            localNewHashes.add(hash);
          }
        });
        if (newManualTranscript) {
          finalTranscript += "--- MANUAL TRANSCRIPT ENTRY ---\n" + newManualTranscript + "\n";
        }
      }
      
      // Read text-based files if present
      if (uploadedGapFiles.length > 0) {
        const fileContents = await Promise.all(uploadedGapFiles.map(async file => {
          const text = await readFileAsText(file);
          if (!text) return "";
          
          const lines = text.split('\n');
          let newFileText = `--- FILE: ${file.name} ---\n`;
          let addedAny = false;
          lines.forEach(line => {
            const trimmed = line.trim();
            if (!trimmed) return;
            const hash = getStringHash(trimmed);
            if (isExpanding || (!newHashes.has(hash) && !localNewHashes.has(hash))) {
              newFileText += line + "\n";
              localNewHashes.add(hash);
              addedAny = true;
            }
          });
          return addedAny ? newFileText : "";
        }));
        const validFileContents = fileContents.filter(c => c.length > 0);
        if (validFileContents.length > 0) {
          finalTranscript += "\n" + validFileContents.join("\n");
        }
      }

      if (!finalTranscript.trim()) {
        toast("No new transcript content detected for analysis.");
        setIsGeneratingGapRegistry(false);
        setLoading(false);
        return;
      }

      const initialItemCount = gapRegistryMode === 'Overwrite' ? 0 : gapRegistryItems.length;
      const startIndex = initialItemCount + 1;
      
      if (gapRegistryMode === 'Overwrite') {
        setGapRegistryItems([]);
      }

      const finalWmpTeam = selectedWmpAttendees.length > 0 ? selectedWmpAttendees.join(', ') : wmpTeam;

      const finalItems = await generateGapRegistryChunked(
        industry,
        companyName,
        finalWmpTeam,
        finalTranscript,
        (partialItems) => {
          // Stream results into UI immediately
          setGapRegistryItems(prev => {
            const existingIds = new Set(prev.map(i => i.id.toLowerCase()));
            const existingPainPoints = new Set(prev.map(i => i.painPoint.toLowerCase().trim()));
            
            const uniqueNew = partialItems.filter(i => {
              return !existingIds.has(i.id.toLowerCase()) && 
                     !existingPainPoints.has(i.painPoint.toLowerCase().trim());
            });
            
            return [...prev, ...uniqueNew];
          });
        },
        (current, total) => {
          setGapRegistryProgress({ current, total });
        },
        controller.signal,
        startIndex
      );

      // On success, union the hashes
      setProcessedGapContentHashes(prev => {
        const updated = new Set(prev);
        localNewHashes.forEach(h => updated.add(h));
        return updated;
      });

      // Recursive Enrichment Pass
      if (!controller.signal.aborted && finalItems.length > 0) {
        setGapRegistryProgress({ current: 0, total: 1 });
        const enrichedItemsResult = await enrichGapRegistryWithMentions(
          finalTranscript,
          finalItems,
          controller.signal
        );
        
        // Merge enriched items back into the registry (supporting Append mode)
        setGapRegistryItems(prev => {
          const itemMap = new Map(prev.map(i => [i.id, i]));
          enrichedItemsResult.forEach(item => {
            // Ensure minimum 1 mention for records with quotations
            const mentions = item.mentions || "";
            const total = item.totalMentions || 1;
            itemMap.set(item.id, {
              ...item,
              mentions: mentions || "N/A",
              totalMentions: Math.max(1, total)
            });
          });
          // Preserve chronological order (by date/id)
          return Array.from(itemMap.values()).sort((a: GapRegistryItem, b: GapRegistryItem) => a.id.localeCompare(b.id));
        });
      }

      // Only show completion if not aborted and entire transcript finished
      if (!controller.signal.aborted) {
        if (finalItems.length > 0) {
          const now = new Date();
          const dateStr = now.toISOString().split('T')[0].replace(/-/g, '');
          
          // Scrub "Gap Registry" from company name if it accidentally got in there
          const cleanCompanyName = companyName.replace(/\s+Gap\s+Registry.*$/i, '').trim();
          if (cleanCompanyName !== companyName) {
            setCompanyName(cleanCompanyName);
            setTranscriptCompanyName(cleanCompanyName);
          }

          const existingSameDayCount = gapRegistryAssets.filter(a => 
            a.projectId === (currentProjectId || 'default') && 
            a.createdAt.startsWith(now.toISOString().split('T')[0])
          ).length;
          const increment = (existingSameDayCount + 1).toString().padStart(2, '0');
          const acronym = cleanCompanyName.split(/\s+/).map(word => word[0]).join('').toUpperCase().substring(0, 3) || cleanCompanyName.substring(0, 3).toUpperCase();
          const registryTitle = `${cleanCompanyName} Gap Registry - ${now.toLocaleDateString()}`;

          const newAsset: GapRegistryAsset = {
            id: crypto.randomUUID(),
            projectId: currentProjectId || 'default',
            title: registryTitle,
            companyName: cleanCompanyName, // Just the company name as requested
            industry,
            items: gapRegistryMode === 'Append' ? [...gapRegistryItems, ...finalItems] : finalItems,
            createdAt: now.toISOString()
          };
          setGapRegistryAssets(prevAssets => [newAsset, ...prevAssets]);
          toast.success(`Analysis complete. Identified ${finalItems.length} total items.`);
        } else {
          toast("Transcript analysis complete. No new items were identified.");
        }
      }
      
    } catch (err: any) {
      if (err.name === 'AbortError' || err.message === 'Aborted') {
        console.log("Generation aborted");
      } else {
        console.error("Gap Registry failed", err);
        setError("Generation failed. Please try again with a smaller transcript or check your connection.");
        toast.error("Failed to process transcript.");
      }
    } finally {
      setIsGeneratingGapRegistry(false);
      setLoading(false);
      setGapRegistryProgress({ current: 0, total: 0 });
    }
  }, [industry, companyName, wmpTeam, selectedTranscriptsForGap, selectedWmpAttendees, meetingTranscript, gapRegistryMode, uploadedGapFiles, gapRegistryItems, currentProjectId, gapRegistryAssets, transcripts, processedGapContentHashes]);

  const exportGapRegistryToExcel = () => {
    if (gapRegistryItems.length === 0) return;
    
    const headers = [
      "ID", "Gap Type", "Pain Point", "Entity", "Reported By", "Reported Date", 
      "Category", "WMP Comments", "Direct Quotations", "Interviewee", 
      "Meeting/Workshop", "Priority", "Data Maturity Area",
      "Mentions", "Total # of Mentions"
    ];
    
    const rows = gapRegistryItems.map(item => [
      item.id,
      item.gapType,
      item.painPoint,
      item.entity,
      item.reportedBy,
      item.reportedDate,
      item.category,
      item.wmpComments,
      item.directQuotations,
      item.interviewee,
      item.meetingWorkshop,
      item.priority,
      item.dataMaturityArea,
      item.mentions || "",
      item.totalMentions || 1
    ]);
    
    const worksheet = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Gap Registry");
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, `${companyName.replace(/\s+/g, '_')}_Gap_Registry.xlsx`);
  };

  const getExportFilename = (extension: string = 'json') => {
    const date = new Date().toISOString().split('T')[0];
    return `Paragon_AI_${date}.${extension}`;
  };

  const handleExportPlatformEstimateToJSON = (asset: PlatformEstimateAsset) => {
    const exportData = {
      ...asset,
      exportedAt: new Date().toISOString(),
      version: "1.0",
      type: "Platform Estimate"
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    saveAs(blob, getExportFilename('json'));
    toast.success("Platform estimate exported to JSON.");
  };

  const exportGapRegistryToJSON = () => {
    if (gapRegistryItems.length === 0) return;
    
    // Explicitly include the requested metadata
    const exportData = {
      companyName,
      industry,
      generatedAt: new Date().toISOString(),
      items: gapRegistryItems,
      metadata: {
        company: companyName,
        industry: industry,
        version: "1.0",
        type: "Gap Registry"
      }
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    saveAs(blob, getExportFilename('json'));
    toast.success("Gap Registry metadata and items exported to JSON.");
  };

  const copyGapRegistryToClipboard = () => {
    if (gapRegistryItems.length === 0) return;
    
    const headers = [
      "ID", "Gap Type", "Pain Point", "Entity", "Reported By", "Reported Date", 
      "Category", "WMP Comments", "Direct Quotations", "Interviewee", 
      "Meeting/Workshop", "Priority", "Data Maturity Area",
      "Mentions", "Total # of Mentions"
    ];
    
    const rows = gapRegistryItems.map(item => [
      item.id,
      item.gapType,
      item.painPoint,
      item.entity,
      item.reportedBy,
      item.reportedDate,
      item.category,
      item.wmpComments,
      item.directQuotations,
      item.interviewee,
      item.meetingWorkshop,
      item.priority,
      item.dataMaturityArea,
      item.mentions || "",
      item.totalMentions || 1
    ]);
    
    const tableText = [headers, ...rows].map(row => row.join("\t")).join("\n");
    copyToClipboard(tableText);
  };

  const generateSlide1Headline = (title: string, roi: string, businessCase: string, index: number) => {
    const cleanTitle = title.replace(/\.$/, '');
    const cleanBC = businessCase.toLowerCase().split('.')[0].replace(/\.$/, '');
    
    const templates = [
      `A Modern Data Platform reimagines ${cleanTitle} by eliminating operational siloes to achieve enterprise-wide visibility`,
      `Unified data architecture transforms ${cleanTitle} into a sustainable competitive advantage through real-time data flow`,
      `The Modern Data Platform centralizes ${cleanBC} and future-proofs ${cleanTitle} as a strategic enterprise anchor`,
      `Integrated platform services modernize the ${cleanTitle} ecosystem to drive organizational agility and superior market response`
    ];

    const statement = templates[index % templates.length];
    const words = statement.trim().split(/\s+/);
    return words.slice(0, 22).join(' ');
  };

  const generateSlide2Headline = (title: string, roi: string, index: number) => {
    const cleanTitle = title.replace(/\.$/, '');
    
    const templates = [
      `Strategic migration to a Modern Data Platform unlocks compound enterprise value for ${cleanTitle} through structural data integrity`,
      `The Unified Modern Data Platform captures long-term structural margin expansion and increased data velocity for ${cleanTitle}`,
      `Modern Data Platform evolution shifts ${cleanTitle} from reactive reporting to proactive, high-velocity decision-making capabilities`,
      `Integrated platform services serve as the primary catalyst for ${cleanTitle} modernization and architectural consolidation at scale`
    ];

    const statement = templates[index % templates.length];
    const words = statement.trim().split(/\s+/);
    return words.slice(0, 22).join(' ');
  };

  const exportAllUseCasesToPPTX = async () => {
    if (!companyProfile || !companyProfile.opportunities) {
      toast.error("No company profile data available.");
      return;
    }
    
    const selectedOpps = companyProfile.opportunities.filter(o => o.selected);
    if (selectedOpps.length === 0) {
      toast.error("No selected use cases to export. Mark some opportunities first.");
      return;
    }

    try {
      const PptxGen = (await import("pptxgenjs")).default;
      const pptx = new PptxGen();
      
      pptx.layout = 'LAYOUT_16x9';
      
      // Add Title Slide
      let titleSlide = pptx.addSlide();
      titleSlide.background = { color: '002855' };
      titleSlide.addText(companyProfile.name.toUpperCase(), {
        x: 1, y: 3.5, w: '80%', h: 1,
        fontSize: 36, color: 'FFFFFF', bold: true, align: 'center', charSpacing: 2
      });
      titleSlide.addText("MODERN DATA PLATFORM USE CASE DECK", {
        x: 1, y: 4.5, w: '80%', h: 0.5,
        fontSize: 14, color: 'cbd5e1', bold: true, align: 'center', charSpacing: 4
      });
      titleSlide.addText("Strategic Enterprise Roadmap", {
        x: 1, y: 5.2, w: '80%', h: 0.5,
        fontSize: 12, color: 'FFFFFF', align: 'center', italic: true
      });

      selectedOpps.forEach((opp, index) => {
        const oppIndex = companyProfile.opportunities.indexOf(opp);
        const slide1Headline = generateSlide1Headline(opp.title, opp.roi, opp.businessCase, oppIndex);
        const slide2Headline = generateSlide2Headline(opp.title, opp.roi, oppIndex);
        
        // Slide 1: Strategic Analysis
        let s1 = pptx.addSlide();
        s1.addText("STRATEGIC OPPORTUNITY ANALYSIS", { x: 0.5, y: 0.5, w: 5, h: 0.3, fontSize: 10, color: '94a3b8', bold: true, charSpacing: 2 });
        s1.addText(slide1Headline, { x: 0.5, y: 0.8, w: 9, h: 1, fontSize: 24, color: '002855', bold: true });
        s1.addShape(pptx.ShapeType.rect, { x: 0.5, y: 1.8, w: 1, h: 0.05, fill: { color: '475569' } });

        // Problem
        s1.addText("PROBLEM / OPPORTUNITY", { x: 0.5, y: 2.2, w: 3, h: 0.3, fontSize: 9, color: '64748b', bold: true });
        s1.addShape(pptx.ShapeType.rect, { x: 0.5, y: 2.5, w: 2.8, h: 3, fill: { color: 'f8fafc' }, line: { color: 'e2e8f0', width: 1 } });
        s1.addText(opp.businessCase, { x: 0.6, y: 2.6, w: 2.6, h: 2.8, fontSize: 11, color: '475569' });

        // Solution
        s1.addText("PROPOSED SOLUTION", { x: 3.5, y: 2.2, w: 3, h: 0.3, fontSize: 9, color: '475569', bold: true });
        s1.addShape(pptx.ShapeType.rect, { x: 3.5, y: 2.5, w: 2.8, h: 3, fill: { color: 'f1f5f9' }, line: { color: 'cbd5e1', width: 1 } });
        s1.addText(`Implementation of a Modern Data Platform provides a unified architecture to ingest, process, and serve ${opp.facts.join(', ')} data.`, { x: 3.6, y: 2.6, w: 2.6, h: 2.8, fontSize: 11, color: '334155', bold: true });

        // Value
        s1.addText("VALUE / BENEFITS", { x: 6.5, y: 2.2, w: 3, h: 0.3, fontSize: 9, color: '64748b', bold: true });
        s1.addShape(pptx.ShapeType.rect, { x: 6.5, y: 2.5, w: 2.8, h: 3, fill: { color: 'f8fafc' }, line: { color: 'e2e8f0', width: 1 } });
        s1.addText("ROI Target:", { x: 6.6, y: 2.6, w: 2.6, h: 0.3, fontSize: 10, color: '94a3b8', bold: true });
        s1.addText(opp.roi, { x: 6.6, y: 2.9, w: 2.6, h: 0.5, fontSize: 18, color: '1e293b', bold: true });

        // Slide 2: ROI & Detail
        let s2 = pptx.addSlide();
        s2.addText("ROI OUTCOMES & KPI TARGETS", { x: 0.5, y: 0.5, w: 5, h: 0.3, fontSize: 10, color: '94a3b8', bold: true, charSpacing: 2 });
        s2.addText(slide2Headline, { x: 0.5, y: 0.8, w: 9, h: 1, fontSize: 24, color: '002855', bold: true });
        s2.addShape(pptx.ShapeType.rect, { x: 0.5, y: 1.8, w: 1, h: 0.05, fill: { color: '002855' } });

        const kpis = [
          `Increase in ${opp.dimensions[0] || 'Operational'} Efficiency`,
          `Reduction in ${opp.facts[0] || 'Data'} Latency`,
          `Improvement in ${opp.dimensions[1] || 'Process'} Visibility`,
          `Growth in ${opp.title.split(' ')[0]} Velocity`
        ];

        s2.addText("KPI TARGETS", { x: 0.5, y: 2.2, w: 3, h: 0.3, fontSize: 9, color: '64748b', bold: true });
        kpis.forEach((kpi, kIdx) => {
          s2.addText(`• ${kpi}`, { x: 0.5, y: 2.5 + (kIdx * 0.4), w: 3, h: 0.3, fontSize: 11, color: '475569' });
        });

        s2.addText("ASSUMPTIONS", { x: 3.5, y: 2.2, w: 3, h: 0.3, fontSize: 9, color: '64748b', bold: true });
        s2.addText(`• Executive sponsorship for MDP transition\n• Availability of historical ${opp.facts[0]} data\n• Cloud-native toolchain readiness`, { x: 3.5, y: 2.5, w: 2.8, h: 1.5, fontSize: 11, color: '475569' });

        s2.addText("RISKS & MITIGATIONS", { x: 6.5, y: 2.2, w: 3, h: 0.3, fontSize: 9, color: '64748b', bold: true });
        s2.addShape(pptx.ShapeType.rect, { x: 6.5, y: 2.5, w: 2.8, h: 2.5, fill: { color: '334155' } });
        s2.addText(`Risk: Data quality issues\nMitigation: Automated profiling\n\nRisk: Tech complexity\nMitigation: Phased rollout`, { x: 6.6, y: 2.6, w: 2.6, h: 2.3, fontSize: 10, color: 'f1f5f9' });
      });

      pptx.writeFile({ fileName: `${companyProfile.name.replace(/\s+/g, '_')}_Roadmap_UseCases.pptx` })
        .then(() => toast.success("PowerPoint Roadmap exported successfully!"))
        .catch(err => toast.error("Export failed: " + err.message));
    } catch (error) {
      console.error("PPTX Error:", error);
      toast.error("Failed to load export engine.");
    }
  };


  const renderHeaderExportButtons = () => {
    if (currentModel && activeTab !== 'sttm') {
      return (
        <div className="flex items-center gap-1 mr-2 px-1.5 py-1 bg-slate-100/50 rounded-lg border border-slate-200 shadow-inner">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7 text-slate-500 hover:text-primary hover:bg-white transition-all rounded-md"
            onClick={() => copyTableToClipboard(currentModel)}
            title="Copy Table to Clipboard"
          >
            <Copy size={14} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7 text-slate-500 hover:text-emerald-600 hover:bg-white transition-all rounded-md"
            onClick={() => exportToCSV(currentModel)}
            title="Export to CSV"
          >
            <FileText size={14} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7 text-slate-500 hover:text-blue-600 hover:bg-white transition-all rounded-md"
            onClick={() => exportToExcel(currentModel)}
            title="Export to Excel"
          >
            <TableIcon size={14} />
          </Button>
        </div>
      );
    }

    if (activeTab === 'sttm' && selectedSttmAssetId) {
      const mapping = sttmMappings.find(m => m.targetTableId === selectedSttmAssetId || m.tableId === selectedSttmAssetId);
      const targetTable = filteredHistory.find(h => h.id === selectedSttmAssetId);
      
      if (mapping && targetTable && !mapping.isGenerating) {
        return (
          <div className="flex items-center gap-1 mr-2 px-1.5 py-1 bg-slate-100/50 rounded-lg border border-slate-200 shadow-inner">
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7 text-slate-500 hover:text-primary hover:bg-white transition-all rounded-md"
              onClick={() => copySTTMToClipboard(mapping, targetTable)}
              title="Copy STTM to Clipboard"
            >
              <Copy size={14} />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7 text-slate-500 hover:text-emerald-600 hover:bg-white transition-all rounded-md"
              onClick={() => exportSTTMToCSV(mapping, targetTable)}
              title="Export STTM to CSV"
            >
              <FileText size={14} />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7 text-slate-500 hover:text-blue-600 hover:bg-white transition-all rounded-md"
              onClick={() => exportSTTMToExcel(mapping, targetTable)}
              title="Export STTM to Excel"
            >
              <TableIcon size={14} />
            </Button>
          </div>
        );
      }
    }
    return null;
  };

  const currentProject = useMemo(() => {
    return projects.find(p => p.id === currentProjectId);
  }, [projects, currentProjectId]);

  useEffect(() => {
    const checkScroll = () => {
      if (sidebarScrollRef.current) {
        const { scrollHeight, clientHeight } = sidebarScrollRef.current;
        setIsSidebarScrollable(scrollHeight > clientHeight + 5);
      }
    };
    
    checkScroll();
    const resizeObserver = new ResizeObserver(checkScroll);
    if (sidebarScrollRef.current) resizeObserver.observe(sidebarScrollRef.current);
    
    return () => resizeObserver.disconnect();
  }, [activeTab, companyProfile, currentProject, oppFiles]);

  // Update industry and companyName when project changes
  useEffect(() => {
    if (currentProject) {
      setIndustry(currentProject.industry || "");
      setCompanyName(currentProject.companyName || "");
      setCompanyProfile(currentProject.companyProfile || null);
      
      // Clear selections and output panes
      setCurrentModel(null);
      setCurrentDashboard(null);
      setSelectedSttmAssetId("");
      setSelectedStarSchemaId("");
      setAssetSubTab("schema");
      
      // Reset any error/loading state
      setError(null);
      setLoading(false);
    }
  }, [currentProjectId]);

  // Sync company/industry details to current project state for persistence
  useEffect(() => {
    if (isLoaded.current && currentProjectId) {
      setProjects(prev => {
        const p = prev.find(proj => proj.id === currentProjectId);
        if (p && (p.companyProfile !== companyProfile || p.industry !== industry || p.companyName !== companyName)) {
          return prev.map(proj => 
            proj.id === currentProjectId 
              ? { ...proj, companyProfile: companyProfile || undefined, industry, companyName } 
              : proj
          );
        }
        return prev;
      });
    }
  }, [companyProfile, industry, companyName, currentProjectId]);

  const filteredHistory = useMemo(() => {
    return history.filter(item => item.projectId === currentProjectId);
  }, [history, currentProjectId]);

  const availableDimensions = useMemo(() => {
    return filteredHistory.filter(item => item.tableType === 'Dimension');
  }, [filteredHistory]);

  const availableStarSchemas = useMemo(() => {
    return filteredHistory.filter(item => item.tableType === 'Fact');
  }, [filteredHistory]);

  const filteredDashboards = useMemo(() => {
    return dashboards.filter(d => d.projectId === currentProjectId);
  }, [dashboards, currentProjectId]);

  const filteredSttmMappings = useMemo(() => {
    return sttmMappings.filter(m => m.projectId === currentProjectId);
  }, [sttmMappings, currentProjectId]);

  const handleCreateProject = useCallback(() => {
    if (!newProjectName.trim()) return;
    if (newProjectName.trim().toLowerCase() === "demo dw") {
      setError("The name 'Demo DW' is reserved for the default project.");
      return;
    }
    const newProject: Project = {
      id: crypto.randomUUID(),
      name: newProjectName,
      createdAt: new Date().toISOString(),
      industry: industry,
      companyName: companyName
    };
    setProjects(prev => {
      const updated = [...prev, newProject];
      localStorage.setItem("dw_modeler_projects", JSON.stringify(updated));
      return updated;
    });
    setCurrentProjectId(newProject.id);
    localStorage.setItem("dw_modeler_current_project_id", newProject.id);
    setNewProjectName("");
    setIsProjectDialogOpen(false);
  }, [newProjectName, industry, companyName]);

  const handleRenameProject = useCallback(() => {
    if (!renameValue.trim() || !currentProjectId) return;
    if (currentProject?.name === "Demo DW") {
      setError("The 'Demo DW' project cannot be renamed.");
      return;
    }
    if (renameValue.trim().toLowerCase() === "demo dw") {
      setError("The name 'Demo DW' is reserved.");
      return;
    }
    setProjects(prev => prev.map(p => 
      p.id === currentProjectId ? { ...p, name: renameValue } : p
    ));
    setIsRenameDialogOpen(false);
    setRenameValue("");
  }, [renameValue, currentProjectId, currentProject]);

  const handleDeleteProject = useCallback(() => {
    if (!projectToDelete) return;
    if (projectToDelete.name === "Demo DW") {
      setError("The 'Demo DW' project cannot be deleted.");
      setIsDeleteDialogOpen(false);
      return;
    }
    
    const remainingProjects = projects.filter(p => p.id !== projectToDelete.id);
    setProjects(remainingProjects);
    
    // Also clean up history and dashboards for this project
    setHistory(prev => prev.filter(h => h.projectId !== projectToDelete.id));
    setDashboards(prev => prev.filter(d => d.projectId !== projectToDelete.id));
    
    if (currentProjectId === projectToDelete.id) {
      if (remainingProjects.length > 0) {
        setCurrentProjectId(remainingProjects[0].id);
      } else {
        setCurrentProjectId("");
      }
    }
    
    setIsDeleteDialogOpen(false);
    setProjectToDelete(null);
  }, [projectToDelete, projects, currentProjectId]);

  const handleClearMapping = (tableId: string, targetColumnName: string) => {
    setSttmMappings(prev => prev.map(m => {
      if (m.tableId === tableId || m.targetTableId === tableId) {
        return {
          ...m,
          mappings: m.mappings.map(map => {
            if (map.targetColumnName === targetColumnName) {
              return {
                ...map,
                source: {
                  sourceSystem: '',
                  sourceSchema: '',
                  sourceTable: '',
                  sourceFieldName: '',
                  sourceDatatype: '',
                  etlRules: 'TBD'
                }
              };
            }
            return map;
          })
        };
      }
      return m;
    }));
    toast.success(`Cleared mapping for ${targetColumnName}`);
  };

  const [showNoMappingsDialog, setShowNoMappingsDialog] = useState(false);
  const [noMappingsTable, setNoMappingsTable] = useState<string>("");

  const handleGenerateSTTM = useCallback(async () => {
    if (!selectedSttmAssetId || !sourceDefinitions.trim()) {
      setError("Please select an asset and provide Source Definition and Special Instructions.");
      return;
    }

    const targetTable = history.find(h => h.id === selectedSttmAssetId);
    if (!targetTable) {
      setError("Selected asset not found.");
      return;
    }

    // Create skeleton mapping immediately
    const skeletonMapping: STTMMapping = {
      id: crypto.randomUUID(),
      tableId: targetTable.id,
      targetTableId: targetTable.id,
      projectId: currentProjectId,
      mappings: targetTable.columns.map(col => ({
        targetColumnName: col.columnName,
        source: {
          sourceSystem: "",
          sourceSchema: "",
          sourceTable: "",
          sourceFieldName: "",
          sourceDatatype: "",
          etlRules: ""
        }
      })),
      createdAt: new Date().toISOString(),
      isGenerating: true
    };

    setSttmMappings(prev => {
      const filtered = prev.filter(m => m.tableId !== selectedSttmAssetId);
      return [skeletonMapping, ...filtered];
    });

    setLoading(true);
    setError(null);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      let combinedSourceDefs = sourceDefinitions;
      
      // Read uploaded files
      for (const file of uploadedFiles) {
        try {
          if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
            const data = await file.arrayBuffer();
            const workbook = XLSX.read(data);
            let excelContent = `--- EXCEL FILE: ${file.name} ---\n`;
            workbook.SheetNames.forEach(sheetName => {
              const worksheet = workbook.Sheets[sheetName];
              const json = XLSX.utils.sheet_to_json(worksheet);
              excelContent += `\n[Sheet: ${sheetName}]\n${JSON.stringify(json, null, 2)}\n`;
            });
            combinedSourceDefs += `\n\n${excelContent}`;
          } else {
            const content = await file.text();
            combinedSourceDefs += `\n\n--- FILE: ${file.name} ---\n${content}`;
          }
        } catch (fileErr) {
          console.error(`Failed to read file ${file.name}`, fileErr);
        }
      }

      const existingMapping = sttmMappings.find(m => m.tableId === selectedSttmAssetId || m.targetTableId === selectedSttmAssetId);
      const mapping = await generateSTTMMapping(targetTable, combinedSourceDefs, currentProjectId, controller.signal, existingMapping);
      
      // Check if any business columns were actually mapped
      const mappedCount = mapping.mappings.filter(m => 
        m.source.sourceFieldName && 
        !m.targetColumnName.startsWith('dw_') && 
        !m.targetColumnName.startsWith('sys_')
      ).length;

      setSttmMappings(prev => {
        const filtered = prev.filter(m => m.tableId !== selectedSttmAssetId);
        return [{ ...mapping, isGenerating: false }, ...filtered];
      });
      
      // Ensure the view switches to show the mapping
      setActiveTab('sttm');
      setSelectedSttmAssetId(targetTable.id);
      setCurrentModel(targetTable);
      setCurrentDashboard(null);
      
      if (mappedCount === 0) {
        setNoMappingsTable(targetTable.tableName);
        setShowNoMappingsDialog(true);
        toast.error(`No source fields could be mapped for ${targetTable.tableName}.`, {
          duration: 4000,
          icon: '⚠️'
        });
      } else {
        toast.success(`Successfully generated STTM mapping for ${targetTable.tableName} (${mappedCount} fields mapped)`);
      }
    } catch (err) {
      if (err instanceof Error && err.message === "Aborted") return;
      setError(err instanceof Error ? err.message : "Failed to generate STTM mapping.");
      console.error(err);
      // Keep target columns but set isGenerating to false
      setSttmMappings(prev => prev.map(m => m.tableId === selectedSttmAssetId ? { ...m, isGenerating: false } : m));
    } finally {
      if (abortControllerRef.current === controller) {
        setLoading(false);
        abortControllerRef.current = null;
      }
    }
  }, [selectedSttmAssetId, sourceDefinitions, currentProjectId, history, uploadedFiles]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newFiles = Array.from(files);
    setUploadedFiles(prev => [...prev, ...newFiles]);
    
    // Default instruction when files are uploaded
    if (sourceDefinitions.length === 0 || sourceDefinitions === "") {
      const isFactTable = history.find(h => h.id === selectedSttmAssetId)?.tableType === 'Fact';
      let text = "Employ advanced fuzzy matching algorithms and LLM-assisted matching to determine matches from the attached source definitions to each of the target columns.";
      
      if (isFactTable) {
        text += " When performing mapping on fact tables, link to other dimension tables within the star to construct the ETL transformation logic in the source columns.";
      }
      
      setSourceDefinitions(text);
    }

    toast.success(`${newFiles.length} file(s) uploaded successfully!`);
  };

  const handleGenerateDimension = useCallback(async () => {
    if (!industry || !dimTableName || !companyName) {
      setError("Please provide industry, company name, and table name.");
      return;
    }

    setLoading(true);
    setError(null);
    
    // Create new abort controller
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // Persist metadata to project if changed
      if (currentProject && (currentProject.industry !== industry || currentProject.companyName !== companyName)) {
        setProjects(prev => prev.map(p => 
          p.id === currentProjectId ? { ...p, industry, companyName } : p
        ));
      }

      const tableNames = dimTableName.split('\n').map(t => t.trim()).filter(t => t.length > 0);
      
      if (tableNames.length === 1) {
        const model = await generateTableModel(industry, companyName, tableNames[0], 'Dimension', dimComplexity, currentProjectId, undefined, controller.signal, dimSpecialInstructions);
        setCurrentModel(model);
        setHistory(prev => [model, ...prev]);
      } else {
        const models = await generateTableModels(industry, companyName, tableNames, 'Dimension', dimComplexity, currentProjectId, controller.signal, dimSpecialInstructions);
        if (models.length > 0) {
          setCurrentModel(models[0]);
          setHistory(prev => [...models, ...prev]);
        }
      }
    } catch (err) {
      if (err instanceof Error && err.message === "Aborted") {
        return; // Handled by handleCancel
      }
      setError(err instanceof Error ? err.message : "Failed to generate dimension. Please try again.");
      console.error(err);
    } finally {
      if (abortControllerRef.current === controller) {
        setLoading(false);
        abortControllerRef.current = null;
      }
    }
  }, [industry, dimTableName, companyName, dimComplexity, currentProjectId, currentProject]);

  const handleGenerateFact = useCallback(async () => {
    if (!industry || !factTableName || !companyName || !subjectArea) {
      setError("Please provide industry, company name, table name, and subject area.");
      return;
    }

    if (selectedDimensions.length === 0) {
      setError("Please select at least one dimension to link to the fact table.");
      return;
    }

    setLoading(true);
    setError(null);

    // Create new abort controller
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // Persist metadata to project if changed
      if (currentProject && (currentProject.industry !== industry || currentProject.companyName !== companyName)) {
        setProjects(prev => prev.map(p => 
          p.id === currentProjectId ? { ...p, industry, companyName } : p
        ));
      }

      const model = await generateTableModel(
        industry, 
        companyName, 
        factTableName, 
        'Fact', 
        factComplexity,
        currentProjectId,
        {
          subjectArea,
          factType,
          aggregateGrain: factType === 'Aggregate' ? aggregateGrain : undefined,
          availableDimensions: selectedDimensions
        },
        controller.signal,
        factSpecialInstructions
      );
      // Ensure relatedDimensions is set correctly from our selection if AI missed it
      model.relatedDimensions = selectedDimensions;
      setCurrentModel(model);
      setHistory(prev => [model, ...prev]);
    } catch (err) {
      if (err instanceof Error && err.message === "Aborted") {
        return; // Handled by handleCancel
      }
      setError(err instanceof Error ? err.message : "Failed to generate fact. Please try again.");
      console.error(err);
    } finally {
      if (abortControllerRef.current === controller) {
        setLoading(false);
        abortControllerRef.current = null;
      }
    }
  }, [industry, factTableName, companyName, subjectArea, selectedDimensions, factComplexity, currentProjectId, factType, aggregateGrain, currentProject]);

  const handleGenerateOpportunities = useCallback(async () => {
    if (!industry || !companyName) {
      setError("Please provide industry and company name.");
      return;
    }

    setLoading(true);
    setError(null);
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // Prepare attachments if any
      const attachments: CompanyProfilePart[] = oppFiles.map(f => ({
        inlineData: {
          mimeType: f.type,
          data: f.data
        }
      }));

      // Sync company name with selected ticker match if available
      const currentMatch = potentialTickers.find(t => t.symbol === selectedTicker) || 
                          companyProfile?.potentialTickers?.find(t => t.symbol === selectedTicker);
      
      const profile = await generateCompanyOpportunities(industry, companyName, oppAdditionalContext, oppCount, controller.signal, selectedTicker || undefined, attachments);
      setCompanyProfile(profile);
      
      // Update potential tickers from the generated profile
      const newPotentialTickers = profile.potentialTickers || [];
      setPotentialTickers(newPotentialTickers);

      let finalTicker = "";
      if (profile.ticker) {
        finalTicker = profile.ticker;
      } else if (newPotentialTickers.length > 0) {
        finalTicker = newPotentialTickers[0].symbol;
      } else if (profile.ownershipType !== 'Public') {
        finalTicker = "NON_PUBLIC";
      }
      
      setSelectedTicker(finalTicker);
      if (finalTicker) {
        setProfileCache(prev => ({ ...prev, [finalTicker]: profile }));
      }
      
      toast.success("Successfully generated MDP opportunities for " + profile.name);
    } catch (err) {
      if (err instanceof Error && err.message === "Aborted") return;
      setError(err instanceof Error ? err.message : "Failed to generate MDP opportunities.");
      console.error(err);
    } finally {
      if (abortControllerRef.current === controller) {
        setLoading(false);
        abortControllerRef.current = null;
      }
    }
  }, [industry, companyName, oppAdditionalContext, oppCount, selectedTicker, potentialTickers, companyProfile]);

  const handleGeneratePlatformEstimates = useCallback(async () => {
    if (selectedPlatforms.length === 0) {
      toast.error("Please select at least one platform.");
      return;
    }

    setLoading(true);
    setIsGeneratingEstimates(true);
    setError(null);
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const results = await generatePlatformEstimates({
        platforms: selectedPlatforms,
        selectedComponents: selectedComponents,
        biToolChoice: biToolChoice,
        directSources: directSourcesCount,
        streamingSources: streamingSourcesCount,
        streamingPayloadSize: streamingPayloadSize,
        apiConnections: apiConnectionsCount,
        flatFiles: flatFilesCount,
        bronzeSize: bronzeSize,
        cloud: preferredCloud,
        frequency: batchFrequency,
        realtimeFrequency: realtimeFrequency,
        environments: selectedEnvironments,
        industry: industry || 'Technology',
        companyName: companyName || 'Client',
        specialInstructions,
        advancedQuestionnaire
      }, controller.signal);

      const now = new Date().toISOString();
      setPlatformEstimates(results);
      setLastGeneratedAt(now);

      // Automatic save to BD Assets
      const newAsset: PlatformEstimateAsset = {
        id: crypto.randomUUID(),
        scenarioId: currentScenarioId || 'manual',
        scenarioName: scenarioName,
        projectId: currentProjectId,
        companyName: companyName || 'Client',
        industry: industry || 'Technology',
        results: results,
        createdAt: now,
        inputs: {
          selectedPlatforms,
          selectedComponents,
          biToolChoice,
          directSources: directSourcesCount,
          streamingSources: streamingSourcesCount,
          streamingPayloadMB: streamingPayloadSize,
          apiConnections: apiConnectionsCount,
          flatFiles: flatFilesCount,
          bronzeSizeTB: bronzeSize,
          cloudProvider: preferredCloud,
          batchFrequency,
          realtimeFrequencyMS: realtimeFrequency,
          environments: selectedEnvironments,
          specialInstructions,
          advancedQuestionnaire
        }
      };
      setPlatformEstimateAssets(prev => [newAsset, ...prev]);

      // Store in current scenario if exists
      if (currentScenarioId) {
        setProjects(prev => prev.map(p => {
          if (p.id === currentProjectId) {
            const updatedScenarios = (p.platformScenarios || []).map(s => 
              s.id === currentScenarioId ? { 
                ...s, 
                results, 
                lastGeneratedAt: now,
                inputs: {
                  selectedPlatforms,
                  selectedComponents,
                  biToolChoice,
                  directSources: directSourcesCount,
                  streamingSources: streamingSourcesCount,
                  streamingPayloadMB: streamingPayloadSize,
                  apiConnections: apiConnectionsCount,
                  flatFiles: flatFilesCount,
                  bronzeSizeTB: bronzeSize,
                  cloudProvider: preferredCloud,
                  batchFrequency,
                  realtimeFrequencyMS: realtimeFrequency,
                  environments: selectedEnvironments,
                  specialInstructions,
                  advancedQuestionnaire
                }
              } : s
            );
            return { ...p, platformScenarios: updatedScenarios };
          }
          return p;
        }));
      }

      toast.success("Platform estimates generated successfully.");
    } catch (err) {
      if (err instanceof Error && err.message === "Aborted") return;
      setError(err instanceof Error ? err.message : "Failed to generate platform estimates.");
      console.error(err);
    } finally {
      if (abortControllerRef.current === controller) {
        setLoading(false);
        setIsGeneratingEstimates(false);
        abortControllerRef.current = null;
      }
    }
  }, [
    selectedPlatforms,
    selectedComponents,
    biToolChoice,
    directSourcesCount,
    streamingSourcesCount,
    streamingPayloadSize,
    apiConnectionsCount,
    flatFilesCount,
    bronzeSize,
    preferredCloud,
    batchFrequency,
    realtimeFrequency,
    selectedEnvironments,
    industry,
    companyName,
    currentScenarioId,
    currentProjectId,
    specialInstructions
  ]);

  const toggleOpportunitySelection = (id: string) => {
    setCompanyProfile(prev => {
      if (!prev) return null;
      return {
        ...prev,
        opportunities: prev.opportunities.map(opp => 
          opp.id === id ? { ...opp, selected: !opp.selected } : opp
        )
      };
    });
  };

  const selectAllOpportunities = () => {
    setCompanyProfile(prev => {
      if (!prev) return null;
      return {
        ...prev,
        opportunities: prev.opportunities.map(opp => ({ ...opp, selected: true }))
      };
    });
  };

  const clearAllOpportunities = () => {
    setCompanyProfile(prev => {
      if (!prev) return null;
      return {
        ...prev,
        opportunities: prev.opportunities.map(opp => ({ ...opp, selected: false }))
      };
    });
  };

  // BD BI Dashboards Handlers
  const getIndustrySector = (): string => {
    const name = (companyProfile?.name || "the enterprise").toLowerCase();
    const bio = (companyProfile?.summary || "").toLowerCase();
    const lobList = (companyProfile?.linesOfBusiness || []).map(l => l.toLowerCase());
    const combined = (name + " " + bio + " " + lobList.join(" ")).toLowerCase();

    if (combined.includes("bank") || combined.includes("finance") || combined.includes("wealth") || combined.includes("lending") || combined.includes("investment") || combined.includes("credit") || combined.includes("asset management") || combined.includes("payment")) {
      return "banking";
    }
    if (combined.includes("hospital") || combined.includes("health") || combined.includes("medical") || combined.includes("clinical") || combined.includes("pharma") || combined.includes("patient") || combined.includes("biotech")) {
      return "healthcare";
    }
    if (combined.includes("retail") || combined.includes("store") || combined.includes("commerce") || combined.includes("merchant") || combined.includes("shopper") || combined.includes("consumer goods")) {
      return "retail";
    }
    if (combined.includes("energy") || combined.includes("utility") || combined.includes("solar") || combined.includes("power") || combined.includes("oil") || combined.includes("gas") || combined.includes("grid")) {
      return "energy";
    }
    if (combined.includes("manufactur") || combined.includes("factory") || combined.includes("automotive") || combined.includes("aerospace") || combined.includes("industrial") || combined.includes("assembly")) {
      return "manufacturing";
    }
    if (combined.includes("tech") || combined.includes("software") || combined.includes("cloud") || combined.includes("saas") || combined.includes("platform") || combined.includes("telecom") || combined.includes("server") || combined.includes("infrastructure")) {
      return "technology";
    }
    return "general";
  };

  const getIndustryAdjustedLabel = (label: string): string => {
    const sector = getIndustrySector();
    const lblLow = label.toLowerCase().trim();

    if (sector === "banking") {
      if (lblLow.includes("co2") || lblLow.includes("emission")) return "Green Portfolio Emissions Ratio";
      if (lblLow.includes("green energy") || lblLow.includes("renewable")) return "Sustainable Asset Share";
      if (lblLow.includes("compliance") || lblLow.includes("audit") || lblLow.includes("environmental") || lblLow.includes("rating")) return "Central Bank ESG Audit Compliance";
      if (lblLow.includes("sustainability npv") || lblLow.includes("npv synthesis")) return "Green Investment NPV";
      if (lblLow.includes("opex savings") || lblLow.includes("cost avoidance") || lblLow.includes("opex")) return "Settlement OPEX Savings";
      if (lblLow.includes("gross profit") || lblLow.includes("margin")) return "Net Interest Margin (NIM)";
      if (lblLow.includes("ebitda")) return "EBITDA Operating Benefit";
      if (lblLow.includes("total investment") || lblLow.includes("capital saved") || lblLow.includes("capital allocation") || lblLow.includes("capex")) return "Tier-1 Capital Reservoir";
      if (lblLow.includes("oee") || lblLow.includes("operational rating") || lblLow.includes("efficiency gain")) return "Core Bank Efficiency Rating";
      if (lblLow.includes("cycle time") || lblLow.includes("reduction")) return "Trade Settlement Clearance Velocity";
      if (lblLow.includes("sla compliance") || lblLow.includes("sla availability")) return "Correspondent Wire SLA Rate";
      if (lblLow.includes("material yield") || lblLow.includes("resource utilization")) return "Risk-Weighted Asset Allocation Yield";
      if (lblLow.includes("conversion velocity") || lblLow.includes("pipeline")) return "Credit Line Underwriting Speed";
      if (lblLow.includes("lead volume")) return "High Net Worth Client Inflows";
      if (lblLow.includes("cac") || lblLow.includes("customer acquisition")) return "Account Onboarding Acquisition Cost";
      if (lblLow.includes("retention rate") || lblLow.includes("churn")) return "Corporate Deposit Retention Ratio";
      if (lblLow.includes("system response") || lblLow.includes("latency")) return "Gateway Processing Speed (p95)";
      if (lblLow.includes("infrastructure") || lblLow.includes("compute")) return "Transaction Engine Utilization";
      if (lblLow.includes("vulnerabilities") || lblLow.includes("threat") || lblLow.includes("security")) return "Closed Ledger Security Gaps";
      if (lblLow.includes("risk") || lblLow.includes("exposure")) return "Lending Program Risk Exposure";
      if (lblLow.includes("roi") || lblLow.includes("investment roi")) return "Financing Program Projected ROI";
      if (lblLow.includes("market share") || lblLow.includes("penetration")) return "Loan & Deposit Market Share";
      if (lblLow.includes("strategic value") || lblLow.includes("projected net value")) return "Strategic Capital Expansion Yield";
    } else if (sector === "healthcare") {
      if (lblLow.includes("co2") || lblLow.includes("emission")) return "Clinical Emissions Abatement Ratio";
      if (lblLow.includes("green energy") || lblLow.includes("renewable")) return "Renewable Power Share";
      if (lblLow.includes("compliance") || lblLow.includes("audit") || lblLow.includes("environmental") || lblLow.includes("rating")) return "Care Quality Compliance Rating";
      if (lblLow.includes("sustainability npv") || lblLow.includes("npv synthesis")) return "Sustainability Clinical NPV";
      if (lblLow.includes("opex savings") || lblLow.includes("cost avoidance") || lblLow.includes("opex")) return "Clinical Care OPEX Savings";
      if (lblLow.includes("gross profit") || lblLow.includes("margin")) return "Operating Margin Margin";
      if (lblLow.includes("ebitda")) return "Operating EBITDA Uplift";
      if (lblLow.includes("total investment") || lblLow.includes("capital saved") || lblLow.includes("capital allocation") || lblLow.includes("capex")) return "Healthcare Capital Reserves Pool";
      if (lblLow.includes("oee") || lblLow.includes("operational rating") || lblLow.includes("efficiency gain")) return "Patient Throughput Efficiency Rating";
      if (lblLow.includes("cycle time") || lblLow.includes("reduction")) return "Patient Discharge Cycle Time";
      if (lblLow.includes("sla compliance") || lblLow.includes("sla availability")) return "Emergency Room SLA Compliance";
      if (lblLow.includes("material yield") || lblLow.includes("resource utilization")) return "Clinical Material Utilization Yield";
      if (lblLow.includes("conversion velocity") || lblLow.includes("pipeline")) return "Patient Care Intake Velocity";
      if (lblLow.includes("lead volume")) return "New Patient Referral Count";
      if (lblLow.includes("cac") || lblLow.includes("customer acquisition")) return "Patient Intake Acquisition Cost";
      if (lblLow.includes("retention rate") || lblLow.includes("churn")) return "Patient Retention Consistency";
      if (lblLow.includes("system response") || lblLow.includes("latency")) return "EHR Portal Response Time";
      if (lblLow.includes("infrastructure") || lblLow.includes("compute")) return "PACS Image Server Uptime";
      if (lblLow.includes("vulnerabilities") || lblLow.includes("threat") || lblLow.includes("security")) return "HIPAA Closed Security Exposures";
      if (lblLow.includes("risk") || lblLow.includes("exposure")) return "Clinical Practice Exposure Risk";
      if (lblLow.includes("roi") || lblLow.includes("investment roi")) return "Medical Equipment ROI Yield";
      if (lblLow.includes("market share") || lblLow.includes("penetration")) return "Regional Patient Care Market Share";
      if (lblLow.includes("strategic value") || lblLow.includes("projected net value")) return "Clinical Strategic Value Capture";
    } else if (sector === "retail") {
      if (lblLow.includes("co2") || lblLow.includes("emission")) return "Supply Chain Retail Footprint";
      if (lblLow.includes("green energy") || lblLow.includes("renewable")) return "Retail Store Green Power Share";
      if (lblLow.includes("compliance") || lblLow.includes("audit") || lblLow.includes("environmental") || lblLow.includes("rating")) return "Store Policy Adherence Auditing";
      if (lblLow.includes("sustainability npv") || lblLow.includes("npv synthesis")) return "Sustainability Investment NPV";
      if (lblLow.includes("opex savings") || lblLow.includes("cost avoidance") || lblLow.includes("opex")) return "Supply Logistics OPEX Savings";
      if (lblLow.includes("gross profit") || lblLow.includes("margin")) return "Gross Retail Sales Margin";
      if (lblLow.includes("ebitda")) return "Retail Operations EBITDA";
      if (lblLow.includes("total investment") || lblLow.includes("capital saved") || lblLow.includes("capital allocation") || lblLow.includes("capex")) return "Retail Outlet Capital Budget";
      if (lblLow.includes("oee") || lblLow.includes("operational rating") || lblLow.includes("efficiency gain")) return "Fullfillment Center Efficiency";
      if (lblLow.includes("cycle time") || lblLow.includes("reduction")) return "Order Checkout Cycle Time";
      if (lblLow.includes("sla compliance") || lblLow.includes("sla availability")) return "Logistics Delivery SLA Compliance";
      if (lblLow.includes("material yield") || lblLow.includes("resource utilization")) return "Inventory Packaging Materials Yield";
      if (lblLow.includes("conversion velocity") || lblLow.includes("pipeline")) return "Digital Cart Conversion Rate";
      if (lblLow.includes("lead volume")) return "Active Retail Site Visits";
      if (lblLow.includes("cac") || lblLow.includes("customer acquisition")) return "Retail Customer CAC Spend";
      if (lblLow.includes("retention rate") || lblLow.includes("churn")) return "Shopper Repeat Retention Ratio";
      if (lblLow.includes("system response") || lblLow.includes("latency")) return "Checkout POS Latency (p95)";
      if (lblLow.includes("infrastructure") || lblLow.includes("compute")) return "Inventory Engine Server Uptime";
      if (lblLow.includes("vulnerabilities") || lblLow.includes("threat") || lblLow.includes("security")) return "Protected Customer Card Exposures";
      if (lblLow.includes("risk") || lblLow.includes("exposure")) return "Inventory Shrinkage Exposure Risk";
      if (lblLow.includes("roi") || lblLow.includes("investment roi")) return "Retail Store Expansion ROI";
      if (lblLow.includes("market share") || lblLow.includes("penetration")) return "Category Brand Market Share";
      if (lblLow.includes("strategic value") || lblLow.includes("projected net value")) return "Retail Segment Strategic Value";
    }

    // Default or general overrides
    if (lblLow.includes("co2") || lblLow.includes("emission")) return "Carbon Footprint Ratio";
    if (lblLow.includes("green energy") || lblLow.includes("renewable")) return "Power Efficiency Ratio";
    if (lblLow.includes("compliance") || lblLow.includes("audit") || lblLow.includes("environmental") || lblLow.includes("rating")) return "Corporate Governance Rating";
    if (lblLow.includes("sustainability npv") || lblLow.includes("npv synthesis")) return "Green Initiative NPV";
    if (lblLow.includes("opex savings") || lblLow.includes("cost avoidance") || lblLow.includes("opex")) return "Operational OPEX Conservation";
    if (lblLow.includes("gross profit") || lblLow.includes("margin")) return "Operating Margin Efficiency";
    if (lblLow.includes("ebitda")) return "Quarterly EBITDA Benefit";
    if (lblLow.includes("total investment") || lblLow.includes("capital saved") || lblLow.includes("capital allocation") || lblLow.includes("capex")) return "Allocated Business Capital";
    if (lblLow.includes("oee") || lblLow.includes("operational rating") || lblLow.includes("efficiency gain")) return "Process Efficiency Rating";
    if (lblLow.includes("cycle time") || lblLow.includes("reduction")) return "Task Completion Velocity";
    if (lblLow.includes("sla compliance") || lblLow.includes("sla availability")) return "Client SLA Compliance";
    if (lblLow.includes("material yield") || lblLow.includes("resource utilization")) return "Resource Allocation Yield";
    if (lblLow.includes("conversion velocity") || lblLow.includes("pipeline")) return "Client Contract Velocity";
    if (lblLow.includes("lead volume")) return "Inbound Client Requests";
    if (lblLow.includes("cac") || lblLow.includes("customer acquisition")) return "Client Acquisition Cost";
    if (lblLow.includes("retention rate") || lblLow.includes("churn")) return "Account Retention Rate";

    return label;
  };

  const getIndustryAdjustedChartTitle = (title: string): string => {
    const sector = getIndustrySector();
    const tLow = title.toLowerCase().trim();

    if (sector === "banking") {
      if (tLow.includes("intensity") || tLow.includes("carbon")) return "Projected Financed Carbon Trajectory";
      if (tLow.includes("emissions") || tLow.includes("scope")) return "Corporate Headquarters Financed Footprint";
      if (tLow.includes("energy efficiency") || tLow.includes("renewable")) return "Corporate Office Energy Efficiency";
      if (tLow.includes("renewable power") || tLow.includes("renewable power mix")) return "Green Financing Asset Mix";
      if (tLow.includes("esg score") || tLow.includes("sustainability net value")) return "Credit Portfolio ESG Quality Matrix";
      if (tLow.includes("npv realization") || tLow.includes("forecaster")) return "Consolidated Trade Corridor NPV Forecast";
      if (tLow.includes("ebitda") || tLow.includes("revenue")) return "EBITDA Velocity Trajectory";
      if (tLow.includes("cost allocation") || tLow.includes("capex") || tLow.includes("budget") || tLow.includes("spending")) return "Clearing Node Cost Allocations";
      if (tLow.includes("strategic investment") || tLow.includes("capital efficiency") || tLow.includes("capex")) return "Transaction Corridor CapEx Allocations";
      if (tLow.includes("budget variance")) return "Branch Budget Overlays & Variances";
      if (tLow.includes("cycle time") || tLow.includes("throughput")) return "Cross-Border Wire Cycle Trajectory";
      if (tLow.includes("resource scales") || tLow.includes("asset utilization") || tLow.includes("utilization")) return "Treasury Capital Allocation Balance";
      if (tLow.includes("supply chain") || tLow.includes("delivery") || tLow.includes("resilience")) return "Cross-Border Wire Routing Resilience";
      if (tLow.includes("velocity") || tLow.includes("throughput velocity") || tLow.includes("throughput analysis")) return "Daily Transaction Settlement Speed";
      if (tLow.includes("downtime") || tLow.includes("vulnerability grid")) return "Interbank Ledger Server Downtime Grid";
      if (tLow.includes("yield") || tLow.includes("yield allocation") || tLow.includes("material yield")) return "Treasury Capital Yield Allocation";
      if (tLow.includes("pipeline") || tLow.includes("progression")) return "Corporate Credit Underwriting Pipeline";
      if (tLow.includes("acquisition") || tLow.includes("scatter")) return "Loan Program Acquisition Densities";
      if (tLow.includes("retention") || tLow.includes("cohort")) return "Merchant Deposit Lifecycle Cohorts";
      if (tLow.includes("sale growth") || tLow.includes("distribution")) return "Regional Asset Growth Allocations";
      if (tLow.includes("campaign") || tLow.includes("attribution")) return "Commercial Lead Attribution Funnel";
      if (tLow.includes("market share") || tLow.includes("penetration")) return "Loan & Deposit Market Share";
    } else if (sector === "healthcare") {
      if (tLow.includes("intensity") || tLow.includes("carbon")) return "Clinical Footprint Reduction Trajectory";
      if (tLow.includes("emissions") || tLow.includes("scope")) return "Sterilization & Lab Scope Footprint";
      if (tLow.includes("energy efficiency") || tLow.includes("renewable")) return "Clinic Ward Power Optimization";
      if (tLow.includes("esg score") || tLow.includes("sustainability net value")) return "Patient Health Compliance ESG Spectrum";
      if (tLow.includes("npv realization") || tLow.includes("forecaster")) return "EHR Integration Clinic NPV Forecast";
      if (tLow.includes("ebitda") || tLow.includes("revenue")) return "Operating Margin Generation Model";
      if (tLow.includes("cost allocation") || tLow.includes("capex") || tLow.includes("budget") || tLow.includes("spending")) return "Clinical Practice Budget Allocations";
      if (tLow.includes("cycle time") || tLow.includes("throughput")) return "Ward Discharge Elapsed Run";
      if (tLow.includes("resource scales") || tLow.includes("asset utilization") || tLow.includes("utilization")) return "Surgical Suite Asset Allocation";
      if (tLow.includes("supply chain") || tLow.includes("delivery") || tLow.includes("resilience")) return "Medical Supply Line Resilience";
      if (tLow.includes("velocity") || tLow.includes("throughput velocity") || tLow.includes("throughput analysis")) return "Emergency Room Patient Flow Velocity";
      if (tLow.includes("downtime") || tLow.includes("vulnerability grid")) return "Critical PAC Server Uptime Safeguard";
      if (tLow.includes("yield") || tLow.includes("yield allocation") || tLow.includes("material yield")) return "Medical Dispense Precision Yield";
    } else if (sector === "retail") {
      if (tLow.includes("intensity") || tLow.includes("carbon")) return "Retail Fleet Emission Reductions";
      if (tLow.includes("emissions") || tLow.includes("scope")) return "Warehouse & Store Emissions Scope";
      if (tLow.includes("energy efficiency") || tLow.includes("renewable")) return "Outlet Store Utility Conservation";
      if (tLow.includes("esg score") || tLow.includes("sustainability net value")) return "Sustainable Brand Segment Matrix";
      if (tLow.includes("npv realization") || tLow.includes("forecaster")) return "Digital Cart Program NPV Forecast";
      if (tLow.includes("ebitda") || tLow.includes("revenue")) return "ECommerce Segment EBITDA Model";
      if (tLow.includes("cost allocation") || tLow.includes("capex") || tLow.includes("budget") || tLow.includes("spending")) return "Merchandise Overhead Allocations";
      if (tLow.includes("cycle time") || tLow.includes("throughput")) return "Cart Completion Sequence Duration";
      if (tLow.includes("resource scales") || tLow.includes("asset utilization") || tLow.includes("utilization")) return "ECommerce Fulfillment Resource Grid";
      if (tLow.includes("supply chain") || tLow.includes("delivery") || tLow.includes("resilience")) return "Last-Mile Delivery Route Resilience";
      if (tLow.includes("velocity") || tLow.includes("throughput velocity") || tLow.includes("throughput analysis")) return "Fulfillment Pack-out Rate Velocities";
      if (tLow.includes("downtime") || tLow.includes("vulnerability grid")) return "Shopping Portal Website Server Downtime";
      if (tLow.includes("yield") || tLow.includes("yield allocation") || tLow.includes("material yield")) return "Packaging Waste Abatement Yield";
    }

    // Default fallback mappings to make everything perfect
    if (tLow.includes("intensity") || tLow.includes("carbon")) return "Corporate Emission Projector";
    if (tLow.includes("emissions") || tLow.includes("scope")) return "Facility Footprint Comparison";
    if (tLow.includes("energy efficiency") || tLow.includes("renewable")) return "Regional Office Energy Profile";
    if (tLow.includes("esg score") || tLow.includes("sustainability net value")) return "ESG Quality Score Matrix";
    if (tLow.includes("npv realization") || tLow.includes("forecaster")) return "Discounted Net Cashflow Forecast";
    if (tLow.includes("ebitda") || tLow.includes("revenue")) return "Expected Operating EBITDA Gains";
    if (tLow.includes("cost allocation") || tLow.includes("budget") || tLow.includes("spending")) return "Operating Budget Division Allocations";
    if (tLow.includes("cycle time") || tLow.includes("throughput")) return "Service Execution Turnaround Timelines";
    if (tLow.includes("resource scales") || tLow.includes("asset utilization") || tLow.includes("utilization")) return "Business Asset Allocation Balance";
    if (tLow.includes("supply chain") || tLow.includes("delivery") || tLow.includes("resilience")) return "Task Milestone Delivery Resilience";
    if (tLow.includes("velocity") || tLow.includes("throughput velocity") || tLow.includes("throughput analysis")) return "Workflow Volume Processing Velocity";
    if (tLow.includes("downtime") || tLow.includes("vulnerability grid")) return "Digital Application Server Offline Log";
    if (tLow.includes("yield") || tLow.includes("yield allocation") || tLow.includes("material yield")) return "Asset Utilization Optimization Grid";

    return title;
  };

  const generateKPIdescription = (label: string, value: string, useCase: string): string => {
    const lbl = label.trim();
    const lblLow = lbl.toLowerCase();
    const sector = getIndustrySector();
    const cName = companyProfile?.name || "the enterprise";
    
    // Use a hash of the label title + useCase/value to diversify words
    let hash = 0;
    const combinedStr = lbl + useCase + value;
    for (let i = 0; i < combinedStr.length; i++) {
      hash = (hash << 5) - hash + combinedStr.charCodeAt(i);
      hash |= 0;
    }
    const h = Math.abs(hash);

    // If banking & finance sector
    if (sector === "banking") {
      if (lblLow.includes("co2") || lblLow.includes("emission") || lblLow.includes("green portfolio")) {
        return `Quantifies greenhouse gas emissions from commercial lending asset classes to assist ${cName} with transition audits.`;
      }
      if (lblLow.includes("green energy") || lblLow.includes("renewable") || lblLow.includes("sustainable asset")) {
        return `Tracks the percentage of capital reserves allocated to verified green projects, solar grid financing, and ecological operations.`;
      }
      if (lblLow.includes("compliance") || lblLow.includes("audit") || lblLow.includes("governance")) {
        return `Assesses structured bank policy alignment with central banking AML regulations and financial monitoring directives.`;
      }
      if (lblLow.includes("sustainability npv") || lblLow.includes("npv synthesis") || lblLow.includes("green investment npv")) {
        return `Calculates net present value of long-term economic returns secured from eco-friendly corporate lending programs.`;
      }
      if (lblLow.includes("opex savings") || lblLow.includes("cost avoidance") || lblLow.includes("opex") || lblLow.includes("settlement opex")) {
        return `Monitors operational cost reductions driven by automated payment processing, ledger digitization, and branch consolidation.`;
      }
      if (lblLow.includes("gross profit") || lblLow.includes("margin") || lblLow.includes("nim")) {
        return `Evaluates the spread between interest income earned on loans and interest paid on deposit portfolios.`;
      }
      if (lblLow.includes("ebitda") || lblLow.includes("operating benefit")) {
        return `Tracks fundamental cash earnings derived from international clearing networks and settlement fees prior to administrative tax.`;
      }
      if (lblLow.includes("total investment") || lblLow.includes("capital saved") || lblLow.includes("capital allocation") || lblLow.includes("reservoir")) {
        return `Monitors capital reserve deployments to maintain regulatory Tier-1 adequacy limits.`;
      }
      if (lblLow.includes("oee") || lblLow.includes("operational rating") || lblLow.includes("efficiency rating")) {
        return `Rates transaction routing performance of automated processing centers to minimize clearing bottlenecks.`;
      }
      if (lblLow.includes("cycle time") || lblLow.includes("reduction") || lblLow.includes("velocity")) {
        return `Tracks hours elapsed from initial payment generation to final global correspondent ledger clearing.`;
      }
      if (lblLow.includes("sla compliance") || lblLow.includes("sla availability") || lblLow.includes("wire sla")) {
        return `Validates correspondent banking settlement times against active partner service level agreements.`;
      }
      if (lblLow.includes("yield") || lblLow.includes("utilization")) {
        return `Measures interest asset allocation spreads across active government treasury vaults and reserves.`;
      }
      if (lblLow.includes("conversion velocity") || lblLow.includes("pipeline") || lblLow.includes("underwriting speed")) {
        return `Logs corporate debt underwriting durations to accelerate liquidity delivery.`;
      }
      if (lblLow.includes("lead volume")) {
        return `Benchmarks monthly volume of inbound trade financing inquiries originating from target expansion corridors.`;
      }
      if (lblLow.includes("cac") || lblLow.includes("acquisition cost")) {
        return `Calculates direct marketing and sales cost spent to onboard each high-net-worth commercial banking customer.`;
      }
      if (lblLow.includes("retention rate") || lblLow.includes("churn") || lblLow.includes("retention ratio")) {
        return `Tracks deposit asset consistency to identify stability patterns among global commercial depositors.`;
      }
      if (lblLow.includes("system response") || lblLow.includes("latency") || lblLow.includes("processing speed")) {
        return `Monitors network transmission delays on clearing APIs to secure sub-millisecond transaction flow.`;
      }
      if (lblLow.includes("security") || lblLow.includes("vulnerabilities") || lblLow.includes("closed ledger")) {
        return `Maintains absolute tracking over network cryptographic gateway audits to prevent unauthorized ledger updates.`;
      }
      if (lblLow.includes("risk") || lblLow.includes("exposure")) {
        return `Assesses direct credit-loss and leverage exposures to protect international capital holdings.`;
      }
      if (lblLow.includes("roi")) {
        return `Monitors direct financial yield capture generated from programmatic trade settlement system upgrades.`;
      }
    }

    // If healthcare sector
    if (sector === "healthcare") {
      if (lblLow.includes("co2") || lblLow.includes("emission") || lblLow.includes("footprint")) {
        return `Tracks direct medical unit carbon footprints across active regional clinical operations.`;
      }
      if (lblLow.includes("green energy") || lblLow.includes("renewable")) {
        return `Quantifies solar energy contributions powering intensive care wards and surgical ventilation machines.`;
      }
      if (lblLow.includes("compliance") || lblLow.includes("audit") || lblLow.includes("rating")) {
        return `Monitors compliance adherence rates with care guidelines and regulatory health audits.`;
      }
      if (lblLow.includes("opex savings") || lblLow.includes("cost avoidance") || lblLow.includes("opex")) {
        return `Measures clinic operational expense savings achieved through digital patient charting.`;
      }
      if (lblLow.includes("cycle time") || lblLow.includes("reduction") || lblLow.includes("discharge")) {
        return `Evaluates average clinical discharge timeline durations to increase medical bed availability.`;
      }
      if (lblLow.includes("material yield") || lblLow.includes("yield") || lblLow.includes("utilization")) {
        return `Balances medical inventory and pharmaceutical drug usage rates to prevent treatment waste.`;
      }
      if (lblLow.includes("conversion velocity") || lblLow.includes("pipeline") || lblLow.includes("intake")) {
        return `Logs standard intake processing durations for emergency patients.`;
      }
      if (lblLow.includes("retention")) {
        return `Monitors patient follow-up consult adherence rates to support long-term care consistency.`;
      }
      if (lblLow.includes("security") || lblLow.includes("vulnerabilities")) {
        return `Audits database network policies to ensure absolute HIPAA customer record security.`;
      }
    }

    // If retail sector
    if (sector === "retail") {
      if (lblLow.includes("co2") || lblLow.includes("emission") || lblLow.includes("footprint")) {
        return `Tracks retail store fleet carbon emissions against target distributor transport targets.`;
      }
      if (lblLow.includes("green energy") || lblLow.includes("renewable")) {
        return `Calculates the percentage of solar power mix utilized across global logistics hubs.`;
      }
      if (lblLow.includes("opex savings") || lblLow.includes("opex")) {
        return `Tracks direct warehouse and merchant store energy conservation opex savings.`;
      }
      if (lblLow.includes("gross profit") || lblLow.includes("margin")) {
        return `Assesses direct retail product pricing markups relative to inventory procurement costs.`;
      }
      if (lblLow.includes("cycle time") || lblLow.includes("checkout")) {
        return `Measures digital cart checkout speeds to eliminate friction at payment nodes.`;
      }
      if (lblLow.includes("supply chain") || lblLow.includes("delivery") || lblLow.includes("sla")) {
        return `Tracks last-mile shipping delivery reliability comparison against customer promises.`;
      }
      if (lblLow.includes("acquisition") || lblLow.includes("cac")) {
        return `Calculates advertisement spend needed to acquire active digital merchant platform shoppers.`;
      }
      if (lblLow.includes("retention") || lblLow.includes("churn")) {
        return `Quantifies yearly contract retention consistency and repeat customer order shares.`;
      }
    }

    // Default Fallback (highly polished, incorporates company Name and useCase dynamically, never duplicate or boilerplate)
    const customizedLabels: Record<string, string> = {
      "carbon footprint ratio": `Monitors greenhouse emissions across ${cName}'s facilities to track environmental targets.`,
      "power efficiency ratio": `Measures clean energy utilization ratios within regional operations at ${cName}.`,
      "corporate governance rating": `Benchmarks overall compliance levels to satisfy sovereign regulatory reporting limits.`,
      "green initiative npv": `Projects long-term capital yields returned from eco-friendly corporate restructurings.`,
      "operational opex conservation": `Records administrative budget conservation achieved by optimizing primary workflows.`,
      "operating margin efficiency": `Monitors company-wide pricing sufficiency and profit retention strength relative to basic costs.`,
      "quarterly ebitda benefit": `Tracks foundational core earnings growth prior to debt, tax, and amortization overrides.`,
      "allocated business capital": `Controls asset reserve divisions to support high-priority corporate development plans.`,
      "process efficiency rating": `Rates task and equipment completion throughput yields vs standard output averages.`,
      "task completion velocity": `Logs average time durations required to verify, execute and deliver operational assets.`,
      "client sla compliance": `Tracks contract response milestones to support client service agreement adherence.`,
      "resource allocation yield": `Evaluates operational stock consumption trends to eliminate material and administrative waste.`,
      "client contract velocity": `Measures conversion sales speed through regional business pipelines.`,
      "inbound client requests": `Monitors prospective inbound inquiries received via active b2b marketing channels.`,
      "client acquisition cost": `Calculates overall sales and marketing expenditure spent onboarding each active enterprise account.`,
      "account retention rate": `Identifies recurring customer contract renewals to project long-term relationship lifetimes.`
    };

    if (customizedLabels[lblLow]) {
      return customizedLabels[lblLow];
    }

    // Unique fallback generator incorporating labels/titles & company details
    const labelTitleClean = lbl.replace(/[+$%M\d.-]/g, "").trim();
    const options = [
      `Assesses "${labelTitleClean}" parameters at ${cName} to support long-term strategic targets.`,
      `Monitors direct "${labelTitleClean}" variations across ${cName}'s active operations groups. `,
      `Tracks standard "${labelTitleClean}" benchmarks to analyze structural growth and check performance.`,
      `Analyzes cumulative "${labelTitleClean}" trends relative to designated quarterly benchmarks.`
    ];
    return options[h % options.length];
  };

  const generateChartDescription = (title: string, useCase: string): string => {
    const t = title.trim();
    const tLow = t.toLowerCase();
    const sector = getIndustrySector();
    const cName = companyProfile?.name || "the enterprise";

    // Use a hash of the chart title + useCase to diversify words
    let hash = 0;
    const combinedStr = t + useCase;
    for (let i = 0; i < combinedStr.length; i++) {
      hash = (hash << 5) - hash + combinedStr.charCodeAt(i);
      hash |= 0;
    }
    const h = Math.abs(hash);

    if (sector === "banking") {
      if (tLow.includes("emissions") || tLow.includes("intensity") || tLow.includes("carbon")) {
        return `Charts projected greenhouse emissions intensity from financed corporate client assets against net-zero corridors.`;
      }
      if (tLow.includes("energy") || tLow.includes("power mix")) {
        return `Illustrates renewable energy mix indicators and power consumption rates across administrative branch grids.`;
      }
      if (tLow.includes("esg score") || tLow.includes("compliance") || tLow.includes("quality matrix")) {
        return `Correlates environmental ratings with corresponding commercial lending risk classes to track default hazards.`;
      }
      if (tLow.includes("npv realization") || tLow.includes("bond yield") || tLow.includes("npv forecast")) {
        return `Plots long-term discounted capital value generated specifically from trade corridor sustainable capital loans.`;
      }
      if (tLow.includes("ebitda") || tLow.includes("revenue velocity") || tLow.includes("trajectory")) {
        return `Traces operating cash collection tracks and transaction interest spreads across quarterly periods.`;
      }
      if (tLow.includes("cost allocation") || tLow.includes("clearing node")) {
        return `Breaks down operating investment budgets and node clearings across regional teller centers.`;
      }
      if (tLow.includes("budget variance") || tLow.includes("allocation variances")) {
        return `Plots continuous variances comparing actual regional branch spending versus annual capital budgets.`;
      }
      if (tLow.includes("cycle time") || tLow.includes("wire cycle")) {
        return `Monitors end-to-end clearing time durations of international wire transactions across payment gateways.`;
      }
      if (tLow.includes("resource scales") || tLow.includes("capital allocation") || tLow.includes("utilization")) {
        return `Balances active ledger processing demands against available transaction container limits to ensure gateway stability.`;
      }
      if (tLow.includes("supply chain") || tLow.includes("wire routing") || tLow.includes("resilience")) {
        return `Analyzes global correspondent banking channels and transaction clearance success indexes.`;
      }
      if (tLow.includes("velocity") || tLow.includes("settlement speed")) {
        return `Measures average verification velocities of cross-border clearances within operations hubs.`;
      }
      if (tLow.includes("downtime") || tLow.includes("ledger server")) {
        return `Registers ledger platform infrastructure uptime logs and highlights potential hardware node vulnerabilities.`;
      }
      if (tLow.includes("yield") || tLow.includes("treasury capital")) {
        return `Illustrates short-term riskless asset security returns relative to general interbank deposit bases.`;
      }
      if (tLow.includes("pipeline") || tLow.includes("underwriting")) {
        return `Tracks progressive deal stages of commercial and corporate underwriting applications in real time.`;
      }
      if (tLow.includes("acquisition") || tLow.includes("loan program")) {
        return `Correlates direct corporate client onboarding expenses against expected net lifetime deposit yield margins.`;
      }
      if (tLow.includes("retention") || tLow.includes("cohort")) {
        return `Traces contract stability and deposit preservation curves among historical regional merchant groups.`;
      }
    }

    if (sector === "healthcare") {
      if (tLow.includes("carbon") || tLow.includes("emissions")) {
        return `Plots direct clinical facility greenhouse footprints to verify environmental progress.`;
      }
      if (tLow.includes("energy") || tLow.includes("efficiency")) {
        return `Illustrates power consumption levels inside active medical surgery wards over time.`;
      }
      if (tLow.includes("cycle time") || tLow.includes("durations") || tLow.includes("elapsed")) {
        return `Assesses clinical discharge durations to track care coordination effectiveness.`;
      }
      if (tLow.includes("resource scales") || tLow.includes("utilization")) {
        return `Monitors surgical equipment readiness and patient ward room occupancy levels.`;
      }
      if (tLow.includes("supply chain") || tLow.includes("delivery") || tLow.includes("resilience")) {
        return `Analyzes surgical supply and pharmaceutical transport resilience across primary paths.`;
      }
    }

    if (sector === "retail") {
      if (tLow.includes("carbon") || tLow.includes("emissions")) {
        return `Illustrates shipment vehicle fuel tracks to analyze shipping emissions.`;
      }
      if (tLow.includes("energy") || tLow.includes("efficiency")) {
        return `Tracks store fuel profiles and heat usage totals to lower retail utility charges.`;
      }
      if (tLow.includes("cycle time") || tLow.includes("checkout")) {
        return `Plots electronic payment processing cycles to minimize site checkout delay.`;
      }
      if (tLow.includes("supply chain") || tLow.includes("delivery") || tLow.includes("resilience")) {
        return `Monitors last-mile shipping delivery durations relative to standard client targets.`;
      }
      if (tLow.includes("retention") || tLow.includes("churn") || tLow.includes("shopper")) {
        return `Traces consistent shopper repeat order rates across regional retail buyer groups.`;
      }
    }

    // Default Fallbacks
    const customizedCharts: Record<string, string> = {
      "corporate emission projector": `Illustrates progressive corporate facility greenhouse emissions against strategic targets.`,
      "facility footprint comparison": `Compares direct company energy outputs side-by-side with external supplier emission totals.`,
      "regional office energy profile": `Monitors local green energy use patterns among various regional administrative centers.`,
      "esg quality score matrix": `Correlates corporate environmental ratings directly with strategic capital yields.`,
      "discounted net cashflow forecast": `Charts long-term cumulative net present value projections relative to baseline budgets.`,
      "expected operating ebitda gains": `Plots expected operating EBITDA trajectories over the designated planning horizon.`,
      "operating budget division allocations": `Breaks down operational investment budgets and office overhead across divisions.`,
      "service execution turnaround timelines": `Monitors average task completion velocities and delivery timelines across teams.`,
      "business asset allocation balance": `Balances core operational asset allocations against general corporate reserve holdings.`,
      "task milestone delivery resilience": `Analyzes deliverable completion reliability cross-checked over transit stages.`,
      "workflow volume processing velocity": `Tracks average team output volumes accomplished during the current sprint.`,
      "digital application server offline log": `Registers digital server offline intervals and identifies network load thresholds.`,
      "asset utilization optimization grid": `Compares standard parts output yields against standard raw facility inputs.`
    };

    if (customizedCharts[tLow]) {
      return customizedCharts[tLow];
    }

    const titleClean = t.replace(/[+$%M\d.-]/g, "").trim();
    const options = [
      `Illustrates progressive analytical trends for "${titleClean}" at ${cName}.`,
      `Correlates "${titleClean}" metrics with estimated operational parameters to identify changes at ${cName}.`,
      `Benchmarks cumulative "${titleClean}" indicators relative to target corporate standards.`,
      `Plots continuous developmental progressions of "${titleClean}" curves across facilities.`
    ];
    return options[h % options.length];
  };

  const getAlignedDashboardMetadata = (personaValue: string, index: number, ucTitle: string) => {
    const pLow = personaValue.toLowerCase();
    const cName = companyProfile?.name || "the enterprise";
    
    let persona = "VP of Corporate Strategy & Product";
    let title = "";
    let description = "";
    let colorScheme = "blue";
    let theme = "Standard Enterprise Performance";
    let prompts: string[] = [];
    let kpis: { label: string; value: string; trend: string; color: string }[] = [];
    let chartTitles: string[] = [];

    if (pLow.includes("cfo") || pLow.includes("financial") || pLow.includes("finance") || pLow.includes("treasury") || pLow.includes("accounting")) {
      persona = "Chief Financial Officer (CFO)";
      colorScheme = "emerald";
      theme = "Fiscal & EBITDA Velocity Desk";
      prompts = ['Reporting Fiscal Cycle', 'Capital Allocation Tier', 'Cost Center Division', 'Exchange Corridor'];
      
      const titles = [
        "Value Realization Dashboard",
        "Strategic Capital Allocation Hub",
        "Fiscal Performance & EBITDA Planner"
      ];
      title = titles[index % titles.length];
      description = `Advanced financial command deck synthesized for the CFO to monitor capital adequacy, track opex conservation, and evaluate net benefit realizations for ${cName}.`;
      
      kpis = [
        { label: 'Opex Savings Realized', value: `$${(Math.random() * 12 + 4).toFixed(1)}M`, trend: '+31.2%', color: 'text-emerald-600' },
        { label: 'Gross Profit Margin', value: `${(Math.random() * 10 + 44).toFixed(1)}%`, trend: '+2.8%', color: 'text-emerald-500' },
        { label: 'Incremental EBITDA Benefit', value: `+${(Math.random() * 5 + 2).toFixed(2)}%`, trend: '+0.5% Target', color: 'text-blue-600' },
        { label: 'Total Investment Value', value: `$${(Math.random() * 30 + 15).toFixed(1)}M`, trend: '+12.4% ARR', color: 'text-primary' },
      ];
      chartTitles = [
        'Incremental EBITDA Trajectory',
        'Gross vs Net Revenue Streams',
        'Operational Cost Allocations',
        'Strategic Investment CapEx Index',
        'Budget Variance Analysis',
        'NPV Realization Forecaster'
      ];
    } else if (pLow.includes("cto") || pLow.includes("tech") || pLow.includes("architect") || pLow.includes("engineer") || pLow.includes("it ") || pLow.includes("information officer") || pLow.includes("platform") || pLow.includes("developer")) {
      persona = "Chief Technology Officer (CTO)";
      colorScheme = "slate";
      theme = "Enterprise Platform Performance Cockpit";
      prompts = ['API Endpoints Layer', 'Infrastructure Core Zone', 'Data Pipeline Capacity', 'Cloud Service Node'];
      
      const titles = [
        "Enterprise Platform & API Performance Cockpit",
        "Cloud Infrastructure Allocation Suite",
        "Systems Integration & Latency Guard"
      ];
      title = titles[index % titles.length];
      description = `High-precision platform performance cockpit customized for the CTO to track API gateway processing, infrastructure uptime, and potential system exposures at ${cName}.`;
      
      kpis = [
        { label: 'System Response (p95)', value: `${Math.floor(Math.random() * 40 + 110)}ms`, trend: '-22% Latency', color: 'text-cyan-600' },
        { label: 'Infrastructure Availability', value: '99.99%', trend: '+0.01% SLA', color: 'text-cyan-500' },
        { label: 'Compute Allocation Ratio', value: `${(Math.random() * 15 + 68).toFixed(1)}%`, trend: 'Optimized', color: 'text-slate-600' },
        { label: 'Estimated API Call Capacity', value: `${(Math.random() * 50 + 120).toFixed(1)}M/day`, trend: '+14% Peak', color: 'text-primary' },
      ];
      chartTitles = [
        'Compute Infrastructure Memory Nodes',
        'Request Latency Variance Curve',
        'Throughput Load Distributions',
        'System SLA Performance Tracker',
        'Data Pipeline Pipeline Funnels',
        'Architecture Health Dependencies'
      ];
    } else if (pLow.includes("coo") || pLow.includes("operations") || pLow.includes("ops") || pLow.includes("logistics") || pLow.includes("chain") || pLow.includes("supply") || pLow.includes("warehouse") || pLow.includes("plant") || pLow.includes("factory") || pLow.includes("operator")) {
      persona = "Chief Operating Officer (COO)";
      colorScheme = "blue";
      theme = "Logistics Work Capacity Grid";
      prompts = ['Facility Operations Cluster', 'Throughput Level', 'Supply Chain Stream', 'SLA Severity Level'];
      
      const titles = [
        "Operational Throughput & Efficiency Monitor",
        "Service Performance & Throughput Cockpit",
        "Enterprise SLA & Cycle Velocity Tracker"
      ];
      title = titles[index % titles.length];
      description = `Core operations tracking room tailored for the COO to streamline execution speeds, eliminate processing bottlenecks, and preserve operational SLAs across ${cName}.`;
      
      kpis = [
        { label: 'OEE Operational Rating', value: `${(Math.random() * 10 + 82).toFixed(1)}%`, trend: '+4.5% Peak', color: 'text-emerald-600' },
        { label: 'Cycle Time Reduction', value: `-${(Math.random() * 15 + 10).toFixed(1)}%`, trend: '-18% Target', color: 'text-blue-600' },
        { label: 'Logistics SLA Compliance', value: '98.92%', trend: '+0.4%', color: 'text-slate-600' },
        { label: 'Material Yield Efficiency', value: `${(Math.random() * 5 + 93).toFixed(1)}%`, trend: '+1.2%', color: 'text-primary' },
      ];
      chartTitles = [
        'Production Cycle Time Trajectory',
        'Facility Resource Scales',
        'Supply Chain Delivery Performance',
        'Operational Throughput Velocity',
        'Downtime Vulnerability Grid',
        'Material Yield Allocation Matrix'
      ];
    } else if (pLow.includes("sales") || pLow.includes("marketing") || pLow.includes("conversion") || pLow.includes("customer") || pLow.includes("retention") || pLow.includes("growth") || pLow.includes("lead") || pLow.includes("cmo") || pLow.includes("shopper")) {
      persona = "VP of Global Sales & Growth";
      colorScheme = "violet";
      theme = "Client Acquisition & Revenue Engine";
      prompts = ['Customer Segment Phase', 'Lead Sourcing Funnel', 'Campaign Portfolio Attribution', 'Conversion Velocity Quarter'];
      
      const titles = [
        "Customer Acquisition & Pipeline Conversion Hub",
        "Regional Market Penetration & Lead Sourcing Engine",
        "Shopper Lifecycle Retention & Cohort Monitor"
      ];
      title = titles[index % titles.length];
      description = `Revenue operations console synthesized for the Chief of Sales and Growth to verify inbound funnel pipelines, track conversion velocities, and monitor client acquisition spend fields at ${cName}.`;
      
      kpis = [
        { label: 'Pipeline Conversion Velocity', value: `${(Math.random() * 15 + 38).toFixed(1)}%`, trend: '+12.8%', color: 'text-violet-600' },
        { label: 'Lead Volume Count', value: `${Math.floor(Math.random() * 1500 + 1000)}`, trend: '+24%', color: 'text-violet-500' },
        { label: 'Customer Acquisition CAC', value: `$${Math.floor(Math.random() * 80 + 120)}`, trend: '-14% YoY', color: 'text-rose-600' },
        { label: 'Net Retention Rate', value: `${(Math.random() * 5 + 108).toFixed(1)}%`, trend: '+1.5%', color: 'text-primary' },
      ];
      chartTitles = [
        'Lead Stage Pipeline Progression',
        'Customer Acquisition Density Scatter',
        'Lifecycle Retention Cohort',
        'Region Sale Growth Distribution',
        'Campaign Attributions Funnel',
        'Product Category Market Share'
      ];
    } else if (pLow.includes("risk") || pLow.includes("compliance") || pLow.includes("security") || pLow.includes("audit") || pLow.includes("esg") || pLow.includes("carbon") || pLow.includes("emission") || pLow.includes("climate") || pLow.includes("safety") || pLow.includes("hazard")) {
      persona = "Chief Risk & Sustainability Officer";
      colorScheme = "amber";
      theme = "Risk Audit & Exposure Guard";
      prompts = ['Audit Policy Boundary', 'Vulnerability Threat Vector', 'Regional Regulatory Shift', 'ISO Compliance Domain'];
      
      const titles = [
        "ESG Corporate Governance & Auditing Matrix",
        "Financed Operations Carbon Abatement Monitor",
        "Sovereign Compliance Risk Exposure Deck"
      ];
      title = titles[index % titles.length];
      description = `Enterprise safety, environmental, and corporate governance command board built for the Chief Risk Officer to oversee audit targets, compliance records, and risk exposures at ${cName}.`;
      
      kpis = [
        { label: 'CO2 Emissions Target', value: `-${(Math.random() * 15 + 12).toFixed(1)}%`, trend: '-4.2% YoY', color: 'text-emerald-600' },
        { label: 'Green Energy Index', value: `${(Math.random() * 20 + 72).toFixed(1)}%`, trend: '+8.1%', color: 'text-emerald-500' },
        { label: 'ESG Compliance Rating', value: 'AA+', trend: 'Top Decile', color: 'text-emerald-700' },
        { label: 'Sustainability NPV', value: `$${(Math.random() * 8 + 3).toFixed(1)}M`, trend: '+1.4M Benefit', color: 'text-primary' },
      ];
      chartTitles = [
        'Audit Vulnerability Aging Grid',
        'Mitigated Exposure Vectors',
        'Compliance Policy Adherence Trends',
        'Operational Cyber Risk Variance',
        'Threat Landscape Quadrants',
        'Sovereign Compliance Levels'
      ];
    } else {
      persona = "VP of Corporate Strategy & Product";
      colorScheme = "rose";
      theme = "Corporate Strategy & Product Synergy";
      prompts = ['Strategic Roadmap Pillar', 'Innovation Stage Gate', 'Product Segment Focus', 'Core Milestone Objective'];
      
      const titles = [
        "Executive Strategic Roadmap Synergy Desk",
        "Innovation Portfolio Value Forecaster",
        "Product Category Alignment & Adoption Guide"
      ];
      title = titles[index % titles.length];
      description = `Executive portfolio monitoring board designed for the VP of Corporate Strategy and Product to verify roadmap milestones, analyze segment adoption, and trace strategic venture yields at ${cName}.`;
      
      kpis = [
        { label: 'Strategic Value', value: `$${(Math.random() * 20 + 10).toFixed(1)}M`, trend: '+14.2%', color: 'text-emerald-600' },
        { label: 'EBITDA Uplift', value: `${(Math.random() * 5 + 3).toFixed(1)}%`, trend: '+1.5%', color: 'text-blue-600' },
        { label: 'Execution Risk', value: 'Nominal', trend: '-22%', color: 'text-slate-600' },
        { label: 'Projected ROI', value: `${(Math.random() * 3 + 2).toFixed(1)}x`, trend: '+0.4x', color: 'text-primary' },
      ];
      chartTitles = [
        'Executive Roadmap Milestone Timeline',
        'Innovation Portfolio Venture Pipeline',
        'Product Category Performance Analysis',
        'Market Penetration Growth Analysis',
        'Category Adoption Velocity Curve',
        'Strategic Synergy Index Matrix'
      ];
    }

    // Apply industry adjustments to labels and chart titles!
    const finalKpis = kpis.map(k => {
      const adjustedLabel = getIndustryAdjustedLabel(k.label);
      return {
        ...k,
        label: adjustedLabel,
        description: generateKPIdescription(adjustedLabel, k.value, ucTitle)
      };
    });

    const finalChartTitles = chartTitles.map(t => getIndustryAdjustedChartTitle(t));

    return {
      title,
      description,
      colorScheme,
      theme,
      persona,
      prompts,
      kpis: finalKpis,
      chartTitles: finalChartTitles
    };
  };

  const parseCustomDashboardRequirements = (requirements: string, ucTitle: string, index: number) => {
    const req = (requirements || "").toLowerCase();
    
    // 1. Detect Persona/Archetype
    let selectedPersonaKey = "strategy";
    if (req.includes("cfo") || req.includes("financial") || req.includes("finance") || req.includes("accounting") || req.includes("cost") || req.includes("profit") || req.includes("revenue") || req.includes("roi") || req.includes("margin") || req.includes("saving") || req.includes("treasury") || req.includes("capital")) {
      selectedPersonaKey = "cfo";
    } else if (req.includes("cto") || req.includes("developer") || req.includes("tech") || req.includes("engineer") || req.includes("latency") || req.includes("it") || req.includes("system") || req.includes("architecture") || req.includes("infrastructure") || req.includes("server") || req.includes("cloud") || req.includes("api")) {
      selectedPersonaKey = "cto";
    } else if (req.includes("coo") || req.includes("operator") || req.includes("operations") || req.includes("ops") || req.includes("logistics") || req.includes("chain") || req.includes("supply") || req.includes("warehouse") || req.includes("plant") || req.includes("factory") || req.includes("oee") || req.includes("throughput")) {
      selectedPersonaKey = "coo";
    } else if (req.includes("sales") || req.includes("marketing") || req.includes("pipeline") || req.includes("conversion") || req.includes("customer") || req.includes("retention") || req.includes("growth") || req.includes("partner") || req.includes("lead") || req.includes("cmo") || req.includes("shopper")) {
      selectedPersonaKey = "sales";
    } else if (req.includes("risk") || req.includes("compliance") || req.includes("security") || req.includes("audit") || req.includes("esg") || req.includes("carbon") || req.includes("emissions") || req.includes("climate") || req.includes("safety") || req.includes("hazard")) {
      selectedPersonaKey = "risk";
    }

    const aligned = getAlignedDashboardMetadata(selectedPersonaKey, index, ucTitle);

    // 2. Extract customized keywords to inject custom phrasing into the dashboard Title, making it dynamic and custom!
    const stopWords = new Set(["i", "want", "a", "an", "the", "for", "of", "and", "or", "in", "with", "dashboard", "dashboards", "on", "to", "show", "display", "represent", "create", "generate", "look", "like", "need", "it", "should", "some", "custom", "additional", "requirements", "please", "based", "user", "input"]);
    const cleanWords = req
      .replace(/[^\w\s]/g, " ")
      .split(/\s+/)
      .filter(w => w && w.length > 3 && !stopWords.has(w));

    const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
    const ucClean = ucTitle.replace("Use Case", "").replace(/[^a-zA-Z0-9\s]/g, "").trim();
    
    let customTitle = aligned.title;
    if (cleanWords.length >= 2) {
      const word1 = cap(cleanWords[0]);
      const word2 = cap(cleanWords[1]);
      customTitle = `Strategic ${word1} & ${word2} Monitor`;
    } else if (cleanWords.length === 1) {
      const word1 = cap(cleanWords[0]);
      customTitle = `${ucClean}: ${word1} Analytics Hub`;
    }

    // Keep Description custom but highly aligned
    const customDesc = `Dynamic analytical workbench synthesized for the ${aligned.persona} to evaluate key performance indicators, process constraints, and multi-dimensional outcomes targeting ${ucTitle} objectives.`;

    return {
      title: customTitle,
      description: customDesc,
      theme: aligned.theme,
      persona: aligned.persona,
      colorScheme: aligned.colorScheme,
      prompts: aligned.prompts,
      kpis: aligned.kpis,
      chartTitles: aligned.chartTitles
    };
  };

  const handleGenerateBDDashboards = () => {
    if (selectedBDUseCases.length === 0) {
      toast.error("Please select at least one MDP Use Case");
      return;
    }

    setIsGeneratingBDDashboards(true);
    setBdGenerationTimer(5); // Start with 5 seconds
    setBdGenerationStatus("Initializing AI Synthesis...");
    
    const intervalId = setInterval(() => {
      setBdGenerationTimer(prev => Math.max(0, prev - 1));
    }, 1000);

    const statusMessages = [
      "Synthesizing BI Correlation Logic...",
      "Mapping Strategic KPI Vectors...",
      "Calibrating Predictive Outcomes...",
      "Structuring Analytic Data Fabric...",
      "Optimizing Metric Hierarchies...",
      "Aligning Multi-Dimensional Insights...",
      "Finalizing Synthesis Perspective..."
    ];
    
    let messageIndex = 0;
    const statusInterval = setInterval(() => {
      setBdGenerationStatus(statusMessages[messageIndex % statusMessages.length]);
      messageIndex++;
    }, 1200);
    
    // Final generation
    setTimeout(() => {
      clearInterval(intervalId);
      clearInterval(statusInterval);
      const newDashboards: SampleDashboard[] = [];
      
      const dashDescriptions = [
        "Executive-level synthesis of roadmap initiatives, providing multi-dimensional visibility into strategic business outcomes and growth trajectories.",
        "Integrated performance framework designed to monitor operational efficiency and identify optimization opportunities across the enterprise landscape.",
        "Precision revenue analysis environment tracking fiscal velocity and projecting long-term value capture for stakeholder alignment.",
        "Advanced market intelligence dashboard synthesizing competitive positioning and penetration metrics for informed decision-making.",
        "Holistic value realization monitor quantifying the impact of MDP initiatives on core business objectives and fiscal health."
      ];

      const promptVariations = [
        ['Temporal Horizon', 'Strategic Objective', 'Geographic Cluster', 'Operational Scale'],
        ['Capital Allocation', 'Resource Utilization', 'Market Segment', 'Execution Priority'],
        ['Efficiency Delta', 'Risk Profile', 'Value Stream', 'Deployment Status'],
        ['Engagement Metric', 'Conversion Funnel', 'Portfolio Weight', 'Target Variance'],
        ['Compliance Guard', 'Infrastructure Tier', 'Service Level', 'Performance Tier']
      ];

      const kpiSets = [
        [
          { label: 'Strategic Value', value: `$${(Math.random() * 20 + 10).toFixed(1)}M`, trend: '+14.2%', color: 'text-emerald-600' },
          { label: 'EBITDA Uplift', value: `${(Math.random() * 5 + 3).toFixed(1)}%`, trend: '+1.5%', color: 'text-blue-600' },
          { label: 'Execution Risk', value: 'Nominal', trend: '-22%', color: 'text-slate-600' },
          { label: 'Projected ROI', value: `${(Math.random() * 3 + 2).toFixed(1)}x`, trend: '+0.4x', color: 'text-primary' },
        ],
        [
          { label: 'Cost Avoidance', value: `$${(Math.random() * 8 + 2).toFixed(1)}M`, trend: '+28.5%', color: 'text-emerald-600' },
          { label: 'Efficiency Gain', value: `${(Math.random() * 15 + 10).toFixed(1)}%`, trend: '+4.2%', color: 'text-blue-600' },
          { label: 'Market Share', value: `${(Math.random() * 4 + 1).toFixed(1)}%`, trend: '+0.8%', color: 'text-slate-600' },
          { label: 'NPV Synthesis', value: `$${(Math.random() * 12 + 5).toFixed(1)}M`, trend: '+2.1M', color: 'text-primary' },
        ]
      ];
      
      const chartTitleVariations = [
        ['Strategic Value Trajectory', 'Operational Scale Efficiency', 'Target vs Actual Yield', 'Execution Velocity', 'Strategic Balance Delta', 'Operational Integrity Index'],
        ['Market Penetration Analysis', 'Revenue Stream Distribution', 'Customer Lifecycle Value', 'Competitive Delta', 'Category Growth Drivers', 'Regional Performance Matrix'],
        ['Risk Concentration Monitor', 'Asset Utilization Matrix', 'Capital Efficiency Score', 'Projected NPV Accrual', 'Tactical Exposure Profile', 'Resource Optimization Score'],
        ['Innovation Cycle Feedback', 'Resource Density Balance', 'Talent Retention Index', 'Stakeholder ROI Scoreboard', 'Maturity Realization Speed', 'Velocity Curve Delta'],
        ['Global Expansion Pace', 'Product Category Performance', 'Supply Chain Resilience', 'Digital Maturity Index', 'Logistics Node Health', 'Throughput Analysis Grid']
      ];

      const availableChartTypes: any[] = ['area', 'bar', 'pie', 'radar', 'table', 'scatter', 'composed', 'funnel', 'treemap', 'radial'];

      selectedBDUseCases.forEach((ucId, ucIndex) => {
        const useCase = companyProfile?.opportunities?.find(o => o.id === ucId);
        const ucTitle = useCase?.title || "Unknown Use Case";
        
        for (let i = 0; i < numDashboards; i++) {
          const dashId = crypto.randomUUID();
          
          let parsed;
          if (bdDashboardTheme === 'Custom' && bdCustomDashboardDesc.trim().length > 0) {
            parsed = parseCustomDashboardRequirements(bdCustomDashboardDesc, ucTitle, ucIndex * numDashboards + i);
          } else {
            // Surprise Me! / default mode - Select persona based on use case keyword semantic match OR cycle sequentially
            let selectedPersonaKey = "strategy";
            const ucLower = ucTitle.toLowerCase();
            
            if (ucLower.includes("risk") || ucLower.includes("audit") || ucLower.includes("compliance") || ucLower.includes("sec") || ucLower.includes("threat") || ucLower.includes("governance") || ucLower.includes("climate") || ucLower.includes("esg") || ucLower.includes("carbon")) {
              selectedPersonaKey = "risk";
            } else if (ucLower.includes("finance") || ucLower.includes("cost") || ucLower.includes("investment") || ucLower.includes("capital") || ucLower.includes("roi") || ucLower.includes("savings") || ucLower.includes("ebitda") || ucLower.includes("value realization") || ucLower.includes("revenue")) {
              selectedPersonaKey = "cfo";
            } else if (ucLower.includes("modernization") || ucLower.includes("architecture") || ucLower.includes("cloud") || ucLower.includes("platform") || ucLower.includes("api") || ucLower.includes("tech") || ucLower.includes("migration") || ucLower.includes("integration") || ucLower.includes("data ")) {
              selectedPersonaKey = "cto";
            } else if (ucLower.includes("customer") || ucLower.includes("onboard") || ucLower.includes("lead") || ucLower.includes("client") || ucLower.includes("engagement") || ucLower.includes("sales") || ucLower.includes("retention") || ucLower.includes("marketing")) {
              selectedPersonaKey = "sales";
            } else if (ucLower.includes("operations") || ucLower.includes("processing") || ucLower.includes("settlement") || ucLower.includes("fulfillment") || ucLower.includes("cycle") || ucLower.includes("throughput") || ucLower.includes("logistics")) {
              selectedPersonaKey = "coo";
            } else {
              // Cycle through all 6 personas to give beautiful variations!
              const allKeys = ["strategy", "cfo", "coo", "cto", "sales", "risk"];
              selectedPersonaKey = allKeys[(ucIndex * numDashboards + i) % allKeys.length];
            }

            parsed = getAlignedDashboardMetadata(selectedPersonaKey, ucIndex * numDashboards + i, ucTitle);
          }

          const chartTitles = parsed.chartTitles;
          
          // Even number of visualizations to fit perfectly in 2-column layout (alternate between 4 and 6 charts counted)
          const chartsCount = i % 2 === 0 ? 4 : 6;
          // Selection of unique chart types for each dashboard - shuffle every time
          const shuffledTypes = [...availableChartTypes].sort(() => Math.random() - 0.5);
          const selectedTypes = shuffledTypes.slice(0, chartsCount);

          newDashboards.push({
            id: dashId,
            projectId: currentProjectId,
            useCaseId: ucId,
            useCaseTitle: ucTitle,
            title: parsed.title,
            description: parsed.description,
            theme: parsed.theme,
            colorScheme: parsed.colorScheme,
            persona: parsed.persona,
            prompts: parsed.prompts,
            kpis: parsed.kpis,
            charts: selectedTypes.map((type, idx) => {
              let chartData: any[] = [];
              
              if (type === 'radar') {
                chartData = [
                  { subject: 'Velocity', A: Math.floor(Math.random() * 50 + 80), B: Math.floor(Math.random() * 40 + 90), fullMark: 150 },
                  { subject: 'Scale', A: Math.floor(Math.random() * 50 + 80), B: Math.floor(Math.random() * 40 + 90), fullMark: 150 },
                  { subject: 'Risk', A: Math.floor(Math.random() * 60 + 60), B: Math.floor(Math.random() * 50 + 70), fullMark: 150 },
                  { subject: 'Margin', A: Math.floor(Math.random() * 40 + 100), B: Math.floor(Math.random() * 50 + 90), fullMark: 150 },
                  { subject: 'Value', A: Math.floor(Math.random() * 50 + 85), B: Math.floor(Math.random() * 60 + 80), fullMark: 150 },
                ];
              } else if (type === 'table') {
                chartData = [
                  { segment: 'Core Ops', value: `$${(Math.random() * 10 + 5).toFixed(1)}M`, status: 'Optimal' },
                  { segment: 'Innovation', value: `$${(Math.random() * 8 + 3).toFixed(1)}M`, status: 'Growing' },
                  { segment: 'Technical', value: `$${(Math.random() * 6 + 2).toFixed(1)}M`, status: 'Stable' },
                  { segment: 'Support', value: `$${(Math.random() * 4 + 1).toFixed(1)}M`, status: 'Legacy' },
                  { segment: 'Global', value: `$${(Math.random() * 5 + 3).toFixed(1)}M`, status: 'Optimal' },
                ];
              } else if (type === 'pie') {
                chartData = [
                  { name: 'Revenue', value: Math.floor(Math.random() * 200 + 300) },
                  { name: 'Opex', value: Math.floor(Math.random() * 150 + 200) },
                  { name: 'Capital', value: Math.floor(Math.random() * 100 + 150) },
                  { name: 'R&D', value: Math.floor(Math.random() * 80 + 100) },
                ];
              } else if (type === 'bar') {
                chartData = [
                  { name: 'Q1', val: Math.floor(Math.random() * 200 + 200) }, 
                  { name: 'Q2', val: Math.floor(Math.random() * 150 + 250) }, 
                  { name: 'Q3', val: Math.floor(Math.random() * 300 + 200) }, 
                  { name: 'Q4', val: Math.floor(Math.random() * 100 + 180) }
                ];
              } else if (type === 'scatter') {
                chartData = Array.from({ length: 20 }, () => ({
                  x: Math.random() * 100,
                  y: Math.random() * 100,
                  z: Math.random() * 100
                }));
              } else if (type === 'composed') {
                chartData = Array.from({ length: 6 }, (_, j) => ({
                  name: `P${j+1}`,
                  value: Math.floor(Math.random() * 100),
                  val: Math.floor(Math.random() * 80),
                  amt: Math.floor(Math.random() * 60)
                }));
              } else if (type === 'funnel') {
                chartData = [
                  { value: 100, name: 'Lead', fill: '#8884d8' },
                  { value: Math.floor(Math.random() * 15 + 75), name: 'Qualified', fill: '#83a6ed' },
                  { value: Math.floor(Math.random() * 20 + 50), name: 'Proposal', fill: '#8dd1e1' },
                  { value: Math.floor(Math.random() * 15 + 35), name: 'Negotiation', fill: '#82ca9d' },
                  { value: Math.floor(Math.random() * 10 + 20), name: 'Closed', fill: '#a4de6c' },
                ];
              } else if (type === 'treemap') {
                chartData = [
                  { name: 'Growth', children: [{ name: 'A1', value: Math.floor(Math.random() * 50 + 80) }, { name: 'A2', value: Math.floor(Math.random() * 40 + 60) }] },
                  { name: 'Risk', children: [{ name: 'B1', value: Math.floor(Math.random() * 30 + 40) }, { name: 'B2', value: Math.floor(Math.random() * 20 + 20) }] },
                  { name: 'Value', children: [{ name: 'C1', value: Math.floor(Math.random() * 100 + 150) }, { name: 'C2', value: Math.floor(Math.random() * 80 + 100) }] },
                ];
              } else if (type === 'radial') {
                chartData = [
                  { name: 'P1', value: parseFloat((Math.random() * 20 + 25).toFixed(2)), fill: '#8884d8' },
                  { name: 'P2', value: parseFloat((Math.random() * 15 + 20).toFixed(2)), fill: '#83a6ed' },
                  { name: 'P3', value: parseFloat((Math.random() * 10 + 10).toFixed(2)), fill: '#8dd1e1' },
                  { name: 'P4', value: parseFloat((Math.random() * 5 + 5).toFixed(2)), fill: '#82ca9d' },
                ];
              } else {
                chartData = Array.from({ length: 12 }, (_, j) => ({ name: `M${j+1}`, value: Math.floor(Math.random() * 100) + (j * 20) }));
              }

              const originalTitle = chartTitles[idx] || "Operational Metric";
              const chartTitle = getIndustryAdjustedChartTitle(originalTitle);
              return {
                id: crypto.randomUUID(),
                type: type,
                title: chartTitle,
                data: chartData,
                description: generateChartDescription(chartTitle, ucTitle)
              };
            }),
            createdAt: new Date().toISOString()
          });
        }
      });
      
      setBdDashboards(prev => [...prev, ...newDashboards]);
      setIsGeneratingBDDashboards(false);
      setBdGenerationStatus("");
      setBdGenerationTimer(0);
      
      // Auto-select the first newly generated dashboard
      if (newDashboards.length > 0) {
        setSelectedBDDashboardId(newDashboards[0].id);
      }
      
      toast.success(`Generated ${newDashboards.length} dashboards for ${selectedBDUseCases.length} use cases`);
    }, 5000);
  };

  const handleDeleteBDDashboard = (id: string) => {
    setBdDashboards(prev => prev.filter(d => d.id !== id));
    if (selectedBDDashboardId === id) setSelectedBDDashboardId(null);
    toast.success("Dashboard deleted");
  };

  const handleDeleteBDDashboardsByUseCase = (useCaseId: string) => {
    setBdDashboards(prev => prev.filter(d => d.useCaseId !== useCaseId));
    toast.success("All dashboards for use case deleted");
  };

  const handleDeleteAllBDDashboards = () => {
    setBdDashboards([]);
    setSelectedBDDashboardId(null);
    toast.success("All BI dashboards cleared");
  };

  // Profile update effect when ticker changes
  useEffect(() => {
    const updateProfile = async () => {
      if (companyProfile && selectedTicker && selectedTicker !== companyProfile.ticker) {
        // Check cache first
        if (profileCache[selectedTicker]) {
          setCompanyProfile(profileCache[selectedTicker]);
          toast.success(`Restored profile for ${profileCache[selectedTicker].name} from cache`);
          return;
        }

        const match = potentialTickers.find(t => t.symbol === selectedTicker) || 
                      companyProfile.potentialTickers?.find(t => t.symbol === selectedTicker);
        
        if (match) {
          setIsUpdatingProfile(true);
          try {
            const updates = await updateCompanyProfileForTicker(industry, match, oppCount, oppAdditionalContext);
            const newProfile: CompanyProfile = {
              ...companyProfile,
              ...updates,
              ticker: selectedTicker,
              name: updates.name || match.companyName,
              opportunities: updates.opportunities?.map((opp, idx) => ({
                ...opp,
                id: `opp-${Date.now()}-${idx}`,
                selected: false
              })) || companyProfile.opportunities
            } as CompanyProfile;

            setCompanyProfile(newProfile);
            setProfileCache(prev => ({ ...prev, [selectedTicker]: newProfile }));
            toast.success(`Updated strategy and opportunities for ${match.companyName}`);
          } catch (err) {
            console.error("Profile update failed:", err);
            toast.error("Fixed ticker context, but profile data sync failed.");
          } finally {
            setIsUpdatingProfile(false);
          }
        }
      }
    };
    updateProfile();
  }, [selectedTicker, industry, oppCount, oppAdditionalContext]);

  const handleCreateMDPModels = () => {
    const firstSelected = companyProfile?.opportunities?.find(o => o.selected);
    if (firstSelected) {
      setSelectedUseCaseOppId(firstSelected.id);
    }
    setActiveTab('usecases');
    toast("Crafting Business Use Case presentation...", { icon: '💼' });
  };

  const handleGenerateDashboard = useCallback(async () => {
    if (!selectedStarSchemaId || !dashboardName) {
      setError("Please select a star schema and provide a dashboard name.");
      return;
    }

    const starSchema = history.find(h => h.id === selectedStarSchemaId);
    if (!starSchema) return;

    setLoading(true);
    setError(null);
    
    // Simulate a short delay for "generation"
    const timeoutId = setTimeout(() => {
      try {
        // Simple keyword check for requirements to influence data
        const reqs = customDashboardDesc.toLowerCase();
        const isDaily = reqs.includes('daily');
        const isWeekly = reqs.includes('weekly');
        
        const timeLabels = isDaily 
          ? ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
          : isWeekly 
            ? ['Wk 1', 'Wk 2', 'Wk 3', 'Wk 4']
            : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];

        // Extract measures and dimensions from the schema for relevance
        const measures = starSchema.columns.filter(c => 
          !c.isPk && !c.fkTo && 
          (c.datatype.toUpperCase().includes('INT') || 
           c.datatype.toUpperCase().includes('DECIMAL') || 
           c.datatype.toUpperCase().includes('FLOAT') || 
           c.datatype.toUpperCase().includes('MONEY') ||
           c.datatype.toUpperCase().includes('NUMERIC'))
        );
        
        const dimensionCols = starSchema.columns.filter(c => 
          !c.isPk && !c.fkTo && 
          (c.datatype.toUpperCase().includes('VARCHAR') || 
           c.datatype.toUpperCase().includes('STRING') || 
           c.datatype.toUpperCase().includes('TEXT'))
        );

        // Randomize selection of measures and dimensions
        const shuffledMeasures = [...measures].sort(() => Math.random() - 0.5);
        const shuffledDims = [...dimensionCols].sort(() => Math.random() - 0.5);

        const primaryMeasure = shuffledMeasures[0]?.businessName || "Total Value";
        const secondaryMeasure = shuffledMeasures[1]?.businessName || "Volume";
        const primaryDim = shuffledDims[0]?.businessName || "Category";

        const vibrantColors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];
        const shuffledColors = [...vibrantColors].sort(() => Math.random() - 0.5);

        // Randomize layout: number of metrics (3-5) and number of charts (2-5)
        const numMetrics = Math.floor(Math.random() * 3) + 3; // 3, 4, or 5
        const numCharts = Math.floor(Math.random() * 3) + 2; // 2, 3, or 4

        const widgets: any[] = [];

        // Add metrics with randomized values and trends
        for (let i = 0; i < numMetrics; i++) {
          const m = shuffledMeasures[i % shuffledMeasures.length];
          const mName = m?.businessName || `Metric ${i+1}`;
          const mValue = (Math.random() * 1000).toFixed(1) + (Math.random() > 0.5 ? 'K' : 'M');
          const mTrend = (Math.random() > 0.5 ? '+' : '-') + (Math.random() * 20).toFixed(1) + '%';
          const labels = [
            `Sum of all ${mName} events`,
            `Mean ${mName} per transaction`,
            `${mName} variance analysis`,
            `Projected ${mName} for current period`,
            `Validated ${mName} source`
          ];
          widgets.push({
            id: `m${i}`,
            type: 'metric',
            title: mName,
            metricValue: mValue,
            metricLabel: labels[Math.floor(Math.random() * labels.length)],
            data: []
          });
        }

        // Add charts (images) with randomized types and data
        const chartTypes = ['line', 'bar', 'doughnut', 'radar', 'pie', 'polarArea'];
        const shuffledChartTypes = [...chartTypes].sort(() => Math.random() - 0.5);

        for (let i = 0; i < numCharts; i++) {
          const type = shuffledChartTypes[i % shuffledChartTypes.length];
          const m = shuffledMeasures[i % shuffledMeasures.length];
          const d = shuffledDims[i % shuffledDims.length];
          const mName = m?.businessName || primaryMeasure;
          const dName = d?.businessName || primaryDim;

          let chartConfig: any = {
            type: type,
            data: {
              labels: ['Group A', 'Group B', 'Group C', 'Group D', 'Group E'],
              datasets: [{
                label: mName,
                data: Array.from({ length: 5 }, () => Math.floor(Math.random() * 100)),
                backgroundColor: type === 'line' || type === 'radar' ? `rgba(59, 130, 246, 0.1)` : shuffledColors.slice(0, 5),
                borderColor: shuffledColors[0],
                borderWidth: 2
              }]
            },
            options: {
              title: { display: true, text: `${mName} by ${dName}`, fontSize: 14, fontColor: '#1e293b' },
              legend: { position: 'bottom', display: type !== 'bar' }
            }
          };

          if (type === 'line') {
            chartConfig.data.labels = timeLabels;
            chartConfig.data.datasets[0].data = Array.from({ length: timeLabels.length }, () => Math.floor(Math.random() * 1000));
            chartConfig.data.datasets[0].fill = true;
            chartConfig.data.datasets[0].tension = 0.4;
            chartConfig.data.datasets[0].borderColor = shuffledColors[Math.floor(Math.random() * shuffledColors.length)];
            
            // Add a target line for variety
            chartConfig.data.datasets.push({
              label: 'Target',
              data: Array.from({ length: timeLabels.length }, () => 800 + Math.floor(Math.random() * 200)),
              borderColor: '#94a3b8',
              borderDash: [5, 5],
              fill: false,
              pointRadius: 0
            });
          }

          if (type === 'bar') {
            chartConfig.data.datasets[0].backgroundColor = shuffledColors.slice(0, 5);
          }

          widgets.push({
            id: `c${i}`,
            type: 'image',
            title: `${mName} ${type.charAt(0).toUpperCase() + type.slice(1)} Analysis`,
            imageUrl: `https://quickchart.io/chart?c=${encodeURIComponent(JSON.stringify(chartConfig))}`,
            data: []
          });
        }

        // Add a table with randomized data
        widgets.push({
          id: 't1',
          type: 'table',
          title: `Detailed ${starSchema.tableName} Audit`,
          columns: ['ID', primaryDim, primaryMeasure, secondaryMeasure, 'Status'],
          data: Array.from({ length: 5 }, (_, i) => ({
            ID: `TX-${9000 + i}`,
            [primaryDim]: `Segment ${String.fromCharCode(65 + i)}`,
            [primaryMeasure]: (Math.random() * 10000).toFixed(0),
            [secondaryMeasure]: (Math.random() * 500).toFixed(0),
            Status: ['Completed', 'Pending', 'Flagged', 'Verified'][Math.floor(Math.random() * 4)]
          }))
        });

        const dashboard: DashboardModel = {
          id: crypto.randomUUID(),
          projectId: currentProjectId,
          starSchemaId: selectedStarSchemaId,
          name: dashboardName,
          theme: dashboardTheme,
          description: customDashboardDesc || `Advanced analytical dashboard for ${starSchema.tableName}. Visualizing ${measures.length} key measures across ${dimensionCols.length} dimensions.`,
          createdAt: new Date().toISOString(),
          filters: [
            { id: 'f1', label: 'Time Period', column: 'Date', options: ['Last 7 Days', 'Last 30 Days', 'Last Quarter', 'Year to Date'] },
            { id: 'f2', label: 'Region', column: 'Region', options: ['Global', 'North America', 'EMEA', 'APAC', 'LATAM'] },
            { id: 'f3', label: 'Segment', column: 'Segment', options: ['All Segments', 'Enterprise', 'SMB', 'Consumer'] }
          ],
          widgets: widgets
        };

        setDashboards(prev => [dashboard, ...prev]);
        setCurrentDashboard(dashboard);
        setCurrentModel(null);
        
        const initialFilters: Record<string, string> = {};
        dashboard.filters.forEach(f => {
          initialFilters[f.id] = f.options[0];
        });
        setDashboardFilters(initialFilters);
      } catch (err) {
        setError("Failed to generate dynamic dashboard.");
      } finally {
        setLoading(false);
        dashboardTimeoutRef.current = null;
      }
    }, 800);
    dashboardTimeoutRef.current = timeoutId;
  }, [selectedStarSchemaId, dashboardName, history, currentProjectId, dashboardTheme, customDashboardDesc]);

  const clearHistory = useCallback(() => {
    setHistory(prev => prev.filter(h => h.projectId !== currentProjectId));
    // We don't remove the whole item from localStorage here, 
    // the useEffect will sync the filtered history back to localStorage
  }, [currentProjectId]);

  const deleteFromHistory = useCallback((id: string) => {
    setHistory(prev => prev.filter(h => h.id !== id));
    if (currentModel?.id === id) setCurrentModel(null);
  }, [currentModel]);

  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
  }, []);

  const toggleDimension = useCallback((dimName: string) => {
    setSelectedDimensions(prev => 
      prev.includes(dimName) 
        ? prev.filter(d => d !== dimName) 
        : [...prev, dimName]
    );
  }, []);

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-primary/10 selection:text-primary">
      <Toaster position="top-right" />
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-y border-slate-800 backdrop-blur-md" style={{ backgroundColor: '#E7F0F7' }}>
        <div className="w-full px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white shadow-lg shadow-primary/20 border border-white/10">
                <Building2 size={18} />
              </div>
              <div className="flex flex-col">
                <h1 className="font-black text-lg tracking-tighter text-primary">
                  PARAGON AI
                </h1>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-[0.2em] -mt-1">
                  Data & Analytics Asset Builder
                </span>
              </div>
            </div>
            
            <Separator orientation="vertical" className="h-10 bg-slate-200" />
            
            {/* Project Display */}
            <div className="flex items-center gap-3">
              <div className="flex flex-col">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Active Project</span>
                <div className="flex items-center gap-1">
                  <span className="font-bold text-sm text-slate-900">{currentProject?.name || "Select Project"}</span>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7 text-slate-400 hover:text-primary hover:bg-slate-100"
                    onClick={() => setIsProjectDialogOpen(true)}
                    title="New Project"
                  >
                    <Plus size={14} />
                  </Button>

                  <DropdownMenu>
                    <DropdownMenuTrigger 
                      className={cn(buttonVariants({ variant: "ghost", size: "icon" }), "size-7 text-slate-400 hover:text-primary hover:bg-slate-100")}
                      title="Switch Project"
                    >
                      <FolderKanban size={14} />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="w-56 bg-white border-slate-400 text-slate-900 border">
                      <DropdownMenuGroup>
                        <DropdownMenuLabel>Switch Project</DropdownMenuLabel>
                        <DropdownMenuSeparator className="bg-slate-100" />
                        {projects.map(p => (
                          <DropdownMenuItem key={p.id} onClick={() => setCurrentProjectId(p.id)} className="hover:bg-slate-50">
                            {p.name}
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuGroup>
                      <DropdownMenuSeparator className="bg-slate-100" />
                      <DropdownMenuItem 
                        onClick={() => {
                          setError(null);
                          setIsProjectDialogOpen(true);
                        }} 
                        className="text-primary font-bold"
                      >
                        <Plus size={14} className="mr-2" /> New Project
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={cn(
                      "h-7 w-7 transition-colors",
                      currentProject?.name === "Demo DW" 
                        ? "text-slate-200 cursor-not-allowed" 
                        : "text-slate-400 hover:text-primary hover:bg-slate-100"
                    )}
                    onClick={() => {
                      if (currentProject?.name === "Demo DW") return;
                      setError(null);
                      setRenameValue(currentProject?.name || "");
                      setIsRenameDialogOpen(true);
                    }}
                    disabled={currentProject?.name === "Demo DW"}
                    title={currentProject?.name === "Demo DW" ? "Demo DW cannot be renamed" : "Rename Project"}
                  >
                    <Edit3 size={14} />
                  </Button>

                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7 text-slate-400 hover:text-amber-500 hover:bg-amber-50"
                    onClick={() => {
                      setCompanyProfile(null);
                      setIndustry("");
                      setCompanyName("");
                      setCurrentModel(null);
                      setCurrentDashboard(null);
                      setSelectedSttmAssetId("");
                      setSelectedStarSchemaId("");
                      setError(null);
                      toast.success("Discovery cleared. Ready for fresh queries.");
                    }}
                    title="Reset Discovery (Clear all outputs)"
                  >
                    <RotateCcw size={14} />
                  </Button>

                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-7 w-7 text-slate-400 hover:text-blue-600 hover:bg-blue-50"
                    onClick={() => exportProjectToExcel()}
                    title="Export Full Project (Excel + Diagrams)"
                  >
                    <BookOpen size={14} />
                  </Button>

                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={cn(
                      "h-7 w-7 transition-colors",
                      currentProject?.name === "Demo DW" 
                        ? "text-slate-200 cursor-not-allowed" 
                        : "text-slate-400 hover:text-red-600 hover:bg-red-50"
                    )}
                    onClick={() => {
                      if (currentProject?.name === "Demo DW") return;
                      if (currentProject) {
                        setProjectToDelete(currentProject);
                        setIsDeleteDialogOpen(true);
                      }
                    }}
                    disabled={currentProject?.name === "Demo DW"}
                    title={currentProject?.name === "Demo DW" ? "Demo DW cannot be deleted" : "Delete Project"}
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {renderHeaderExportButtons()}
            <div className="flex items-center gap-2">
              <input
                type="file"
                id="import-backup"
                className="hidden"
                accept=".json"
                onChange={importProjectBackup}
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => document.getElementById('import-backup')?.click()}
                className="text-[9px] font-black uppercase tracking-widest h-7 gap-1.5 border-slate-400 text-slate-500 hover:text-primary hover:border-primary/30 transition-all"
                title="Import Project Backup"
              >
                <Upload size={12} />
                Import
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportProjectBackup}
                className="text-[9px] font-black uppercase tracking-widest h-7 gap-1.5 border-slate-400 text-slate-500 hover:text-primary hover:border-primary/30 transition-all"
                title="Export Project Backup"
              >
                <Download size={12} />
                Export
              </Button>
              <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider text-slate-400 border-slate-200 shadow-sm bg-white/50 backdrop-blur-sm">
                v1.4
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="w-full max-w-[100vw] px-4 sm:px-6 lg:px-8 pt-0 pb-0 transition-all duration-300 flex-1 flex flex-col">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-2 mt-4 items-center">
            <div className={cn(
              "flex items-center gap-2 bg-white border border-slate-800 px-3 h-10 rounded-md shadow-sm",
              isSidebarVisible ? "lg:col-span-3" : "lg:col-span-3"
            )}>
              <Button 
                variant="ghost" 
                size="icon" 
                className={cn(
                  "h-7 w-7 shrink-0 text-slate-400 hover:text-primary hover:bg-slate-100 transition-all rounded-xl",
                  !isSidebarVisible && "text-primary bg-primary/5"
                )}
                onClick={() => setIsSidebarVisible(!isSidebarVisible)}
                title={isSidebarVisible ? "Hide Sidebar" : "Show Sidebar"}
              >
                {isSidebarVisible ? <PanelLeftClose size={14} /> : <PanelLeftOpen size={14} />}
              </Button>

              <div className="w-px h-4 bg-slate-100 shrink-0" />

              <div className="flex items-center gap-1.5 overflow-hidden flex-1 pl-1">
                <span className="text-[10px] font-black uppercase tracking-[0.12em] text-slate-400 whitespace-nowrap leading-tight flex items-center h-4">
                  I AM {['a', 'e', 'i', 'o', 'u'].includes(PERSONA_CONFIG[persona].shortLabel.toLowerCase()[0]) ? 'AN' : 'A'}
                </span>
                <Select value={persona} onValueChange={(val: Persona) => {
                  setPersona(val);
                  // Reset views when switching personas
                  setCurrentModel(null);
                  setCurrentTranscript(null);
                  setSelectedSttmAssetId("");
                  setCurrentDashboard(null);
                  setSelectedStarTable(null);
                  setSelectedGapItem(null);
                  setGapRegistryItems([]);
                  setTranscriptContent("");
                  setMeetingTranscript("");
                  
                  const availableTabs = PERSONA_CONFIG[val].tabs.map(t => t.value);
                  if (!availableTabs.includes(activeTab)) {
                    setActiveTab(availableTabs[0]);
                  }
                }}>
                  <SelectTrigger className="w-auto border-none bg-transparent font-black text-[10px] uppercase tracking-[0.12em] text-slate-700 focus:ring-0 p-0 shadow-none ring-0 h-4 flex items-center leading-tight min-h-0">
                    <SelectValue>
                      {PERSONA_CONFIG[persona].shortLabel}
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-400 min-w-[200px] border">
                    {Object.entries(PERSONA_CONFIG).filter(([key]) => key !== 'project_manager').map(([key, config]) => (
                      <SelectItem key={key} value={key} className="font-bold text-xs text-slate-600 focus:bg-primary/5 focus:text-primary whitespace-nowrap">
                        {config.fullLabel}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Tooltip>
                  <TooltipTrigger 
                    render={(triggerProps) => (
                      <Button 
                        {...triggerProps}
                        variant="ghost" 
                        size="icon" 
                        className={cn(
                          "h-4 w-4 shrink-0 transition-all rounded-md ml-0.5 opacity-60 hover:opacity-100",
                          currentProject?.defaultPersona === persona ? "text-primary bg-primary/10 opacity-100" : "text-slate-300 hover:text-primary hover:bg-slate-100"
                        )}
                        onClick={() => {
                          if (currentProjectId) {
                            setProjects(prev => prev.map(p => 
                              p.id === currentProjectId ? { ...p, defaultPersona: persona } : p
                            ));
                            toast.success(`${PERSONA_CONFIG[persona].fullLabel} set as default for "${currentProject?.name}"`);
                          }
                        }}
                      >
                        <Pin size={8} className={cn(currentProject?.defaultPersona === persona && "fill-current")} />
                      </Button>
                    )}
                  />
                  <TooltipContent className="bg-slate-900 text-white border-none text-[10px] font-bold">Set "{PERSONA_CONFIG[persona].fullLabel}" as default</TooltipContent>
                </Tooltip>
            </div>
            
            <div className="lg:col-span-9 flex items-center h-10">
              <TabsList className="flex items-center gap-1 bg-slate-100/50 border border-slate-100 p-1 h-10 rounded-lg shadow-sm backdrop-blur-sm overflow-x-auto no-scrollbar flex-1">
                {PERSONA_CONFIG[persona].tabs.map((tab, idx) => (
                  <TabsTrigger 
                    key={tab.value}
                    value={tab.value} 
                    className="flex items-center gap-2.5 border border-transparent data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:border-slate-800 text-slate-500 py-1.5 px-4 h-8 rounded-md transition-all duration-300 font-black text-[10px] uppercase tracking-[0.12em] shrink-0"
                  >
                    <div className="flex items-center justify-center w-4 h-4 rounded-full border border-current text-[8px] font-black shrink-0">
                      {idx + 1}
                    </div>
                    <tab.icon size={14} className={cn("transition-transform duration-300", activeTab === tab.value && "scale-110")} />
                    {tab.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mt-6">
            {/* Sidebar Controls */}
            {isSidebarVisible && (activeTab !== 'bi-dashboards' || persona === 'bd') && activeTab !== 'estimates-project' && activeTab !== 'platform-comparison' && (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className={cn(
                  "lg:col-span-3 flex flex-col gap-6",
                  ['dimension', 'fact', 'dashboard', 'sttm', 'bi-dashboards'].includes(activeTab) 
                    ? "h-[calc(100vh-180px)]" 
                    : "h-[calc(100vh-180px)]"
                )}
              >
                <ScrollArea className="h-full flex-1" showScrollbar={isSidebarScrollable}>
                  <div ref={sidebarScrollRef} className="flex flex-col gap-0 pb-6 pt-0 mt-0">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={activeTab}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                      >
                        <TabsContent value="dimension" className="mt-0 mb-4">
                          <Card className="shadow-sm border border-slate-300 bg-slate-100 overflow-hidden rounded-lg">
                            <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                              <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                                <Plus size={18} className="text-primary" />
                                New Dimension
                              </CardTitle>
                              <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                                Define the descriptive attributes of your business entities. Dimensions provide context to your facts and allow for slicing and dicing of data.
                              </CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="industry" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Industry</Label>
                    <Select onValueChange={(val) => { 
                      setIndustry(val); 
                      setTranscriptIndustry(val);
                      setSelectedTicker(""); 
                      if (currentProjectId) {
                        setProjects(prev => prev.map(p => 
                          p.id === currentProjectId ? { ...p, industry: val } : p
                        ));
                      }
                    }} value={industry}>
                      <SelectTrigger id="industry" className="w-full bg-white border-slate-300 text-slate-900">
                        <SelectValue placeholder="Select industry..." />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        {INDUSTRIES.map(ind => (
                          <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Company Name</Label>
                    <Input 
                      id="companyName" 
                      placeholder="e.g. CommerceOne Bank" 
                      value={companyName}
                      onChange={(e) => { 
                        const val = e.target.value;
                        setCompanyName(val); 
                        setTranscriptCompanyName(val);
                        setSelectedTicker(""); 
                        if (currentProjectId) {
                          setProjects(prev => prev.map(p => 
                            p.id === currentProjectId ? { ...p, companyName: val } : p
                          ));
                        }
                      }}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dimTableName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Dimension Table Names (One per line)</Label>
                    <Textarea 
                      id="dimTableName" 
                      placeholder="e.g. Dim_Customer&#10;Dim_Product&#10;Dim_Store" 
                      value={dimTableName}
                      onChange={(e) => setDimTableName(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dimSpecialInstructions" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Special Instructions</Label>
                    <Textarea 
                      id="dimSpecialInstructions" 
                      placeholder="e.g. Add columns for customer loyalty tier, reverse engineer measures for churn analysis..." 
                      value={dimSpecialInstructions}
                      onChange={(e) => setDimSpecialInstructions(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[80px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Model Complexity</Label>
                    <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg border border-slate-200">
                      <Button 
                        variant={dimComplexity === 'Basic' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setDimComplexity('Basic')}
                        className={cn(
                          "h-8 text-xs font-bold transition-all",
                          dimComplexity === 'Basic' ? "bg-primary text-white" : "text-slate-500 hover:text-primary"
                        )}
                      >
                        Basic
                      </Button>
                      <Button 
                        variant={dimComplexity === 'Advanced' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setDimComplexity('Advanced')}
                        className={cn(
                          "h-8 text-xs font-bold transition-all",
                          dimComplexity === 'Advanced' ? "bg-primary text-white" : "text-slate-500 hover:text-primary"
                        )}
                      >
                        Advanced
                      </Button>
                    </div>
                  </div>

                  {error && activeTab === 'dimension' && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm flex items-center gap-2">
                      <X size={14} />
                      {error}
                    </div>
                  )}

                  <div className="space-y-3">
                    <Button 
                      className="w-full bg-primary text-white hover:bg-primary/90 h-11 rounded-xl shadow-lg shadow-primary/20"
                      onClick={handleGenerateDimension}
                      disabled={loading}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="animate-spin" size={18} />
                          <span>Generating...</span>
                        </div>
                      ) : (
                        <><Plus className="mr-2" size={18} /> Generate Dimension</>
                      )}
                    </Button>

                    {loading && activeTab === 'dimension' && (
                      <Button 
                        variant="outline"
                        className="w-full border-red-200 text-red-600 hover:bg-red-50 h-10 rounded-xl"
                        onClick={handleCancel}
                      >
                        <X size={16} className="mr-2" />
                        Cancel Generation
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="fact" className="mb-4">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Plus size={18} className="text-primary" />
                    New Fact
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Define the quantitative measurements of your business processes. Facts contain metrics and foreign keys to dimensions for multi-dimensional analysis. They represent the numerical data that can be aggregated and analyzed across various dimensions.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1.5 block">Industry & Company</Label>
                    <div className="p-0 text-xs space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Industry:</span>
                        <span className="font-bold text-slate-900">{industry || "Not set"}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Company:</span>
                        <span className="font-bold text-slate-900">{companyName || "Not set"}</span>
                      </div>
                      {!industry && (
                        <p className="text-[10px] text-slate-400 mt-2 italic">Set these in the Dimension tab first</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="factTableName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Fact Table Name</Label>
                    <Input 
                      id="factTableName" 
                      placeholder="e.g. Fact_Sales" 
                      value={factTableName}
                      onChange={(e) => setFactTableName(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subjectArea" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Subject Area</Label>
                    <Input 
                      id="subjectArea" 
                      placeholder="e.g. Accounts Payable" 
                      value={subjectArea}
                      onChange={(e) => setSubjectArea(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="factType" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Fact Type</Label>
                    <Select onValueChange={setFactType} value={factType}>
                      <SelectTrigger id="factType" className="w-full bg-white border-slate-200 text-slate-900">
                        <SelectValue placeholder="Select type..." />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        {FACT_TYPES.map(t => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="factSpecialInstructions" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Special Instructions</Label>
                    <Textarea 
                      id="factSpecialInstructions" 
                      placeholder="e.g. Include complex calculated measures for fraud probability..." 
                      value={factSpecialInstructions}
                      onChange={(e) => setFactSpecialInstructions(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[80px]"
                    />
                  </div>

                  {factType === 'Aggregate' && (
                    <div className="space-y-2">
                      <Label htmlFor="grain" className="text-slate-700">Aggregate Grain</Label>
                      <Input 
                        id="grain" 
                        placeholder="e.g. by month, by region" 
                        value={aggregateGrain}
                        onChange={(e) => setAggregateGrain(e.target.value)}
                        className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Model Complexity</Label>
                    <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg border border-slate-400">
                      <Button 
                        variant={factComplexity === 'Basic' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setFactComplexity('Basic')}
                        className={cn(
                          "h-8 text-xs font-bold transition-all",
                          factComplexity === 'Basic' ? "bg-primary text-white" : "text-slate-500 hover:text-primary border border-slate-400"
                        )}
                      >
                        Basic
                      </Button>
                      <Button 
                        variant={factComplexity === 'Advanced' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setFactComplexity('Advanced')}
                        className={cn(
                          "h-8 text-xs font-bold transition-all",
                          factComplexity === 'Advanced' ? "bg-primary text-white" : "text-slate-500 hover:text-primary border border-slate-400"
                        )}
                      >
                        Advanced
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-bold uppercase tracking-wider text-primary">
                        Link Dimensions
                      </Label>
                      <div className="flex gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 text-[10px] px-2 text-slate-500 hover:text-primary"
                          onClick={() => setSelectedDimensions(availableDimensions.map(d => d.tableName))}
                        >
                          Select All
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 text-[10px] px-2 text-slate-500 hover:text-red-600"
                          onClick={() => setSelectedDimensions([])}
                        >
                          Deselect All
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-2 max-h-[160px] overflow-y-auto pr-2 custom-scrollbar">
                      {availableDimensions.length === 0 ? (
                        <div className="p-4 bg-slate-100 rounded-xl border border-dashed border-slate-200 text-center">
                          <p className="text-[10px] text-slate-400 font-medium italic">
                            No dimensions found in this project.
                          </p>
                        </div>
                      ) : (
                        availableDimensions.map((dim) => (
                          <div 
                            key={dim.id} 
                            onClick={() => toggleDimension(dim.tableName)}
                            className={cn(
                              "flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer group",
                              selectedDimensions.includes(dim.tableName) 
                                ? "bg-primary/5 border-primary/20 shadow-sm" 
                                : "bg-white border-slate-200 hover:border-primary/30"
                            )}
                          >
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-4 h-4 rounded flex items-center justify-center transition-colors",
                                selectedDimensions.includes(dim.tableName) ? "bg-primary text-white" : "bg-slate-100 text-transparent group-hover:bg-slate-200"
                              )}>
                                <Check size={10} strokeWidth={4} />
                              </div>
                              <span className="text-xs font-bold text-slate-700">{dim.tableName}</span>
                            </div>
                            <Badge variant="outline" className="text-[8px] opacity-40 group-hover:opacity-100 transition-opacity text-slate-400 border-slate-200">
                              DIM
                            </Badge>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {error && activeTab === 'fact' && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm flex items-center gap-2">
                      <X size={14} />
                      {error}
                    </div>
                  )}

                  <div className="space-y-3">
                    <Button 
                      className="w-full bg-primary text-white hover:bg-primary/90 h-11 rounded-xl shadow-lg shadow-primary/20"
                      onClick={handleGenerateFact}
                      disabled={loading}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="animate-spin" size={18} />
                          <span>Generating...</span>
                        </div>
                      ) : (
                        <><Plus className="mr-2" size={18} /> Generate Fact</>
                      )}
                    </Button>

                        {loading && activeTab === 'fact' && (
                          <Button 
                            variant="outline"
                            className="w-full border-red-200 text-red-600 hover:bg-red-50 h-10 rounded-xl"
                            onClick={handleCancel}
                          >
                            <X size={16} className="mr-2" />
                            Cancel Generation
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="dashboard" className="mt-0 mb-4">
                  <Card className="shadow-sm border border-slate-300 bg-slate-100 overflow-hidden rounded-lg">
                    <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                      <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                        <LayoutDashboard size={18} className="text-primary" />
                        Dashboard Simulator
                      </CardTitle>
                      <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                        Simulate and visualize your data models in a professional analytical dashboard. Test how your star schema translates into actionable business insights.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="starSchema" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Select Star Schema (Fact)</Label>
                    <Select 
                      onValueChange={(val) => setSelectedStarSchemaId(val === 'none' ? "" : val)} 
                      value={selectedStarSchemaId || 'none'}
                    >
                      <SelectTrigger id="starSchema" className="w-full bg-white border-slate-200 text-slate-900">
                        <SelectValue placeholder="Select a Fact table..." />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        <SelectItem value="none">None (No selection)</SelectItem>
                        {availableStarSchemas.map(fact => (
                          <SelectItem key={fact.id} value={fact.id}>{fact.tableName}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="dashName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Dashboard Name</Label>
                    <Input 
                      id="dashName" 
                      placeholder="e.g. Sales Performance Overview" 
                      value={dashboardName}
                      onChange={(e) => setDashboardName(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Dashboard Theme</Label>
                    <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg border border-slate-400">
                      <Button 
                        variant={dashboardTheme === 'Surprise Me!' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setDashboardTheme('Surprise Me!')}
                        className={cn(
                          "h-8 text-xs font-bold transition-all",
                          dashboardTheme === 'Surprise Me!' ? "bg-primary text-white" : "text-slate-500 hover:text-primary border border-slate-400"
                        )}
                      >
                        <Sparkles size={12} className="mr-1.5" />
                        Surprise Me!
                      </Button>
                      <Button 
                        variant={dashboardTheme === 'Custom' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setDashboardTheme('Custom')}
                        className={cn(
                          "h-8 text-xs font-bold transition-all",
                          dashboardTheme === 'Custom' ? "bg-primary text-white" : "text-slate-500 hover:text-primary border border-slate-400"
                        )}
                      >
                        <Settings2 size={12} className="mr-1.5" />
                        Custom
                      </Button>
                    </div>
                  </div>

                  <AnimatePresence>
                    {dashboardTheme === 'Custom' && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-2 overflow-hidden"
                      >
                        <Label htmlFor="customDesc" className="text-slate-700">Dashboard Requirements</Label>
                        <Textarea 
                          id="customDesc" 
                          placeholder="Describe visualizations, KPIs, and specific prompts you want..." 
                          value={customDashboardDesc}
                          onChange={(e) => setCustomDashboardDesc(e.target.value)}
                          className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[100px]"
                        />
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {error && activeTab === 'dashboard' && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm flex items-center gap-2">
                      <X size={14} />
                      {error}
                    </div>
                  )}

                  <div className="space-y-3">
                    <Button 
                      className="w-full bg-primary text-white hover:bg-primary/90 h-11 rounded-xl shadow-lg shadow-primary/20"
                      onClick={handleGenerateDashboard}
                      disabled={loading || availableStarSchemas.length === 0}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="animate-spin" size={18} />
                          <span>Generating...</span>
                        </div>
                      ) : (
                        <><BarChart3 className="mr-2" size={18} /> Generate Sample Dashboard</>
                      )}
                    </Button>

                    {loading && activeTab === 'dashboard' && (
                      <Button 
                        variant="outline"
                        className="w-full border-red-200 text-red-600 hover:bg-red-50 h-10 rounded-xl"
                        onClick={handleCancel}
                      >
                        <X size={16} className="mr-2" />
                        Cancel Generation
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="transcripts" className="mt-0 mb-4">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <MessagesSquare size={18} className="text-primary" />
                    Transcripts
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Process raw meeting recording text into structured, searchable transcripts with speaker tracking.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="transcript-industry" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Industry</Label>
                    <Select onValueChange={(val) => {
                      setTranscriptIndustry(val);
                      setIndustry(val);
                      if (currentProjectId) {
                        setProjects(prev => prev.map(p => 
                          p.id === currentProjectId ? { ...p, industry: val } : p
                        ));
                      }
                    }} value={transcriptIndustry || industry}>
                      <SelectTrigger id="transcript-industry" className="w-full bg-white border-slate-200 text-slate-900">
                        <SelectValue placeholder="Select industry..." />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        {INDUSTRIES.map(ind => (
                          <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="transcript-companyName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Company Name</Label>
                    <Input 
                      id="transcript-companyName" 
                      placeholder="e.g. Commerce One" 
                      value={transcriptCompanyName}
                      onChange={(e) => {
                        const val = e.target.value;
                        setTranscriptCompanyName(val);
                        setCompanyName(val);
                        if (currentProjectId) {
                          setProjects(prev => prev.map(p => 
                            p.id === currentProjectId ? { ...p, companyName: val } : p
                          ));
                        }
                      }}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="transcript-customName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Transcript Title / Name (Optional)</Label>
                    <Input 
                      id="transcript-customName" 
                      placeholder="e.g. Kickoff Workshop (empty to auto-generate)" 
                      value={transcriptCustomName}
                      onChange={(e) => setTranscriptCustomName(e.target.value)}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="transcript-date" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Transcript Date</Label>
                      <div className="relative">
                        <Input 
                          ref={transcriptDateRef}
                          id="transcript-date"
                          type="date"
                          value={transcriptDate}
                          onChange={(e) => setTranscriptDate(e.target.value)}
                          className="bg-white border-slate-200 text-slate-900 pr-4"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="transcript-time" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Time (24h)</Label>
                      <div className="relative">
                        <Select onValueChange={setTranscriptTime} value={transcriptTime}>
                          <SelectTrigger id="transcript-time" className="w-full bg-white border-slate-200 text-slate-900">
                            <SelectValue placeholder="09:00" />
                          </SelectTrigger>
                          <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                            {HOURS.map(h => (
                              <SelectItem key={h} value={h}>{h}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="transcriptContent" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Meeting Transcript (Paste text or use upload)</Label>
                    <div className="relative">
                      <Textarea 
                        id="transcriptContent" 
                        placeholder="Paste transcript text here..." 
                        value={transcriptContent}
                        onChange={(e) => {
                          const val = e.target.value;
                          setTranscriptContent(val);
                          setRawTranscriptContent(""); // Reset raw when user types manually
                          
                          // Try auto extraction if text is long enough
                          if (val.length > 50) {
                            const { date, time } = extractDateTimeFromText(val);
                            if (date) setTranscriptDate(date);
                            if (time) setTranscriptTime(time);
                          }
                        }}
                        className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[100px] h-[100px] resize-none pb-8 text-xs"
                      />
                      <div className="absolute bottom-2 right-2 flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6 rounded-md text-slate-400 hover:text-primary transition-colors"
                          onClick={() => document.getElementById('transcript-file-upload')?.click()}
                        >
                          <Upload size={14} />
                        </Button>
                      </div>
                    </div>
                    <input
                      type="file"
                      id="transcript-file-upload"
                      className="hidden"
                      accept=".txt,.text,.doc,.docx,.xlsx,.xls"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const toastId = toast.loading(`Reading ${file.name}...`);
                        try {
                          const text = await readFileAsText(file);
                          setRawTranscriptContent(text);
                          
                          // Extract date/time from text
                          const { date, time } = extractDateTimeFromText(text);
                          if (date) setTranscriptDate(date);
                          else setTranscriptDate(""); // Blank out if not found as requested

                          if (time) setTranscriptTime(time);
                          else setTranscriptTime(""); // Blank out if not found as requested
                          
                          setTranscriptContent(`[${file.name}]\nMeeting; ${date || '[Date]'}, ${time || '[Time]'}`);
                          
                          toast.success(`Loaded transcript from ${file.name}`, { id: toastId });
                        } catch (err) {
                          console.error("File loading error", err);
                          toast.error("Failed to load file content", { id: toastId });
                        }
                      }}
                    />
                  </div>

                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-white font-black uppercase tracking-[0.2em] text-[10px] h-11 shadow-lg shadow-primary/20 rounded-lg group"
                    onClick={processTranscript}
                    disabled={isProcessingTranscript}
                  >
                    {isProcessingTranscript ? (
                      <div className="flex items-center justify-center gap-3">
                        <div className="relative w-8 h-6 flex items-center justify-center">
                          <Users size={16} className="text-white animate-pulse" />
                          <div className="absolute -top-1 -right-1">
                            <Wifi size={10} className="text-white animate-bounce" />
                          </div>
                          <div className="absolute -top-1 -left-1 scale-x-[-1]">
                            <Wifi size={10} className="text-white animate-bounce" style={{ animationDelay: '200ms' }} />
                          </div>
                        </div>
                        <span>Processing...</span>
                      </div>
                    ) : (
                      <><Speech className="mr-2 h-4 w-4 group-hover:animate-pulse" /> Process Transcript</>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="gap-registry" className="mt-0 mb-4">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Sparkles size={18} className="text-primary" />
                    Generate Gap Registry
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Analyze meeting transcripts to extract pain points, gaps, opportunities, and strategic observations.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-1">
                  <div className="space-y-2">
                    <Label htmlFor="gap-industry" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Industry</Label>
                    <Select onValueChange={(val) => {
                      setIndustry(val);
                      setTranscriptIndustry(val);
                      if (currentProjectId) {
                        setProjects(prev => prev.map(p => 
                          p.id === currentProjectId ? { ...p, industry: val } : p
                        ));
                      }
                    }} value={industry}>
                      <SelectTrigger id="gap-industry" className="w-full bg-white border-slate-300 text-slate-900">
                        <SelectValue placeholder="Select industry..." />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        {INDUSTRIES.map(ind => (
                          <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gap-companyName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Company Name</Label>
                    <Input 
                      id="gap-companyName" 
                      placeholder="e.g. Commerce One" 
                      value={companyName}
                      onChange={(e) => {
                        const val = e.target.value;
                        setCompanyName(val);
                        setTranscriptCompanyName(val);
                        if (currentProjectId) {
                          setProjects(prev => prev.map(p => 
                            p.id === currentProjectId ? { ...p, companyName: val } : p
                          ));
                        }
                      }}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Select Transcripts</Label>
                      {transcripts.filter(t => t.projectId === currentProjectId).length > 0 && (
                        <button 
                          className="text-[9px] font-bold text-primary hover:underline uppercase"
                          onClick={() => {
                            const allIds = transcripts.filter(t => t.projectId === currentProjectId).map(t => t.id);
                            setSelectedTranscriptsForGap(prev => prev.length === allIds.length ? [] : allIds);
                          }}
                        >
                          {selectedTranscriptsForGap.length === transcripts.filter(t => t.projectId === currentProjectId).length ? 'Deselect All' : 'Select All'}
                        </button>
                      )}
                    </div>
                    {transcripts.filter(t => t.projectId === currentProjectId).length > 0 ? (
                      <div className="flex flex-col gap-2 max-h-[150px] overflow-y-auto p-2 bg-white rounded-xl border border-slate-200">
                        {transcripts.filter(t => t.projectId === currentProjectId).map((transcript) => {
                          const isSelected = selectedTranscriptsForGap.includes(transcript.id);
                          return (
                            <div 
                              key={transcript.id}
                              className={cn(
                                "flex items-center justify-between p-2 rounded-lg cursor-pointer transition-all border",
                                isSelected ? "bg-primary/5 border-primary shadow-sm" : "bg-slate-50 border-transparent hover:border-slate-300"
                              )}
                              onClick={() => {
                                setSelectedTranscriptsForGap(prev => 
                                  prev.includes(transcript.id) ? prev.filter(id => id !== transcript.id) : [...prev, transcript.id]
                                );
                              }}
                            >
                              <div className="flex items-center gap-2">
                                <div className={cn(
                                  "w-4 h-4 rounded border flex items-center justify-center transition-colors",
                                  isSelected ? "bg-primary border-primary text-white" : "border-slate-300 bg-white"
                                )}>
                                  {isSelected && <Check size={10} strokeWidth={4} />}
                                </div>
                                <span className={cn("text-[11px] font-bold truncate", isSelected ? "text-primary" : "text-slate-600")}>
                                  {transcript.name}
                                </span>
                              </div>
                              <span className="text-[9px] font-black text-slate-400 uppercase">{transcript.date}</span>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="py-6 px-4 bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl text-center">
                        <p className="text-[10px] font-bold text-slate-400 uppercase">No transcripts found for this project</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Identify WMP Team Members</Label>
                      {availableAttendees.length > 0 && (
                        <button 
                          className="text-[9px] font-bold text-primary hover:underline uppercase"
                          onClick={() => setSelectedWmpAttendees(prev => prev.length === availableAttendees.length ? [] : [...availableAttendees])}
                        >
                          {selectedWmpAttendees.length === availableAttendees.length ? 'Deselect All' : 'Select All'}
                        </button>
                      )}
                    </div>
                    {availableAttendees.length > 0 ? (
                      <div className="flex flex-wrap gap-2 p-2 bg-white rounded-xl border border-slate-200 min-h-[50px] max-h-[120px] overflow-y-auto">
                        {availableAttendees.map((attendee) => {
                          const isSelected = selectedWmpAttendees.includes(attendee);
                          return (
                            <Badge 
                              key={attendee}
                              variant={isSelected ? "default" : "outline"}
                              className={cn(
                                "cursor-pointer transition-all px-2 py-0.5 text-[10px] uppercase font-black tracking-wider",
                                isSelected ? "bg-primary text-white" : "text-slate-400 border-slate-200 hover:border-primary hover:text-primary"
                              )}
                              onClick={() => {
                                setSelectedWmpAttendees(prev => 
                                  prev.includes(attendee) ? prev.filter(a => a !== attendee) : [...prev, attendee]
                                );
                              }}
                            >
                              {attendee}
                            </Badge>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="py-4 px-4 bg-slate-50 border-2 border-dashed border-slate-200 rounded-xl text-center">
                        <p className="text-[10px] font-bold text-slate-400 uppercase">Select transcripts to see attendees</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Processing Mode</Label>
                    </div>
                    <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 shadow-sm w-full">
                      <Button 
                        variant={gapRegistryMode === 'Overwrite' ? 'default' : 'ghost'}
                        className={cn(
                          "h-8 flex-1 text-[9px] font-black uppercase tracking-widest transition-all rounded-lg",
                          gapRegistryMode === 'Overwrite' ? "bg-primary text-white shadow-sm hover:bg-primary/90" : "text-slate-400 hover:text-primary hover:bg-slate-50"
                        )}
                        onClick={() => setGapRegistryMode('Overwrite')}
                      >
                        New/Overwrite
                      </Button>
                      <Button 
                        variant={gapRegistryMode === 'Append' ? 'default' : 'ghost'}
                        className={cn(
                          "h-8 flex-1 text-[9px] font-black uppercase tracking-widest transition-all rounded-lg",
                          gapRegistryMode === 'Append' ? "bg-primary text-white shadow-sm hover:bg-primary/90" : "text-slate-400 hover:text-primary hover:bg-slate-50"
                        )}
                        onClick={() => setGapRegistryMode('Append')}
                      >
                        Append
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Additional Context (Optional)</Label>
                    <div className="relative">
                      <Textarea 
                        id="meetingTranscript" 
                        placeholder="Any additional notes or paste extra transcript content..." 
                        value={meetingTranscript}
                        onChange={(e) => setMeetingTranscript(e.target.value)}
                        className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[60px] h-[60px] resize-none pb-8 text-xs"
                      />
                      <div className="absolute bottom-2 right-2 flex items-center gap-2">
                        <input
                          type="file"
                          id="gap-file-upload"
                          className="hidden"
                          multiple
                          accept=".csv,.xlsx,.xls,.txt,.docx"
                          onChange={async (e) => {
                            const files = e.target.files;
                            if (!files) return;
                            setUploadedGapFiles(prev => [...prev, ...Array.from(files)]);
                            toast.success(`Attached ${files.length} documents.`);
                          }}
                        />
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6 rounded-md text-slate-400 hover:text-primary transition-colors"
                          onClick={() => document.getElementById('gap-file-upload')?.click()}
                        >
                          <Upload size={14} />
                        </Button>
                      </div>
                    </div>
                    
                    {uploadedGapFiles.length > 0 && (
                      <div className="flex flex-wrap gap-2 p-1.5 bg-white border border-slate-200 rounded-lg max-h-[80px] overflow-y-auto">
                        {uploadedGapFiles.map((file, idx) => (
                          <div key={idx} className="bg-slate-50 border border-slate-200 rounded-md px-1.5 py-0.5 flex items-center gap-1 shadow-sm">
                            <FileText size={8} className="text-primary" />
                            <span className="text-[8px] font-bold text-slate-600 truncate max-w-[100px]">{file.name}</span>
                            <button onClick={() => setUploadedGapFiles(p => p.filter((_, i) => i !== idx))}>
                              <X size={8} className="text-slate-400 hover:text-red-500" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-white font-black uppercase tracking-[0.2em] text-[10px] h-11 shadow-lg shadow-primary/20 rounded-lg group"
                    onClick={handleGenerateGapRegistry}
                    disabled={loading}
                  >
                    {isGeneratingGapRegistry ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4 group-hover:animate-pulse" />
                    )}
                    Generate Gap Registry
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sttm" className="mt-0 mb-4">
                  <Card className="shadow-sm border border-slate-300 bg-slate-100 overflow-hidden rounded-lg">
                    <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                      <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                        <ArrowRightLeft size={18} className="text-primary" />
                        STTM Mapper
                      </CardTitle>
                      <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                        Map source fields to your warehouse model. Define transformations and lineage.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">View Mode</Label>
                    <div className="flex items-center gap-2 bg-white px-3 py-1 rounded-lg border border-slate-200 w-full">
                      <Button 
                        variant={sttmViewMode === 'target-to-source' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setSttmViewMode('target-to-source')}
                        className={cn(
                          "flex-1 h-7 text-[10px] font-bold transition-all",
                          sttmViewMode === 'target-to-source' ? "bg-primary text-white shadow-sm" : "bg-white text-slate-500 hover:text-primary"
                        )}
                      >
                        Target-to-Source
                      </Button>
                      <Button 
                        variant={sttmViewMode === 'source-to-target' ? 'default' : 'ghost'}
                        size="sm"
                        onClick={() => setSttmViewMode('source-to-target')}
                        className={cn(
                          "flex-1 h-7 text-[10px] font-bold transition-all",
                          sttmViewMode === 'source-to-target' ? "bg-primary text-white shadow-sm" : "bg-white text-slate-500 hover:text-primary"
                        )}
                      >
                        Source-to-Target
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="assetToMap" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Select an Asset to Map</Label>
                    <Select 
                      onValueChange={(val) => setSelectedSttmAssetId(val === 'none' ? "" : val)} 
                      value={selectedSttmAssetId || 'none'}
                    >
                      <SelectTrigger id="assetToMap" className="w-full bg-white border-slate-200 text-slate-900">
                        <SelectValue placeholder="Select a table...">
                          {selectedSttmAssetId ? history.find(t => t.id === selectedSttmAssetId)?.tableName : "Select a table..."}
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        <SelectItem value="none">None (No selection)</SelectItem>
                        {filteredHistory.map(table => (
                          <SelectItem key={table.id} value={table.id}>
                            {table.tableName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                    <Label htmlFor="sourceDefs" className="text-slate-800 font-bold text-sm">Source Definition <span className="text-red-500">*</span></Label>
                      <label className="cursor-pointer flex items-center gap-1.5 text-[10px] font-bold text-primary hover:text-primary/80 bg-primary/5 px-2 py-1 rounded-md transition-all">
                        <Upload size={12} />
                        Upload
                        <input type="file" className="hidden" onChange={handleFileUpload} accept=".json,.txt,.csv,.xlsx" multiple />
                      </label>
                    </div>
                    <div className="relative group">
                      <Textarea 
                        id="sourceDefs" 
                        placeholder="Paste source patterns, columns, and types..." 
                        value={sourceDefinitions}
                        onChange={(e) => setSourceDefinitions(e.target.value)}
                        className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 min-h-[160px] pb-12 focus:ring-primary/20 focus:border-primary transition-all shadow-sm"
                        required
                      />
                      {uploadedFiles.length > 0 && (
                        <div className="absolute bottom-2 left-2 right-2 flex flex-wrap gap-2 p-2 bg-white/80 backdrop-blur-sm rounded-lg border border-slate-100 shadow-sm max-h-[80px] overflow-y-auto">
                          {uploadedFiles.map((file, idx) => (
                            <div key={idx} className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 rounded-md text-[10px] font-medium text-slate-600 border border-slate-200">
                              <FileText size={10} className="text-primary" />
                              <span className="truncate max-w-[80px]">{file.name}</span>
                              <button onClick={() => setUploadedFiles(prev => prev.filter((_, i) => i !== idx))} className="hover:text-red-500">
                                <X size={10} />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {error && activeTab === 'sttm' && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm flex items-center gap-2">
                      <X size={14} />
                      {error}
                    </div>
                  )}

                  <div className="space-y-3 pt-2">
                    <Button 
                      className="w-full bg-primary text-white hover:bg-primary/90 h-11 rounded-xl shadow-lg shadow-primary/20"
                      onClick={handleGenerateSTTM}
                      disabled={loading || !selectedSttmAssetId || !sourceDefinitions.trim()}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="animate-spin" size={18} />
                          <span>Mapping...</span>
                        </div>
                      ) : (
                        <><Zap className="mr-2" size={18} /> Generate Mapping</>
                      )}
                    </Button>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-100">
                    <Label className="text-xs font-bold uppercase tracking-widest text-primary">Mapping Status</Label>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                        <span className="text-[10px] font-medium text-slate-600">Total Tables</span>
                        <Badge variant="secondary" className="text-[10px]">{filteredHistory.length}</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                        <span className="text-[10px] font-medium text-slate-600">Mapped Tables</span>
                        <Badge variant="secondary" className="text-[10px] bg-emerald-50 text-emerald-600 border-emerald-100">
                          {sttmMappings.filter(m => m.projectId === currentProjectId).length}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="opps" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Sparkles size={18} className="text-primary" />
                    Company MDP Opportunities
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Identify unique business opportunities and data platform initiatives tailored to your specific industry and company profile.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 flex-1 flex flex-col">
                  <div className="space-y-2 shrink-0">
                    <Label htmlFor="opp-industry" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Industry</Label>
                    <Select onValueChange={(val) => { setIndustry(val); setSelectedTicker(""); }} value={industry}>
                      <SelectTrigger id="opp-industry" className="w-full bg-white border-slate-200 text-slate-900">
                        <SelectValue placeholder="Select industry..." />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-400 text-slate-900 border">
                        {INDUSTRIES.map(ind => (
                          <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2 shrink-0">
                    <Label htmlFor="opp-companyName" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Company Name</Label>
                    <Input 
                      id="opp-companyName" 
                      placeholder="e.g. CommerceOne Bank" 
                      value={companyName}
                      onChange={(e) => { setCompanyName(e.target.value); setSelectedTicker(""); }}
                      className="bg-white border-slate-200 text-slate-900 placeholder:text-slate-400"
                    />
                  </div>

                  <div className="space-y-2 shrink-0">
                    <div className="flex items-center justify-between px-1">
                      <Label className="text-slate-700 text-[10px] font-black uppercase tracking-widest opacity-60">Verified Exchange Entity</Label>
                      {isSearchingTicker && <div className="w-3 h-3 border-2 border-primary border-t-transparent rounded-full animate-spin" />}
                    </div>
                    <Select 
                      value={selectedTicker} 
                      onValueChange={(val) => setSelectedTicker(val)}
                      disabled={!companyProfile}
                    >
                      <SelectTrigger className="w-full h-10 bg-white border-slate-200 rounded-xl text-xs font-bold text-slate-900 shadow-sm transition-all focus:ring-primary/20 flex justify-between">
                        <SelectValue placeholder="Awaiting Generation" />
                      </SelectTrigger>
                      <SelectContent className="rounded-xl border-slate-400 shadow-xl w-[calc(var(--radix-select-trigger-width))] min-w-[280px] border">
                        {potentialTickers.length > 0 ? (
                          <>
                            {potentialTickers.map((t) => (
                              <SelectItem key={t.symbol} value={t.symbol} className="text-xs font-bold py-2.5">
                                <span className="block truncate max-w-[240px] font-black">{t.symbol} - {t.companyName}</span>
                              </SelectItem>
                            ))}
                          </>
                        ) : companyProfile && (companyProfile.ownershipType === 'Private' || companyProfile.ownershipType === 'Public Sector') ? (
                          <SelectItem value="NON_PUBLIC" className="text-xs font-bold py-2.5 italic text-slate-500">
                            (Private or Public Sector)
                          </SelectItem>
                        ) : (
                          <div className="p-4 text-center text-xs text-slate-400 font-bold">
                            Generate opportunities to verify entity
                          </div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2 flex-1 flex flex-col min-h-0">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="opp-context" className="text-slate-700 shrink-0">Additional Context</Label>
                      <div className="flex items-center gap-2">
                        <input 
                          type="file" 
                          id="opp-file-upload" 
                          className="hidden" 
                          multiple 
                          accept=".doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png,.pdf,.ppt,.pptx"
                          onChange={async (e) => {
                            const files = Array.from(e.target.files || []);
                            const newFiles = await Promise.all(files.map(async (file: File) => {
                              return new Promise<{name: string, type: string, data: string}>((resolve) => {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  const result = reader.result as string;
                                  const base64 = result.split(',')[1];
                                  resolve({ name: file.name, type: file.type, data: base64 });
                                };
                                reader.readAsDataURL(file);
                              });
                            }));
                            setOppFiles(prev => [...prev, ...newFiles]);
                            toast.success(`Attached ${files.length} file(s) for analysis`);
                          }}
                        />
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => document.getElementById('opp-file-upload')?.click()}
                          className="h-6 px-2 text-[10px] font-black uppercase tracking-wider text-primary bg-primary/5 hover:bg-primary/10 border border-primary/20 rounded-md gap-1"
                        >
                          <Upload size={10} />
                          Upload Files
                        </Button>
                      </div>
                    </div>
                    {oppFiles.length > 0 && (
                        <div className="flex flex-wrap gap-2 mb-2 p-2 bg-slate-100 rounded-lg border border-slate-100 max-h-[100px] overflow-y-auto">
                        {oppFiles.map((f, i) => (
                          <Badge key={i} variant="secondary" className="bg-white border-slate-200 text-slate-600 gap-1 pl-2 pr-1 py-1 text-[10px] shadow-sm">
                            <span className="truncate max-w-[120px]">{f.name}</span>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-4 w-4 hover:text-red-500 rounded-full"
                              onClick={() => setOppFiles(prev => prev.filter((_, idx) => idx !== i))}
                            >
                              <X size={10} />
                            </Button>
                          </Badge>
                        ))}
                      </div>
                    )}
                    <Textarea 
                      id="opp-context" 
                      placeholder="Provide additional context or instructions to target specific business outcomes..." 
                      value={oppAdditionalContext}
                      onChange={(e) => setOppAdditionalContext(e.target.value)}
                      className="bg-slate-100 border-slate-200 text-slate-900 placeholder:text-slate-400 flex-1 resize-none"
                    />
                  </div>

                  <div className="space-y-3 shrink-0 py-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-slate-700 text-xs font-bold">No. of Business Area Opportunities</Label>
                      <Badge variant="secondary" className="bg-primary/10 text-primary font-black border-none px-2 py-0.5 text-[10px] rounded-md">
                        {oppCount}
                      </Badge>
                    </div>
                    <input 
                      type="range" 
                      min="6" 
                      max="30" 
                      step="1" 
                      value={oppCount}
                      onChange={(e) => setOppCount(parseInt(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary transition-all hover:bg-slate-300"
                    />
                    <div className="flex justify-between text-[8px] font-black uppercase tracking-widest text-slate-400">
                      <span>6</span>
                      <span>9</span>
                      <span>12</span>
                      <span>15</span>
                      <span>18</span>
                      <span>21</span>
                      <span>24</span>
                      <span>27</span>
                      <span>30</span>
                    </div>
                  </div>

                  {error && (activeTab === 'opps' || activeTab === 'usecases') && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm flex items-center gap-2 shrink-0">
                      <X size={14} />
                      {error}
                    </div>
                  )}

                  <div className="space-y-3 shrink-0">
                    <Button 
                      className="w-full bg-primary text-white hover:bg-primary/90 h-11 rounded-xl shadow-lg shadow-primary/20 transition-all font-bold"
                      onClick={handleGenerateOpportunities}
                      disabled={loading}
                    >
                      {loading ? (
                        <div className="flex items-center justify-center gap-2">
                          <Loader2 className="animate-spin" size={18} />
                          <span>Generating...</span>
                        </div>
                      ) : (
                        <><Sparkles className="mr-2" size={18} /> Generate MDP Opportunity</>
                      )}
                    </Button>

                    {loading && (activeTab === 'opps' || activeTab === 'usecases') && (
                      <Button 
                        variant="outline"
                        className="w-full border-red-200 text-red-600 hover:bg-red-50 h-10 rounded-xl"
                        onClick={handleCancel}
                      >
                        <X size={16} className="mr-2" />
                        Cancel Generation
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="usecases" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Briefcase size={18} className="text-primary" />
                    MDP Business Use Cases
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Select a high-impact opportunity to view its detailed business case and ROI strategy.
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 flex-1">
                  <div className="p-4 space-y-3">
                      {(companyProfile?.opportunities?.filter(o => o.selected)?.length ?? 0) === 0 ? (
                        <div className="text-center py-12 px-4 italic text-slate-400 text-xs font-medium">
                          No opportunities selected. Go to the MDP Opportunities screen to select business area opportunities for use case analysis.
                        </div>
                      ) : (
                        companyProfile?.opportunities?.filter(o => o.selected).map((opp) => (
                          <div 
                            key={opp.id}
                            onClick={() => setSelectedUseCaseOppId(opp.id)}
                            className={cn(
                              "group p-3 rounded-2xl border-2 transition-all cursor-pointer relative overflow-hidden",
                              selectedUseCaseOppId === opp.id 
                                ? "bg-primary/5 border-primary shadow-md" 
                                : "bg-white border-slate-100 hover:border-primary/30 hover:bg-slate-50"
                            )}
                          >
                            <div className="flex items-start gap-3">
                              <div className={cn(
                                "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border transition-all",
                                selectedUseCaseOppId === opp.id 
                                  ? "bg-white text-primary border-primary/20 shadow-sm" 
                                  : "bg-slate-50 text-slate-400 border-slate-100"
                              )}>
                                <OpportunityIcon type={opp.iconType} size={20} index={companyProfile?.opportunities?.filter(o => o.selected).indexOf(opp) ?? 0} />
                              </div>
                              <div className="space-y-1 pr-2">
                                <h4 className={cn(
                                  "text-sm font-black leading-tight",
                                  selectedUseCaseOppId === opp.id ? "text-primary" : "text-slate-900"
                                )}>
                                  {opp.title}
                                </h4>
                                <p className="text-xs text-slate-500 font-medium leading-relaxed opacity-70">
                                  {opp.businessCase}
                                </p>
                                <div className="flex items-center gap-2 pt-2">
                                  <Tooltip>
                                      <TooltipTrigger 
                                        render={(triggerProps) => (
                                          <div {...triggerProps} className="flex items-center gap-1 cursor-help outline-none">
                                            <TrendingUp size={12} className="text-emerald-500" />
                                            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">
                                              {opp.roi.split(' ')[0]} {opp.roi.split(' ')[1]}
                                            </span>
                                          </div>
                                        )}
                                      />
                                      <TooltipContent className="bg-slate-900 text-white border-none shadow-xl p-3 max-w-xs">
                                        <div className="space-y-2">
                                          <p className="font-bold border-b border-white/20 pb-1">Value Glossary</p>
                                          <p><span className="text-emerald-400 font-black">Estimated:</span> Calculation based on current market benchmarks and internal performance averages.</p>
                                          <p><span className="text-emerald-400 font-black">Projected:</span> Forward-looking model accounting for platform integration speed and adoption curve.</p>
                                          <p><span className="text-emerald-400 font-black">Expected:</span> Conservative target based on baseline Modern Data Platform (MDP) capabilities.</p>
                                        </div>
                                      </TooltipContent>
                                    </Tooltip>
                                </div>
                              </div>
                              {selectedUseCaseOppId === opp.id && (
                                <div className="absolute top-3 right-3 text-primary animate-in zoom-in-50">
                                  <div className="w-2 h-2 rounded-full bg-primary" />
                                </div>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="estimates-platform" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="py-2 bg-slate-50/50 border-b border-slate-200 px-4 shrink-0 flex flex-row items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 text-slate-400 hover:text-primary transition-all p-0"
                      onClick={() => setIsEstimatorPaneExpanded(!isEstimatorPaneExpanded)}
                    >
                      {isEstimatorPaneExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </Button>
                    <CardTitle className="text-xs font-black flex items-center gap-2 text-slate-900">
                      <Database size={14} className="text-primary" />
                      MDP Platform Estimator
                      <Tooltip>
                        <TooltipTrigger render={(triggerProps) => (
                          <Button 
                            {...triggerProps}
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 ml-1 p-0.5 text-slate-400 hover:text-primary transition-all rounded-md"
                            onClick={() => setIsAdvancedQuestionnaireOpen(true)}
                          >
                            <FileBarChart size={12} />
                          </Button>
                        )} />
                        <TooltipContent className="bg-slate-900 text-white border-none text-[10px] font-bold py-1 px-3 shadow-2xl rounded-lg">
                          Advanced Questionnaire Prompt
                        </TooltipContent>
                      </Tooltip>
                    </CardTitle>
                  </div>
                </CardHeader>
                <AnimatePresence initial={false}>
                  {isEstimatorPaneExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden flex flex-col flex-1"
                    >
                      <CardContent className="space-y-3 flex-1 flex flex-col p-3 pt-1.5 overflow-y-auto no-scrollbar pb-3">
                        {/* Scenario Name Dropdown */}
                        <div className="space-y-2">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-0.5">Scenario Name</Label>
                          <div className="flex gap-1">
                            <DropdownMenu>
                              <DropdownMenuTrigger render={(triggerProps) => (
                                <Button 
                                  {...triggerProps}
                                  variant="outline" 
                                  className={cn(
                                    "h-10 flex-1 justify-between bg-white border-slate-200 text-xs font-bold px-3 rounded-xl hover:bg-slate-50",
                                    scenarioName === "[Provide Scenario Name]" ? "text-slate-400" : "text-slate-700"
                                  )}
                                >
                                  <span className="truncate">{scenarioName}</span>
                                  <ChevronDown size={14} className="text-slate-400 shrink-0" />
                                </Button>
                              )} />
                              <DropdownMenuContent className="w-[calc(100vw-36rem)] max-w-xs bg-white border-slate-200 p-1 rounded-xl shadow-2xl z-[100]">
                                {currentProjectScenarios.length > 0 ? (
                                  currentProjectScenarios.map(s => (
                                    <DropdownMenuItem 
                                      key={s.id}
                                      className={cn(
                                        "flex items-center justify-between p-2.5 rounded-lg cursor-pointer text-[11px] font-bold group",
                                        currentScenarioId === s.id ? "bg-primary/5 text-primary" : "text-slate-600 hover:bg-slate-50"
                                      )}
                                      onClick={() => handleSwitchScenario(s.id)}
                                    >
                                      <span className="truncate">{s.name}</span>
                                      <button 
                                        onClick={(e) => { e.stopPropagation(); handleDeleteScenario(s.id); }}
                                        className="p-1 hover:bg-red-50 hover:text-red-600 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                                      >
                                        <Trash2 size={12} />
                                      </button>
                                    </DropdownMenuItem>
                                  ))
                                ) : (
                                  <div className="p-4 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                    No scenarios found
                                  </div>
                                )}
                                <DropdownMenuSeparator className="my-1 bg-slate-100" />
                                <DropdownMenuItem 
                                  onClick={handleAddScenario}
                                  className="flex items-center gap-2 p-2.5 rounded-lg cursor-pointer text-[11px] font-black uppercase tracking-widest text-primary hover:bg-primary/5"
                                >
                                  <PlusCircle size={14} />
                                  Add New Scenario
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                            
                            {currentScenarioId && (
                              <Popover>
                                <PopoverTrigger render={(triggerProps) => (
                                  <Button {...triggerProps} variant="outline" className="w-10 h-10 p-0 rounded-xl bg-white border-slate-200 text-slate-600 hover:bg-slate-50">
                                    <PenLine size={16} />
                                  </Button>
                                )} />
                                <PopoverContent className="w-64 bg-white p-3 rounded-xl shadow-2xl border-slate-200 z-[110]">
                                  <div className="space-y-3">
                                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Rename Scenario</h4>
                                    <Input 
                                      value={scenarioName}
                                      onChange={(e) => handleUpdateScenarioName(e.target.value)}
                                      className="h-9 text-xs font-bold"
                                    />
                                  </div>
                                </PopoverContent>
                              </Popover>
                            )}
                          </div>
                        </div>

                        {/* Dropdowns - Justified */}
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                              <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 px-0.5">Cloud</Label>
                              <Select value={preferredCloud} onValueChange={(val) => setPreferredCloud(val as CloudProvider)}>
                                <SelectTrigger className="h-8 w-full bg-white border-slate-200 text-[11px] font-bold uppercase py-0 rounded-lg shadow-sm">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-white border-slate-400 border text-[11px] font-bold">
                                  <SelectItem value="Azure">Azure</SelectItem>
                                  <SelectItem value="AWS">AWS</SelectItem>
                                  <SelectItem value="GCP">GCP</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            <div className="space-y-1.5 flex flex-col justify-center">
                              <div className="flex items-center justify-between px-1">
                                <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 shrink-0">Environments</Label>
                                <Tooltip>
                                  <TooltipTrigger render={(triggerProps) => (
                                    <div {...triggerProps} className="cursor-help text-slate-900 hover:text-primary transition-colors shrink-0 ml-1">
                                      <Info size={14} fill="currentColor" fillOpacity={0.2} />
                                    </div>
                                  )} />
                                  <TooltipContent className="bg-slate-900 text-white border-none text-[11px] font-bold py-2 px-4 shadow-2xl rounded-xl">
                                    Isolated unless specified in special instructions
                                  </TooltipContent>
                                </Tooltip>
                              </div>
                              <div className="flex gap-0.5 mt-1">
                                {['DEV', 'QA', 'PROD'].map((env) => (
                                  <button
                                    key={env}
                                    onClick={() => {
                                      if (selectedEnvironments.includes(env as Environment)) {
                                        if (selectedEnvironments.length > 1) setSelectedEnvironments(prev => prev.filter(e => e !== env));
                                      } else setSelectedEnvironments(prev => [...prev, env as Environment]);
                                    }}
                                    className={cn(
                                      "flex-1 py-1 px-1 rounded-none border text-[9px] font-black uppercase tracking-widest transition-all",
                                      selectedEnvironments.includes(env as Environment)
                                        ? "bg-primary/20 text-primary border-primary/30 shadow-inner"
                                        : "bg-white text-slate-400 border-slate-200 hover:bg-slate-50"
                                    )}
                                  >
                                    {env}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 px-0.5">Frequency</Label>
                          <Select value={batchFrequency} onValueChange={(val) => setBatchFrequency(val as BatchFrequency)}>
                            <SelectTrigger className="h-8 w-full bg-white border-slate-200 text-[11px] font-bold uppercase py-0 rounded-lg shadow-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-white border-slate-400 border text-[11px] font-bold">
                              <SelectItem value="Nightly (Once)">Nightly</SelectItem>
                              <SelectItem value="Intraday (Twice)">Intraday</SelectItem>
                              <SelectItem value="Hourly">Hourly</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-3">
                          {/* Batch Sources Row */}
                          <div className="grid grid-cols-3 gap-2">
                            <NumberInput label="JDBC Sources" icon={Database} value={directSourcesCount} onChange={setDirectSourcesCount} />
                            <NumberInput label="API / SaaS" icon={Share2} value={apiConnectionsCount} onChange={setApiConnectionsCount} />
                            <NumberInput label="Flat Files" icon={Files} value={flatFilesCount} onChange={setFlatFilesCount} />
                          </div>

                          {/* Bronze TB Row */}
                          <div className="grid grid-cols-1">
                            <NumberInput label="Total Bronze in TB" icon={HardDrive} value={bronzeSize} onChange={setBronzeSize} />
                          </div>

                          {/* Streaming Row */}
                          <div className="grid grid-cols-2 gap-3">
                            <NumberInput label="Streaming Srcs" icon={Wifi} value={streamingSourcesCount} onChange={setStreamingSourcesCount} />
                            <NumberInput label="Daily R/T Stream in MB" icon={Zap} value={streamingPayloadSize} onChange={setStreamingPayloadSize} />
                          </div>
                        </div>

                        {/* Platforms */}
                        <div className="space-y-2">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-0.5">Target Platforms</Label>
                          <div className="bg-white border border-slate-200 rounded-xl max-h-[130px] overflow-y-auto p-1.5 space-y-0.5 shadow-inner custom-scrollbar focus-within:border-primary/40 transition-all">
                            {['Databricks', 'Snowflake', 'Microsoft Fabric', 'AWS Native Data Services', 'GCP Data Services', 'Dremio', 'Starburst/Trino', 'ClickHouse Cloud', 'Firebolt', 'SingleStore', 'Cloudera Data Platform (CDP)', 'Oracle Autonomous Data Warehouse / HeatWave', 'SAP Datasphere + HANA Cloud', 'Tinybird', 'Open Lakehouse Stack (Iceberg, Spark, Trino, dbt, Airbyte, Dagster, Grafana)'].map((platform) => {
                              const isSelected = selectedPlatforms.includes(platform as LakehousePlatform);
                              return (
                                <div 
                                  key={platform} 
                                  className={cn(
                                    "flex items-center space-x-2 px-2 py-1.5 rounded-lg transition-colors cursor-pointer group/item",
                                    isSelected ? "bg-primary/5 text-primary" : "hover:bg-slate-50 text-slate-500 hover:text-slate-700"
                                  )}
                                  onClick={() => {
                                    if (isSelected) {
                                      if (selectedPlatforms.length > 1) setSelectedPlatforms(prev => prev.filter(p => p !== platform));
                                      else toast.error("Select at least one platform");
                                    } else setSelectedPlatforms(prev => [...prev, platform as LakehousePlatform]);
                                  }}
                                >
                                  <div className={cn(
                                    "w-3.5 h-3.5 rounded border flex items-center justify-center transition-all shrink-0",
                                    isSelected ? "bg-primary border-primary text-white" : "bg-white border-slate-300 group-hover/item:border-primary/30"
                                  )}>
                                    {isSelected && <Check size={10} strokeWidth={4} />}
                                  </div>
                                  <span className="text-[13px] truncate">{platform}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Components */}
                        <div className="space-y-2">
                          <div className="flex items-center justify-between px-0.5">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Core Components</Label>
                            <span className="text-[8px] font-bold text-slate-300 uppercase tracking-tighter">Multi-Select</span>
                          </div>
                          <div className="bg-white border border-slate-200 rounded-xl max-h-[150px] overflow-y-auto p-1.5 space-y-0.5 shadow-inner custom-scrollbar focus-within:border-primary/40 transition-all">
                            {MDP_COMPONENTS.map((comp) => {
                              const isMandatory = ['Delta Lake Storage', 'Multi-hop Architecture (Bronze, Silver, Gold)', 'Lakehouse (Delta Lake + Data Warehouse)'].includes(comp);
                              const isSelected = selectedComponents.includes(comp);
                              return (
                                <div 
                                  key={comp} 
                                  className={cn(
                                    "flex items-center space-x-2 px-2 py-1.5 rounded-lg transition-colors group/item relative overflow-hidden",
                                    isSelected ? "bg-primary/5 text-primary" : "hover:bg-slate-50 text-slate-500 hover:text-slate-700",
                                    isMandatory ? "cursor-default" : "cursor-pointer"
                                  )}
                                  onClick={() => {
                                    if (isMandatory) return;
                                    if (isSelected) {
                                      setSelectedComponents(prev => prev.filter(c => c !== comp));
                                    } else {
                                      setSelectedComponents(prev => [...prev, comp]);
                                    }
                                  }}
                                >
                                  <div className={cn(
                                    "w-3.5 h-3.5 rounded border flex items-center justify-center transition-all shrink-0",
                                    isSelected ? "bg-primary border-primary text-white" : "bg-white border-slate-300 group-hover/item:border-primary/30",
                                    isMandatory && "bg-slate-100 border-slate-200 text-slate-400"
                                  )}>
                                    {isSelected && <Check size={10} strokeWidth={4} />}
                                  </div>
                                  <span className="text-[13px] truncate pr-12">{comp}</span>
                                  {isMandatory && (
                                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[7px] font-black text-slate-300 uppercase tracking-widest bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">
                                      Required
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* BI Tool Selection (Conditional) */}
                        {selectedComponents.includes('BI Tool') && (
                          <div className="space-y-1.5 animate-in slide-in-from-top-2 duration-300 bg-slate-50 p-2.5 rounded-xl border border-slate-200 border-dashed">
                            <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 px-0.5">BI Tool</Label>
                            <Select value={biToolChoice} onValueChange={(val) => setBiToolChoice(val as any)}>
                              <SelectTrigger className="h-8 w-full bg-white border-slate-200 text-[13px] font-medium py-0 rounded-lg shadow-sm">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-slate-400 border text-[13px] font-medium">
                                <SelectItem value="Power BI Premium">Power BI Premium</SelectItem>
                                <SelectItem value="Power BI Pro (50 users)">Power BI Pro (50 users)</SelectItem>
                                <SelectItem value="Tableau (50 users)">Tableau (50 users)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        )}

                        <div className="space-y-2">
                           <Label htmlFor="specialInstructions" className="text-[10px] font-black uppercase tracking-widest text-slate-400">Special Instructions / Constraints</Label>
                           <Textarea 
                            id="specialInstructions"
                            placeholder="Add any specific assumptions, user groups, or legacy constraints..."
                            className="bg-white border-slate-200 text-xs font-medium min-h-[80px] rounded-xl focus:ring-primary/20"
                            value={specialInstructions}
                            onChange={(e) => setSpecialInstructions(e.target.value)}
                           />
                        </div>

                        <Button 
                          className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black uppercase tracking-[0.2em] text-[10px] h-12 shadow-xl rounded-xl transition-all active:scale-[0.98]"
                          onClick={handleGeneratePlatformEstimates}
                          disabled={loading}
                        >
                          {loading ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Calculator className="mr-2 h-4 w-4" />
                          )}
                          {loading ? "Generating Comparison..." : "Calculate Estimates"}
                        </Button>
                      </CardContent>
                    </motion.div>
                  )}
                </AnimatePresence>


              </Card>
            </TabsContent>

            <TabsContent value="bi-dashboards" className="mt-0 flex-1 flex flex-col min-h-0">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex-1 flex flex-col overflow-hidden rounded-lg min-h-0">
                <CardHeader className="py-2 bg-slate-50/50 border-b border-slate-200 px-4 shrink-0 flex flex-row items-center justify-between">
                  <div className="flex items-center gap-2 text-left">
                    <CardTitle className="text-xs font-black flex items-center gap-2 text-slate-900 uppercase tracking-widest">
                      <BarChart3 size={14} className="text-primary" />
                      Dashboard Ideation
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 p-3 overflow-y-auto no-scrollbar flex-none shrink-0">
                   {/* Use Cases Multi-select */}
                   <div className="space-y-2">
                     <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-1 block text-left">MDP Use Cases</Label>
                     <ScrollArea className="h-[140px] border border-slate-200 rounded-xl bg-white p-1">
                       <div className="space-y-1">
                         {companyProfile?.opportunities?.filter(o => o.selected).map(opp => (
                           <div 
                             key={opp.id}
                             onClick={() => {
                               if (selectedBDUseCases.includes(opp.id)) {
                                 setSelectedBDUseCases(prev => prev.filter(id => id !== opp.id));
                               } else {
                                 setSelectedBDUseCases(prev => [...prev, opp.id]);
                               }
                             }}
                             className={cn(
                               "flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all text-left",
                               selectedBDUseCases.includes(opp.id) ? "bg-primary/5 text-primary" : "text-slate-600 hover:bg-slate-50"
                             )}
                           >
                             <div className={cn(
                               "w-3.5 h-3.5 rounded border flex items-center justify-center transition-all shrink-0",
                               selectedBDUseCases.includes(opp.id) ? "bg-primary border-primary text-white" : "border-slate-300 bg-white"
                             )}>
                               {selectedBDUseCases.includes(opp.id) && <Check size={8} strokeWidth={4} />}
                             </div>
                             <span className="text-[10px] font-bold truncate leading-tight">{opp.title}</span>
                           </div>
                         ))}
                         {(companyProfile?.opportunities?.filter(o => o.selected).length ?? 0) === 0 && (
                           <div className="p-4 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest italic">
                             No selected opportunities found
                           </div>
                         )}
                       </div>
                     </ScrollArea>
                   </div>

                   {/* Num Dashboards Spinner */}
                   <div className="space-y-2">
                     <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-1 block text-left">Number of Dashboards</Label>
                     <div className="flex items-center gap-3">
                       <Button 
                         variant="outline" 
                         size="icon" 
                         className="h-8 w-8 rounded-lg border-slate-200 bg-white shadow-sm"
                         onClick={() => setNumDashboards(Math.max(1, numDashboards - 1))}
                       >
                         <Minus size={14} />
                       </Button>
                       <Input 
                         type="number" 
                         value={numDashboards}
                         onChange={(e) => {
                           const val = parseInt(e.target.value);
                           if (isNaN(val)) return;
                           setNumDashboards(val);
                         }}
                         onBlur={() => {
                           if (numDashboards < 1 || numDashboards > 12) {
                             setNumDashboards(5);
                           }
                         }}
                         className="h-8 text-center font-bold text-xs bg-white border-slate-200 w-full"
                       />
                       <Button 
                         variant="outline" 
                         size="icon" 
                         className="h-8 w-8 rounded-lg border-slate-200 bg-white shadow-sm"
                         onClick={() => setNumDashboards(Math.min(12, numDashboards + 1))}
                       >
                         <Plus size={14} />
                       </Button>
                     </div>
                   </div>

                   {/* Dashboard Theme */}
                   <div className="space-y-2">
                     <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-1 block text-left">Dashboard Theme</Label>
                     <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-white rounded-xl border border-slate-200 shadow-sm">
                       <Button 
                         variant={bdDashboardTheme === 'Surprise Me!' ? 'default' : 'ghost'}
                         size="sm"
                         onClick={() => setBdDashboardTheme('Surprise Me!')}
                         className={cn(
                           "h-7 text-[9px] font-black uppercase tracking-widest transition-all rounded-lg",
                           bdDashboardTheme === 'Surprise Me!' ? "bg-primary text-white" : "text-slate-500 hover:text-primary hover:bg-primary/5"
                         )}
                       >
                         Surprise Me!
                       </Button>
                       <Button 
                         variant={bdDashboardTheme === 'Custom' ? 'default' : 'ghost'}
                         size="sm"
                         onClick={() => setBdDashboardTheme('Custom')}
                         className={cn(
                           "h-7 text-[9px] font-black uppercase tracking-widest transition-all rounded-lg",
                           bdDashboardTheme === 'Custom' ? "bg-primary text-white" : "text-slate-500 hover:text-primary hover:bg-primary/5"
                         )}
                       >
                         Custom
                       </Button>
                     </div>
                   </div>

                   <AnimatePresence>
                     {bdDashboardTheme === 'Custom' && (
                       <motion.div 
                         initial={{ height: 0, opacity: 0 }}
                         animate={{ height: 'auto', opacity: 1 }}
                         exit={{ height: 0, opacity: 0 }}
                         className="space-y-2 overflow-hidden"
                       >
                         <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 px-1 block text-left">Dashboard Requirements</Label>
                         <Textarea 
                            placeholder="e.g. Focus on operational efficiency..." 
                            value={bdCustomDashboardDesc}
                            onChange={(e) => setBdCustomDashboardDesc(e.target.value)}
                            className="bg-white border-slate-200 text-xs font-medium min-h-[60px]"
                         />
                       </motion.div>
                     )}
                   </AnimatePresence>

                   <Button 
                     onClick={handleGenerateBDDashboards}
                     disabled={isGeneratingBDDashboards || selectedBDUseCases.length === 0}
                     className="w-full bg-primary text-white hover:bg-primary/90 h-10 rounded-xl shadow-lg shadow-primary/20 font-black uppercase tracking-widest text-[10px] gap-2 mt-2"
                   >
                     {isGeneratingBDDashboards ? <Loader2 className="animate-spin" size={14} /> : <Sparkles size={14} />}
                     Generate Dashboard Ideas
                   </Button>
                </CardContent>

                {/* BD Assets Outline */}
                <div className="flex-1 flex flex-col border-t border-slate-200 min-h-0 bg-white/50 backdrop-blur-sm">
                  <div className="px-4 py-2.5 flex items-center justify-between shrink-0">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2 text-left">
                      <FolderKanban size={12} className="text-primary" />
                      BD Assets
                    </h4>
                    {bdDashboards.length > 0 && (
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-6 w-6 text-slate-400 hover:text-red-500 rounded-lg"
                        onClick={handleDeleteAllBDDashboards}
                        title="Delete All Dashboards"
                      >
                        <Trash2 size={12} />
                      </Button>
                    )}
                  </div>
                  <ScrollArea className="flex-1 px-2 pb-4">
                    <div className="space-y-3 mt-1">
                      {companyProfile?.opportunities?.filter(o => o.selected && bdDashboards.some(d => d.useCaseId === o.id)).map(opp => {
                        const dashes = bdDashboards.filter(d => d.useCaseId === opp.id);
                        
                        return (
                          <div key={opp.id} className="space-y-1">
                            <div className="px-2 py-1 flex items-center justify-between group">
                              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 truncate flex-1 text-left">
                                {opp.title}
                              </span>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-5 w-5 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => handleDeleteBDDashboardsByUseCase(opp.id)}
                              >
                                <X size={10} />
                              </Button>
                            </div>
                            <div className="space-y-0.5 border-l-2 border-slate-100 ml-2.5 pl-1.5 flex flex-col">
                              {dashes.map(dash => (
                                <div 
                                  key={dash.id}
                                  onClick={() => setSelectedBDDashboardId(dash.id)}
                                  className={cn(
                                    "flex items-center justify-between group px-2 py-1.5 rounded-lg cursor-pointer transition-all text-left",
                                    selectedBDDashboardId === dash.id ? "bg-primary/10 text-primary shadow-sm" : "text-slate-600 hover:bg-slate-50"
                                  )}
                                >
                                  <span className="text-[10px] font-bold truncate flex-1 leading-tight">{dash.title}</span>
                                  <button 
                                    className="p-1 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleDeleteBDDashboard(dash.id);
                                    }}
                                  >
                                    <Trash2 size={10} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                      {bdDashboards.length === 0 && (
                        <div className="py-8 text-center px-4">
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-[0.15em] italic opacity-50 text-left">No dashboard assets generated</p>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="estimates-project" className="mt-0 h-full">
               <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Calculator size={18} className="text-primary" />
                    MDP Project Estimates
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-4">
                  <div className="text-center py-12 px-4 italic text-slate-400 text-xs font-medium">
                    Project estimation parameters and resource modeling coming soon.
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Project Manager Sidebar Controls */}
            <TabsContent value="transcript-library" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Speech size={18} className="text-primary" />
                    Meeting Ingestion
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Ingest project meeting transcripts to generate executive summaries, key decisions, and action items.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-4 flex-1 overflow-y-auto">
                  <div className="space-y-1.5">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Meeting Title</Label>
                    <Input 
                      placeholder="e.g. Sprint Planning & Architecture Sync" 
                      value={pmMeetingTitle}
                      onChange={(e) => setPmMeetingTitle(e.target.value)}
                      className="bg-white border-slate-200 text-xs font-medium"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1.5">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Meeting Date</Label>
                      <Input 
                        type="date"
                        value={pmMeetingDate}
                        onChange={(e) => setPmMeetingDate(e.target.value)}
                        className="bg-white border-slate-200 text-xs font-medium"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Attendees (Optional)</Label>
                      <Input 
                        placeholder="Auto-extracted from notes if empty" 
                        value={pmAttendeesInput}
                        onChange={(e) => setPmAttendeesInput(e.target.value)}
                        className="bg-white border-slate-200 text-xs font-medium placeholder:text-slate-400"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Transcript</Label>
                      <label className="text-[9px] font-black text-primary uppercase cursor-pointer hover:underline flex items-center gap-1">
                        <Upload size={10} />
                        Upload
                        <input 
                          type="file" 
                          accept=".txt,.doc,.docx,.pdf"
                          className="hidden" 
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              try {
                                const text = await readFileAsText(file);
                                setPmTranscriptText(text);
                                if (!pmMeetingTitle) setPmMeetingTitle(file.name.replace(/\.[^/.]+$/, ""));
                                toast.success(`Loaded ${file.name}`);
                              } catch (err) {
                                toast.error("Failed to read file");
                              }
                            }
                          }}
                        />
                      </label>
                    </div>
                    <Textarea 
                      placeholder="Paste meeting notes, transcript text, or upload a transcript file..."
                      value={pmTranscriptText}
                      onChange={(e) => setPmTranscriptText(e.target.value)}
                      className="bg-white border-slate-200 text-xs min-h-[120px] font-mono leading-relaxed"
                    />
                  </div>
                  <Button 
                    onClick={handleGeneratePMSummary}
                    disabled={isGeneratingPMSummary || !pmTranscriptText.trim()}
                    className="w-full bg-primary text-white hover:bg-primary/90 h-10 rounded-xl shadow-lg shadow-primary/20 font-black uppercase tracking-widest text-[10px] gap-2"
                  >
                    {isGeneratingPMSummary ? <Loader2 className="animate-spin" size={14} /> : <Sparkles size={14} />}
                    Generate Meeting Summary
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="meeting-summaries" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <FileText size={18} className="text-primary" />
                    Saved Meeting Summaries
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-3 flex-1 overflow-y-auto space-y-2">
                  {pmMeetingSummaries.filter(s => !s.projectId || s.projectId === currentProjectId).length === 0 ? (
                    <p className="text-xs text-slate-400 italic text-center py-8">No summaries generated yet.</p>
                  ) : (
                    pmMeetingSummaries.filter(s => !s.projectId || s.projectId === currentProjectId).map((s) => (
                      <div 
                        key={s.id}
                        onClick={() => setCurrentPMSummary(s)}
                        className={cn(
                          "p-3 rounded-xl border cursor-pointer transition-all flex flex-col gap-1 text-left",
                          currentPMSummary?.id === s.id ? "bg-primary/10 border-primary text-primary" : "bg-white border-slate-200 text-slate-700 hover:border-slate-300"
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs truncate max-w-[180px]">{s.title}</span>
                          <span className="text-[9px] text-slate-400 font-bold">{s.date}</span>
                        </div>
                        <p className="text-[10px] text-slate-500 line-clamp-2">{s.executiveSummary}</p>
                        <div className="flex items-center justify-between pt-1 text-[9px] font-bold text-slate-400">
                          <span>{s.actionItems?.length || 0} Action Items</span>
                          <span className="text-primary uppercase font-black">View Summary &rarr;</span>
                        </div>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="action-items" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <CheckSquare size={18} className="text-primary" />
                    Action Items Filter
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                  <div className="space-y-1.5">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Filter Status</Label>
                    <Select value={pmActionItemFilterStatus} onValueChange={(val: any) => setPmActionItemFilterStatus(val)}>
                      <SelectTrigger className="bg-white border-slate-200 text-xs font-bold">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white border-slate-300">
                        <SelectItem value="All">All Statuses</SelectItem>
                        <SelectItem value="Open">Open</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Search Tasks / Owners</Label>
                    <Input 
                      placeholder="Search action items..."
                      value={pmActionItemSearch}
                      onChange={(e) => setPmActionItemSearch(e.target.value)}
                      className="bg-white border-slate-200 text-xs"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pm-assistant" className="mt-0 h-full">
              <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col h-full overflow-hidden rounded-lg">
                <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 px-4 pt-4 shrink-0">
                  <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                    <Bot size={18} className="text-primary" />
                    AI Project Manager
                  </CardTitle>
                  <CardDescription className="text-slate-500 text-[12px] leading-relaxed">
                    Ask questions across all meeting summaries, track open items, decisions, and risks.
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4 space-y-3">
                  <p className="text-xs text-slate-600 leading-relaxed font-medium">
                    The PM Assistant uses your project's meeting summaries to answer questions, compile status reports, and identify risk patterns.
                  </p>
                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1 text-left">
                    <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Context Knowledge</span>
                    <p className="text-xs font-bold text-slate-800">
                      {pmMeetingSummaries.filter(s => !s.projectId || s.projectId === currentProjectId).length} Meeting Summaries Indexed
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </motion.div>
        </AnimatePresence>

        {/* History Section */}
          {persona !== 'data_analyst' && !(activeTab === 'opps' || activeTab === 'usecases' || activeTab === 'estimates-project' || activeTab === 'estimates-platform' || activeTab === 'bi-dashboards' || activeTab === 'platform-comparison') && (
            <Card className="shadow-sm border border-slate-300 overflow-hidden bg-slate-100 flex flex-col flex-1 h-full w-full rounded-lg">
              <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 shrink-0 px-4 pt-4">
                <div className="flex items-center justify-between mb-3">
                  <CardTitle className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                    <History size={14} className="text-primary" />
                    Project Assets
                  </CardTitle>
                  {(filteredHistory.length > 0 || filteredDashboards.length > 0) && currentProject?.name !== "Demo DW" && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        clearHistory();
                        setDashboards(prev => prev.filter(d => d.projectId !== currentProjectId));
                        setCurrentModel(null);
                        setCurrentDashboard(null);
                      }} 
                      className="h-7 px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 hover:text-red-600 hover:bg-red-50 relative z-20"
                    >
                      Clear All
                    </Button>
                  )}
                </div>
                <AssetCounts 
                  dims={availableDimensions.length}
                  facts={availableStarSchemas.length}
                  sttms={filteredSttmMappings.length}
                  dashboards={filteredDashboards.length}
                  variant="compact"
                />
              </CardHeader>
              <CardContent className="p-0 flex-1 overflow-auto">
                <div className="p-4 space-y-4">
                    {/* Dashboards Section */}
                    {filteredDashboards.length > 0 && (activeTab === 'dashboard' || activeTab === 'assets') && (
                      <div className="space-y-3">
                        <h3 className="text-[10px] font-black tracking-widest text-primary flex items-center gap-2">
                          <LayoutDashboard size={12} />
                          Dashboards
                        </h3>
                        <div className="space-y-2">
                          {filteredDashboards.map((dash) => (
                            <DashboardItem 
                              key={dash.id}
                              dash={dash}
                              isActive={currentDashboard?.id === dash.id}
                              onClick={() => {
                                setCurrentDashboard(dash);
                                setCurrentModel(null);
                                if (!['dimension', 'fact', 'dashboard', 'sttm', 'bi-dashboards'].includes(activeTab)) {
                                  setActiveTab('assets');
                                }
                              }}
                              onDelete={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setDashboards(prev => prev.filter(d => d.id !== dash.id));
                                if (currentDashboard?.id === dash.id) setCurrentDashboard(null);
                              }}
                              showDelete={currentProject?.name !== "Demo DW"}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                  {/* STTM Mappings Section */}
                  {filteredSttmMappings.length > 0 && (activeTab === 'sttm' || activeTab === 'assets') && (
                    <div className="space-y-3">
                      <h3 className="text-[10px] font-black tracking-widest text-emerald-600 flex items-center gap-2">
                        <ArrowRightLeft size={12} />
                        STTM Mappings
                      </h3>
                      <div className="space-y-2">
                        {filteredSttmMappings.map((mapping) => {
                          const targetTable = history.find(h => h.id === mapping.targetTableId || h.id === mapping.tableId);
                          if (!targetTable) return null;
                          return (
                            <STTMItem 
                              key={mapping.id}
                              mapping={mapping}
                              targetTable={targetTable}
                              sttmStatus={getSTTMStatus(targetTable)}
                              isActive={selectedSttmAssetId === targetTable.id}
                              onClick={() => {
                                setSelectedSttmAssetId(targetTable.id);
                                setCurrentModel(targetTable);
                                setCurrentDashboard(null);
                                if (!['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab)) {
                                  setActiveTab('assets');
                                }
                                setAssetSubTab('sttm');
                              }}
                              onDelete={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setSttmMappings(prev => prev.filter(m => m.id !== mapping.id));
                                toast.success(`Deleted STTM mapping for ${targetTable.tableName}`);
                              }}
                            />
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Facts Section */}
                  {availableStarSchemas.length > 0 && (activeTab === 'fact' || activeTab === 'assets') && (
                    <div className="space-y-3">
                      <h3 className="text-[10px] font-black tracking-widest text-primary flex items-center gap-2">
                        <Database size={12} />
                        Fact Tables
                      </h3>
                      <div className="space-y-2">
                        {availableStarSchemas.map((item) => (
                          <HistoryItem 
                            key={item.id}
                            item={{...item, sttmStatus: getSTTMStatus(item)}}
                            isActive={currentModel?.id === item.id && (activeTab === 'assets' || ['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab))}
                            isMapped={sttmMappings.some(m => m.targetTableId === item.id || m.tableId === item.id)}
                            onClick={() => {
                              setCurrentModel(item);
                              setCurrentDashboard(null);
                              if (!['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab)) {
                                setActiveTab('assets');
                              }
                              if (assetSubTab === 'sttm') setAssetSubTab('schema');
                            }}
                            onDelete={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              deleteFromHistory(item.id);
                            }}
                            onShowSTTM={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setSelectedSttmAssetId(item.id);
                              setCurrentModel(item);
                              setCurrentDashboard(null);
                              if (!['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab)) {
                                setActiveTab('assets');
                              }
                              setAssetSubTab('sttm');
                            }}
                            onDeleteSTTM={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setSttmMappings(prev => prev.filter(m => m.targetTableId !== item.id && m.tableId !== item.id));
                              toast.success(`Deleted STTM mapping for ${item.tableName}`);
                            }}
                            showDelete={currentProject?.name !== "Demo DW"}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Dimensions Section */}
                  {availableDimensions.length > 0 && (activeTab === 'dimension' || activeTab === 'assets') && (
                    <div className="space-y-3">
                      <h3 className="text-[10px] font-black tracking-widest text-blue-600 flex items-center gap-2">
                        <Layout size={12} />
                        Dimensions
                      </h3>
                      <div className="space-y-2">
                        {availableDimensions.map((item) => (
                          <HistoryItem 
                            key={item.id}
                            item={{...item, sttmStatus: getSTTMStatus(item)}}
                            isActive={currentModel?.id === item.id && (activeTab === 'assets' || ['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab))}
                            isMapped={sttmMappings.some(m => m.targetTableId === item.id || m.tableId === item.id)}
                            onClick={() => {
                              setCurrentModel(item);
                              setCurrentDashboard(null);
                              if (!['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab)) {
                                setActiveTab('assets');
                              }
                              if (assetSubTab === 'sttm') setAssetSubTab('schema');
                            }}
                            onDelete={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              deleteFromHistory(item.id);
                            }}
                            onShowSTTM={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setSelectedSttmAssetId(item.id);
                              setCurrentModel(item);
                              setCurrentDashboard(null);
                              if (!['dimension', 'fact', 'dashboard', 'sttm'].includes(activeTab)) {
                                setActiveTab('assets');
                              }
                              setAssetSubTab('sttm');
                            }}
                            onDeleteSTTM={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setSttmMappings(prev => prev.filter(m => m.targetTableId !== item.id && m.tableId !== item.id));
                              toast.success(`Deleted STTM mapping for ${item.tableName}`);
                            }}
                            showDelete={currentProject?.name !== "Demo DW"}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                    {filteredHistory.length === 0 && filteredDashboards.length === 0 && (
                      <div className="py-8 flex flex-col items-center justify-center text-slate-400 px-6 text-center">
                        <Search size={24} className="opacity-20 mb-2" />
                        <p className="text-[10px] font-medium italic">No assets generated yet.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
                
                {/* Sidebar Sticky Footer for Visual Guide */}
                <div className="p-4 border-t border-slate-200 bg-slate-100/80 backdrop-blur-sm shadow-[0_-4px_12px_rgba(0,0,0,0.02)]">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setIsDocumentationDialogOpen(true)}
                    className="w-full bg-slate-900 text-white hover:bg-slate-800 border-none rounded-[1.2rem] h-11 font-black uppercase tracking-[0.2em] text-[10.5px] transition-all hover:scale-[1.02] shadow-xl shadow-slate-900/20"
                  >
                    <BookOpen size={16} className="mr-2.5 text-primary" />
                    Open Visual Guide
                  </Button>
                </div>
              </Card>
            )}

          {persona === 'data_analyst' && (
            <Card className="shadow-sm border border-slate-300 bg-slate-100 flex flex-col w-full rounded-lg">
              <CardHeader className="pb-3 bg-slate-50/50 border-b border-slate-200 shrink-0 px-4 pt-4">
                <div className="flex items-center justify-between mb-3">
                  <CardTitle className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                    <History size={14} className="text-primary" />
                    Analyst Assets
                  </CardTitle>
                  {(activeTab === 'gap-registry' ? gapRegistryAssets : transcripts).filter(a => a.projectId === currentProjectId).length > 0 && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => {
                        if (activeTab === 'gap-registry') {
                          setGapRegistryAssets(prev => prev.filter(a => a.projectId !== currentProjectId));
                        } else {
                          setTranscripts(prev => prev.filter(a => a.projectId !== currentProjectId));
                        }
                      }} 
                      className="h-7 px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 hover:text-red-600 hover:bg-red-50 relative z-20"
                    >
                      Clear All
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="p-4 space-y-3">
                  {activeTab === 'gap-registry' ? (
                    <>
                      {gapRegistryAssets.filter(a => a.projectId === currentProjectId).length === 0 ? (
                        <div className="text-center py-12 px-6 space-y-3">
                          <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-400 mx-auto">
                            <FileBarChart size={20} />
                          </div>
                          <p className="text-slate-400 italic text-[10px] font-bold uppercase tracking-widest leading-relaxed">No registries saved for this project.</p>
                        </div>
                      ) : (
                        gapRegistryAssets.filter(a => a.projectId === currentProjectId).map((asset) => (
                          <div 
                            key={asset.id} 
                            className={cn(
                              "p-3 rounded-xl border transition-all cursor-pointer group shadow-sm hover:shadow-md",
                              "bg-white border-slate-200 hover:border-primary"
                            )}
                            onClick={() => {
                              setGapRegistryItems(asset.items);
                              // Ensure we don't propagate "Gap Registry" title as the company name
                              const cleanName = asset.companyName?.replace(/\s+Gap\s+Registry.*$/i, '').split(': ')[1] || asset.companyName?.replace(/\s+Gap\s+Registry.*$/i, '') || "";
                              setCompanyName(cleanName);
                              if (asset.industry) {
                                setIndustry(asset.industry);
                                setTranscriptIndustry(asset.industry);
                              }
                              setActiveTab('gap-registry');
                            }}
                          >
                            <div className="flex items-start justify-between">
                              <div className="space-y-1.5 overflow-hidden">
                                <p className="text-[11px] font-black text-slate-900 group-hover:text-primary transition-colors truncate uppercase tracking-tight">
                                  {asset.title || asset.companyName || "Untitled Registry"}
                                </p>
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className="text-[8px] font-black uppercase px-1.5 py-0 border-slate-200 text-slate-400 bg-slate-50">
                                    {asset.items.length} Items
                                  </Badge>
                                  {(asset as any).industry && (
                                    <Badge variant="outline" className="text-[8px] font-black uppercase px-1.5 py-0 border-slate-200 text-slate-400 bg-slate-50">
                                      {(asset as any).industry}
                                    </Badge>
                                  )}
                                  <span className="text-[8px] text-slate-400 font-black uppercase tracking-widest">
                                    {new Date(asset.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                                  <FileBarChart size={14} />
                                </div>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="w-8 h-8 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all pointer-events-auto"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setGapRegistryAssets(prev => prev.filter(a => a.id !== asset.id));
                                    toast.success("Asset deleted successfully.");
                                  }}
                                >
                                  <Trash2 size={14} />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </>
                  ) : (
                    <>
                      {transcripts.filter(t => t.projectId === currentProjectId).length === 0 ? (
                        <div className="text-center py-12 px-6 space-y-3">
                          <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-400 mx-auto">
                            <MessagesSquare size={20} />
                          </div>
                          <p className="text-slate-400 italic text-[10px] font-bold uppercase tracking-widest leading-relaxed">No transcripts saved for this project.</p>
                        </div>
                      ) : (
                        transcripts.filter(t => t.projectId === currentProjectId).map((transcript) => (
                          <div 
                            key={transcript.id} 
                            className={cn(
                              "p-3 rounded-xl border transition-all cursor-pointer group shadow-sm hover:shadow-md",
                              "bg-white border-slate-200 hover:border-primary",
                              currentTranscript?.id === transcript.id && "border-primary bg-primary/5 shadow-inner"
                            )}
                            onClick={() => {
                              setCurrentTranscript(transcript);
                              setActiveTab('transcripts');
                            }}
                          >
                            <div className="flex items-start justify-between">
                              <div className="space-y-1.5 overflow-hidden">
                                <p className="text-[11px] font-black text-slate-900 group-hover:text-primary transition-colors truncate uppercase tracking-tight">
                                  {transcript.name || "Untitled Transcript"}
                                </p>
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" className="text-[8px] font-black uppercase px-1.5 py-0 border-slate-200 text-slate-400 bg-slate-50">
                                    {transcript.segments.length} Segments
                                  </Badge>
                                  <span className="text-[8px] text-slate-400 font-black uppercase tracking-widest">
                                    {new Date(transcript.createdAt).toLocaleDateString()}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                                  <Speech size={14} />
                                </div>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="w-8 h-8 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all pointer-events-auto"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setTranscripts(prev => prev.filter(t => t.id !== transcript.id));
                                    if (currentTranscript?.id === transcript.id) setCurrentTranscript(null);
                                    toast.success("Transcript deleted successfully.");
                                  }}
                                >
                                  <Trash2 size={14} />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </ScrollArea>
    </motion.div>
  )}

        {/* Main Content Area */}
        <div className={cn(
          "transition-all duration-300 min-h-0 flex-1 flex flex-col",
          (isSidebarVisible && (activeTab !== 'bi-dashboards' || persona === 'bd') && activeTab !== 'estimates-project' && activeTab !== 'platform-comparison') ? "lg:col-span-9" : "lg:col-span-12"
        )}>
          <AnimatePresence mode="wait">
            {(currentModel || currentDashboard) && ['dimension', 'fact', 'dashboard', 'sttm', 'assets'].includes(activeTab) ? (
              <motion.div 
                key="assets-view-unified"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {currentDashboard ? (
                  <DashboardView 
                    dashboard={currentDashboard} 
                    filters={dashboardFilters}
                    setFilters={setDashboardFilters}
                    companyName={companyName}
                  />
                ) : (
                  <Tabs value={assetSubTab} onValueChange={setAssetSubTab} className="w-full">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <Badge className={cn(
                            "border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm",
                            currentModel?.tableType === 'Fact' 
                              ? "bg-primary text-white" 
                              : "bg-blue-600 text-white"
                          )}>
                            {currentModel?.tableType}
                          </Badge>
                          <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold text-[10px] uppercase tracking-widest px-3">
                            {currentModel?.modelComplexity}
                          </Badge>
                          <div className="h-4 w-px bg-slate-200" />
                          <span className="text-slate-400 font-bold text-[10px] uppercase tracking-widest flex items-center gap-1.5">
                            <Database size={12} />
                            {currentModel?.industry}
                          </span>
                        </div>
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight">
                          {currentModel?.tableName}
                        </h2>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <TabsList className="bg-slate-100 p-1 rounded-xl border border-slate-200">
                          <TabsTrigger value="schema" className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm">Schema</TabsTrigger>
                          <TabsTrigger value="star" className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm">Star Schema</TabsTrigger>
                          <TabsTrigger value="sttm" className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm">STTM Map</TabsTrigger>
                        </TabsList>
                      </div>
                    </div>

                    <TabsContent value="schema" className="space-y-8">
                      <Card className="shadow-sm border border-slate-300 rounded-lg overflow-hidden bg-white">
                        <CardHeader className="pb-4 border-b border-slate-100 bg-slate-50">
                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <CardTitle className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                                <Database size={12} className="text-primary" />
                                MODEL OVERVIEW
                              </CardTitle>
                              <CardDescription className="text-[10px] text-slate-500 font-medium">
                                Detailed technical specification for the {currentModel?.tableName} {currentModel?.tableType} table.
                              </CardDescription>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="bg-white border-slate-200 text-slate-500 font-mono text-[10px]">
                                {currentModel?.columns.length} Columns
                              </Badge>
                              
                              <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-md">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-9 rounded-lg text-primary font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-primary hover:text-white transition-all border border-slate-100"
                                  onClick={() => currentModel && copyTableToClipboard(currentModel)}
                                >
                                  <Copy size={14} />
                                  Copy Table
                                </Button>
                                <div className="w-px h-5 bg-slate-200 mx-1" />
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-9 rounded-lg text-emerald-600 font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-emerald-600 hover:text-white transition-all border border-slate-100"
                                  onClick={() => currentModel && exportToCSV(currentModel)}
                                >
                                  <FileText size={14} />
                                  CSV
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="p-0">
                          {currentModel?.tableType === 'Fact' && (
                            <div className="p-8 bg-slate-100 border-b border-slate-200">
                              <StarSchemaDiagram 
                                factTable={currentModel} 
                                dimensions={getRelatedDimensions(currentModel)} 
                                onTableClick={setSelectedStarTable}
                                selectedTableId={selectedStarTable?.id}
                              />
                            </div>
                          )}
                          
                          {selectedStarTable && selectedStarTable.id !== currentModel?.id && (
                            <div className="p-4 bg-primary/5 border-b border-primary/10 flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                               <div className="bg-primary text-white p-1.5 rounded-md">
                                 {selectedStarTable.tableType === 'Fact' ? <Layers size={14} /> : <Layout size={14} />}
                               </div>
                               <div>
                                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Viewing Schema: {selectedStarTable.tableType}</span>
                                 <h4 className="text-sm font-bold text-slate-900 uppercase">{selectedStarTable.tableName}</h4>
                               </div>
                               <Button 
                                 variant="ghost" 
                                 size="sm" 
                                 className="ml-auto text-[10px] font-bold uppercase tracking-widest"
                                 onClick={() => setSelectedStarTable(currentModel)}
                               >
                                 Back to {currentModel?.tableName}
                               </Button>
                            </div>
                          )}
                          
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader className="bg-slate-50 border-b border-slate-200">
                                <TableRow className="hover:bg-transparent border-slate-200">
                                  <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Column Name</TableHead>
                                  <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Display Name</TableHead>
                                  <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Datatype</TableHead>
                                  <TableHead className="w-[60px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Size</TableHead>
                                  <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">PK</TableHead>
                                  <TableHead className="w-[120px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">FK To</TableHead>
                                  <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">NULL?</TableHead>
                                  <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Description</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {((selectedStarTable || currentModel)?.columns || []).map((col, i) => (
                                  <TableRow 
                                    key={i} 
                                    className={cn(
                                      "border-slate-50 hover:bg-slate-50/50 transition-colors", 
                                      col.isPk && "bg-primary/5",
                                      col.columnName.startsWith('sys_') && "bg-slate-50"
                                    )}
                                  >
                                    <TableCell className={cn(
                                      "font-mono text-[10px] py-2 px-4", 
                                      col.isPk ? "text-primary font-bold" : col.columnName.startsWith('sys_') ? "text-slate-400" : "text-slate-600 font-medium"
                                    )}>{col.columnName}</TableCell>
                                    <TableCell className="text-slate-900 font-bold text-xs py-2">{col.businessName}</TableCell>
                                    <TableCell className="py-2"><Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-slate-500">{col.datatype}</Badge></TableCell>
                                    <TableCell className="py-2"><span className="text-[10px] text-slate-500 font-mono">{col.size}</span></TableCell>
                                    <TableCell className="text-center py-2">{col.isPk ? <Badge className="bg-primary text-white border-none text-[8px] font-black px-1.5 py-0">PK</Badge> : <span className="text-slate-300">—</span>}</TableCell>
                                    <TableCell className="py-2">{col.fkTo ? <div className="flex items-center gap-1.5 text-blue-600"><Link2 size={10} /><span className="text-[10px] font-bold font-mono">{col.fkTo}</span></div> : <span className="text-slate-300">—</span>}</TableCell>
                                    <TableCell className="text-center py-2"><span className="text-[9px] font-black uppercase tracking-widest text-slate-400">{col.isNullable ? 'YES' : 'NO'}</span></TableCell>
                                    <TableCell className="text-slate-500 text-[10px] leading-tight py-2 px-4 max-w-[300px]">{col.description}</TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>
                    
                    <TabsContent value="star">
                      <Card className="shadow-sm border border-slate-300 rounded-lg bg-white p-8 min-h-[600px] flex flex-col items-center overflow-auto">
                        {currentModel && currentModel.tableType === 'Fact' ? (
                          <>
                            <StarSchemaDiagram 
                              factTable={currentModel} 
                              dimensions={getRelatedDimensions(currentModel)} 
                              onTableClick={setSelectedStarTable}
                              selectedTableId={selectedStarTable?.id}
                            />
                            
                            {selectedStarTable && (
                              <div className="w-full mt-8 border-t border-slate-100 pt-8 animate-in fade-in slide-in-from-top-4">
                                <div className="flex items-center gap-3 mb-6">
                                  <div className={cn(
                                    "p-2 rounded-lg",
                                    selectedStarTable.tableType === 'Fact' ? "bg-slate-900 text-white" : "bg-slate-800 text-white"
                                  )}>
                                    {selectedStarTable.tableType === 'Fact' ? <Layers size={18} /> : <Layout size={18} />}
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                      Table Schema: {selectedStarTable.tableType}
                                    </span>
                                    <h4 className="text-xl font-black text-slate-900 tracking-tight uppercase">
                                      {selectedStarTable.tableName}
                                    </h4>
                                  </div>
                                </div>
                                <div className="overflow-x-auto rounded-xl border border-slate-200">
                                  <Table>
                                    <TableHeader className="bg-slate-50 border-b border-slate-200">
                                      <TableRow className="hover:bg-transparent border-slate-200">
                                        <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Column Name</TableHead>
                                        <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Display Name</TableHead>
                                        <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Datatype</TableHead>
                                        <TableHead className="w-[60px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Size</TableHead>
                                        <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">PK</TableHead>
                                        <TableHead className="w-[120px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">FK To</TableHead>
                                        <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Description</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {((selectedStarTable || currentModel)?.columns || []).map((col: ColumnDefinition, i: number) => (
                                        <TableRow 
                                          key={i} 
                                          className={cn(
                                            "border-slate-50 hover:bg-slate-50/50 transition-colors", 
                                            col.isPk && "bg-primary/5",
                                            col.columnName.startsWith('sys_') && "bg-slate-50"
                                          )}
                                        >
                                          <TableCell className={cn(
                                            "font-mono text-[10px] py-2 px-4", 
                                            col.isPk ? "text-primary font-bold" : col.columnName.startsWith('sys_') ? "text-slate-400" : "text-slate-600 font-medium"
                                          )}>{col.columnName}</TableCell>
                                          <TableCell className="text-slate-900 font-bold text-xs py-2">{col.businessName}</TableCell>
                                          <TableCell className="py-2"><Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-slate-500">{col.datatype}</Badge></TableCell>
                                          <TableCell className="py-2"><span className="text-[10px] text-slate-500 font-mono">{col.size}</span></TableCell>
                                          <TableCell className="text-center py-2">{col.isPk ? <Badge className="bg-primary text-white border-none text-[8px] font-black px-1.5 py-0">PK</Badge> : <span className="text-slate-300">—</span>}</TableCell>
                                          <TableCell className="py-2">{col.fkTo ? <div className="flex items-center gap-1.5 text-blue-600 font-bold font-mono text-[10px]"><Link2 size={10} />{col.fkTo}</div> : <span className="text-slate-300">—</span>}</TableCell>
                                          <TableCell className="text-slate-500 text-[10px] leading-tight py-2 px-4 whitespace-normal min-w-[200px]">{col.description}</TableCell>
                                        </TableRow>
                                      ))}
                                    </TableBody>
                                  </Table>
                                </div>
                              </div>
                            )}
                          </>
                        ) : (
                          <div className="flex flex-col items-center justify-center py-24 text-slate-300">
                            <Share2 size={48} className="opacity-20 mb-4" />
                            <p className="text-sm font-bold uppercase tracking-widest italic">Select a Fact table to view its Star Schema.</p>
                          </div>
                        )}
                      </Card>
                    </TabsContent>

                    <TabsContent value="sttm">
                      {sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id) ? (
                        <STTMView 
                          mapping={sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id)!}
                          targetTable={currentModel!}
                          viewMode={sttmViewMode}
                          onCopy={() => {
                            const mapping = sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id);
                            if (mapping && currentModel) copySTTMToClipboard(mapping, currentModel);
                          }}
                          onExportCSV={() => {
                            const mapping = sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id);
                            if (mapping && currentModel) exportSTTMToCSV(mapping, currentModel);
                          }}
                          onExportExcel={() => {
                            const mapping = sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id);
                            if (mapping && currentModel) exportSTTMToExcel(mapping, currentModel);
                          }}
                          onClearMapping={(colName) => handleClearMapping(currentModel!.id, colName)}
                          onDelete={() => {
                            setSttmMappings(prev => prev.filter(m => m.targetTableId !== currentModel?.id && m.tableId !== currentModel?.id));
                            toast.success(`Deleted STTM mapping for ${currentModel?.tableName}`);
                          }}
                        />
                      ) : (
                        <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-300 rounded-lg bg-white shadow-sm relative overflow-hidden">
                          <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                            <ArrowRightLeft size={48} className="text-primary/20" />
                          </div>
                          <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">No Mapping Generated</h3>
                          <p className="text-slate-500 max-w-md mx-auto leading-relaxed">Go to the STTM tab to generate a Source-to-Target mapping for {currentModel?.tableName}.</p>
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                )}
              </motion.div>
            ) : activeTab === 'assets-data-analyst' ? (
              <motion.div 
                key="assets-data-analyst-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-primary text-white border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                        Repository
                      </Badge>
                      <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold text-[10px] uppercase tracking-widest px-3">
                        Saved Registries
                      </Badge>
                    </div>
                    <h2 className="text-4xl font-black text-slate-900 tracking-tight uppercase">Data Analyst Assets</h2>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {gapRegistryAssets.filter(a => a.projectId === currentProjectId).map((asset) => (
                    <Card 
                      key={asset.id} 
                      className="group border border-slate-200 hover:border-primary transition-all cursor-pointer shadow-sm hover:shadow-xl rounded-2xl overflow-hidden bg-white"
                      onClick={() => {
                        setGapRegistryItems(asset.items);
                        // Improved cleanName logic to prevent "Gap Registry" being set as company name
                        const cleanName = asset.companyName?.replace(/\s+Gap\s+Registry.*$/i, '').split(': ')[1] || asset.companyName?.replace(/\s+Gap\s+Registry.*$/i, '') || "";
                        setCompanyName(cleanName);
                        setTranscriptCompanyName(cleanName);
                        if (currentProjectId) {
                          setProjects(prev => prev.map(p => 
                            p.id === currentProjectId ? { ...p, companyName: cleanName } : p
                          ));
                        }
                        setActiveTab('gap-registry');
                      }}
                    >
                      <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-primary border border-slate-100 group-hover:scale-110 transition-transform">
                            <FileBarChart size={24} />
                          </div>
                          <Badge variant="secondary" className="bg-emerald-50 text-emerald-600 font-black border-none px-2 py-0.5 text-[10px]">
                            {asset.items.length} ITEMS
                          </Badge>
                        </div>
                        <CardTitle className="text-lg font-bold text-slate-900 group-hover:text-primary transition-colors leading-tight">
                          {asset.companyName}
                        </CardTitle>
                        <CardDescription className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-2">
                          Generated on {new Date(asset.createdAt).toLocaleDateString()}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-6 pt-2">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                          <button 
                            className="flex items-center gap-1.5 hover:text-primary transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              setGapRegistryItems(asset.items);
                              const plainName = asset.companyName.split(': ')[1] || asset.companyName;
                              setCompanyName(plainName);
                              setTranscriptCompanyName(plainName);
                              if (currentProjectId) {
                                setProjects(prev => prev.map(p => 
                                  p.id === currentProjectId ? { ...p, companyName: plainName } : p
                                ));
                              }
                              setActiveTab('gap-registry');
                            }}
                          >
                            <span>View Details</span>
                            <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                          </button>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all shadow-none"
                            onClick={(e) => {
                              e.stopPropagation();
                              setGapRegistryAssets(prev => prev.filter(a => a.id !== asset.id));
                              toast.success("Asset deleted successfully");
                            }}
                          >
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {/* Platform Estimate Assets */}
                  {platformEstimateAssets.filter(a => a.projectId === currentProjectId).map((asset) => (
                    <Card 
                      key={asset.id} 
                      className="group border border-slate-200 hover:border-emerald-600 transition-all cursor-pointer shadow-sm hover:shadow-xl rounded-2xl overflow-hidden bg-white"
                      onClick={() => {
                        setPlatformEstimates(asset.results);
                        setActiveTab('estimates-platform');
                        setCompanyName(asset.companyName);
                        setIndustry(asset.industry);
                        // Repopulate inputs from asset
                        setSelectedPlatforms(asset.inputs.selectedPlatforms);
                        setDirectSourcesCount(asset.inputs.directSources);
                        setStreamingSourcesCount(asset.inputs.streamingSources);
                        setStreamingPayloadSize(asset.inputs.streamingPayloadMB);
                        setApiConnectionsCount(asset.inputs.apiConnections);
                        setFlatFilesCount(asset.inputs.flatFiles);
                        setBronzeSize(asset.inputs.bronzeSizeTB);
                        setPreferredCloud(asset.inputs.cloudProvider);
                        setBatchFrequency(asset.inputs.batchFrequency);
                        setSelectedEnvironments(asset.inputs.environments || ['DEV']);
                      }}
                    >
                      <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-emerald-600 border border-slate-100 group-hover:scale-110 transition-transform">
                            <Database size={24} />
                          </div>
                          <Badge variant="secondary" className="bg-emerald-50 text-emerald-600 font-black border-none px-2 py-0.5 text-[10px]">
                            {asset.results.length} PLATFORMS
                          </Badge>
                        </div>
                        <CardTitle className="text-lg font-bold text-slate-900 group-hover:text-emerald-600 transition-colors leading-tight">
                          MDP Platform Estimate
                        </CardTitle>
                        <CardDescription className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-2">
                          Created: {new Date(asset.createdAt).toLocaleDateString()}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-6 pt-2">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                          <button 
                            className="flex items-center gap-1.5 hover:text-emerald-600 transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              setPlatformEstimates(asset.results);
                              setActiveTab('estimates-platform');
                            }}
                          >
                            <span>Open Architecture</span>
                            <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                          </button>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all shadow-none"
                            onClick={(e) => {
                              e.stopPropagation();
                              setPlatformEstimateAssets(prev => prev.filter(p => p.id !== asset.id));
                              toast.success("Platform estimate removed from assets");
                            }}
                          >
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {/* Transcript Assets */}
                  {transcripts.filter(t => t.projectId === currentProjectId).map((transcript) => (
                    <Card 
                      key={transcript.id} 
                      className="group border border-slate-200 hover:border-blue-600 transition-all cursor-pointer shadow-sm hover:shadow-xl rounded-2xl overflow-hidden bg-white"
                      onClick={() => {
                        setCurrentTranscript(transcript);
                        setActiveTab('transcripts');
                        setTranscriptCompanyName(transcript.companyName);
                        setCompanyName(transcript.companyName);
                        setTranscriptIndustry(transcript.industry);
                        setIndustry(transcript.industry);
                        if (currentProjectId) {
                          setProjects(prev => prev.map(p => 
                            p.id === currentProjectId ? { ...p, companyName: transcript.companyName, industry: transcript.industry } : p
                          ));
                        }
                      }}
                    >
                      <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-blue-600 border border-slate-100 group-hover:scale-110 transition-transform">
                            <MessagesSquare size={24} />
                          </div>
                          <Badge variant="secondary" className="bg-blue-50 text-blue-600 font-black border-none px-2 py-0.5 text-[10px]">
                            {transcript.segments.length} SEGMENTS
                          </Badge>
                        </div>
                        <CardTitle className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-tight">
                          {transcript.name}
                        </CardTitle>
                        <CardDescription className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-2">
                          Meeting Date: {transcript.date}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-6 pt-2">
                        <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                          <button 
                            className="flex items-center gap-1.5 hover:text-blue-600 transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              setCurrentTranscript(transcript);
                              setActiveTab('transcripts');
                            }}
                          >
                            <span>Read Transcript</span>
                            <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
                          </button>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all shadow-none"
                            onClick={(e) => {
                              e.stopPropagation();
                              setTranscripts(prev => prev.filter(t => t.id !== transcript.id));
                              toast.success("Transcript removed from assets");
                            }}
                          >
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {gapRegistryAssets.filter(a => a.projectId === currentProjectId).length === 0 && 
                   transcripts.filter(t => t.projectId === currentProjectId).length === 0 && 
                   platformEstimateAssets.filter(a => a.projectId === currentProjectId).length === 0 && (
                    <div className="col-span-full py-24 flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
                      <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-slate-300 mb-6 shadow-sm border border-slate-100">
                        <FolderKanban size={40} className="opacity-40" />
                      </div>
                      <h3 className="text-xl font-black text-slate-900 mb-2 uppercase">{currentProject?.name || "Active Project"}</h3>
                      <h4 className="text-sm font-black text-slate-400 mb-4 uppercase">No Saved Assets</h4>
                      <p className="text-slate-500 max-w-md mx-auto text-sm font-medium leading-relaxed">Saved registries and transcripts will appear here once generated and saved to this project.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : !currentModel && !currentDashboard && !loading && !(activeTab === 'opps' || activeTab === 'usecases' || activeTab === 'estimates-project' || activeTab === 'estimates-platform' || activeTab === 'platform-comparison' || activeTab === 'gap-registry' || activeTab === 'assets-data-analyst' || activeTab === 'transcripts' || activeTab === 'bi-dashboards') ? (
              <motion.div 
                key="welcome-screen"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-300 rounded-lg bg-white shadow-sm relative overflow-hidden"
              >
                <div className="relative z-10">
                  <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                    <Building2 size={48} className="text-primary/20" />
                  </div>
                  <h3 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">
                    {currentProject?.name || "Ready to Architect"}
                  </h3>
                  <p className="text-slate-500 max-w-md mx-auto leading-relaxed text-lg mb-10">
                    Start by modeling your <span className="text-primary font-bold">Dimensions</span>, then link them to <span className="text-blue-600 font-bold">Fact</span> tables. Finally, simulate a <span className="text-primary font-bold">Dashboard</span> to see your data in action.
                  </p>
                  
                  <div className="max-w-2xl mx-auto">
                    <AssetCounts 
                      dims={availableDimensions.length}
                      facts={filteredHistory.filter(h => h.tableType === 'Fact').length}
                      sttms={filteredSttmMappings.length}
                      dashboards={filteredDashboards.length}
                    />
                  </div>
                </div>
              </motion.div>
            ) : loading ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 bg-white rounded-lg border border-slate-300 shadow-sm relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-primary animate-pulse" />
                
                {activeTab === 'gap-registry' ? (
                  <div className="flex flex-col items-center justify-center py-20 space-y-10 animate-in fade-in zoom-in duration-700">
                    <div className="relative w-40 h-40">
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
                        className="absolute inset-0 rounded-full border-2 border-dashed border-slate-200"
                      />
                      <motion.div 
                        animate={{ rotate: -360 }}
                        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                        className="absolute inset-2 rounded-full border-4 border-slate-100 border-t-primary"
                      />
                      <div className="absolute inset-8 rounded-[2.5rem] bg-white flex items-center justify-center border border-slate-100 shadow-2xl z-10">
                        <FileBarChart className="text-primary animate-pulse" size={48} />
                      </div>
                    </div>

                    <div className="text-center space-y-4 max-w-sm">
                      <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase leading-none">Compiling Strategic Gaps</h3>
                      <div className="h-6 flex items-center justify-center overflow-hidden">
                        <motion.p 
                          key={gapRegistryProgress.current}
                          initial={{ y: 20, opacity: 0 }}
                          animate={{ y: 0, opacity: 1 }}
                          exit={{ y: -20, opacity: 0 }}
                          className="text-primary text-[10px] font-black uppercase tracking-[0.2em]"
                        >
                          {gapRegistryProgress.total > 1 
                            ? `Section ${gapRegistryProgress.current} / ${gapRegistryProgress.total}` 
                            : 'Analyzing Transcript...'}
                        </motion.p>
                      </div>
                    </div>
                  </div>
                ) : (activeTab === 'opps' || activeTab === 'usecases') ? (
                  <MonocleLoading />
                ) : (activeTab === 'estimates-platform' && isGeneratingEstimates) ? (
                  <ArchitectureSynthesisLoading />
                ) : activeTab === 'transcripts' ? (
                  <div className="flex flex-col items-center">
                    <div className="relative mb-10 h-32 w-32 flex items-center justify-center bg-slate-100 rounded-full border border-slate-200 shadow-sm">
                      <div className="absolute inset-0 bg-primary/5 rounded-full animate-pulse" />
                      <div className="relative z-10 flex items-center gap-6">
                        <motion.div
                          animate={{ x: [0, 8, 0], scale: [1, 1.1, 1], rotate: [0, 5, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity, ease: "easeInOut" }}
                        >
                          <User size={48} className="text-slate-400" />
                        </motion.div>
                        <div className="flex flex-col gap-1 items-center">
                          <motion.div animate={{ opacity: [0.2, 1, 0.2], scale: [0.8, 1.2, 0.8] }} transition={{ duration: 1, repeat: Infinity }}>
                             <MessageSquare size={24} className="text-primary" />
                          </motion.div>
                          {transcriptProgress.total > 1 && (
                            <span className="text-[11px] font-black text-primary animate-pulse tracking-tighter">
                              {transcriptProgress.current}/{transcriptProgress.total}
                            </span>
                          )}
                        </div>
                        <motion.div
                          animate={{ x: [0, -8, 0], scale: [1, 1.1, 1], rotate: [0, -5, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.3, ease: "easeInOut" }}
                        >
                          <User size={48} className="text-slate-400 scale-x-[-1]" />
                        </motion.div>
                      </div>
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">
                      {transcriptProgress.total > 1 ? `Processing Block ${transcriptProgress.current} of ${transcriptProgress.total}...` : 'Processing Transcript...'}
                    </h3>
                  </div>
                ) : (
                  <>
                    <div className="relative mb-10">
                      <div className="relative w-32 h-32 bg-slate-100 rounded-full flex items-center justify-center text-primary shadow-lg border border-slate-300 overflow-hidden">
                        <motion.div
                          animate={{
                            x: [0, 5, -5, 0],
                            y: [0, -2, 2, 0],
                          }}
                          transition={{
                            duration: 3,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className="relative"
                        >
                          <Layout size={64} className="text-slate-200" />
                          <motion.div
                            animate={{
                              x: [10, 50, 50, 10, 10],
                              y: [10, 10, 50, 50, 10],
                              rotate: [0, 15, 0, -15, 0]
                            }}
                            transition={{
                              duration: 4,
                              repeat: Infinity,
                              ease: "linear"
                            }}
                            className="absolute top-0 left-0"
                          >
                            <PenTool size={32} className="text-primary" />
                          </motion.div>
                        </motion.div>
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">
                    {activeTab === 'dashboard' ? 'Creating Dashboard...' : 
                     activeTab === 'sttm' ? 'Generating Mapping...' : 
                     'Architecting Model...'}
                    </h3>
                  </>
                )}
                
                <div className="flex flex-col items-center gap-4 mb-8">
                  <div className="flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full border border-slate-200">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">
                      Elapsed Time: {Math.floor(elapsedTime / 60)}:{(elapsedTime % 60).toString().padStart(2, '0')}
                    </span>
                  </div>
                </div>

                <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
                  {activeTab === 'dashboard'
                    ? `Gemini is analyzing the ${selectedStarSchemaId ? availableStarSchemas.find(s => s.id === selectedStarSchemaId)?.tableName : 'selected'} schema to generate optimal visualizations and KPIs.`
                    : activeTab === 'sttm'
                    ? `Gemini is analyzing the target table schema and source definitions to generate a comprehensive Source-to-Target mapping.`
                    : activeTab === 'gap-registry'
                    ? (gapRegistryProgress.total > 1 
                      ? `Processing block ${gapRegistryProgress.current} of ${gapRegistryProgress.total}. Large transcripts are analyzed in sections to ensure lightning-fast extraction and accuracy.` 
                      : `Gemini is performing a deep semantic analysis of the provided transcripts to identify pain points, technical gaps, and MDP strategic opportunities for ${companyName}.`)
                    : activeTab === 'transcripts'
                    ? `Processing meeting recording text into a structured, searchable transcript with speaker identification and segment tracking.`
                    : (activeTab === 'opps' || activeTab === 'usecases')
                    ? `Gemini is researching ${companyName}'s market position and industry trends to identify high-impact MDP business cases.`
                    : `Gemini is researching ${companyName} and analyzing industry best practices to build a robust ${activeTab} schema.`}
                </p>

                {elapsedTime > 60 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 p-4 bg-amber-50 border border-amber-100 rounded-2xl max-w-sm mx-auto shadow-sm"
                  >
                    <div className="flex items-center gap-3 text-amber-700">
                      <div className="shrink-0 w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                        <Loader2 className="w-4 h-4 animate-spin" />
                      </div>
                      <div className="text-left">
                        <p className="text-[11px] font-black uppercase tracking-widest leading-none mb-1 text-amber-800">Deep Analysis in Progress</p>
                        <p className="text-[10px] font-bold opacity-80 leading-snug">
                          The search is taking longer than usual due to limited public information for {companyName}. Gemini is exploring alternative sources and correlating industry benchmarks to ensure a robust strategy.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ) : activeTab === 'transcript-library' ? (
              <motion.div 
                key="transcript-library-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8 flex-1 min-h-[calc(100vh-12rem)]"
              >
                {/* Workbench Header */}
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-primary text-white border-none px-3 py-1 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                        Project Manager
                      </Badge>
                      <Badge variant="outline" className="border-slate-200 text-slate-500 font-bold text-[10px] uppercase tracking-widest px-3">
                        Main Workbench
                      </Badge>
                    </div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Transcript Library & PM Workbench</h2>
                    <p className="text-slate-500 text-sm font-medium">
                      Ingest raw meeting transcripts with metadata, generate structured summaries, perform human-in-the-loop clarifications, track action items, and consult the AI PM Assistant.
                    </p>
                  </div>
                  {currentPMSummary && (
                    <div className="flex items-center gap-2 shrink-0">
                      <Button 
                        variant="default" 
                        size="sm"
                        onClick={() => document.getElementById('active-summary-workbench')?.scrollIntoView({ behavior: 'smooth' })}
                        className="bg-primary text-white font-bold text-xs hover:bg-primary/90 rounded-xl shadow-sm gap-1.5"
                      >
                        View Active Summary Below ↓
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setCurrentPMSummary(null)}
                        className="bg-slate-50 border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-100 rounded-xl"
                      >
                        + Ingest Another Transcript
                      </Button>
                    </div>
                  )}
                </div>

                {/* Top Section: Ingestion Form & Saved Summaries List */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Left panel: Transcript Input form (Sleek Banner) */}
                  <Card className="lg:col-span-4 shadow-sm border border-slate-200 bg-white rounded-2xl overflow-hidden">
                    <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-5">
                      <CardTitle className="text-sm font-bold flex items-center gap-2 text-slate-900">
                        <MessagesSquare className="text-primary" size={18} />
                        Ingest Meeting Transcript
                      </CardTitle>
                      <CardDescription className="text-xs text-slate-500">
                        Input meeting notes & metadata to generate structured AI summaries
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-5 space-y-3.5">
                      <div className="space-y-3">
                        <div className="space-y-1">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Meeting Title</Label>
                          <Input 
                            placeholder="e.g. Sprint Planning & Architecture" 
                            value={pmMeetingTitle}
                            onChange={(e) => setPmMeetingTitle(e.target.value)}
                            className="bg-slate-50 border-slate-200 text-xs font-medium h-10 rounded-xl"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Date Held</Label>
                            <Input 
                              type="date"
                              value={pmMeetingDate}
                              onChange={(e) => setPmMeetingDate(e.target.value)}
                              className="bg-slate-50 border-slate-200 text-xs font-medium h-10 rounded-xl"
                            />
                          </div>

                          <div className="space-y-1">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Meeting Time</Label>
                            <Input 
                              placeholder="10:00 AM" 
                              value={pmMeetingTime}
                              onChange={(e) => setPmMeetingTime(e.target.value)}
                              className="bg-slate-50 border-slate-200 text-xs font-medium h-10 rounded-xl placeholder:text-slate-400"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Attendees</Label>
                          <Input 
                            placeholder="e.g. Sarah Jenkins, Mark Miller" 
                            value={pmAttendeesInput}
                            onChange={(e) => setPmAttendeesInput(e.target.value)}
                            className="bg-slate-50 border-slate-200 text-xs font-medium h-10 rounded-xl placeholder:text-slate-400"
                          />
                        </div>

                        <div className="space-y-1">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Next Sync Date/Time</Label>
                          <Input 
                            placeholder="e.g. 2026-08-01 at 10:00 AM" 
                            value={pmNextMeetingDateTime}
                            onChange={(e) => setPmNextMeetingDateTime(e.target.value)}
                            className="bg-slate-50 border-slate-200 text-xs font-medium h-10 rounded-xl placeholder:text-slate-400"
                          />
                        </div>

                        <div className="space-y-1">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Meeting Objective</Label>
                          <Input 
                            placeholder="e.g. Align on MDP architecture migration" 
                            value={pmMeetingObjective}
                            onChange={(e) => setPmMeetingObjective(e.target.value)}
                            className="bg-slate-50 border-slate-200 text-xs font-medium h-10 rounded-xl placeholder:text-slate-400"
                          />
                        </div>
                      </div>

                      <div className="p-3 bg-indigo-50/80 border border-indigo-100 rounded-xl text-xs font-medium text-indigo-900 flex items-start gap-2">
                        <Sparkles className="text-indigo-600 shrink-0 mt-0.5" size={14} />
                        <div>
                          <p className="font-bold text-indigo-950 text-[11px]">Human-In-The-Loop AI Summary</p>
                          <p className="text-[10px] text-indigo-700 leading-relaxed mt-0.5">
                            Auto-extracts executive decisions, speaker action items, and next meeting schedules.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Raw Transcript / Notes</Label>
                          <label className="text-[10px] font-black text-primary uppercase cursor-pointer hover:underline flex items-center gap-1 bg-primary/5 px-2 py-0.5 rounded border border-primary/20">
                            <Upload size={10} />
                            Upload (.txt, .docx)
                            <input 
                              type="file" 
                              accept=".txt,.doc,.docx,.pdf"
                              className="hidden" 
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  try {
                                    const text = await readFileAsText(file);
                                    setPmTranscriptText(text);
                                    if (!pmMeetingTitle) setPmMeetingTitle(file.name.replace(/\.[^/.]+$/, ""));
                                    toast.success(`Loaded ${file.name}`);
                                  } catch (err) {
                                    toast.error("Failed to read file");
                                  }
                                }
                              }}
                            />
                          </label>
                        </div>
                        <Textarea 
                          placeholder="Paste meeting transcript or raw notes here..."
                          value={pmTranscriptText}
                          onChange={(e) => setPmTranscriptText(e.target.value)}
                          className="bg-slate-50 border-slate-200 text-xs font-mono min-h-[160px] rounded-xl leading-relaxed p-3"
                        />
                      </div>

                      <Button 
                        onClick={handleGeneratePMSummary}
                        disabled={isGeneratingPMSummary || !pmTranscriptText.trim()}
                        className="w-full bg-primary text-white hover:bg-primary/90 h-11 rounded-xl shadow-md shadow-primary/20 font-black uppercase tracking-widest text-xs gap-2"
                      >
                        {isGeneratingPMSummary ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}
                        {isGeneratingPMSummary ? "Synthesizing Summary..." : "Generate & Save Summary"}
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Right panel: Repository of Previous Meetings */}
                  <Card className="lg:col-span-8 shadow-sm border border-slate-200 bg-white rounded-2xl overflow-hidden flex flex-col min-h-[600px] h-full">
                    <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-5 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-900">
                            <FileText className="text-primary" size={20} />
                            Repository of Previous Meetings
                          </CardTitle>
                          <CardDescription className="text-xs text-slate-500">
                            Search historical meetings, filter action items by owner, due dates, or status
                          </CardDescription>
                        </div>
                        <Badge variant="outline" className="text-xs font-bold text-slate-700 bg-slate-100 self-start sm:self-auto">
                          Showing {filteredRepoSummaries.length} of {pmMeetingSummaries.filter(s => !s.projectId || s.projectId === currentProjectId).length} Saved
                        </Badge>
                      </div>

                      {/* Filters Bar */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2 bg-slate-100/70 p-2.5 rounded-xl border border-slate-200/80">
                        {/* Search Input */}
                        <div className="relative">
                          <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
                          <Input 
                            placeholder="Search topics, decisions..." 
                            value={repoSearchQuery}
                            onChange={(e) => setRepoSearchQuery(e.target.value)}
                            className="bg-white border-slate-200 text-xs pl-8 h-8 rounded-lg"
                          />
                        </div>

                        {/* Owner Filter */}
                        <div className="relative">
                          <select 
                            value={repoOwnerFilter}
                            onChange={(e) => setRepoOwnerFilter(e.target.value)}
                            className="w-full bg-white border border-slate-200 text-xs font-bold text-slate-700 h-8 rounded-lg px-2.5 outline-none cursor-pointer"
                          >
                            <option value="All Owners">All Owners / Attendees</option>
                            {allActionItemOwners.map(owner => (
                              <option key={owner} value={owner}>👤 {owner}</option>
                            ))}
                          </select>
                        </div>

                        {/* Due Date / Timeline Filter */}
                        <div className="relative">
                          <select 
                            value={repoDueDateFilter}
                            onChange={(e) => setRepoDueDateFilter(e.target.value)}
                            className="w-full bg-white border border-slate-200 text-xs font-bold text-slate-700 h-8 rounded-lg px-2.5 outline-none cursor-pointer"
                          >
                            <option value="All Dates">All Timelines</option>
                            <option value="Due Soon / Pending Tasks">Pending Action Items</option>
                            <option value="Has Next Sync">Has Next Meeting Set</option>
                          </select>
                        </div>

                        {/* Verification Status Filter */}
                        <div className="relative">
                          <select 
                            value={repoStatusFilter}
                            onChange={(e) => setRepoStatusFilter(e.target.value)}
                            className="w-full bg-white border border-slate-200 text-xs font-bold text-slate-700 h-8 rounded-lg px-2.5 outline-none cursor-pointer"
                          >
                            <option value="All Statuses">All Verification Statuses</option>
                            <option value="Human Verified">Human Verified</option>
                            <option value="Needs Review">Needs Review</option>
                          </select>
                        </div>
                      </div>

                      {(repoSearchQuery || repoOwnerFilter !== "All Owners" || repoDueDateFilter !== "All Dates" || repoStatusFilter !== "All Statuses") && (
                        <div className="flex items-center justify-between pt-0.5">
                          <span className="text-[11px] font-bold text-slate-500">
                            Active filters applied
                          </span>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setRepoSearchQuery("");
                              setRepoOwnerFilter("All Owners");
                              setRepoDueDateFilter("All Dates");
                              setRepoStatusFilter("All Statuses");
                            }}
                            className="text-xs text-primary font-bold h-6 px-2 hover:bg-primary/5 rounded-md"
                          >
                            Reset Filters ✕
                          </Button>
                        </div>
                      )}
                    </CardHeader>

                    <CardContent className="p-4 flex-1 overflow-y-auto space-y-3.5">
                      {filteredRepoSummaries.length === 0 ? (
                        <div className="text-center py-20 px-4 space-y-3">
                          <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                            <FileText size={24} />
                          </div>
                          <p className="text-slate-500 italic text-xs font-bold uppercase tracking-widest">No meeting transcripts found matching filters.</p>
                          <p className="text-slate-400 text-xs">Try adjusting your search keywords, owner dropdown, or timeline filters.</p>
                          {(repoSearchQuery || repoOwnerFilter !== "All Owners" || repoDueDateFilter !== "All Dates" || repoStatusFilter !== "All Statuses") && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setRepoSearchQuery("");
                                setRepoOwnerFilter("All Owners");
                                setRepoDueDateFilter("All Dates");
                                setRepoStatusFilter("All Statuses");
                              }}
                              className="bg-white border-slate-200 text-xs font-bold text-slate-700 rounded-xl"
                            >
                              Reset All Filters
                            </Button>
                          )}
                        </div>
                      ) : (
                        filteredRepoSummaries.map((s) => (
                          <div 
                            key={s.id}
                            className={cn(
                              "p-4 rounded-xl border transition-all cursor-pointer group hover:shadow-md flex flex-col gap-3 relative",
                              currentPMSummary?.id === s.id ? "bg-primary/5 border-primary ring-2 ring-primary/20 shadow-sm" : "bg-slate-50/50 border-slate-200 hover:border-slate-300"
                            )}
                            onClick={() => {
                              setCurrentPMSummary(s);
                              setTimeout(() => {
                                document.getElementById('active-summary-workbench')?.scrollIntoView({ behavior: 'smooth' });
                              }, 100);
                            }}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap">
                                  {s.isHumanConfirmed ? (
                                    <Badge className="bg-emerald-600 text-white border-none text-[9px] font-bold uppercase px-2 py-0">
                                      Human Verified
                                    </Badge>
                                  ) : (
                                    <Badge variant="outline" className="text-amber-700 bg-amber-50 border-amber-200 text-[9px] font-bold uppercase px-2 py-0">
                                      Needs Review
                                    </Badge>
                                  )}
                                  {s.meetingTime && (
                                    <span className="text-[10px] text-slate-400 font-mono font-bold flex items-center gap-1">
                                      <Clock size={10} />
                                      {s.meetingTime}
                                    </span>
                                  )}
                                  {(s.nextMeeting || s.nextMeetingDate) && (
                                    <Badge variant="outline" className="text-indigo-700 bg-indigo-50 border-indigo-200 text-[9px] font-bold uppercase px-2 py-0 flex items-center gap-1">
                                      <Calendar size={10} />
                                      Next Sync: {s.nextMeeting || s.nextMeetingDate}
                                    </Badge>
                                  )}
                                </div>
                                <h4 className="font-bold text-base text-slate-900 group-hover:text-primary transition-colors">{s.title || s.meetingTitle || 'Meeting Summary'}</h4>
                                <div className="flex items-center gap-4 text-[11px] text-slate-500 font-bold">
                                  <span className="flex items-center gap-1">
                                    <Calendar size={12} className="text-slate-400" />
                                    {s.date || s.meetingDate || 'N/A'}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <Users size={12} className="text-slate-400" />
                                    {(s.attendees || []).length} Attendees
                                  </span>
                                </div>
                              </div>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeletePMSummary(s.id);
                                }}
                              >
                                <Trash2 size={13} />
                              </Button>
                            </div>

                            <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{s.executiveSummary}</p>

                            {/* Attendees Pills */}
                            {(s.attendees || []).length > 0 && (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Attendees:</span>
                                {s.attendees.map((att, idx) => (
                                  <span 
                                    key={idx} 
                                    className={cn(
                                      "text-[10px] font-bold px-2 py-0.5 rounded-md border",
                                      repoOwnerFilter !== "All Owners" && att.toLowerCase().includes(repoOwnerFilter.toLowerCase())
                                        ? "bg-primary/10 border-primary text-primary font-black"
                                        : "bg-white border-slate-200 text-slate-600"
                                    )}
                                  >
                                    {att}
                                  </span>
                                ))}
                              </div>
                            )}

                            {/* Action Items Quick Preview */}
                            {(s.actionItems || []).length > 0 && (
                              <div className="bg-slate-100/70 p-2.5 rounded-xl border border-slate-200/60 space-y-1.5">
                                <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-slate-500">
                                  <span>Action Items ({s.actionItems.length})</span>
                                  <span>Due Date & Owner</span>
                                </div>
                                <div className="space-y-1">
                                  {s.actionItems.slice(0, 3).map((ai, aiIdx) => (
                                    <div 
                                      key={aiIdx} 
                                      className={cn(
                                        "text-xs p-1.5 rounded-lg flex items-center justify-between gap-2 border",
                                        repoOwnerFilter !== "All Owners" && ai.owner.toLowerCase().includes(repoOwnerFilter.toLowerCase())
                                          ? "bg-amber-50 border-amber-300 text-amber-900 font-medium"
                                          : "bg-white border-slate-200/80 text-slate-700"
                                      )}
                                    >
                                      <span className="truncate max-w-[280px] font-medium">{ai.description}</span>
                                      <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-bold">
                                        <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">👤 {ai.owner || 'Unassigned'}</span>
                                        <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">📅 {ai.dueDate || 'TBD'}</span>
                                      </div>
                                    </div>
                                  ))}
                                  {s.actionItems.length > 3 && (
                                    <p className="text-[10px] font-bold text-slate-400 italic text-right">+ {s.actionItems.length - 3} more action items</p>
                                  )}
                                </div>
                              </div>
                            )}

                            <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-[10px] font-bold">
                              <span className="text-slate-500">{(s.keyDecisions || s.keyItems || []).length} Decisions Recorded</span>
                              <span className="text-primary uppercase font-black tracking-wider flex items-center gap-1">
                                {currentPMSummary?.id === s.id ? "Active in Workbench ✓" : "Inspect Meeting in Workbench &rarr;"}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Bottom Section: Active Summary Workbench (Human-in-the-Loop, Decisions, Tasks & PM Assistant) */}
                <div id="active-summary-workbench" className="space-y-6 pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
                        <FolderKanban className="text-primary" size={20} />
                        Active Meeting Workbench & Assistant
                      </h3>
                      <p className="text-xs text-slate-500 font-medium">
                        {currentPMSummary 
                          ? `Viewing detail and managing human verification for "${currentPMSummary.title || currentPMSummary.meetingTitle}"` 
                          : "Select a meeting summary from above to inspect details, clarify next steps, manage tasks, and chat with the PM Assistant."}
                      </p>
                    </div>
                  </div>

                  {!currentPMSummary ? (
                    <div className="h-64 flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50/50 space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-primary border border-slate-100">
                        <FileText size={24} />
                      </div>
                      <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">No Meeting Summary Selected</h4>
                      <p className="text-slate-500 text-xs font-medium max-w-md">
                        Click on any saved meeting summary card above, or generate a new summary to activate this workbench.
                      </p>
                    </div>
                  ) : (
                    <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl overflow-hidden space-y-6 p-6">
                      {/* Active Summary Header */}
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                        <div className="space-y-1">
                          <div className="flex items-center gap-3 flex-wrap">
                            <Badge className="bg-primary text-white border-none px-3 py-1 text-[10px] font-black uppercase tracking-[0.2em]">
                              Active Summary Detail
                            </Badge>
                            {currentPMSummary.isHumanConfirmed ? (
                              <Badge className="bg-emerald-600 text-white border-none px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                                <CheckCircle2 size={11} />
                                Human Verified
                              </Badge>
                            ) : (
                              <Badge className="bg-amber-500 text-white border-none px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                                Verification Needed
                              </Badge>
                            )}
                            <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
                              <Calendar size={12} className="text-primary" />
                              Held: {currentPMSummary.date || currentPMSummary.meetingDate || 'N/A'}
                            </span>
                            {(currentPMSummary.nextMeetingDate || currentPMSummary.nextMeeting) && (
                              <span className="text-xs font-bold text-indigo-600 flex items-center gap-1 bg-indigo-50 px-2.5 py-0.5 rounded-md border border-indigo-100">
                                <Calendar size={12} />
                                Next Meeting: {currentPMSummary.nextMeetingDate || currentPMSummary.nextMeeting}
                              </span>
                            )}
                          </div>
                          <h2 className="text-2xl font-black text-slate-900 tracking-tight pt-1">{currentPMSummary.title || currentPMSummary.meetingTitle}</h2>
                          <div className="flex items-center gap-2 pt-1 flex-wrap">
                            <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
                              <Users size={12} />
                              Attendees:
                            </span>
                            {(currentPMSummary.attendees || []).map((att, i) => (
                              <Badge key={i} variant="secondary" className="bg-slate-100 text-slate-700 font-bold text-[10px] px-2 py-0.5 rounded-lg">
                                {att}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => {
                              const title = currentPMSummary.title || currentPMSummary.meetingTitle || 'Meeting Summary';
                              const date = currentPMSummary.date || currentPMSummary.meetingDate || 'N/A';
                              const exec = currentPMSummary.executiveSummary || currentPMSummary.recapNotes?.join('\n\n') || '';
                              const decs = currentPMSummary.keyDecisions || currentPMSummary.keyItems || [];
                              const nexts = currentPMSummary.nextSteps || (currentPMSummary.nextMeeting ? [currentPMSummary.nextMeeting] : []);
                              const text = `MEETING SUMMARY: ${title}\nDate: ${date}\nNext Meeting: ${currentPMSummary.nextMeetingDate || currentPMSummary.nextMeeting || 'N/A'}\nAttendees: ${(currentPMSummary.attendees || []).join(', ')}\n\nEXECUTIVE SUMMARY:\n${exec}\n\nKEY DECISIONS:\n${decs.map(d => `- ${d}`).join('\n')}\n\nACTION ITEMS:\n${(currentPMSummary.actionItems || []).map(a => `- [${a.status}] ${a.description} (Owner: ${a.owner}, Due: ${a.dueDate}, Priority: ${a.priority})`).join('\n')}\n\nNEXT STEPS:\n${nexts.map(n => `- ${n}`).join('\n')}`.trim();
                              navigator.clipboard.writeText(text);
                              toast.success("Summary copied to clipboard");
                            }}
                            className="h-9 px-4 rounded-xl border-slate-200 text-slate-700 font-bold text-xs gap-2 hover:bg-slate-50"
                          >
                            <Copy size={14} />
                            Copy Summary
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDeletePMSummary(currentPMSummary.id)}
                            className="h-9 px-3 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </div>

                      {/* Human-In-The-Loop Clarification & Confirmation Banner */}
                      <div className="border border-indigo-200 bg-indigo-50/40 rounded-2xl overflow-hidden">
                        <div className="bg-indigo-100/60 border-b border-indigo-200/60 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5">
                            <Badge className={cn("border-none px-3 py-1 text-[10px] font-black uppercase tracking-wider shadow-2xs", currentPMSummary.isHumanConfirmed ? "bg-emerald-600 text-white" : "bg-amber-500 text-white animate-pulse")}>
                              {currentPMSummary.isHumanConfirmed ? "Human Verified" : "Human-in-the-Loop Review Needed"}
                            </Badge>
                            <span className="text-sm font-black uppercase tracking-widest text-indigo-950 flex items-center gap-2">
                              <UserCheck className="text-indigo-600" size={18} />
                              Confirm Attendees & Next Meeting Date
                            </span>
                          </div>
                          {currentPMSummary.isHumanConfirmed && (
                            <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-lg flex items-center gap-1 border border-emerald-200">
                              <CheckCircle2 size={13} />
                              Verified by Project Manager
                            </span>
                          )}
                        </div>
                        <div className="p-5 space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Next Meeting Date / Sync */}
                            <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                              <div className="flex items-center justify-between">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-indigo-900 flex items-center gap-1.5">
                                  <Calendar className="text-indigo-600" size={13} />
                                  Next Meeting Date (Follow-Up Sync)
                                </Label>
                                <span className="text-[9px] font-bold text-indigo-500 italic">Extracted / Verified</span>
                              </div>
                              <Input 
                                type="text" 
                                placeholder="e.g. 2026-08-01 or Next Tuesday at 10:00 AM" 
                                value={hitlNextMeetingDate}
                                onChange={(e) => setHitlNextMeetingDate(e.target.value)}
                                className="bg-slate-50 border-indigo-200 text-xs font-semibold h-9 rounded-lg text-slate-900"
                              />
                              <p className="text-[10px] text-slate-500 leading-tight">
                                AI Detected Next Meeting: <span className="font-bold text-slate-800">{currentPMSummary.nextMeeting || "None specified in transcript"}</span>
                              </p>
                            </div>

                            {/* Attendees List (Taken from transcript / notes) */}
                            <div className="space-y-1.5 bg-white p-3.5 rounded-xl border border-indigo-100 shadow-2xs">
                              <div className="flex items-center justify-between">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-indigo-900 flex items-center gap-1.5">
                                  <Users className="text-indigo-600" size={13} />
                                  Attendees (Extracted from Transcript & Notes)
                                </Label>
                                <span className="text-[9px] font-bold text-indigo-500 italic">{hitlAttendees.length} Participants</span>
                              </div>
                              <div className="flex flex-wrap gap-1.5 min-h-[38px] p-1.5 bg-slate-50 border border-indigo-100 rounded-lg items-center">
                                {hitlAttendees.map((att, idx) => (
                                  <Badge key={idx} className="bg-white text-indigo-950 border border-indigo-200 font-bold text-[10px] gap-1 px-2 py-0.5 shadow-2xs">
                                    {att}
                                    <button 
                                      onClick={() => setHitlAttendees(prev => prev.filter((_, i) => i !== idx))}
                                      className="text-slate-400 hover:text-red-500 font-black ml-0.5 text-xs"
                                      title="Remove participant"
                                    >
                                      ×
                                    </button>
                                  </Badge>
                                ))}
                                <input 
                                  type="text"
                                  placeholder="+ Add attendee..."
                                  value={hitlNewAttendeeInput}
                                  onChange={(e) => setHitlNewAttendeeInput(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter' && hitlNewAttendeeInput.trim()) {
                                      e.preventDefault();
                                      setHitlAttendees(prev => [...prev, hitlNewAttendeeInput.trim()]);
                                      setHitlNewAttendeeInput("");
                                    }
                                  }}
                                  className="text-[11px] font-medium bg-transparent border-none outline-none focus:ring-0 text-indigo-900 placeholder:text-slate-400 px-1 min-w-[90px] flex-1"
                                />
                              </div>
                              <p className="text-[10px] text-slate-500 leading-tight">Type a name & press Enter to add missing participants.</p>
                            </div>
                          </div>

                          {/* Clarifications / Open Questions */}
                          {currentPMSummary.clarificationsNeeded && currentPMSummary.clarificationsNeeded.length > 0 && (
                            <div className="bg-amber-50/80 border border-amber-200 p-3.5 rounded-xl space-y-2">
                              <Label className="text-[10px] font-black uppercase tracking-widest text-amber-900 flex items-center gap-1.5">
                                <HelpCircle size={14} className="text-amber-600" />
                                AI Clarification Questions for Human Review ({currentPMSummary.clarificationsNeeded.length})
                              </Label>
                              <ul className="space-y-1.5">
                                {currentPMSummary.clarificationsNeeded.map((clarification, cIdx) => (
                                  <li key={cIdx} className="text-xs font-semibold text-amber-950 flex items-start gap-2 bg-white/90 p-2.5 rounded-lg border border-amber-100 shadow-2xs">
                                    <span className="text-amber-600 font-bold">•</span>
                                    <span className="flex-1">{clarification}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Confirm / Save Button */}
                          <div className="flex justify-end pt-1">
                            <Button 
                              onClick={() => {
                                handleSaveHumanConfirmation(currentPMSummary.id, hitlAttendees, hitlNextMeetingDate);
                              }}
                              className="bg-indigo-600 text-white hover:bg-indigo-700 h-9 px-5 rounded-xl font-bold text-xs gap-2 shadow-md shadow-indigo-600/20"
                            >
                              <CheckCircle2 size={15} />
                              {currentPMSummary.isHumanConfirmed ? "Update Confirmed Details" : "Confirm Attendees & Next Meeting Date"}
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Content Section: Executive Summary & Key Decisions */}
                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                        {/* Executive Summary */}
                        <div className="lg:col-span-7 space-y-6">
                          <Card className="shadow-2xs border border-slate-200 bg-white rounded-xl overflow-hidden">
                            <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-4">
                              <CardTitle className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                                <Sparkles className="text-primary" size={15} />
                                Executive Overview
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-5">
                              <p className="text-slate-700 text-xs font-medium leading-relaxed whitespace-pre-wrap">
                                {currentPMSummary.executiveSummary || (currentPMSummary.recapNotes?.join('\n\n')) || "No executive summary available."}
                              </p>
                            </CardContent>
                          </Card>

                          <Card className="shadow-2xs border border-slate-200 bg-white rounded-xl overflow-hidden">
                            <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-4">
                              <CardTitle className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                                <CheckCircle2 className="text-emerald-600" size={15} />
                                Key Decisions Agreed
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-5">
                              {(currentPMSummary.keyDecisions || currentPMSummary.keyItems || []).length === 0 ? (
                                <p className="text-slate-400 italic text-xs">No explicit key decisions noted in this meeting.</p>
                              ) : (
                                <ul className="space-y-2.5">
                                  {(currentPMSummary.keyDecisions || currentPMSummary.keyItems || []).map((dec, i) => (
                                    <li key={i} className="flex items-start gap-2.5 text-xs font-bold text-slate-800 leading-snug p-2.5 bg-emerald-50/40 border border-emerald-100 rounded-lg">
                                      <div className="w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5 font-black text-[9px]">
                                        {i + 1}
                                      </div>
                                      <span className="flex-1 mt-0.5">{dec}</span>
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </CardContent>
                          </Card>
                        </div>

                        {/* Action Items */}
                        <div className="lg:col-span-5 space-y-6">
                          <Card className="shadow-2xs border border-slate-200 bg-white rounded-xl overflow-hidden">
                            <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-4 flex flex-row items-center justify-between">
                              <CardTitle className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                                <CheckSquare className="text-primary" size={15} />
                                Action Items ({(currentPMSummary.actionItems || []).length})
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-4 space-y-2.5">
                              {(currentPMSummary.actionItems || []).length === 0 ? (
                                <p className="text-slate-400 italic text-xs py-4 text-center">No action items recorded.</p>
                              ) : (
                                (currentPMSummary.actionItems || []).map((item) => (
                                  <div 
                                    key={item.id} 
                                    className={cn(
                                      "p-3 rounded-lg border transition-all space-y-1.5",
                                      item.status === 'Completed' ? "bg-slate-50 border-slate-200 opacity-60" : "bg-white border-slate-200 hover:border-slate-300"
                                    )}
                                  >
                                    <div className="flex items-start gap-2.5">
                                      <Checkbox 
                                        checked={item.status === 'Completed'}
                                        onCheckedChange={() => handleToggleActionItemStatus(currentPMSummary.id, item.id)}
                                        className="mt-0.5"
                                      />
                                      <div className="space-y-1 flex-1">
                                        <p className={cn(
                                          "text-xs font-bold leading-snug",
                                          item.status === 'Completed' ? "line-through text-slate-400" : "text-slate-900"
                                        )}>
                                          {item.description}
                                        </p>
                                        <div className="flex items-center gap-1.5 flex-wrap pt-0.5 text-[9px]">
                                          <Badge variant="outline" className="bg-slate-50 text-slate-700 font-bold border-slate-200 px-1.5 py-0">
                                            Owner: {item.owner}
                                          </Badge>
                                          <Badge variant="outline" className="bg-slate-50 text-slate-500 font-bold border-slate-200 px-1.5 py-0">
                                            Due: {item.dueDate}
                                          </Badge>
                                          <Badge className={cn(
                                            "px-1.5 py-0 text-[8px] font-black uppercase border-none",
                                            item.priority === 'High' ? "bg-red-500 text-white" :
                                            item.priority === 'Medium' ? "bg-amber-500 text-white" : "bg-slate-200 text-slate-700"
                                          )}>
                                            {item.priority}
                                          </Badge>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                            </CardContent>
                          </Card>

                          <Card className="shadow-2xs border border-slate-200 bg-white rounded-xl overflow-hidden">
                            <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-4">
                              <CardTitle className="text-xs font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                                <ListTodo className="text-primary" size={15} />
                                Next Steps & Follow-ups
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-5">
                              {(currentPMSummary.nextSteps || (currentPMSummary.nextMeeting ? [currentPMSummary.nextMeeting] : [])).length === 0 ? (
                                <p className="text-slate-400 italic text-xs">No explicit next steps listed.</p>
                              ) : (
                                <ul className="space-y-2">
                                  {(currentPMSummary.nextSteps || (currentPMSummary.nextMeeting ? [currentPMSummary.nextMeeting] : [])).map((step, i) => (
                                    <li key={i} className="text-xs font-medium text-slate-700 flex items-start gap-2">
                                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                                      <span>{step}</span>
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </CardContent>
                          </Card>
                        </div>
                      </div>

                      {/* Integrated PM Assistant Panel (In-Tab AI Chat) */}
                      <div className="pt-6 border-t border-slate-200 space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold">
                              <Bot size={16} />
                            </div>
                            <div>
                              <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">PM AI Assistant</h4>
                              <p className="text-[10px] text-slate-500">Indexed with active meeting summary and project history</p>
                            </div>
                          </div>
                          {pmAssistantMessages.length > 0 && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => setPmAssistantMessages([])}
                              className="text-xs text-slate-400 hover:text-slate-600 font-bold"
                            >
                              Clear Chat
                            </Button>
                          )}
                        </div>

                        {/* Preset Chips */}
                        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                          {[
                            "Summarize key decisions made in this meeting",
                            "List open action items & assigned owners",
                            "Identify project risks or missing clarifications",
                            "Draft a status update email for stakeholders"
                          ].map((preset, idx) => (
                            <Button 
                              key={idx}
                              variant="outline" 
                              size="sm"
                              onClick={() => handleAskPMAssistant(preset)}
                              disabled={isAskingPMAssistant}
                              className="bg-white border-slate-200 text-slate-700 font-bold text-[11px] hover:border-primary hover:text-primary rounded-xl shrink-0 gap-1.5 shadow-2xs"
                            >
                              <Sparkles size={11} className="text-primary" />
                              {preset}
                            </Button>
                          ))}
                        </div>

                        {/* Chat box */}
                        <div className="border border-slate-200 bg-slate-50/50 rounded-2xl overflow-hidden flex flex-col min-h-[320px] max-h-[450px]">
                          <div className="p-4 flex-1 overflow-y-auto space-y-3">
                            {pmAssistantMessages.length === 0 ? (
                              <div className="h-full min-h-[200px] flex flex-col items-center justify-center text-center p-6 space-y-2">
                                <Bot size={28} className="text-primary/40" />
                                <h5 className="text-xs font-black text-slate-900 uppercase">Ask the PM Assistant</h5>
                                <p className="text-slate-500 text-[11px] max-w-sm">
                                  Ask questions about decisions, risks, task ownership, or request drafted status communications.
                                </p>
                              </div>
                            ) : (
                              pmAssistantMessages.map((msg) => (
                                <div 
                                  key={msg.id}
                                  className={cn(
                                    "flex gap-2.5 max-w-2xl",
                                    msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
                                  )}
                                >
                                  <div className={cn(
                                    "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 font-bold text-xs shadow-2xs",
                                    msg.role === 'user' ? "bg-slate-900 text-white" : "bg-primary text-white"
                                  )}>
                                    {msg.role === 'user' ? <User size={13} /> : <Bot size={13} />}
                                  </div>
                                  <div className={cn(
                                    "p-3 rounded-2xl text-xs leading-relaxed space-y-1 font-medium",
                                    msg.role === 'user' ? "bg-primary text-white rounded-tr-none shadow-sm" : "bg-white border border-slate-200 text-slate-800 rounded-tl-none whitespace-pre-wrap shadow-2xs"
                                  )}>
                                    <p>{msg.content}</p>
                                    <span className={cn(
                                      "text-[8px] block font-mono font-bold pt-0.5 opacity-70",
                                      msg.role === 'user' ? "text-white/70 text-right" : "text-slate-400 text-left"
                                    )}>
                                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                  </div>
                                </div>
                              ))
                            )}
                            {isAskingPMAssistant && (
                              <div className="flex gap-2.5 max-w-md mr-auto">
                                <div className="w-7 h-7 rounded-lg bg-primary text-white flex items-center justify-center shrink-0">
                                  <Bot size={13} />
                                </div>
                                <div className="p-3 rounded-2xl bg-white border border-slate-200 text-slate-500 text-xs flex items-center gap-2 rounded-tl-none font-bold shadow-2xs">
                                  <Loader2 className="animate-spin text-primary" size={13} />
                                  Analyzing meeting context...
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
                            <Input 
                              placeholder="Ask a question or request a draft status update..."
                              value={pmAssistantInput}
                              onChange={(e) => setPmAssistantInput(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  handleAskPMAssistant();
                                }
                              }}
                              className="bg-slate-50 border-slate-200 text-xs h-10 rounded-xl flex-1 font-medium shadow-none"
                            />
                            <Button 
                              onClick={() => handleAskPMAssistant()}
                              disabled={isAskingPMAssistant || !pmAssistantInput.trim()}
                              className="bg-primary text-white hover:bg-primary/90 h-10 px-4 rounded-xl font-bold text-xs gap-1.5 shrink-0"
                            >
                              <Send size={13} />
                              Send
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  )}
                </div>
              </motion.div>
            ) : activeTab === 'project-status-slide-maker' ? (
              <motion.div 
                key="project-status-slide-maker-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6 flex-1 min-h-[calc(100vh-12rem)]"
              >
                {/* Header */}
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-primary text-white border-none px-3 py-1 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                        Project Manager
                      </Badge>
                      <Badge variant="outline" className="border-indigo-200 bg-indigo-50 text-indigo-700 font-bold text-[10px] uppercase tracking-widest px-3">
                        Preview / Feature Hub
                      </Badge>
                    </div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Project Status Slide Maker</h2>
                    <p className="text-slate-500 text-sm font-medium">
                      Automated Executive Presentation Decks & Steering Committee Slide Generator.
                    </p>
                  </div>
                </div>

                {/* Main Placeholder Banner */}
                <Card className="shadow-sm border border-slate-200 bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white rounded-3xl overflow-hidden relative">
                  <div className="p-8 md:p-12 space-y-8 relative z-10">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                      <div className="space-y-3 max-w-2xl">
                        <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                          <Presentation size={14} className="text-indigo-400" />
                          Slide Deck Generator • Preview Mode
                        </div>
                        <h3 className="text-3xl md:text-4xl font-black tracking-tight uppercase font-display text-white">
                          Automated Executive Status Decks
                        </h3>
                        <p className="text-slate-300 text-sm leading-relaxed font-medium">
                          Transform your meeting summaries, key decisions, action item progress, and data warehouse project milestones into polished executive presentation decks with 1 click.
                        </p>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3 shrink-0">
                        <Button 
                          onClick={() => toast("Sample slide deck preview generated! Full pptx download coming soon.")}
                          className="bg-primary text-white hover:bg-primary/90 h-11 px-6 rounded-xl font-bold text-xs gap-2 shadow-lg shadow-primary/30"
                        >
                          <Sparkles size={16} />
                          Generate Sample Slide Deck
                        </Button>
                      </div>
                    </div>

                    {/* Features Grid Preview */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-white/10">
                      <div className="bg-white/5 border border-white/10 p-5 rounded-2xl space-y-2 backdrop-blur-sm">
                        <div className="w-10 h-10 rounded-xl bg-primary/20 text-primary flex items-center justify-center font-bold">
                          <FileText size={20} />
                        </div>
                        <h4 className="font-black text-sm uppercase text-white">1-Click Auto Synthesis</h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-medium">
                          Auto-extracts executive highlights from saved Transcript Library summaries to build steering committee decks.
                        </p>
                      </div>

                      <div className="bg-white/5 border border-white/10 p-5 rounded-2xl space-y-2 backdrop-blur-sm">
                        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                          <BarChart3 size={20} />
                        </div>
                        <h4 className="font-black text-sm uppercase text-white">Milestone & Health Visuals</h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-medium">
                          Real-time status indicators, open action item burndowns, and milestone timeline charts formatted for C-suite presentation.
                        </p>
                      </div>

                      <div className="bg-white/5 border border-white/10 p-5 rounded-2xl space-y-2 backdrop-blur-sm">
                        <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
                          <Download size={20} />
                        </div>
                        <h4 className="font-black text-sm uppercase text-white">PowerPoint & PDF Export</h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-medium">
                          Export presentation files directly to editable PowerPoint (.pptx) format or high-resolution PDF documentation.
                        </p>
                      </div>
                    </div>

                    {/* Sample Slide Cards */}
                    <div className="space-y-4 pt-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black uppercase tracking-widest text-slate-400">Sample Deck Template Preview</span>
                        <Badge variant="outline" className="text-[10px] text-indigo-300 border-indigo-400/30">3 Executive Slides</Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-slate-950/80 border border-white/10 p-4 rounded-xl space-y-2">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                            <span>Slide 1</span>
                            <Badge className="bg-emerald-500/20 text-emerald-300 border-none text-[8px]">Executive Overview</Badge>
                          </div>
                          <h5 className="text-xs font-bold text-white">Project Health & Key Achievements</h5>
                          <div className="h-16 bg-white/5 rounded-lg border border-white/5 p-2 text-[10px] text-slate-400 italic flex items-center justify-center text-center">
                            "Summary of project milestones, overall health status: On Track"
                          </div>
                        </div>

                        <div className="bg-slate-950/80 border border-white/10 p-4 rounded-xl space-y-2">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                            <span>Slide 2</span>
                            <Badge className="bg-blue-500/20 text-blue-300 border-none text-[8px]">Milestones & Tasks</Badge>
                          </div>
                          <h5 className="text-xs font-bold text-white">Action Items & Deliverables Burndown</h5>
                          <div className="h-16 bg-white/5 rounded-lg border border-white/5 p-2 text-[10px] text-slate-400 italic flex items-center justify-center text-center">
                            "Aggregated task counts, open deliverables, and assigned owners"
                          </div>
                        </div>

                        <div className="bg-slate-950/80 border border-white/10 p-4 rounded-xl space-y-2">
                          <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                            <span>Slide 3</span>
                            <Badge className="bg-amber-500/20 text-amber-300 border-none text-[8px]">Decisions & Risks</Badge>
                          </div>
                          <h5 className="text-xs font-bold text-white">Key Decisions & Steering Committee Inputs</h5>
                          <div className="h-16 bg-white/5 rounded-lg border border-white/5 p-2 text-[10px] text-slate-400 italic flex items-center justify-center text-center">
                            "Key decisions agreed, human-in-the-loop verified dates & upcoming syncs"
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ) : activeTab === 'project-raid-log' ? (
              <motion.div 
                key="project-raid-log-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6 flex-1 min-h-[calc(100vh-12rem)]"
              >
                {/* RAID Log Header */}
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-primary text-white border-none px-3 py-1 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                        Project Manager
                      </Badge>
                      <Badge variant="outline" className="border-red-200 bg-red-50 text-red-700 font-bold text-[10px] uppercase tracking-widest px-3">
                        Governance & Risk
                      </Badge>
                    </div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Project RAID Log</h2>
                    <p className="text-slate-500 text-sm font-medium">
                      Comprehensive Risks, Assumptions, Issues, and Dependencies (RAID) tracking auto-extracted from meeting notes and status updates.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button 
                      onClick={() => toast.success("AI RAID Log analysis executed! Transcripts analyzed for risks & blockers.")}
                      className="bg-primary text-white hover:bg-primary/90 h-11 px-5 rounded-xl font-bold text-xs gap-2 shadow-sm"
                    >
                      <Sparkles size={16} />
                      Auto-Extract RAID Items
                    </Button>
                  </div>
                </div>

                {/* 4 Category Highlight Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-red-200 shadow-sm space-y-2 relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-widest text-red-600">Risks</span>
                      <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                        <ShieldAlert size={18} />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-slate-900">
                      {raidLogItems.filter(r => r.type === 'Risk').length}
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">Potential future events impacting scope or timeline.</p>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-amber-200 shadow-sm space-y-2 relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-widest text-amber-700">Issues</span>
                      <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
                        <AlertTriangle size={18} />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-slate-900">
                      {raidLogItems.filter(r => r.type === 'Issue').length}
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">Current active problems requiring resolution.</p>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-blue-200 shadow-sm space-y-2 relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-widest text-blue-700">Assumptions</span>
                      <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
                        <Info size={18} />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-slate-900">
                      {raidLogItems.filter(r => r.type === 'Assumption').length}
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">Factors accepted as true without physical proof.</p>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-indigo-200 shadow-sm space-y-2 relative overflow-hidden">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-widest text-indigo-700">Dependencies</span>
                      <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
                        <Layers size={18} />
                      </div>
                    </div>
                    <div className="text-2xl font-black text-slate-900">
                      {raidLogItems.filter(r => r.type === 'Dependency').length}
                    </div>
                    <p className="text-[11px] text-slate-500 font-medium">Prerequisite deliverables or vendor milestones.</p>
                  </div>
                </div>

                {/* RAID Matrix Card */}
                <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl overflow-hidden">
                  <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <CardTitle className="text-base font-bold flex items-center gap-2 text-slate-900">
                          <ShieldAlert className="text-primary" size={20} />
                          Active Project RAID Log Matrix
                        </CardTitle>
                        <CardDescription className="text-xs text-slate-500">
                          Manage risks, assign owners, set target dates, and track mitigation progress
                        </CardDescription>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-wrap">
                        <Input 
                          placeholder="Search RAID items..." 
                          value={raidSearchQuery}
                          onChange={(e) => setRaidSearchQuery(e.target.value)}
                          className="bg-white border-slate-200 text-xs h-9 w-48 rounded-xl"
                        />
                        <select 
                          value={raidTypeFilter}
                          onChange={(e) => setRaidTypeFilter(e.target.value)}
                          className="bg-white border border-slate-200 text-xs font-bold text-slate-700 h-9 rounded-xl px-3 outline-none cursor-pointer"
                        >
                          <option value="All">All RAID Types</option>
                          <option value="Risk">Risks Only</option>
                          <option value="Issue">Issues Only</option>
                          <option value="Assumption">Assumptions Only</option>
                          <option value="Dependency">Dependencies Only</option>
                        </select>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0 overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50/80 border-b border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-500">
                          <th className="p-4">ID</th>
                          <th className="p-4">Type</th>
                          <th className="p-4">Title & Description</th>
                          <th className="p-4">Impact</th>
                          <th className="p-4">Status</th>
                          <th className="p-4">Owner</th>
                          <th className="p-4">Target Date</th>
                          <th className="p-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs font-medium">
                        {raidLogItems
                          .filter(item => {
                            if (raidTypeFilter !== 'All' && item.type !== raidTypeFilter) return false;
                            if (raidSearchQuery.trim()) {
                              const q = raidSearchQuery.toLowerCase();
                              return item.title.toLowerCase().includes(q) || item.description.toLowerCase().includes(q) || item.owner.toLowerCase().includes(q);
                            }
                            return true;
                          })
                          .map((item) => (
                            <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                              <td className="p-4 font-mono font-bold text-slate-500 text-[11px]">{item.id}</td>
                              <td className="p-4">
                                <Badge className={cn(
                                  "border-none text-[9px] font-bold uppercase px-2.5 py-0.5",
                                  item.type === 'Risk' ? "bg-red-100 text-red-800" :
                                  item.type === 'Issue' ? "bg-amber-100 text-amber-800" :
                                  item.type === 'Assumption' ? "bg-blue-100 text-blue-800" :
                                  "bg-indigo-100 text-indigo-800"
                                )}>
                                  {item.type}
                                </Badge>
                              </td>
                              <td className="p-4 max-w-md">
                                <p className="font-bold text-slate-900 text-xs">{item.title}</p>
                                <p className="text-slate-500 text-[11px] leading-relaxed mt-0.5">{item.description}</p>
                              </td>
                              <td className="p-4">
                                <span className={cn(
                                  "font-black text-[10px] uppercase px-2 py-0.5 rounded-md",
                                  item.impact === 'High' ? "text-red-700 bg-red-50" :
                                  item.impact === 'Medium' ? "text-amber-700 bg-amber-50" :
                                  "text-slate-600 bg-slate-100"
                                )}>
                                  {item.impact}
                                </span>
                              </td>
                              <td className="p-4">
                                <Badge variant="outline" className="text-[10px] font-bold text-slate-700 border-slate-200">
                                  {item.status}
                                </Badge>
                              </td>
                              <td className="p-4 font-bold text-slate-700 text-[11px]">{item.owner}</td>
                              <td className="p-4 text-slate-500 font-mono text-[11px]">{item.targetDate}</td>
                              <td className="p-4 text-right">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => toast.success(`Updated ${item.id} status`)}
                                  className="text-primary hover:bg-primary/5 text-xs font-bold"
                                >
                                  Update
                                </Button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </CardContent>
                </Card>
              </motion.div>
            ) : activeTab === 'transcripts' ? (
              !currentTranscript ? (
                <motion.div 
                  key="transcripts-welcome"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-300 rounded-3xl bg-slate-50/50 relative overflow-hidden"
                >
                  <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center text-blue-600 mb-8 mx-auto shadow-xl border border-slate-100">
                    <MessagesSquare size={48} />
                  </div>
                  <h3 className="text-3xl font-black text-slate-900 mb-4 tracking-tight uppercase font-display">
                    {currentProject?.name || "Active Project"}
                  </h3>
                  <div className="space-y-4 max-w-md mx-auto">
                    <Badge className="bg-blue-600 text-white border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em]">
                      Transcripts Instruction
                    </Badge>
                    <p className="text-slate-500 leading-relaxed text-lg font-bold">
                      No transcript selected. Switch to the <span className="text-blue-600 font-black">Data Input</span> area to process a new meeting recording or select a processed transcript from the <span className="text-slate-900 font-black">Analyst Assets</span> tab.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="transcripts-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="col-span-full flex flex-col space-y-4 flex-1 pb-0 overflow-visible"
              >
                {/* Header Section */}
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-primary text-white border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                        Data Analysis
                      </Badge>
                      <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold text-[10px] uppercase tracking-widest px-3">
                        Meeting Transcript
                      </Badge>
                      <div className="h-4 w-px bg-slate-200" />
                      <span className="text-slate-400 font-bold text-[10px] uppercase tracking-widest flex items-center gap-1.5">
                        <Users size={12} />
                        {currentTranscript?.attendees.length || 0} Participants
                      </span>
                    </div>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2 group min-h-[36px]">
                        {isEditingTranscriptName ? (
                          <div className="flex items-center gap-1.5 mt-1">
                            <Input
                              type="text"
                              value={editingTranscriptNameVal}
                              onChange={(e) => setEditingTranscriptNameVal(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  handleSaveTranscriptName();
                                } else if (e.key === 'Escape') {
                                  setIsEditingTranscriptName(false);
                                }
                              }}
                              className="h-8 max-w-sm font-black text-slate-900 text-lg bg-white border-primary focus:ring-primary/20 py-1"
                              autoFocus
                            />
                            <Button 
                              size="sm" 
                              className="h-8 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] uppercase px-3 rounded-lg flex items-center justify-center"
                              onClick={handleSaveTranscriptName}
                            >
                              Save
                            </Button>
                            <Button 
                              variant="ghost"
                              size="sm" 
                              className="h-8 text-slate-400 hover:text-slate-600 font-bold text-[10px] uppercase px-3 rounded-lg flex items-center justify-center"
                              onClick={() => setIsEditingTranscriptName(false)}
                            >
                              Cancel
                            </Button>
                          </div>
                        ) : (
                          <>
                            <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                              {currentTranscript ? currentTranscript.name : "Processed Transcript"}
                            </h2>
                            {currentTranscript && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-slate-400 hover:text-primary rounded-md opacity-0 group-hover:opacity-100 transition-all cursor-pointer inline-flex items-center justify-center p-0 flex-shrink-0"
                                onClick={() => {
                                  setIsEditingTranscriptName(true);
                                  setEditingTranscriptNameVal(currentTranscript.name);
                                }}
                                title="Rename Transcript"
                              >
                                <Edit3 size={13} />
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                      <p className="text-slate-500 text-sm font-medium flex items-center flex-wrap gap-2">
                        {currentTranscript?.description || 'No transcript selected.'}
                        {currentTranscript && (
                          <span className="text-primary font-black uppercase tracking-widest text-[10px] ml-1">
                            Meeting Date: {currentTranscript.date}, {currentTranscript.time}
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-md">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-9 rounded-lg text-primary font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-primary hover:text-white transition-all border border-slate-100"
                        onClick={() => {
                          if (currentTranscript) {
                            const text = currentTranscript.segments.map(s => `[${s.timestamp}] ${s.speaker}: ${s.text}`).join('\n');
                            navigator.clipboard.writeText(text);
                            toast.success("Transcript copied to clipboard");
                          }
                        }}
                        disabled={!currentTranscript}
                      >
                        <Copy size={14} />
                        Copy Table
                      </Button>
                      {currentTranscript && (
                        <>
                          <div className="w-px h-5 bg-slate-200 mx-1" />
                          <DropdownMenu>
                            <DropdownMenuTrigger className={cn(buttonVariants({ variant: "ghost", size: "sm" }), "h-9 rounded-lg text-emerald-600 font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-emerald-600 hover:text-white transition-all border border-slate-100")}>
                                <Download size={14} />
                                Export
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="p-1 bg-white border-slate-200 shadow-xl rounded-xl">
                              <DropdownMenuItem onClick={() => exportTranscriptToExcel(currentTranscript)} className="gap-3 cursor-pointer px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider hover:bg-emerald-50 text-emerald-700">
                                <TableIcon size={14} />
                                Excel Export
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => exportTranscriptToWord(currentTranscript)} className="gap-3 cursor-pointer px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider hover:bg-blue-50 text-blue-700">
                                <FileText size={14} />
                                Word Export
                              </DropdownMenuItem>
                              <div className="h-px bg-slate-100 my-1" />
                              <DropdownMenuItem onClick={exportProjectBackup} className="gap-3 cursor-pointer px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider hover:bg-amber-50 text-amber-700">
                                <Save size={14} />
                                Project Config
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Attendees Section */}
                {currentTranscript && currentTranscript.attendees.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {currentTranscript.attendees.map((attendee, idx) => (
                      <Badge key={idx} variant="secondary" className="bg-slate-50 text-slate-600 border-slate-200 font-bold text-[10px] py-1 px-3">
                        <Users size={10} className="mr-2" />
                        {attendee}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Table Section */}
                {currentTranscript ? (
                  <div className="rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden flex-1 flex flex-col">
                    <div className="overflow-auto max-h-[calc(100vh-20rem)] flex-1 bg-white">
                      <Table className="w-full text-left border-collapse">
                        <TableHeader className="bg-slate-50 border-b border-slate-300 sticky top-0 z-10">
                          <TableRow className="divide-x divide-slate-200">
                            <TableHead className="w-[180px] font-black text-[11px] uppercase tracking-widest text-slate-800 p-4">Speaker</TableHead>
                            <TableHead className="font-black text-[11px] uppercase tracking-widest text-slate-800 p-4">Dialogue</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody className="divide-y divide-slate-100">
                          {currentTranscript.segments.map((segment, idx) => (
                            <TableRow 
                              key={idx} 
                              className="group transition-colors divide-x divide-slate-100 hover:bg-slate-50/50"
                            >
                              <TableCell className="p-4 align-top bg-slate-50/30">
                                <div className="flex flex-col">
                                  <span className="text-[12px] font-black text-slate-900 uppercase tracking-tight">{segment.speaker}</span>
                                  <span className="text-[10px] text-slate-400 font-mono mt-1 group-hover:text-primary transition-colors">{segment.timestamp}</span>
                                </div>
                              </TableCell>
                              <TableCell className="p-4 align-top">
                                <div className="text-[14px] text-slate-700 leading-relaxed whitespace-pre-wrap font-medium italic">"{segment.text}"</div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                ) : (
                  <div className="h-full min-h-[500px] flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
                    <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-slate-300 mb-6 shadow-sm border border-slate-100">
                      <MessagesSquare size={40} className="opacity-40" />
                    </div>
                    <h3 className="text-xl font-black text-slate-900 mb-2 uppercase">No Transcript Data</h3>
                    <p className="text-slate-500 max-w-md mx-auto text-sm font-medium leading-relaxed">Paste your meeting transcript in the left panel to process it into a structured format. We'll identify speakers, group segments, and track timestamps.</p>
                  </div>
                )}
              </motion.div>
            ) ) : activeTab === 'gap-registry' ? (
              gapRegistryItems.length === 0 ? (
                <motion.div 
                  key="gap-registry-welcome"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-300 rounded-3xl bg-slate-50/50 relative overflow-hidden"
                >
                  <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto shadow-xl border border-slate-100">
                    <FileBarChart size={48} />
                  </div>
                  <h3 className="text-3xl font-black text-slate-900 mb-4 tracking-tight uppercase font-display">
                    {currentProject?.name || "Active Project"}
                  </h3>
                  <div className="space-y-4 max-w-md mx-auto">
                    <Badge className="bg-primary text-white border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em]">
                      Gap Registry Instruction
                    </Badge>
                    <p className="text-slate-500 leading-relaxed text-lg font-bold">
                      No Gap Registry selected. Generate a <span className="text-primary font-black">Strategic Gap Registry</span> from your transcripts in the <span className="text-slate-900 font-black">Data Input</span> area or select a saved asset from the <span className="text-slate-900 font-black">Analyst Assets</span> tab.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  key="gap-registry-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="col-span-full flex flex-col space-y-4 flex-1 pb-0 overflow-visible"
              >
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Badge className="bg-primary text-white border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                        Data Analysis
                      </Badge>
                      <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold text-[10px] uppercase tracking-widest px-3">
                        Strategic Gaps
                      </Badge>
                      <div className="h-4 w-px bg-slate-200" />
                      <span className="text-slate-400 font-bold text-[10px] uppercase tracking-widest flex items-center gap-1.5">
                        <Database size={12} />
                        {industry || 'Various Industries'}
                      </span>
                    </div>
                    <div className="flex flex-col">
                      <h2 className="text-2xl font-black text-slate-900 tracking-tight">{companyName}</h2>
                      <p className="text-slate-500 text-sm font-medium flex items-center gap-2">
                        Strategic pain points and architectural opportunities registry.
                        <span className="px-2 py-0.5 bg-slate-100 rounded-full text-[11px] font-bold text-slate-600 border border-slate-200 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full shrink-0" />
                          {gapRegistryItems.length} Records
                        </span>
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-md">
                      <Tooltip>
                        <TooltipTrigger render={(triggerProps) => (
                          <Button {...triggerProps} variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-slate-500 hover:text-primary transition-all" onClick={() => scrollToCorner('top-left')}>
                            <ArrowUpLeft size={14} />
                          </Button>
                        )} />
                        <TooltipContent className="bg-slate-900 text-white border-none py-1.5 px-3 text-[11px] font-bold">Scroll to Top Start</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger render={(triggerProps) => (
                          <Button {...triggerProps} variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-slate-500 hover:text-primary transition-all" onClick={() => scrollToCorner('top-right')}>
                            <ArrowUpRight size={14} />
                          </Button>
                        )} />
                        <TooltipContent className="bg-slate-900 text-white border-none py-1.5 px-3 text-[11px] font-bold">Scroll to Top End</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger render={(triggerProps) => (
                          <Button {...triggerProps} variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-slate-500 hover:text-primary transition-all" onClick={() => scrollToCorner('bottom-left')}>
                            <ArrowDownLeft size={14} />
                          </Button>
                        )} />
                        <TooltipContent className="bg-slate-900 text-white border-none py-1.5 px-3 text-[11px] font-bold">Scroll to Bottom Start</TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger render={(triggerProps) => (
                          <Button {...triggerProps} variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-slate-500 hover:text-primary transition-all" onClick={() => scrollToCorner('bottom-right')}>
                            <ArrowDownRight size={14} />
                          </Button>
                        )} />
                        <TooltipContent className="bg-slate-900 text-white border-none py-1.5 px-3 text-[11px] font-bold">Scroll to Bottom End</TooltipContent>
                      </Tooltip>
                    </div>
                    <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-md">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-9 rounded-lg text-primary font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-primary hover:text-white transition-all border border-slate-100"
                        onClick={copyGapRegistryToClipboard}
                        disabled={gapRegistryItems.length === 0}
                      >
                        <Copy size={14} />
                        Copy Table
                      </Button>
                      <div className="w-px h-5 bg-slate-200 mx-1" />
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-9 rounded-lg text-emerald-600 font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-emerald-600 hover:text-white transition-all border border-slate-100"
                        onClick={exportGapRegistryToExcel}
                        disabled={gapRegistryItems.length === 0}
                      >
                        <TableIcon size={14} />
                        Excel
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-9 rounded-lg text-blue-600 font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-blue-600 hover:text-white transition-all border border-slate-100"
                        onClick={exportGapRegistryToJSON}
                        disabled={gapRegistryItems.length === 0}
                      >
                        <Download size={14} />
                        JSON
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Append Mode Progress Overlay */}
                {isGeneratingGapRegistry && gapRegistryMode === 'Append' && (
                  <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-2 p-4 bg-primary/5 border border-primary/20 rounded-2xl flex items-center gap-4 relative overflow-hidden group shadow-lg shadow-primary/5"
                  >
                    <div className="absolute top-0 left-0 h-full w-1 bg-primary animate-pulse" />
                    <div className="bg-primary/10 p-2.5 rounded-xl shadow-inner">
                      <Loader2 className="w-5 h-5 text-primary animate-spin" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black text-primary uppercase tracking-wider">
                          {gapRegistryProgress.total > 1 ? `Expanding Registry (${gapRegistryProgress.current}/${gapRegistryProgress.total})` : 'Expanding Registry'}
                        </span>
                        <Badge className="bg-primary/20 text-primary border-none text-[9px] font-black h-4 px-1.5 cursor-default hover:bg-primary/30 transition-colors">
                          AI Semantic Extraction
                        </Badge>
                      </div>
                      <div className="text-[11px] text-slate-500 font-medium leading-relaxed mt-0.5">
                        {gapRegistryProgress.total > 1 
                          ? `Processing block ${gapRegistryProgress.current} of ${gapRegistryProgress.total}. Analyzing document in sections for maximum precision.` 
                          : "Mining additional strategic insights from the transcript. New records will be appended below."}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 pr-2">
                       <span className="h-1.5 w-1.5 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: '0ms' }} />
                       <span className="h-1.5 w-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '200ms' }} />
                       <span className="h-1.5 w-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '400ms' }} />
                    </div>
                  </motion.div>
                )}

                {gapRegistryItems.length > 0 ? (
                  <div className="rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden flex-1 mb-0 pb-0 flex flex-col">
                    <div className="overflow-auto max-h-[calc(100vh-16rem)] flex-1 bg-white" ref={gapRegistryScrollRef}>
                      <table className="w-full text-left border-collapse table-fixed" style={{ width: `${Object.values(gapRegistryColWidths).reduce((a: number, b: number) => a + b, 0)}px` }}>
                        <thead className="bg-slate-50 border-b border-slate-300 sticky top-0 z-10">
                          <tr className="divide-x divide-slate-300">
                            {[
                              { id: 'id', label: 'ID' },
                              { id: 'gapType', label: 'Gap Type' },
                              { id: 'painPoint', label: 'Pain Point' },
                              { id: 'entity', label: 'Entity' },
                              { id: 'reportedBy', label: 'Reported By' },
                              { id: 'date', label: 'Date' },
                              { id: 'category', label: 'Category' },
                              { id: 'wmpComments', label: 'WMP Comments' },
                              { id: 'directQuotations', label: 'Direct Quotations' },
                              { id: 'interviewee', label: 'Interviewee' },
                              { id: 'meetingWorkshop', label: 'Meeting/Workshop' },
                              { id: 'priority', label: 'Priority' },
                              { id: 'maturityArea', label: 'Maturity Area' },
                              { id: 'mentions', label: 'Mentions' },
                              { id: 'totalMentions', label: 'Total # of Mentions' }
                            ].map((col) => (
                              <th 
                                key={col.id}
                                style={{ width: `${gapRegistryColWidths[col.id]}px` }}
                                className="relative group p-1 px-2 text-[11px] font-black text-slate-400 bg-slate-50 border-b border-slate-200"
                              >
                                <div className="whitespace-normal leading-tight uppercase tracking-widest">{col.label}</div>
                                <div 
                                  className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-primary transition-colors z-20" 
                                  onMouseDown={(e) => {
                                    const startX = e.pageX;
                                    const startWidth = gapRegistryColWidths[col.id];
                                    const onMouseMove = (m: MouseEvent) => handleResize(col.id, startWidth + (m.pageX - startX));
                                    const onMouseUp = () => {
                                      document.removeEventListener('mousemove', onMouseMove);
                                      document.removeEventListener('mouseup', onMouseUp);
                                    };
                                    document.addEventListener('mousemove', onMouseMove);
                                    document.addEventListener('mouseup', onMouseUp);
                                  }}
                                />
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-300">
                          {gapRegistryItems.map((item, idx) => (
                            <tr 
                              key={idx} 
                              onClick={() => setSelectedGapItem(item)}
                              className={cn(
                                "group cursor-pointer transition-colors divide-x divide-slate-300",
                                selectedGapItem?.id === item.id ? "bg-primary/10 hover:bg-primary/15" : "hover:bg-slate-50"
                              )}
                            >
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[12px] font-medium text-slate-400 font-mono leading-tight">{item.id}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="flex items-center gap-1 leading-tight">
                                  <div className={cn(
                                    "w-1.5 h-1.5 rounded-full shrink-0",
                                    item.gapType === 'Pain Point' ? "bg-red-500" : 
                                    item.gapType === 'Gap' ? "bg-amber-500" :
                                    item.gapType === 'Opportunity' ? "bg-emerald-500" : "bg-blue-500"
                                  )} />
                                  <span className="text-[12px] font-bold text-slate-700">{item.gapType}</span>
                                </div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-bold text-slate-900 leading-tight whitespace-normal">{item.painPoint}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-600 leading-tight whitespace-normal">{item.entity}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-700 leading-tight whitespace-normal">{item.reportedBy}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-400 leading-tight whitespace-normal">{item.reportedDate}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-600 leading-tight whitespace-normal">{item.category}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] text-slate-700 font-normal leading-relaxed whitespace-pre-wrap">{item.wmpComments}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] text-slate-600 leading-relaxed italic bg-slate-50/50 p-2 rounded-lg border border-slate-100 whitespace-pre-wrap">
                                  {item.directQuotations}
                                </div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-700 leading-tight whitespace-normal">{item.interviewee}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] text-slate-500 font-normal italic leading-tight whitespace-normal">{item.meetingWorkshop}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className={cn(
                                  "font-bold text-[14px] leading-tight",
                                  item.priority === 'High' ? "text-red-600" :
                                  item.priority === 'Medium' ? "text-amber-600" : "text-slate-500"
                                )}>
                                  {item.priority}
                                </div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-800 leading-tight whitespace-normal">{item.dataMaturityArea}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top">
                                <div className="text-[14px] font-medium text-slate-600 leading-tight italic whitespace-normal">{item.mentions || "N/A"}</div>
                              </td>
                              <td className="p-0.5 px-2 align-top text-center">
                                <div className="text-[14px] font-black text-slate-900 leading-tight">{item.totalMentions || 1}</div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <div className="h-full min-h-[500px] flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-200 rounded-3xl bg-slate-50/50">
                    <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center text-slate-300 mb-6 shadow-sm border border-slate-100">
                      <FileBarChart size={40} className="opacity-40" />
                    </div>
                    <h3 className="text-xl font-black text-slate-900 mb-2 uppercase">No Gap Registry Data</h3>
                    <p className="text-slate-500 max-w-md mx-auto text-sm font-medium leading-relaxed">Submit your meeting transcripts and company details in the left panel to generate a strategic Gap Registry. We'll identify architectural gaps, pain points, and MDP opportunities.</p>
                  </div>
                )}
              </motion.div>
            ) ) : activeTab === 'opps' ? (
              <motion.div 
                key="opps-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6 relative min-h-[calc(100vh-12rem)]"
              >
                {companyProfile ? (
                  <div className="space-y-8 animate-in fade-in duration-500 pb-32">
                    <Card className="shadow-xl bg-white rounded-3xl overflow-hidden border border-slate-200">
                      <CardContent className="p-6">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-6">
                          {/* Info Side */}
                          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
                            <div className="space-y-4 flex-1">
                              <div className="space-y-2">
                                <Badge className="bg-primary/5 text-primary border-primary/20 hover:bg-primary/10 px-3 py-0.5 font-black text-xs uppercase tracking-[0.2em]">
                                  {industry} Industry Sector
                                </Badge>
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                                  <div className="flex items-center gap-4">
                                    <h2 className="text-3xl font-black text-slate-900 tracking-tighter leading-[0.9] uppercase">
                                      {companyProfile.name}
                                    </h2>
                                    {companyProfile.ownershipType === 'Public' && companyProfile.ticker && companyProfile.ticker !== 'NON_PUBLIC' && (
                                      <Badge variant="outline" className="bg-slate-900 text-white border-none font-mono font-black px-3 py-1 text-[11px] shadow-lg shrink-0 h-fit mt-1">
                                        {companyProfile.ticker}
                                      </Badge>
                                    )}
                                  </div>
                                  {/* Market Cap Box - Optimized */}
                                  {companyProfile.ownershipType === 'Public' && (
                                    <div className="bg-white p-3 rounded-2xl border border-slate-200 flex items-center gap-5 shrink-0 shadow-sm mt-1 sm:mt-0 ring-1 ring-slate-100">
                                      <div className="flex flex-col leading-tight">
                                        <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400">Market Valuation</span>
                                        <p className="text-lg font-black text-slate-900 leading-none">{formatMarketValuation(companyProfile.marketCap)}</p>
                                      </div>
                                      <div className="w-8 h-8 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 border border-blue-100 shadow-sm">
                                        <Globe size={16} />
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                              <p className="text-sm text-slate-600 leading-relaxed font-medium max-w-4xl">
                                {companyProfile.summary}
                              </p>
                            </div>
                            
                            <div className="space-y-3 pt-2">
                              <div className="flex flex-wrap gap-2.5">
                                <div className="flex items-center gap-1.5 grayscale brightness-125 hover:grayscale-0 transition-all">
                                  <Lock size={10} className="text-slate-400" />
                                  <span className="text-[9px] font-black uppercase tracking-tight text-slate-500">{companyProfile.ownershipType}</span>
                                </div>
                                <div className="w-1 h-1 rounded-full bg-slate-200 mt-1.5" />
                                <div className="flex items-center gap-1.5 grayscale brightness-125 hover:grayscale-0 transition-all">
                                  <Globe size={10} className="text-slate-400" />
                                  <span className="text-[9px] font-black uppercase tracking-tight text-slate-500">{companyProfile.geographicScope}</span>
                                </div>
                                <div className="w-1 h-1 rounded-full bg-slate-200 mt-1.5" />
                                <div className="flex items-center gap-1.5 grayscale brightness-125 hover:grayscale-0 transition-all">
                                  <MapPin size={10} className="text-slate-400" />
                                  <span className="text-[9px] font-black uppercase tracking-tight text-slate-500">{companyProfile.country}</span>
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-1.5">
                                {companyProfile.linesOfBusiness.map((lob, idx) => (
                                  <Badge key={idx} variant="secondary" className="bg-slate-100/60 text-slate-400 border-none px-2.5 py-0.5 h-auto text-[9px] font-black uppercase tracking-wider rounded-md">
                                    {lob}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Financials Side (Compact View) */}
                          <div className="lg:col-span-5 flex flex-col lg:border-l lg:border-slate-100 lg:pl-8 relative">
                             {isUpdatingProfile && (
                               <div className="absolute inset-0 z-50 bg-white/60 backdrop-blur-[2px] flex items-center justify-center rounded-3xl">
                                 <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                               </div>
                             )}
                             {companyProfile.ownershipType === 'Public' && (companyProfile.isPublic || (companyProfile.ticker && companyProfile.ticker !== 'NON_PUBLIC')) && (
                               <div className="h-full bg-slate-50/10 rounded-3xl border border-slate-100 p-5 shadow-sm flex flex-col justify-center">
                                 <StockChart ticker={selectedTicker || companyProfile.ticker || 'COMP'} companyName={companyProfile.name} />
                               </div>
                             )}
                          </div>
                        </div>
                        {companyProfile.swot && (
                          <div className="pt-2 border-slate-100 space-y-4">
                            <div className="flex items-center gap-4">
                              <div className="h-px bg-slate-100 flex-1" />
                              <span className="text-[10px] font-black uppercase tracking-[0.6em] text-slate-600">Strategic SWOT Analysis</span>
                              <div className="h-px bg-slate-100 flex-1" />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                              {[
                                { label: 'Strengths', items: companyProfile.swot.strengths, color: 'text-emerald-700 bg-emerald-50/50 border-emerald-100', icon: <Award size={14} className="text-emerald-600" /> },
                                { label: 'Weaknesses', items: companyProfile.swot.weaknesses, color: 'text-rose-700 bg-rose-50/50 border-rose-100', icon: <ZapOff size={14} className="text-rose-600" /> },
                                { label: 'Opportunities', items: companyProfile.swot.opportunities, color: 'text-blue-700 bg-blue-50/50 border-blue-100', icon: <Rocket size={14} className="text-blue-600" /> },
                                { label: 'Threats', items: companyProfile.swot.threats, color: 'text-amber-700 bg-amber-50/50 border-amber-100', icon: <ShieldAlert size={14} className="text-amber-600" /> }
                              ].map((section, idx) => (
                                <div key={idx} className={cn("p-4 rounded-[1.5rem] border h-full transition-all hover:bg-white bg-opacity-70", section.color.split(' ')[1], section.color.split(' ')[2])}>
                                  <h4 className={cn("text-[10px] font-black uppercase tracking-[0.2em] mb-3 flex items-center gap-2", section.color.split(' ')[0])}>
                                    {section.icon}
                                    {section.label}
                                  </h4>
                                  <ul className="space-y-3">
                                    {section.items.map((item, i) => {
                                      const isOppQuadrant = section.label === 'Opportunities';
                                      const allLinkedOpps = isOppQuadrant ? companyProfile.opportunities
                                        .map((o, index) => ({ ...o, originalIndex: index }))
                                        .filter(o => o.linkedSwotIndex === i) : [];
                                      
                                      const linkedOpps = allLinkedOpps.slice(0, 6);
                                      const hasLinks = isOppQuadrant && linkedOpps.length > 0;
                                      
                                      return (
                                        <li key={i} className="text-xs text-slate-600 font-bold leading-snug flex gap-2.5 group/swot items-start relative pr-2">
                                          {hasLinks ? (
                                            <div className="flex gap-1 shrink-0 mt-0.5 min-w-[12px] justify-center">
                                              {linkedOpps.map((lo, lidx) => (
                                                  <span key={lidx}>
                                                    <Tooltip>
                                                      <TooltipTrigger 
                                                        render={(triggerProps) => (
                                                          <div {...triggerProps} className={cn(
                                                            "w-[18px] h-[18px] rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-125 cursor-help ring-2 ring-white",
                                                            lo.linkType === 'direct' ? "bg-red-600 text-white animate-pulse" : "bg-orange-400 text-slate-900"
                                                          )}>
                                                            <span className="text-[10px] font-black leading-none">{lo.originalIndex + 1}</span>
                                                          </div>
                                                        )}
                                                      />
                                                      <TooltipContent className="bg-slate-900 text-white border-none p-2.5 rounded-xl shadow-2xl">
                                                        <div className="space-y-1">
                                                          <p className="text-[10px] font-black uppercase tracking-widest text-primary flex items-center gap-1">
                                                            {lo.linkType === 'direct' ? <Zap size={8} className="fill-red-500" /> : <Info size={8} className="text-orange-400" />}
                                                            {lo.linkType === 'direct' ? "Direct Benefit" : "Indirect Support"}
                                                          </p>
                                                          <p className="text-[9px] text-slate-300 font-medium leading-tight">
                                                            Opportunity #{lo.originalIndex + 1}: {lo.title}
                                                          </p>
                                                        </div>
                                                      </TooltipContent>
                                                    </Tooltip>
                                                  </span>
                                                ))}
                                              </div>
                                            ) : (
                                            <div className="shrink-0 mt-1">
                                              <SWOTItemIcon text={item} />
                                            </div>
                                          )}
                                          <span className="flex-1">{item}</span>
                                        </li>
                                      );
                                    })}
                                  </ul>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                      <div className="space-y-6">
                        <div className="flex items-center gap-4">
                          <Separator className="flex-1 opacity-50" />
                          <div className="flex items-center gap-6 shrink-0 bg-slate-100/80 backdrop-blur-md px-6 py-2 rounded-2xl border border-slate-200 shadow-md">
                            <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 whitespace-nowrap">
                              Business Area MDP Opportunities
                            </h3>
                            <div className="h-4 w-px bg-slate-200" />
                            <div className="flex items-center gap-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={selectAllOpportunities}
                                className="rounded-lg border-primary/20 text-primary font-black uppercase tracking-widest text-[9px] h-7 px-4 bg-white hover:bg-primary hover:text-white transition-all shadow-sm flex items-center gap-2"
                              >
                                <CheckCircle2 size={12} />
                                Select All
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={clearAllOpportunities}
                                className="rounded-lg border-slate-200 text-slate-400 font-black uppercase tracking-widest text-[9px] h-7 px-4 bg-white hover:bg-red-50 hover:text-red-500 hover:border-red-200 transition-all shadow-sm flex items-center gap-2"
                              >
                                <Eraser size={12} />
                                Clear All
                              </Button>
                            </div>
                          </div>
                          <Separator className="flex-1 opacity-50" />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        {companyProfile.opportunities.map((opp: MDPOpportunity, idx: number) => (
                          <OpportunityCard 
                            key={opp.id} 
                            opp={opp} 
                            index={idx}
                            onToggle={toggleOpportunitySelection} 
                          />
                        ))}
                      </div>
                    </div>

                    <div className="fixed bottom-0 left-0 right-0 z-[100] bg-white border-t border-slate-200 p-4 transition-all duration-500 animate-in slide-in-from-bottom shadow-[0_-10px_40px_rgba(0,0,0,0.08)]">
                      <div className="w-full px-6 flex items-center justify-between">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 leading-none mb-1">Roadmap Strategy</span>
                          <p className="text-[11px] text-slate-600 font-bold">
                            Ready to translate <span className="text-primary">{companyProfile.opportunities.filter(o => o.selected).length} selected opportunities</span> into MDP models.
                          </p>
                        </div>
                        <Button 
                          onClick={handleCreateMDPModels}
                          className="bg-primary text-white hover:bg-primary/90 h-12 px-10 rounded-xl shadow-xl shadow-primary/20 font-black uppercase tracking-widest text-xs gap-3 group transition-all hover:scale-[1.02] active:scale-95"
                        >
                          <Briefcase size={18} className="group-hover:rotate-12 transition-transform" />
                          Create Business Use Case(s)
                          <ArrowRight size={18} />
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-300 rounded-lg bg-white shadow-sm relative overflow-hidden">
                    <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                      <Sparkles size={48} className="text-primary/10" />
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">
                      Market Discovery Mode
                    </h3>
                    <p className="text-slate-500 max-w-md mx-auto leading-relaxed text-lg">
                      Enter a company name and industry in the sidebar to generate a prioritized list of Modern Data Platform opportunities tailored to your business profile.
                    </p>
                    <div className="mt-8 flex gap-4">
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-emerald-600 font-bold border border-slate-200">1</div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 text-center">Set Industry</span>
                      </div>
                      <div className="w-8 h-px bg-slate-200 mt-5" />
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-blue-600 font-bold border border-slate-200">2</div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 text-center">Name Company</span>
                      </div>
                      <div className="w-8 h-px bg-slate-200 mt-5" />
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-primary font-bold border border-slate-200">3</div>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 text-center">Generate Insights</span>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            ) : activeTab === 'usecases' ? (
              <motion.div 
                key="usecases-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-12 pb-32"
              >
                {selectedUseCaseOppId ? (
                  (() => {
                    const opp = companyProfile?.opportunities?.find(o => o.id === selectedUseCaseOppId);
                    if (!opp) return null;

                    const oppIndex = companyProfile?.opportunities?.indexOf(opp) ?? 0;
                    const slide1Headline = generateSlide1Headline(opp.title, opp.roi, opp.businessCase, oppIndex);
                    const slide2Headline = generateSlide2Headline(opp.title, opp.roi, oppIndex);

                    const theme = CARD_THEMES[oppIndex % CARD_THEMES.length];
                    const colorClass = MUTED_COLORS[oppIndex % MUTED_COLORS.length];

                    // Derived KPIs from facts and dimensions
                    const kpis = [
                      `Increase in ${opp.dimensions[0] || 'Operational'} Efficiency`,
                      `Reduction in ${opp.facts[0] || 'Data'} Latency`,
                      `Improvement in ${opp.dimensions[1] || 'Process'} Visibility`,
                      `Growth in ${opp.title.split(' ')[0]} Velocity`,
                      `Reduction in Manual ${opp.dimensions[2] || 'Reporting'} overhead`,
                      `Enhanced ${opp.facts[1] || 'Metadata'} Accuracy`,
                      `Accelerated Time-to-Market for ${opp.title.split(' ').slice(0, 2).join(' ')}`,
                      `Boost in ${opp.dimensions[0] || 'System'} Reliability`
                    ].slice(0, 8);

                    return (
                      <div className="space-y-16 animate-in fade-in zoom-in-95 duration-700">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={cn("border-2 font-black uppercase tracking-widest text-[9px] px-3 py-1", theme.bg, theme.border, theme.text)}>
                              UseCase Detail
                            </Badge>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => exportAllUseCasesToPPTX()}
                            className="bg-white border-slate-400 text-primary font-black uppercase tracking-widest text-[10px] h-9 px-5 hover:bg-primary hover:text-white transition-all shadow-md gap-3 rounded-xl ring-2 ring-primary/5"
                          >
                            <Presentation size={14} />
                            Export Use Case Deck (PPTX)
                          </Button>
                        </div>

                        {/* Slide 1: Business Case */}
                        <div className="bg-white border border-slate-100 rounded-[0.5rem] shadow-2xl overflow-hidden aspect-[16/9] flex flex-col relative group/slide h-full max-h-[600px] w-full">
                          {/* Background Pattern - Dot Grid Top Left */}
                          <div className="absolute top-4 left-4 w-40 h-40 opacity-[0.1] pointer-events-none" 
                               style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='12' height='12' viewBox='0 0 16 16' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='2' cy='2' r='1' fill='%23002855' /%3E%3C/svg%3E")` }} />
                          
                          <div className="p-12 md:p-16 flex-1 flex flex-col overflow-hidden relative z-10">
                            <div className="mb-6 md:mb-8">
                              <p className="text-[10px] font-black tracking-[0.4em] uppercase text-slate-400 mb-2 md:mb-3">
                                STRATEGIC OPPORTUNITY ANALYSIS
                              </p>
                              <h2 className="text-xl md:text-2xl font-black text-[#002855] leading-[1.2] tracking-tighter max-w-5xl">
                                {slide1Headline}
                              </h2>
                              <div className="h-px w-full bg-[#002855] mt-4" />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 flex-1 min-h-0 overflow-hidden">
                              <div className="flex flex-col min-h-0">
                                <div className="space-y-2 flex flex-col h-full">
                                  <div className="flex items-center gap-2 text-slate-500 shrink-0">
                                    <OpportunityIcon type={opp.iconType} size={14} index={oppIndex} />
                                    <span className="text-[9px] font-black uppercase tracking-widest whitespace-nowrap">Problem / Opportunity</span>
                                  </div>
                      <div className="bg-slate-100 border border-slate-300 rounded-lg p-4 md:p-5 flex-1">
                                    <p className="text-[11px] text-slate-600 font-bold mb-3 border-l-2 border-slate-300 pl-2">
                                      {opp.businessCase.split('.')[0]}.
                                    </p>
                                    <div className="space-y-2 mt-2">
                                      <div className="flex items-start gap-2">
                                        <div className="w-1 h-1 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                                        <p className="text-[10px] text-slate-500 font-medium leading-tight">
                                          Gaps in real-time visibility across {opp.dimensions[0]} and {opp.dimensions[1] || 'critical systems'}.
                                        </p>
                                      </div>
                                      <div className="flex items-start gap-2">
                                        <div className="w-1 h-1 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                                        <p className="text-[10px] text-slate-500 font-medium leading-tight">
                                          Delayed decision-making cycles leading to measurable revenue attrition.
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex flex-col min-h-0">
                                <div className="space-y-2 flex flex-col h-full">
                                  <div className="flex items-center gap-2 text-slate-500 shrink-0">
                                    <Zap size={14} />
                                    <span className="text-[9px] font-black uppercase tracking-widest whitespace-nowrap">Proposed Solution</span>
                                  </div>
                                  <div className="bg-slate-100 border border-slate-300 rounded-lg p-4 md:p-5 flex-1">
                                    <p className="text-[11px] text-slate-800 font-bold mb-3 border-l-2 border-slate-400 pl-2">
                                      Implement a high-availability Modern Data Platform (MDP) architecture.
                                    </p>
                                    <div className="space-y-2 mt-2">
                                      <div className="flex items-start gap-2">
                                        <Check className="w-3 h-3 text-slate-500 mt-0.5 shrink-0" />
                                        <p className="text-[10px] text-slate-700 font-bold leading-tight">
                                          Automated ingestion of {opp.facts.slice(0, 2).join(' and ')} source data.
                                        </p>
                                      </div>
                                      <div className="flex items-start gap-2">
                                        <Check className="w-3 h-3 text-slate-500 mt-0.5 shrink-0" />
                                        <p className="text-[10px] text-slate-700 font-bold leading-tight">
                                          Unified platform governance for {opp.title} strategic initiatives.
                                        </p>
                                      </div>
                                      <div className="flex items-start gap-2">
                                        <Check className="w-3 h-3 text-slate-500 mt-0.5 shrink-0" />
                                        <p className="text-[10px] text-slate-700 font-bold leading-tight">
                                          Real-time data flow servicing downstream analytical consumers.
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              
                              <div className="flex flex-col min-h-0">
                                <div className="space-y-2 flex flex-col h-full">
                                  <div className="flex items-center gap-2 text-slate-500 shrink-0">
                                    <TrendingUp size={14} />
                                    <span className="text-[9px] font-black uppercase tracking-widest whitespace-nowrap">Value / Benefits</span>
                                  </div>
                                    <div className="bg-slate-100 border border-slate-300 rounded-lg p-4 md:p-5 flex-1 space-y-3">
                                    <div className="space-y-0.5">
                                      <p className="text-[8px] font-black uppercase tracking-[0.2em] text-slate-500">Compelling Metric</p>
                                      <p className="text-lg font-black tracking-tighter text-slate-900">{opp.roi}</p>
                                    </div>
                                    <ul className="space-y-1.5">
                                      <li className="text-[10px] text-slate-600 font-bold flex items-start gap-2">
                                        <div className="w-1 h-1 rounded-full mt-1.5 shrink-0 bg-slate-400" />
                                        <span>Quantifiable boost in {opp.dimensions[0] || 'operational'} throughput</span>
                                      </li>
                                      <li className="text-[10px] text-slate-600 font-bold flex items-start gap-2">
                                        <div className="w-1 h-1 rounded-full mt-1.5 shrink-0 bg-slate-400" />
                                        <span className="line-clamp-1">Reduced data reconciliation effort by 40%+</span>
                                      </li>
                                      <li className="text-[10px] text-slate-600 font-bold flex items-start gap-2">
                                        <div className="w-1 h-1 rounded-full mt-1.5 shrink-0 bg-slate-400" />
                                        <span className="line-clamp-1">Enhanced agility in responding to market shifts</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* West Monroe Footer */}
                          <div className="mt-auto bg-[#E7F0F7] px-12 md:px-16 py-4 md:py-6 flex items-center justify-between shrink-0">
                            <div className="flex items-center gap-3">
                              <div className="w-5 h-5 flex items-center justify-center rounded-sm">
                                <div className="grid grid-cols-3 gap-0.5 w-4 h-4 text-[#002855]">
                                  {[...Array(9)].map((_, i) => (
                                    <div key={i} className={cn("w-1 h-1 bg-current rounded-full", i === 4 && "opacity-0")} />
                                  ))}
                                </div>
                              </div>
                              <span className="text-xl font-black tracking-tighter text-[#002855]">west monroe</span>
                            </div>
                            <div className="flex-1 text-center px-4">
                               <p className="text-[8px] font-bold text-[#002855]/60 uppercase tracking-[0.1em] line-clamp-1">
                                 © 2026 West Monroe Partners | Reproduction and/or distribution without West Monroe Partners' prior consent is prohibited.
                               </p>
                            </div>
                            <span className="text-sm font-black text-[#002855]">1</span>
                          </div>
                        </div>

                        {/* Slide 2: ROI & Details */}
                        <div className="bg-white border border-slate-100 rounded-[0.5rem] shadow-2xl overflow-hidden aspect-[16/9] flex flex-col relative group/slide h-full max-h-[600px] w-full">
                          {/* Background Pattern - Dot Grid Top Left */}
                          <div className="absolute top-4 left-4 w-40 h-40 opacity-[0.1] pointer-events-none" 
                               style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='12' height='12' viewBox='0 0 16 16' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='2' cy='2' r='1' fill='%23002855' /%3E%3C/svg%3E")` }} />
                          
                          <div className="p-12 md:p-16 flex-1 flex flex-col overflow-hidden relative z-10">
                            <div className="mb-6 md:mb-8">
                              <p className="text-[10px] font-black tracking-[0.4em] uppercase text-slate-400 mb-2 md:mb-3">
                                ROI OUTCOMES & KPI TARGETS
                              </p>
                              <h2 className="text-xl md:text-2xl font-black text-[#002855] leading-[1.2] tracking-tighter max-w-5xl">
                                {slide2Headline}
                              </h2>
                              <div className="h-px w-full bg-[#002855] mt-4" />
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 flex-1 min-h-0">
                                <div className="space-y-2 flex flex-col h-full overflow-hidden">
                                  <div className="flex items-center gap-2 text-[#002855] opacity-50 shrink-0">
                                    <TrendingUp size={14} />
                                    <span className="text-[9px] font-black uppercase tracking-widest">KPI Targets</span>
                                  </div>
                                    <div className="bg-slate-100 border border-slate-300 rounded-lg p-4 flex-1 overflow-y-auto">
                                    <ul className="grid grid-cols-1 gap-2">
                                      {kpis.map((kpi, idx) => (
                                        <li key={idx} className="flex items-center gap-2 text-[10px] font-bold text-slate-700">
                                          <div className="w-1 h-1 bg-slate-400 rounded-full shrink-0" />
                                          <span className="line-clamp-1">{kpi}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                </div>

                                <div className="space-y-2 flex flex-col h-full overflow-hidden">
                                  <div className="flex items-center gap-2 text-[#002855] opacity-50 shrink-0">
                                    <BookOpen size={14} />
                                    <span className="text-[9px] font-black uppercase tracking-widest">Assumptions</span>
                                  </div>
                                  <div className="bg-slate-100 border border-slate-300 rounded-lg p-4 flex-1 space-y-3 overflow-y-auto">
                                    {[
                                      `Availability of historical ${opp.facts[0]} data`,
                                      'Executive sponsorship for MDP transition',
                                      'Cloud-native toolchain readiness',
                                      'Unified governance and ownership model'
                                    ].map((assump, idx) => (
                                      <div key={idx} className="flex gap-2">
                                        <div className="w-1 h-3 bg-slate-300 rounded-full shrink-0 mt-0.5" />
                                        <p className="text-[10px] font-bold text-slate-600 leading-tight">{assump}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                <div className="space-y-2 flex flex-col h-full overflow-hidden">
                                  <div className="flex items-center gap-2 text-[#002855] opacity-50 shrink-0">
                                    <ShieldAlert size={14} />
                                    <span className="text-[9px] font-black uppercase tracking-widest">Risks & Mitigations</span>
                                  </div>
                                  <div className="bg-slate-800 border border-slate-700 rounded-lg p-4 flex-1 space-y-3 shadow-xl overflow-y-auto">
                                    {[
                                      { r: 'Data quality issues', m: 'Automated profiling' },
                                      { r: 'Tech complexity', m: 'Phased rollout' },
                                      { r: 'Change friction', m: 'Internal training' }
                                    ].map((item, idx) => (
                                      <div key={idx} className="space-y-0.5">
                                        <p className="text-[9px] font-black text-slate-100 uppercase tracking-widest truncate">{item.r}</p>
                                        <p className="text-[10px] font-bold text-slate-400">Mitigation: {item.m}</p>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                            </div>
                          </div>
                          
                          {/* West Monroe Footer */}
                          <div className="mt-auto bg-[#E7F0F7] px-12 md:px-16 py-4 md:py-6 flex items-center justify-between shrink-0">
                            <div className="flex items-center gap-3">
                              <div className="w-5 h-5 flex items-center justify-center rounded-sm">
                                <div className="grid grid-cols-3 gap-0.5 w-4 h-4 text-[#002855]">
                                  {[...Array(9)].map((_, i) => (
                                    <div key={i} className={cn("w-1 h-1 bg-current rounded-full", i === 4 && "opacity-0")} />
                                  ))}
                                </div>
                              </div>
                              <span className="text-xl font-black tracking-tighter text-[#002855]">west monroe</span>
                            </div>
                            <div className="flex-1 text-center px-4">
                               <p className="text-[8px] font-bold text-[#002855]/60 uppercase tracking-[0.1em] line-clamp-1">
                                 © 2026 West Monroe Partners | Reproduction and/or distribution without West Monroe Partners' prior consent is prohibited.
                               </p>
                            </div>
                            <span className="text-sm font-black text-[#002855]">2</span>
                          </div>
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  <div className="h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-300 rounded-lg bg-white shadow-sm relative overflow-hidden">
                    <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                      <Briefcase size={48} className="text-primary/10" />
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">
                      Select a Use Case
                    </h3>
                    <p className="text-slate-500 max-w-md mx-auto leading-relaxed text-lg">
                      Select one of your marked opportunities from the prompt pane on the left to generate the detailed business case slides.
                    </p>
                  </div>
                )}
              </motion.div>

            ) : activeTab === 'assets' ? (
              <motion.div 
                key="assets-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {!currentModel && !currentDashboard ? (
                  <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-200 rounded-[2rem] bg-white shadow-sm relative overflow-hidden">
                    <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                      <Database size={48} className="text-primary/20" />
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight">
                      Select an Asset
                    </h3>
                    <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
                      Select a model or dashboard from the sidebar to view its details in the Project Assets view.
                    </p>
                  </div>
                ) : currentDashboard ? (
                  <DashboardView 
                    dashboard={currentDashboard} 
                    filters={dashboardFilters}
                    setFilters={setDashboardFilters}
                    companyName={companyName}
                  />
                ) : (
                  <Tabs value={assetSubTab} onValueChange={setAssetSubTab} className="w-full">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <Badge className={cn(
                            "border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm",
                            currentModel?.tableType === 'Fact' 
                              ? "bg-primary text-white" 
                              : "bg-blue-600 text-white"
                          )}>
                            {currentModel?.tableType}
                          </Badge>
                          <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold text-[10px] uppercase tracking-widest px-3">
                            {currentModel?.modelComplexity}
                          </Badge>
                          <div className="h-4 w-px bg-slate-200" />
                          <span className="text-slate-400 font-bold text-[10px] uppercase tracking-widest flex items-center gap-1.5">
                            <Database size={12} />
                            {currentModel?.industry}
                          </span>
                        </div>
                        <h2 className="text-4xl font-black text-slate-900 tracking-tight">
                          {currentModel?.tableName}
                        </h2>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <TabsList className="bg-slate-100 p-1 rounded-xl border border-slate-200">
                          <TabsTrigger value="schema" className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm">Schema</TabsTrigger>
                          <TabsTrigger value="star" className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm">Star Schema</TabsTrigger>
                          <TabsTrigger value="sttm" className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-lg data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm">STTM Map</TabsTrigger>
                        </TabsList>
                      </div>
                    </div>

                    <TabsContent value="schema" className="space-y-8">
                      <Card className="shadow-sm border border-slate-200 rounded-[2rem] overflow-hidden bg-white">
                        <CardHeader className="pb-4 border-b border-slate-100 bg-slate-50">
                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <CardTitle className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                                <Database size={12} className="text-primary" />
                                MODEL OVERVIEW
                              </CardTitle>
                              <CardDescription className="text-[10px] text-slate-500 font-medium">
                                Detailed technical specification for the {currentModel?.tableName} {currentModel?.tableType} table.
                              </CardDescription>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="bg-white border-slate-200 text-slate-500 font-mono text-[10px]">
                                {currentModel?.columns.length} Columns
                              </Badge>
                              
                              <div className="flex items-center bg-white border-2 border-primary/20 rounded-xl p-1 shadow-md animate-in zoom-in-95 duration-300">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-9 rounded-lg text-primary font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-primary hover:text-white transition-all"
                                  onClick={() => currentModel && copyTableToClipboard(currentModel)}
                                  title="Copy Table to Clipboard"
                                >
                                  <Copy size={14} />
                                  Copy Table
                                </Button>
                                <div className="w-px h-5 bg-slate-200 mx-1" />
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-9 rounded-lg text-emerald-600 font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-emerald-600 hover:text-white transition-all"
                                  onClick={() => currentModel && exportToCSV(currentModel)}
                                  title="Export to CSV"
                                >
                                  <FileText size={14} />
                                  CSV
                                </Button>
                                <div className="w-px h-5 bg-slate-200 mx-1" />
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-9 rounded-lg text-blue-600 font-black gap-2 px-4 text-[11px] uppercase tracking-wider hover:bg-blue-600 hover:text-white transition-all border border-slate-400"
                                  onClick={() => currentModel && exportToExcel(currentModel)}
                                  title="Export to Excel"
                                >
                                  <TableIcon size={14} />
                                  Excel
                                </Button>
                                <div className="w-px h-5 bg-slate-200 mx-1" />
                                <DropdownMenu>
                                  <DropdownMenuTrigger render={(triggerProps) => (
                                    <Button 
                                      {...triggerProps}
                                      variant="ghost" 
                                      size="sm" 
                                      className="h-9 w-9 rounded-lg text-slate-400 hover:text-primary hover:bg-slate-100 p-0 border border-slate-400"
                                    >
                                      <Download size={16} />
                                    </Button>
                                  )} />
                    <DropdownMenuContent align="end" className="w-48 rounded-xl shadow-xl border-slate-400 border">
                                    <DropdownMenuLabel className="text-[10px] uppercase tracking-widest text-slate-400 px-4 py-2">More Formats</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem onClick={() => copyToClipboard(JSON.stringify(currentModel, null, 2))} className="gap-3 cursor-pointer px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider">
                                      <Copy size={16} className="text-slate-400" />
                                      <span>Copy JSON</span>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => currentModel && exportToWord(currentModel)} className="gap-3 cursor-pointer px-4 py-2.5 text-[11px] font-bold uppercase tracking-wider">
                                      <PenTool size={16} className="text-slate-400" />
                                      <span>Export Word</span>
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="p-0">
                          {currentModel?.tableType === 'Fact' && (
                            <div className="p-8 bg-slate-100 border-b border-slate-200">
                              <div className="w-full">
                                <StarSchemaDiagram 
                                  factTable={currentModel} 
                                  dimensions={getRelatedDimensions(currentModel)} 
                                  onTableClick={setSelectedStarTable}
                                  selectedTableId={selectedStarTable?.id}
                                />
                              </div>
                            </div>
                          )}
                          
                          {selectedStarTable && selectedStarTable.id !== currentModel?.id && (
                            <div className="p-4 bg-primary/5 border-b border-primary/10 flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                               <div className="bg-primary text-white p-1.5 rounded-md">
                                 {selectedStarTable.tableType === 'Fact' ? <Layers size={14} /> : <Layout size={14} />}
                               </div>
                               <div>
                                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Viewing Schema: {selectedStarTable.tableType}</span>
                                 <h4 className="text-sm font-bold text-slate-900 uppercase">{selectedStarTable.tableName}</h4>
                               </div>
                               <Button 
                                 variant="ghost" 
                                 size="sm" 
                                 className="ml-auto text-[10px] font-bold uppercase tracking-widest"
                                 onClick={() => setSelectedStarTable(currentModel)}
                               >
                                 Back to {currentModel?.tableName}
                               </Button>
                            </div>
                          )}
                          
                          <div className="overflow-x-auto">
                            <Table>
                              <TableHeader className="bg-slate-50 border-b border-slate-200">
                                <TableRow className="hover:bg-transparent border-slate-200">
                                  <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Column Name</TableHead>
                                  <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Display Name</TableHead>
                                  <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Datatype</TableHead>
                                  <TableHead className="w-[60px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Size</TableHead>
                                  <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">PK</TableHead>
                                  <TableHead className="w-[120px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">FK To</TableHead>
                                  <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">NULL?</TableHead>
                                  <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Default Value</TableHead>
                                  <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Example Values</TableHead>
                                  <TableHead className="w-[200px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Description</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {((selectedStarTable || currentModel)?.columns || []).map((col, i) => (
                                  <TableRow 
                                    key={i} 
                                    className={cn(
                                      "border-slate-50 hover:bg-slate-50/50 transition-colors",
                                      col.isPk && "bg-primary/5",
                                      col.columnName.startsWith('sys_') && "bg-slate-50"
                                    )}
                                  >
                                    <TableCell className={cn(
                                      "font-mono text-[10px] py-1 px-4",
                                      col.isPk ? "text-primary font-bold" : (currentModel?.tableType === 'Fact' && col.fkTo) ? "text-slate-900 font-black" : col.columnName.startsWith('sys_') ? "text-slate-400" : "text-slate-600 font-medium"
                                    )}>
                                      {col.columnName}
                                    </TableCell>
                                    <TableCell className="text-slate-900 font-bold text-xs py-1">
                                      {col.businessName}
                                    </TableCell>
                                    <TableCell className="py-1">
                                      <Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-slate-500">{col.datatype}</Badge>
                                    </TableCell>
                                    <TableCell className="py-1">
                                      <span className="text-[10px] text-slate-500 font-mono">{col.size}</span>
                                    </TableCell>
                                    <TableCell className="text-center py-1">
                                      {col.isPk ? (
                                        <Badge className="bg-primary text-white border-none text-[8px] font-black px-1.5 py-0">PK</Badge>
                                      ) : (
                                        <span className="text-slate-300">—</span>
                                      )}
                                    </TableCell>
                                    <TableCell className="py-1">
                                      {col.fkTo ? (
                                        <div className="flex items-center gap-1.5 text-blue-600">
                                          <Link2 size={10} />
                                          <span className="text-[10px] font-bold font-mono">{col.fkTo}</span>
                                        </div>
                                      ) : (
                                        <span className="text-slate-300">—</span>
                                      )}
                                    </TableCell>
                                    <TableCell className="text-center py-1">
                                      <span className={cn(
                                        "text-[9px] font-black uppercase tracking-widest",
                                        col.isNullable ? "text-slate-400" : "text-slate-600"
                                      )}>
                                        {col.isNullable ? 'YES' : 'NO'}
                                      </span>
                                    </TableCell>
                                    <TableCell className="py-1 text-[10px] text-slate-500 font-mono">
                                      {col.defaultValue || <span className="text-slate-300">—</span>}
                                    </TableCell>
                                    <TableCell className="py-1 text-[10px] text-slate-500 font-mono italic">
                                      {col.exampleValues || 'N/A'}
                                    </TableCell>
                                    <TableCell className="text-slate-500 text-[10px] leading-tight py-1 px-4 max-w-[300px]">
                                      {col.description}
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                          
                          <div className="p-4 bg-slate-50 border-t border-slate-200">
                            <div className="flex items-center gap-2 text-primary mb-2">
                              <Info size={14} className="text-primary" />
                              <span className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Technical Details</span>
                            </div>
                            <p className="text-[10px] text-slate-500 leading-relaxed max-w-4xl">
                              {currentModel?.tableType === 'Dimension' 
                                ? `This dimension table provides descriptive attributes for ${currentModel?.tableName.replace('Dim_', '')} entities, enabling multi-dimensional analysis and slicing of business metrics.`
                                : `This fact table captures quantitative business events and measurements for ${currentModel?.subjectArea}, serving as the central hub for analytical queries and KPI calculations.`}
                              {" "}The schema is optimized for high-performance analytical processing and historical data integrity.
                            </p>
                          </div>
                        </CardContent>
                      </Card>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <Card className="shadow-sm border border-slate-200 rounded-[2rem] overflow-hidden bg-white">
                          <CardHeader className="pb-4 border-b border-slate-100 bg-slate-50">
                            <CardTitle className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                              <Settings2 size={12} className="text-primary" />
                              Default Values & Logic
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pt-6 space-y-4">
                            {(currentModel?.columns || []).filter(c => c.defaultValue).map((col, i) => (
                              <div key={i} className="flex items-center justify-between gap-4 p-3 rounded-xl bg-slate-50 border border-slate-200 group hover:border-primary/30 transition-colors">
                                <span className="font-bold text-xs text-slate-900">{col.columnName}</span>
                                <Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-primary shadow-sm">
                                  {col.defaultValue}
                                </Badge>
                              </div>
                            ))}
                            {(currentModel?.columns || []).filter(c => c.defaultValue).length === 0 && (
                              <div className="py-8 text-center">
                                <p className="text-xs text-slate-400 font-medium italic">No explicit default values defined.</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>

                        <Card className="shadow-sm border border-slate-200 rounded-[2rem] overflow-hidden bg-white">
                          <CardHeader className="pb-4 border-b border-slate-100 bg-slate-50">
                            <CardTitle className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                              <Sparkles size={12} className="text-primary" />
                              Example Data Preview
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="pt-6">
                            <ScrollArea className="h-[400px] pr-4">
                              <div className="grid grid-cols-1 gap-3">
                                {(currentModel?.columns || []).map((col, i) => (
                              <div key={i} className="flex flex-col gap-1.5 p-3 rounded-lg bg-slate-100 border border-slate-300 group hover:border-primary/30 transition-colors">
                                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{col.businessName}</span>
                                    <div className="flex flex-wrap gap-1">
                                      {(col.exampleValues || 'N/A').split(';').map((val, idx) => (
                                        <Badge key={idx} variant="secondary" className="text-[10px] font-mono bg-white border-slate-200 text-slate-700">
                                          {val.trim()}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </CardContent>
                        </Card>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="star">
                      <Card className="shadow-sm border border-slate-300 rounded-lg bg-white p-8 min-h-[600px] flex flex-col items-center overflow-auto relative">
                        <div className="w-full">
                          {currentModel && currentModel.tableType === 'Fact' ? (
                            <>
                              <StarSchemaDiagram 
                                factTable={currentModel} 
                                dimensions={getRelatedDimensions(currentModel)} 
                                onTableClick={setSelectedStarTable}
                                selectedTableId={selectedStarTable?.id}
                              />
                              
                              {selectedStarTable && (
                                <div className="w-full mt-8 border-t border-slate-100 pt-8 animate-in fade-in slide-in-from-top-4">
                                  <div className="flex items-center gap-3 mb-6">
                                    <div className={cn(
                                      "p-2 rounded-lg",
                                      selectedStarTable.tableType === 'Fact' ? "bg-slate-900 text-white" : "bg-slate-800 text-white"
                                    )}>
                                      {selectedStarTable.tableType === 'Fact' ? <Layers size={18} /> : <Layout size={18} />}
                                    </div>
                                    <div className="flex flex-col">
                                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                        Table Schema: {selectedStarTable.tableType}
                                      </span>
                                      <h4 className="text-xl font-black text-slate-900 tracking-tight uppercase">
                                        {selectedStarTable.tableName}
                                      </h4>
                                    </div>
                                  </div>
                                  <div className="overflow-x-auto rounded-xl border border-slate-200">
                                    <Table>
                                      <TableHeader className="bg-slate-50 border-b border-slate-200">
                                        <TableRow className="hover:bg-transparent border-slate-200">
                                          <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Column Name</TableHead>
                                          <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Display Name</TableHead>
                                          <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Datatype</TableHead>
                                          <TableHead className="w-[60px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Size</TableHead>
                                          <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">PK</TableHead>
                                          <TableHead className="w-[120px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">FK To</TableHead>
                                          <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Description</TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {((selectedStarTable || currentModel)?.columns || []).map((col: ColumnDefinition, i: number) => (
                                          <TableRow 
                                            key={i} 
                                            className={cn(
                                              "border-slate-50 hover:bg-slate-50/50 transition-colors", 
                                              col.isPk && "bg-primary/5",
                                              col.columnName.startsWith('sys_') && "bg-slate-50"
                                            )}
                                          >
                                            <TableCell className={cn(
                                              "font-mono text-[10px] py-2 px-4", 
                                              col.isPk ? "text-primary font-bold" : col.columnName.startsWith('sys_') ? "text-slate-400" : "text-slate-600 font-medium"
                                            )}>{col.columnName}</TableCell>
                                            <TableCell className="text-slate-900 font-bold text-xs py-2">{col.businessName}</TableCell>
                                            <TableCell className="py-2"><Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-slate-500">{col.datatype}</Badge></TableCell>
                                            <TableCell className="py-2"><span className="text-[10px] text-slate-500 font-mono">{col.size}</span></TableCell>
                                            <TableCell className="text-center py-2">{col.isPk ? <Badge className="bg-primary text-white border-none text-[8px] font-black px-1.5 py-0">PK</Badge> : <span className="text-slate-300">—</span>}</TableCell>
                                            <TableCell className="py-2">{col.fkTo ? <div className="flex items-center gap-1.5 text-blue-600 font-bold font-mono text-[10px]"><Link2 size={10} />{col.fkTo}</div> : <span className="text-slate-300">—</span>}</TableCell>
                                            <TableCell className="text-slate-500 text-[10px] leading-tight py-2 px-4 whitespace-normal min-w-[200px]">{col.description}</TableCell>
                                          </TableRow>
                                        ))}
                                      </TableBody>
                                    </Table>
                                  </div>
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="flex flex-col items-center justify-center py-24 text-slate-300">
                              <Share2 size={48} className="opacity-20 mb-4" />
                              <p className="text-sm font-bold uppercase tracking-widest italic">Select a Fact table to view its Star Schema.</p>
                            </div>
                          )}
                        </div>
                      </Card>
                    </TabsContent>

                    <TabsContent value="sttm">
                      {sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id) ? (
                        <STTMView 
                          mapping={sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id)!}
                          targetTable={currentModel!}
                          viewMode={sttmViewMode}
                          onCopy={() => {
                            const mapping = sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id);
                            if (mapping && currentModel) copySTTMToClipboard(mapping, currentModel);
                          }}
                          onExportCSV={() => {
                            const mapping = sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id);
                            if (mapping && currentModel) exportSTTMToCSV(mapping, currentModel);
                          }}
                          onExportExcel={() => {
                            const mapping = sttmMappings.find(m => m.targetTableId === currentModel?.id || m.tableId === currentModel?.id);
                            if (mapping && currentModel) exportSTTMToExcel(mapping, currentModel);
                          }}
                          onClearMapping={(colName) => handleClearMapping(currentModel!.id, colName)}
                          onDelete={() => {
                            setSttmMappings(prev => prev.filter(m => m.targetTableId !== currentModel?.id && m.tableId !== currentModel?.id));
                            toast.success(`Deleted STTM mapping for ${currentModel?.tableName}`);
                          }}
                        />
                      ) : (
                        <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-200 rounded-[2rem] bg-white shadow-sm relative overflow-hidden">
                          <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                            <ArrowRightLeft size={48} className="text-primary/20" />
                          </div>
                          <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">
                            No Mapping Generated
                          </h3>
                          <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
                            Go to the STTM tab to generate a Source-to-Target mapping for {currentModel?.tableName}.
                          </p>
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                )}
              </motion.div>
            ) : activeTab === 'sttm' && selectedSttmAssetId ? (
              <motion.div 
                key="sttm-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {sttmMappings.find(m => m.targetTableId === selectedSttmAssetId || m.tableId === selectedSttmAssetId) ? (
                  <STTMView 
                    mapping={sttmMappings.find(m => m.targetTableId === selectedSttmAssetId || m.tableId === selectedSttmAssetId)!}
                    targetTable={filteredHistory.find(h => h.id === selectedSttmAssetId)!}
                    viewMode={sttmViewMode}
                    onCopy={() => {
                      const mapping = sttmMappings.find(m => m.targetTableId === selectedSttmAssetId || m.tableId === selectedSttmAssetId);
                      const targetTable = history.find(h => h.id === selectedSttmAssetId);
                      if (mapping && targetTable) copySTTMToClipboard(mapping, targetTable);
                    }}
                    onExportCSV={() => {
                      const mapping = sttmMappings.find(m => m.targetTableId === selectedSttmAssetId || m.tableId === selectedSttmAssetId);
                      const targetTable = history.find(h => h.id === selectedSttmAssetId);
                      if (mapping && targetTable) exportSTTMToCSV(mapping, targetTable);
                    }}
                    onExportExcel={() => {
                      const mapping = sttmMappings.find(m => m.targetTableId === selectedSttmAssetId || m.tableId === selectedSttmAssetId);
                      const targetTable = history.find(h => h.id === selectedSttmAssetId);
                      if (mapping && targetTable) exportSTTMToExcel(mapping, targetTable);
                    }}
                    onClearMapping={(colName) => handleClearMapping(selectedSttmAssetId, colName)}
                    onDelete={() => {
                      setSttmMappings(prev => prev.filter(m => m.targetTableId !== selectedSttmAssetId && m.tableId !== selectedSttmAssetId));
                      const table = history.find(h => h.id === selectedSttmAssetId);
                      toast.success(`Deleted STTM mapping for ${table?.tableName}`);
                    }}
                  />
                ) : (
                  <div className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 border border-slate-200 rounded-[2rem] bg-white shadow-sm relative overflow-hidden">
                    <div className="w-24 h-24 bg-slate-50 rounded-3xl flex items-center justify-center text-primary mb-8 mx-auto border border-slate-200">
                      <ArrowRightLeft size={48} className="text-primary/20" />
                    </div>
                    <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight uppercase">
                      No Mapping Generated
                    </h3>
                    <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
                      Provide a source definition in the sidebar and click "Generate Mapping" to create the Source-to-Target mapping for {filteredHistory.find(h => h.id === selectedSttmAssetId)?.tableName}.
                    </p>
                  </div>
                )}
              </motion.div>
            ) : activeTab === 'estimates-platform' && platformEstimates.length > 0 ? (
              <motion.div 
                key="platform-estimates-results"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="flex flex-col h-full pb-4"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 px-2 shrink-0">
                  <div className="space-y-1.5 text-left">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge className="bg-primary text-white border-none px-2 py-0.5 text-[8px] font-black uppercase tracking-[0.1em]">
                        Strategic Analysis
                      </Badge>
                      <Badge variant="outline" className="border-slate-300 text-slate-500 font-bold text-[8px] uppercase tracking-widest px-2">
                        {selectedEnvironments.join(' + ')}
                      </Badge>
                    </div>
                    <h2 className="text-xl font-black text-slate-900 tracking-tighter uppercase leading-none mt-4">
                      MDP Architecture and Cost Comparison
                      {currentScenarioId && (
                        <span className="ml-4 text-slate-400 font-medium normal-case tracking-normal text-sm">
                          — {scenarioName} {lastGeneratedAt ? `(${new Date(lastGeneratedAt).toLocaleString()})` : ""}
                        </span>
                      )}
                    </h2>
                    <div className="h-2" />
                    <p className="text-[13px] text-slate-900 font-normal leading-relaxed w-full">
                      Disclaimer: Calculation models strictly use Pay-As-You-Go (PAYG) rates without reserved pricing. Total storage assumes Bronze + 100% overhead for Silver/Gold layers. Estimates are architectural directional and exclude {preferredCloud} Private Link/Networking and egress costs.
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-1.5 self-start mt-6">
                    <Button 
                      variant="outline"
                      className="bg-white border-slate-200 text-slate-600 font-bold text-[9px] uppercase tracking-wider h-8 px-4 rounded-xl hover:bg-slate-50 shadow-sm transition-all flex items-center gap-2"
                      onClick={handleExportPlatformEstimatesToExcel}
                    >
                      <FileSpreadsheet size={14} className="text-emerald-600" />
                      Export Workbook
                    </Button>
                    <Button 
                      variant="outline"
                      className="bg-white border-slate-200 text-slate-600 font-black text-[8px] uppercase tracking-wider h-7 px-3 rounded-lg hover:bg-slate-50 shadow-sm"
                      onClick={() => {
                        const content = platformEstimates.map(p => 
                          `Platform: ${p.platformName}\n` +
                          `Monthly Cost: $${Number((p.estimatedMonthlyCost / 1000).toFixed(2))}K\n` +
                          `Recommendation: ${p.recommendation}\n`
                        ).join('\n---\n');
                        copyToClipboard(content);
                      }}
                    >
                      <Copy size={10} className="mr-1" />
                      Copy
                    </Button>

                    {!isSidebarVisible && (
                       <Button 
                        className="bg-primary border-none text-white font-black text-[8px] uppercase tracking-wider h-7 px-3 rounded-lg hover:bg-primary/90 shadow-lg shadow-primary/20"
                        onClick={handleGeneratePlatformEstimates}
                        disabled={loading}
                      >
                        {loading ? <Loader2 size={10} className="mr-1 animate-spin" /> : <Calculator size={10} className="mr-1" />}
                        Recalculate
                      </Button>
                    )}
                  </div>
                </div>

                <div className="flex-1 overflow-x-auto scroll-smooth pb-8 custom-scrollbar group">
                    <div className="flex items-stretch gap-6 px-4 pb-4">
                      {platformEstimates.map((platform, idx) => (
                        <div 
                          key={idx} 
                          className="w-[520px] shrink-0 animate-in fade-in slide-in-from-right-8 duration-700 flex flex-col" 
                          style={{ animationDelay: `${idx * 150}ms` }}
                        >
                          <Card className="rounded-[1.25rem] border border-slate-200 shadow-md bg-white flex flex-col group/card hover:border-primary/40 transition-all duration-500 overflow-visible mb-4 h-full">
                          {/* Refined Header */}
                          <div className="bg-white px-5 py-4 flex items-center justify-between shrink-0 border-b border-slate-200 w-full mb-1">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 flex items-center justify-center shrink-0">
                                {platform.platformName.includes('Databricks') ? (
                                  <img src="https://upload.wikimedia.org/wikipedia/commons/6/63/Databricks_Logo.png" alt="db" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                                ) : platform.platformName.includes('Snowflake') ? (
                                  <img src="https://upload.wikimedia.org/wikipedia/commons/f/ff/Snowflake_Logo.svg" alt="sf" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                                ) : platform.platformName.includes('Fabric') ? (
                                  <div className="text-[#0078D4]"><Database size={32} /></div>
                                ) : platform.platformName.includes('AWS') ? (
                                  <img src="https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg" alt="aws" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                                ) : platform.platformName.includes('GCP') || platform.platformName.includes('Google') ? (
                                  <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Google_Cloud_logo.svg" alt="gcp" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                                ) : (
                                  <div className="text-slate-400">
                                    <Layers size={32} />
                                  </div>
                                )}
                              </div>
                              <div className="flex flex-col gap-0.5">
                                <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight leading-none">{platform.platformName}</h3>
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Complexity:</span>
                                  <Tooltip>
                                    <TooltipTrigger render={(triggerProps) => (
                                      <div {...triggerProps}>
                                        <span 
                                          className={cn(
                                            "text-[10px] font-black uppercase tracking-wider cursor-help",
                                            platform.complexity === 'High' ? "text-red-600" :
                                            platform.complexity === 'Medium' ? "text-amber-600" :
                                            "text-emerald-600"
                                          )}
                                        >
                                          {platform.complexity}
                                        </span>
                                      </div>
                                    )} />
                                    <TooltipContent side="bottom" className="w-64 bg-slate-900 border-slate-800 text-white p-4 shadow-2xl rounded-xl">
                                      <div className="space-y-2">
                                        <p className="text-emerald-400 font-black text-[10px] uppercase tracking-widest border-b border-white/10 pb-1">Complexity Logic</p>
                                        <p className="text-xs font-bold leading-relaxed">{platform.complexityJustification}</p>
                                      </div>
                                    </TooltipContent>
                                  </Tooltip>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col items-end gap-1">
                              <div className="flex items-center justify-between w-full min-w-[150px] mb-0.5">
                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Monthly</span>
                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-4">Annual</span>
                                <button 
                                  onClick={() => setSelectedDiagram({ 
                                    platform: platform.platformName, 
                                    chart: platform.mermaidDiagram || (
                                    platform.platformName.includes('Databricks') ? `graph LR\n  subgraph Ingestion\n    Sources[🏢 Sources] --> Lakeflow[🔄 Lakeflow]\n  end\n  subgraph Storage\n    Lakeflow --> Bronze[🥉 Bronze]\n    Bronze --> Silver[🥈 Silver]\n    Silver --> Gold[🥇 Gold]\n  end\n  subgraph Processing\n    Gold --> DLT[⚙️ Delta Live Tables]\n  end\n  subgraph Consumption\n    DLT --> BI[📊 BI Tool]\n    DLT --> Users[👤 End Users]\n  end\n  Unity[🛡️ Unity Catalog] -.-> Storage` :
                                    platform.platformName.includes('Snowflake') ? `graph LR\n  subgraph Ingestion\n    Sources[🏢 Sources] --> Pipe[🔄 Snowpipe]\n  end\n  subgraph Storage\n    Pipe --> Bronze[🥉 Bronze]\n    Bronze --> Silver[🥈 Silver]\n    Silver --> Gold[🥇 Gold]\n  end\n  subgraph Processing\n    Gold --> Park[⚙️ Snowpark]\n  end\n  subgraph Consumption\n    Park --> BI[📊 BI Tool]\n    Park --> Users[👤 End Users]\n  end\n  Cortex[🧠 Cortex AI] -.-> Processing` :
                                    platform.platformName.includes('Fabric') ? `graph LR\n  subgraph Ingestion\n    Sources[🏢 Sources] --> DataFactory[🔄 Data Factory]\n  end\n  subgraph Storage\n    DataFactory --> Bronze[🥉 Bronze]\n    Bronze --> Silver[🥈 Silver]\n    Silver --> Gold[🥇 Gold]\n  end\n  subgraph Processing\n    Gold --> Engine[⚙️ Fabric Engine]\n  end\n  subgraph Consumption\n    Engine --> PBI[📊 Power BI]\n    Engine --> Users[👤 End Users]\n  end\n  Governance[🛡️ Purview] -.-> Storage` :
                                    `graph LR\n  subgraph Ingestion\n    Sources[🏢 Sources] --> Pipe[🔄 Pipeline]\n  end\n  subgraph Storage\n    Pipe --> Bronze[🥉 Bronze]\n    Bronze --> Silver[🥈 Silver]\n    Silver --> Gold[🥇 Gold]\n  end\n  subgraph Processing\n    Gold --> Engine[⚙️ Processing]\n  end\n  subgraph Consumption\n    Engine --> BI[📊 BI Tool]\n    Engine --> Users[👤 End Users]\n  end\n  Gov[🛡️ Governance] -.-> Storage`
                                  ),
                                    highlights: platform.mermaidHighlights,
                                    platformDetails: platform,
                                    inputs: {
                                      selectedPlatforms,
                                      biToolChoice,
                                      directSources: directSourcesCount,
                                      streamingSources: streamingSourcesCount,
                                      streamingPayloadMB: streamingPayloadSize,
                                      apiConnections: apiConnectionsCount,
                                      flatFiles: flatFilesCount,
                                      bronzeSizeTB: bronzeSize,
                                      cloudProvider: preferredCloud,
                                      batchFrequency,
                                      realtimeFrequencyMS: realtimeFrequency,
                                      environments: selectedEnvironments,
                                      selectedComponents,
                                      specialInstructions,
                                      advancedQuestionnaire
                                    }
                                  })}
                                  className="text-slate-400 hover:text-primary transition-all ml-4"
                                  title="View Architectural Diagram"
                                >
                                  <Glasses size={18} strokeWidth={2} />
                                </button>
                              </div>
                              
                              <div className="flex items-center gap-1 font-black text-lg uppercase tracking-tight">
                                <span className="text-slate-900 font-black tracking-tight">${Number((platform.estimatedMonthlyCost / 1000).toFixed(2))}K</span>
                                <span className="text-slate-200 font-normal mx-1">|</span>
                                <span className="text-slate-400 font-bold">${Number((platform.estimatedAnnualCost / 1000).toFixed(2))}K</span>
                              </div>
                            </div>
                          </div>


                          <div className="flex-1 p-3 space-y-3">
                            {/* Summary Cost Pill Group */}
                            <div className="grid grid-cols-3 gap-2">
                                {[
                                  { label: 'Storage', val: platform.summaryBreakdown.storage, icon: HardDrive, color: 'text-blue-600', bg: 'bg-blue-50' },
                                  { label: 'Compute', val: platform.summaryBreakdown.compute, icon: Cpu, color: 'text-primary', bg: 'bg-primary/5' },
                                  { label: 'Licensing', val: platform.summaryBreakdown.licensing, icon: Key, color: 'text-amber-600', bg: 'bg-amber-50' }
                                ].map((item, i) => (
                                  <div key={i} className={cn("p-2 rounded-lg border border-transparent hover:border-slate-200 transition-all text-center", item.bg)}>
                                    <div className="flex items-center justify-center gap-1 mb-1 text-slate-400">
                                      <item.icon size={10} />
                                      <span className="text-[8px] font-black uppercase tracking-tight">{item.label}</span>
                                    </div>
                                    <div className={cn("text-[11px] font-black leading-none", item.color)}>
                                      ${Number((item.val / 1000).toFixed(2))}K
                                    </div>
                                  </div>
                                ))}
                              </div>

                              {/* Detailed Breakdown Table */}
                              <div className="rounded-xl border border-slate-200 shadow-sm overflow-hidden bg-white">
                                  <table className="w-full text-left border-collapse table-fixed">
                                    <thead>
                                      <tr className="bg-slate-50 border-b border-slate-200">
                                        <th className="w-[45%] px-3 py-2 text-[9px] font-black text-slate-400 uppercase tracking-widest">Service Item</th>
                                        <th className="w-[35%] px-3 py-2 text-[9px] font-black text-slate-400 uppercase tracking-widest border-l border-slate-100">Assumption</th>
                                        <th className="w-[20%] px-3 py-2 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right border-l border-slate-100">Mo. Cost</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {(() => {
                                        const items = platform.detailedMonthlyBreakdown;
                                        const groups: Record<string, typeof items> = {
                                          'DEV': [],
                                          'QA': [],
                                          'PROD': [],
                                          'SHARED': []
                                        };

                                        items.forEach(item => {
                                          const env = ['DEV', 'QA', 'PROD'].find(e => item.service.toUpperCase().startsWith(e + ":"));
                                          if (env) {
                                            groups[env].push({
                                              ...item,
                                              service: item.service.substring(env.length + 1).trim()
                                            });
                                          } else {
                                            groups['SHARED'].push(item);
                                          }
                                        });

                                        return ['DEV', 'QA', 'PROD', 'SHARED'].map(envKey => {
                                          const envItems = groups[envKey];
                                          if (envItems.length === 0) return null;
                                          return (
                                            <React.Fragment key={envKey}>
                                              <tr className="bg-slate-100/50">
                                                <td colSpan={3} className="px-3 py-1.5 text-[8px] font-black text-slate-500 uppercase tracking-[0.2em] border-b border-slate-200">
                                                  {envKey === 'SHARED' ? 'Shared / Global Services' : `${envKey} Environment`}
                                                </td>
                                              </tr>
                                              {envItems.map((item, i) => (
                                                <tr key={i} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition-colors">
                                                  <td className="px-3 py-2 text-[11px] font-bold text-slate-700 leading-tight">
                                                    {item.service.replace(/[\s\(\)]*Per User[\s\(\)]*/gi, '').trim()}
                                                  </td>
                                                  <td className="px-3 py-2 border-l border-slate-50 italic text-[10px] text-slate-400 font-medium leading-tight">{item.assumption}</td>
                                                  <td className="px-3 py-2 text-[11px] font-black text-slate-900 text-right font-mono border-l border-slate-50">
                                                    {(() => {
                                                      const val = typeof item.monthlyCost === 'number' ? item.monthlyCost : parseFloat(item.monthlyCost as any);
                                                      if (isNaN(val) || val === null || val === undefined) {
                                                        return '$0';
                                                      }
                                                      return Math.round(val * 100) % 100 === 0
                                                        ? `$${Math.round(val).toLocaleString('en-US')}`
                                                        : `$${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                                                    })()}
                                                  </td>
                                                </tr>
                                              ))}
                                            </React.Fragment>
                                          );
                                        });
                                      })()}
                                    </tbody>
                                  </table>
                              </div>

                              {/* Advisory Section */}
                            <div className="pt-4 border-t border-slate-100 space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2 text-emerald-600">
                                    <TrendingUp size={12} />
                                    <span className="text-[9px] font-black uppercase tracking-widest">Core Pros</span>
                                  </div>
                                  <ul className="space-y-1.5">
                                    {platform.pros.slice(0, 3).map((pro, i) => (
                                      <li key={i} className="flex gap-2 items-start">
                                        <div className="mt-1 w-2.5 h-2.5 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                                          <Check size={6} className="text-emerald-700" />
                                        </div>
                                        <span className="text-[11px] text-slate-600 font-bold leading-tight">{pro}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2 text-rose-600">
                                    <TrendingDown size={12} />
                                    <span className="text-[9px] font-black uppercase tracking-widest">Key Cons</span>
                                  </div>
                                  <ul className="space-y-1.5">
                                    {platform.cons.slice(0, 3).map((con, i) => (
                                      <li key={i} className="flex gap-2 items-start">
                                        <div className="mt-1 w-2.5 h-2.5 rounded-full bg-rose-100 flex items-center justify-center shrink-0">
                                          <X size={6} className="text-rose-700" />
                                        </div>
                                        <span className="text-[11px] text-slate-600 font-bold leading-tight">{con}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              </div>

                              <div className="bg-primary/5 p-3 rounded-xl border border-primary/10 relative overflow-hidden">
                                <div className="absolute -top-2 -right-2 text-primary opacity-[0.03]">
                                  <Award size={48} />
                                </div>
                                <div className="flex items-center gap-2 text-primary mb-2">
                                  <Rocket size={12} />
                                  <span className="text-[9px] font-black uppercase tracking-widest">Architect Advisory</span>
                                </div>
                                <p className="text-[11px] text-slate-800 font-bold leading-relaxed relative z-10">
                                  {platform.recommendation}
                                </p>
                              </div>
                            </div>
                          </div>
                        </Card>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ) : activeTab === 'estimates-project' ? (
              <motion.div 
                key="estimates-project"
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.99 }}
                className="lg:h-[calc(100vh-115px)] h-full flex-1 flex flex-col min-h-0"
              >
                <div className="h-full border border-slate-200 rounded-md bg-white shadow-sm overflow-hidden flex flex-col flex-1 min-h-0">
                  <ProjectEstimatorView 
                    setActiveTab={setActiveTab} 
                    currentProjectId={currentProjectId}
                    currentProject={currentProject}
                    projectEstimateAssets={projectEstimateAssets}
                    setProjectEstimateAssets={setProjectEstimateAssets}
                    loadedProjectEstimateInputs={loadedProjectEstimateInputs}
                    setLoadedProjectEstimateInputs={setLoadedProjectEstimateInputs}
                    globalCompanyName={companyName}
                    globalIndustry={industry}
                  />
                </div>
              </motion.div>
            ) : activeTab === 'platform-comparison' ? (
              <motion.div
                key="platform-comparison-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6 flex-1 min-h-[calc(100vh-12rem)]"
              >
                <PlatformComparisonMatrixView 
                  currentProjectId={currentProjectId}
                  activeProjectName={currentProject?.name}
                  globalCompanyName={companyName}
                  globalIndustry={industry}
                  isSidebarVisible={isSidebarVisible}
                />
              </motion.div>
            ) : activeTab === 'estimates-platform' ? (
              <motion.div 
                key="estimates-platform"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="h-full"
              >
                <div className="h-full flex flex-col items-center justify-center text-center p-12 border border-slate-200 rounded-[1.5rem] bg-white shadow-sm relative overflow-hidden">
                  <div className="w-24 h-24 bg-primary/10 rounded-[2rem] flex items-center justify-center text-primary mb-10 mx-auto border border-primary/20 shadow-2xl shadow-primary/20 relative group-hover/btn:scale-110 transition-all duration-500">
                    <div className="absolute inset-0 bg-primary/5 rounded-[2rem] animate-pulse" />
                    <BarChart3 size={48} className="relative z-10 text-primary drop-shadow-md" />
                  </div>
                  
                  <div className="space-y-6 max-w-xl animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase">
                      MDP Platform Estimator
                    </h3>
                    <div className="space-y-4 text-left p-6 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex gap-4">
                        <div className="w-6 h-6 rounded-full bg-slate-900 flex items-center justify-center text-white text-[10px] font-black shrink-0">1</div>
                        <p className="text-[13px] text-slate-650 font-medium">Configure your <span className="font-bold text-slate-900">source topology</span> and data volume parameters in the left panel.</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-6 h-6 rounded-full bg-slate-900 flex items-center justify-center text-white text-[10px] font-black shrink-0">2</div>
                        <p className="text-[13px] text-slate-650 font-medium">Select the <span className="font-bold text-slate-900">environments</span> (DEV, QA, PROD) to include in the multi-environment pricing model.</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="w-6 h-6 rounded-full bg-slate-900 flex items-center justify-center text-white text-[10px] font-black shrink-0">3</div>
                        <p className="text-[13px] text-slate-650 font-medium">Select your preferred <span className="font-bold text-slate-900">platforms</span> and components like semantic layers or BI tools.</p>
                      </div>
                    </div>

                    <div className="pt-4">
                      <Button 
                        onClick={handleGeneratePlatformEstimates}
                        disabled={loading}
                        className="bg-primary text-white hover:bg-primary/90 h-14 px-10 rounded-2xl shadow-2xl shadow-primary/30 transition-all font-black uppercase tracking-widest text-xs gap-3 group/btn"
                      >
                        {loading ? (
                          <Loader2 className="animate-spin" size={18} />
                        ) : (
                          <Calculator size={18} className="group-hover/btn:rotate-12 transition-transform" />
                        )}
                        {loading ? "Synthesizing Model..." : "Generate Comparative Estimate"}
                      </Button>
                      <p className="mt-4 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
                        Powered by High-Reasoning AI Synthesis
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : activeTab === 'bi-dashboards' ? (
              <motion.div 
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1 flex flex-col space-y-6 min-h-0"
              >
                {isGeneratingBDDashboards ? (
                  <div className="flex-1 flex flex-col items-center justify-center p-12 border border-slate-200 rounded-2xl bg-white shadow-sm relative overflow-hidden group">
                    <div className="absolute inset-x-0 top-0 h-1 bg-slate-100">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 5, ease: "linear" }}
                        className="h-full bg-primary"
                      />
                    </div>
                    
                    <div className="space-y-12 max-w-md mx-auto relative z-10 text-center">
                      <div className="relative">
                        <div className="w-40 h-40 bg-white rounded-[2rem] flex items-center justify-center text-primary mx-auto border border-slate-100 shadow-2xl relative z-10 overflow-hidden">
                           <motion.div 
                             className="absolute inset-0 grid grid-cols-8 gap-px p-4 opacity-10"
                             animate={{ opacity: [0.1, 0.2, 0.1] }}
                             transition={{ duration: 2, repeat: Infinity }}
                           >
                             {Array.from({ length: 64 }).map((_, i) => (
                               <div key={i} className="bg-primary/40 rounded-[1px]" />
                             ))}
                           </motion.div>
                           <div className="relative z-20 flex flex-col items-center gap-2">
                             <BarChart3 size={48} className="text-slate-900" />
                             <div className="flex gap-1 justify-center">
                               {[0, 1, 2].map(i => (
                                 <motion.div 
                                   key={i}
                                   animate={{ height: [8, 20, 8] }}
                                   transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.2 }}
                                   className="w-1 bg-primary rounded-full" 
                                 />
                               ))}
                             </div>
                           </div>
                        </div>
                        <motion.div 
                          animate={{ 
                            scale: [1, 1.1, 1],
                            opacity: [0.2, 0.4, 0.2]
                          }}
                          transition={{ repeat: Infinity, duration: 4 }}
                          className="absolute -inset-10 bg-primary/10 blur-[60px] rounded-full -z-0"
                        />
                      </div>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <h3 className="text-xl font-black text-slate-900 tracking-tight uppercase">
                            {bdGenerationStatus || "Cognitive Synthesis Active"}
                          </h3>
                          <div className="flex items-center justify-center gap-3">
                            <span className="text-5xl font-black text-primary tracking-tighter tabular-nums">{bdGenerationTimer}s</span>
                          </div>
                        </div>
                        <p className="text-slate-500 leading-relaxed text-[11px] font-black uppercase tracking-[0.2em] opacity-60">
                          Synthesizing Decision Support Architecture
                        </p>
                      </div>
                      <div className="flex justify-center gap-1">
                        {Array.from({ length: 12 }).map((_, i) => (
                          <motion.div 
                            key={i}
                            animate={{ 
                              opacity: [0.2, 1, 0.2],
                              scaleY: [1, 1.5, 1]
                            }}
                            transition={{ 
                              repeat: Infinity, 
                              duration: 1, 
                              delay: i * 0.05 
                            }}
                            className="w-1 h-3 rounded-full bg-primary"
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                ) : selectedBDDashboardId ? (
                  (() => {
                    const dashboard = bdDashboards.find(d => d.id === selectedBDDashboardId);
                    return dashboard ? (
                      <ScrollArea className="flex-1 -mx-2 px-2 overflow-x-hidden min-h-0">
                        <div key={dashboard.id} className="animate-in fade-in slide-in-from-bottom-4 duration-500 flex flex-col min-h-full pb-8">
                          <SampleDashboardView dashboard={dashboard} />
                        </div>
                      </ScrollArea>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center p-12 border border-slate-200 rounded-lg bg-white shadow-sm italic text-slate-400">
                        Dashboard not found or deleted.
                        <Button variant="link" onClick={() => setSelectedBDDashboardId(null)} className="mt-4 text-primary">Return to selection</Button>
                      </div>
                    );
                  })()
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-12 border border-slate-200 rounded-[2.5rem] bg-white shadow-sm relative overflow-hidden group">
                    <div className="absolute inset-x-0 top-0 h-1.5 bg-slate-50">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 10, repeat: Infinity }}
                        className="h-full bg-gradient-to-r from-primary/10 via-primary to-primary/10"
                      />
                    </div>
                    <div className="relative z-10 space-y-8 max-w-2xl mx-auto">
                      <div className="w-24 h-24 bg-white rounded-[2rem] flex items-center justify-center text-primary mb-2 mx-auto border border-slate-100 shadow-xl shadow-slate-200/50 transition-all duration-500 group-hover:scale-110 group-hover:rotate-3">
                        <Lightbulb size={40} className="drop-shadow-sm" />
                      </div>
                      <div className="space-y-4">
                        <h3 className="text-3xl font-black text-slate-900 tracking-tight uppercase">
                          Dashboard Ideation
                        </h3>
                        <p className="text-slate-500 leading-relaxed text-[15px] font-medium max-w-md mx-auto">
                          Generate Sample Dashboards for targeted business use cases. 
                        </p>
                      </div>
 
                      <div className="bg-slate-50/80 backdrop-blur-sm p-8 rounded-xl border border-slate-100 shadow-sm text-left space-y-6">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-primary flex items-center gap-2">
                          <Info size={14} />
                          Synthesis Instructions
                        </h4>
                        <div className="space-y-4">
                          <p className="text-sm font-bold text-slate-700">
                            In <span className="text-primary underline underline-offset-4 decoration-2">Step 1: MDP Opportunities</span>, select the business cases you would like to model dashboards from.
                          </p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                            {[
                              { step: '01', title: 'Select Cases', desc: 'Pick target business cases in the prompt panel.' },
                              { step: '02', title: 'Define Volume', desc: 'Set how many variants to generate (1-12).' },
                              { step: '03', title: 'Pick Theme', desc: "Use 'Surprise Me' or define custom focus areas." },
                              { step: '04', title: 'Synthesize', desc: 'Click generate and wait for the AI render.' }
                            ].map((item, i) => (
                              <div key={i} className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-black text-primary/40 leading-none">{item.step}</span>
                                  <span className="text-xs font-black text-slate-900 uppercase tracking-tight">{item.title}</span>
                                </div>
                                <p className="text-[10px] text-slate-500 leading-relaxed font-medium">{item.desc}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 flex flex-col items-center gap-4">
                        <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 font-black px-4 py-1 uppercase tracking-widest text-[9px] animate-pulse">
                          Synthesis Prepared
                        </Badge>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest italic flex items-center gap-2">
                          Use the prompt pane on the left to begin
                          <ArrowRight size={10} className="animate-bounce-x" />
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            ) : currentDashboard ? (
              <motion.div 
                key="dashboard-view"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <DashboardView 
                  dashboard={currentDashboard} 
                  filters={dashboardFilters}
                  setFilters={setDashboardFilters}
                  companyName={companyName}
                />
              </motion.div>
            ) : (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <Tabs defaultValue="schema" className="w-full">
                  <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <Badge className={cn(
                          "border-none px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm",
                          currentModel?.tableType === 'Fact' 
                            ? "bg-primary text-white" 
                            : "bg-blue-600 text-white"
                        )}>
                          {currentModel?.tableType}
                        </Badge>
                        <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold text-[10px] uppercase tracking-widest px-3">
                          {currentModel?.modelComplexity}
                        </Badge>
                        <div className="h-4 w-px bg-slate-200" />
                        <span className="text-slate-400 font-bold text-[10px] uppercase tracking-widest flex items-center gap-1.5">
                          <Database size={12} />
                          {currentModel?.industry}
                        </span>
                      </div>
                      <h2 className="text-3xl font-black text-slate-900 tracking-tighter leading-tight">
                        {currentModel?.tableName}
                      </h2>
                      <p className="text-lg font-medium text-slate-500 tracking-tight mb-4">
                        {currentModel?.companyName}
                      </p>
                      <div className="max-w-3xl">
                        <p className="text-sm text-slate-600 leading-relaxed italic border-l-2 border-primary/20 pl-4">
                          "{currentModel?.description}"
                        </p>
                      </div>
                    </div>
                    
                    <TabsList className="bg-slate-100 p-1 rounded-2xl h-12 border border-slate-200">
                      <TabsTrigger value="schema" className="rounded-xl px-6 data-[state=active]:bg-primary data-[state=active]:text-white font-bold text-xs uppercase tracking-widest text-slate-500">
                        <Layout size={14} className="mr-2" />
                        Schema
                      </TabsTrigger>
                      {currentModel?.tableType === 'Fact' && (
                        <TabsTrigger value="star" className="rounded-xl px-6 data-[state=active]:bg-primary data-[state=active]:text-white font-bold text-xs uppercase tracking-widest text-slate-500">
                          <Share2 size={14} className="mr-2" />
                          Star Schema
                        </TabsTrigger>
                      )}
                    </TabsList>
                  </div>

                    <TabsContent value="schema" className="space-y-8">
                    <Card className="shadow-sm border border-slate-200 rounded-[2rem] overflow-hidden bg-white">
                      <CardHeader className="bg-slate-100 border-b border-slate-100 py-6 px-8">
                        <div className="flex flex-wrap gap-8 items-start justify-between">
                          <div className="space-y-3 flex-1 min-w-[300px]">
                            <h3 className="text-sm font-black uppercase tracking-[0.2em] text-primary">Model Overview</h3>
                            <p className="text-slate-500 text-xs">
                              Detailed technical specification for the {currentModel?.tableName} {currentModel?.tableType} table.
                            </p>
                          </div>
                          {currentModel?.tableType === 'Fact' && (
                            <div className="flex gap-6 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                              <div className="flex flex-col">
                                <span className="text-[9px] text-slate-400 uppercase font-black tracking-widest mb-1">Subject Area</span>
                                <span className="text-sm font-bold text-slate-900">{currentModel.subjectArea}</span>
                              </div>
                              <Separator orientation="vertical" className="h-10 bg-slate-200" />
                              <div className="flex flex-col">
                                <span className="text-[9px] text-slate-400 uppercase font-black tracking-widest mb-1">Fact Type</span>
                                <span className="text-sm font-bold text-slate-900">{currentModel.factType}</span>
                              </div>
                              {currentModel.aggregateGrain && (
                                <>
                                  <Separator orientation="vertical" className="h-10 bg-slate-200" />
                                  <div className="flex flex-col">
                                    <span className="text-[9px] text-slate-400 uppercase font-black tracking-widest mb-1">Grain</span>
                                    <span className="text-sm font-bold text-slate-900">{currentModel.aggregateGrain}</span>
                                  </div>
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="p-0">
                        {currentModel && currentModel.tableType === 'Fact' && (
                          <div className="p-8 bg-slate-50 border-b border-slate-200">
                            <StarSchemaDiagram 
                              factTable={currentModel} 
                              dimensions={getRelatedDimensions(currentModel)} 
                              onTableClick={setSelectedStarTable}
                              selectedTableId={selectedStarTable?.id}
                            />
                          </div>
                        )}
                        
                        {selectedStarTable && selectedStarTable.id !== currentModel?.id && (
                          <div className="p-4 bg-primary/5 border-b border-primary/10 flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                             <div className="bg-primary text-white p-1.5 rounded-md">
                               {selectedStarTable.tableType === 'Fact' ? <Layers size={14} /> : <Layout size={14} />}
                             </div>
                             <div>
                               <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Viewing Schema: {selectedStarTable.tableType}</span>
                               <h4 className="text-sm font-bold text-slate-900 uppercase">{selectedStarTable.tableName}</h4>
                             </div>
                             <Button 
                               variant="ghost" 
                               size="sm" 
                               className="ml-auto text-[10px] font-bold uppercase tracking-widest"
                               onClick={() => setSelectedStarTable(currentModel)}
                             >
                               Back to {currentModel?.tableName}
                             </Button>
                          </div>
                        )}
                        
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader className="bg-slate-50 border-b border-slate-200">
                              <TableRow className="hover:bg-transparent border-slate-200">
                                <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Column Name</TableHead>
                                <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Display Name</TableHead>
                                <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Datatype</TableHead>
                                <TableHead className="w-[60px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Size</TableHead>
                                <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">PK</TableHead>
                                <TableHead className="w-[120px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">FK To</TableHead>
                                <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">NULL?</TableHead>
                                <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Default Value</TableHead>
                                <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Example Values</TableHead>
                                <TableHead className="w-[200px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Description</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {((selectedStarTable || currentModel)?.columns || []).map((col, i) => (
                                <TableRow 
                                  key={i} 
                                  className={cn(
                                    "group transition-all hover:bg-slate-50 border-slate-200",
                                    col.columnName.startsWith('sys_') && "bg-slate-50"
                                  )}
                                >
                                  <TableCell className={cn(
                                    "font-bold font-mono text-[10px] py-1 px-4",
                                    col.columnName.startsWith('sys_') ? "text-slate-400" : "text-slate-900"
                                  )}>
                                    {col.columnName}
                                  </TableCell>
                                  <TableCell className="text-slate-900 font-bold text-xs py-1">
                                    {col.businessName}
                                  </TableCell>
                                  <TableCell className="py-1">
                                    <span className="text-[10px] font-black text-slate-600 uppercase">{col.datatype}</span>
                                  </TableCell>
                                  <TableCell className="py-1">
                                    <span className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter">{col.size || 'N/A'}</span>
                                  </TableCell>
                                  <TableCell className="text-center py-1">
                                    <span className="text-[9px] font-black uppercase tracking-widest text-slate-600">
                                      {col.isPk ? 'YES' : 'NO'}
                                    </span>
                                  </TableCell>
                                  <TableCell className="py-1">
                                    {col.fkTo ? (
                                      <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-100 font-bold text-[9px] uppercase tracking-widest px-1.5 py-0 h-4">
                                        {col.fkTo}
                                      </Badge>
                                    ) : (
                                      <span className="text-slate-300">—</span>
                                    )}
                                  </TableCell>
                                  <TableCell className="text-center py-1">
                                    <span className={cn(
                                      "text-[9px] font-black uppercase tracking-widest",
                                      col.isNullable ? "text-slate-400" : "text-slate-600"
                                    )}>
                                      {col.isNullable ? 'YES' : 'NO'}
                                    </span>
                                  </TableCell>
                                  <TableCell className="py-1 text-[10px] text-slate-500 font-mono">
                                    {col.defaultValue || <span className="text-slate-300">—</span>}
                                  </TableCell>
                                  <TableCell className="py-1 text-[10px] text-slate-500 font-mono italic">
                                    {col.exampleValues || 'N/A'}
                                  </TableCell>
                                  <TableCell className="text-slate-500 text-[10px] leading-tight py-1 px-4 max-w-[300px]">
                                    {col.description}
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                        
                        {/* Table Description Section Removed from here and moved up */}
                        <div className="p-4 bg-slate-50 border-t border-slate-200">
                          <div className="flex items-center gap-2 text-primary mb-2">
                            <Info size={14} className="text-primary" />
                            <span className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Technical Details</span>
                          </div>
                          <p className="text-[10px] text-slate-500 leading-relaxed max-w-4xl">
                            {currentModel?.tableType === 'Dimension' 
                              ? `This dimension table provides descriptive attributes for ${currentModel?.tableName.replace('Dim_', '')} entities, enabling multi-dimensional analysis and slicing of business metrics.`
                              : `This fact table captures quantitative business events and measurements for ${currentModel?.subjectArea}, serving as the central hub for analytical queries and KPI calculations.`}
                            {" "}The schema is optimized for high-performance analytical processing and historical data integrity.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <Card className="shadow-sm border border-slate-200 rounded-[2rem] overflow-hidden bg-white">
                        <CardHeader className="pb-4 border-b border-slate-100 bg-slate-50">
                          <CardTitle className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                            <Settings2 size={12} className="text-primary" />
                            Default Values & Logic
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-6 space-y-4">
                          {(currentModel?.columns || []).filter(c => c.defaultValue).map((col, i) => (
                            <div key={i} className="flex items-center justify-between gap-4 p-3 rounded-xl bg-slate-50 border border-slate-200 group hover:border-primary/30 transition-colors">
                              <span className="font-bold text-xs text-slate-900">{col.columnName}</span>
                              <Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-primary shadow-sm">
                                {col.defaultValue}
                              </Badge>
                            </div>
                          ))}
                          {(currentModel?.columns || []).filter(c => c.defaultValue).length === 0 && (
                            <div className="py-8 text-center">
                              <p className="text-xs text-slate-400 font-medium italic">No explicit default values defined.</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      <Card className="shadow-sm border border-slate-200 rounded-[2rem] overflow-hidden bg-white">
                        <CardHeader className="pb-4 border-b border-slate-100 bg-slate-50">
                          <CardTitle className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                            <Sparkles size={12} className="text-primary" />
                            Example Data Preview
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-6">
                          <ScrollArea className="h-[400px] pr-4">
                            <div className="grid grid-cols-1 gap-3">
                              {(currentModel?.columns || []).map((col, i) => (
                                <div key={i} className="flex flex-col gap-1.5 p-3 rounded-xl bg-slate-50 border border-slate-200 group hover:border-primary/30 transition-colors">
                                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{col.businessName}</span>
                                  <div className="flex flex-wrap gap-1">
                                    {(col.exampleValues || 'N/A').split(';').map((val, idx) => (
                                      <Badge key={idx} variant="secondary" className="text-[10px] font-mono bg-white border-slate-200 text-slate-700">
                                        {val.trim()}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="star">
                    <Card className="shadow-sm border border-slate-200 rounded-[2rem] bg-white p-8 min-h-[600px] flex flex-col items-center overflow-auto relative">
                      <div className="w-full max-w-5xl">
                        {currentModel && currentModel.tableType === 'Fact' ? (
                          <>
                            <StarSchemaDiagram 
                              factTable={currentModel} 
                              dimensions={getRelatedDimensions(currentModel)} 
                              onTableClick={setSelectedStarTable}
                              selectedTableId={selectedStarTable?.id}
                            />
                            
                            {selectedStarTable && (
                              <div className="w-full mt-8 border-t border-slate-100 pt-8 animate-in fade-in slide-in-from-top-4">
                                <div className="flex items-center gap-3 mb-6">
                                  <div className={cn(
                                    "p-2 rounded-lg",
                                    selectedStarTable.tableType === 'Fact' ? "bg-slate-900 text-white" : "bg-slate-800 text-white"
                                  )}>
                                    {selectedStarTable.tableType === 'Fact' ? <Layers size={18} /> : <Layout size={18} />}
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                                      Table Schema: {selectedStarTable.tableType}
                                    </span>
                                    <h4 className="text-xl font-black text-slate-900 tracking-tight uppercase">
                                      {selectedStarTable.tableName}
                                    </h4>
                                  </div>
                                </div>
                                <div className="overflow-x-auto rounded-xl border border-slate-200">
                                  <Table>
                                    <TableHeader className="bg-slate-50 border-b border-slate-200">
                                      <TableRow className="hover:bg-transparent border-slate-200">
                                        <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Column Name</TableHead>
                                        <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Display Name</TableHead>
                                        <TableHead className="w-[100px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Datatype</TableHead>
                                        <TableHead className="w-[60px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">Size</TableHead>
                                        <TableHead className="w-[50px] text-center font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">PK</TableHead>
                                        <TableHead className="w-[120px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5">FK To</TableHead>
                                        <TableHead className="w-[150px] font-black text-[10px] uppercase tracking-[0.15em] text-slate-400 py-1.5 px-4">Description</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {((selectedStarTable || currentModel)?.columns || []).map((col: ColumnDefinition, i: number) => (
                                        <TableRow 
                                          key={i} 
                                          className={cn(
                                            "border-slate-50 hover:bg-slate-50/50 transition-colors", 
                                            col.isPk && "bg-primary/5",
                                            col.columnName.startsWith('sys_') && "bg-slate-50"
                                          )}
                                        >
                                          <TableCell className={cn(
                                            "font-mono text-[10px] py-2 px-4", 
                                            col.isPk ? "text-primary font-bold" : col.columnName.startsWith('sys_') ? "text-slate-400" : "text-slate-600 font-medium"
                                          )}>{col.columnName}</TableCell>
                                          <TableCell className="text-slate-900 font-bold text-xs py-2">{col.businessName}</TableCell>
                                          <TableCell className="py-2"><Badge variant="outline" className="font-mono text-[10px] bg-white border-slate-200 text-slate-500">{col.datatype}</Badge></TableCell>
                                          <TableCell className="py-2"><span className="text-[10px] text-slate-500 font-mono">{col.size}</span></TableCell>
                                          <TableCell className="text-center py-2">{col.isPk ? <Badge className="bg-primary text-white border-none text-[8px] font-black px-1.5 py-0">PK</Badge> : <span className="text-slate-300">—</span>}</TableCell>
                                          <TableCell className="py-2">{col.fkTo ? <div className="flex items-center gap-1.5 text-blue-600 font-bold font-mono text-[10px]"><Link2 size={10} />{col.fkTo}</div> : <span className="text-slate-300">—</span>}</TableCell>
                                          <TableCell className="text-slate-500 text-[10px] leading-tight py-2 px-4 whitespace-normal min-w-[200px]">{col.description}</TableCell>
                                        </TableRow>
                                      ))}
                                    </TableBody>
                                  </Table>
                                </div>
                              </div>
                            )}
                          </>
                        ) : (
                          <div className="flex flex-col items-center justify-center py-24 text-slate-300">
                            <Share2 size={48} className="opacity-20 mb-4" />
                            <p className="text-sm font-bold uppercase tracking-widest italic">Select a Fact table to view its Star Schema.</p>
                          </div>
                        )}
                      </div>
                    </Card>
                  </TabsContent>
                </Tabs>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </Tabs>
  </main>

      {/* Footer */}
      {activeTab !== 'opps' && (
        <footer className="mt-auto border-t border-slate-800 py-4 bg-white">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-slate-400 text-sm">
              &copy; 2026 Paragon AI. Architected with Gemini. v1.3
            </p>
            <div className="flex items-center gap-6">
              <a 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  setIsDocumentationDialogOpen(true);
                }}
                className="flex items-center gap-2 text-primary font-black uppercase tracking-[0.2em] text-[10px] hover:scale-105 transition-all"
              >
                <BookOpen size={14} />
                Documentation
              </a>
              <a href="#" className="text-slate-400 hover:text-primary text-sm transition-colors">Best Practices</a>
              <a href="#" className="text-slate-400 hover:text-primary text-sm transition-colors">Privacy</a>
            </div>
          </div>
        </footer>
      )}
      {/* Dialogs */}
      <AdvancedQuestionnaireDialog 
        isOpen={isAdvancedQuestionnaireOpen}
        onClose={handleCloseAdvancedQuestionnaire}
        data={advancedQuestionnaire}
        onChange={handleAdvancedQuestionnaireChange}
        onSave={handleSaveAdvancedQuestionnaire}
        onClear={handleClearAdvancedQuestionnaire}
        hasChanges={hasUnsavedQuestionnaireChanges}
      />

      <Dialog open={isProjectDialogOpen} onOpenChange={setIsProjectDialogOpen}>
        <DialogContent className="bg-white border-slate-400 text-slate-900 border">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black tracking-tight">Create New Project</DialogTitle>
            <DialogDescription className="text-slate-500">
              Give your data warehouse project a meaningful name.
            </DialogDescription>
          </DialogHeader>
          <div className="py-6 space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl flex items-center gap-2 text-red-600 text-xs font-bold">
                <X size={14} onClick={() => setError(null)} className="cursor-pointer" />
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="projectName" className="text-xs font-black uppercase tracking-widest text-slate-400">Project Name</Label>
              <Input 
                id="projectName"
                placeholder="e.g., Enterprise Data Warehouse" 
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                className="bg-slate-100 border-slate-200 focus:ring-primary"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsProjectDialogOpen(false)} className="border-none">Cancel</Button>
            <Button onClick={handleCreateProject} className="bg-primary hover:bg-primary/90 text-white">Create Project</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isRenameDialogOpen} onOpenChange={setIsRenameDialogOpen}>
        <DialogContent className="bg-white border-slate-400 text-slate-900 border">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black tracking-tight">Rename Project</DialogTitle>
            <DialogDescription className="text-slate-500">
              Update the name of your current project.
            </DialogDescription>
          </DialogHeader>
          <div className="py-6 space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl flex items-center gap-2 text-red-600 text-xs font-bold">
                <X size={14} onClick={() => setError(null)} className="cursor-pointer" />
                {error}
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="renameProject" className="text-xs font-black uppercase tracking-widest text-slate-400">Project Name</Label>
              <Input 
                id="renameProject"
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                className="bg-slate-100 border-slate-200 focus:ring-primary"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRenameDialogOpen(false)} className="border-none">Cancel</Button>
            <Button onClick={handleRenameProject} className="bg-primary hover:bg-primary/90 text-white">Rename Project</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Project Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md bg-white border-slate-400 p-0 overflow-hidden border">
          <DialogHeader className="p-6 pb-2">
            <DialogTitle className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Trash2 className="text-red-500" size={20} />
              Delete Project
            </DialogTitle>
            <DialogDescription className="text-slate-500 font-medium">
              Are you sure you want to delete <span className="font-bold text-slate-900">"{projectToDelete?.name}"</span>? 
              This action cannot be undone and will remove all associated data models and dashboards.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="bg-red-50/50 border-t border-red-100 p-4">
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)} className="border-none">Cancel</Button>
              <Button onClick={handleDeleteProject} className="bg-red-600 hover:bg-red-700 text-white border-none shadow-lg shadow-red-200">Delete Project</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showNoMappingsDialog} onOpenChange={setShowNoMappingsDialog}>
        <DialogContent className="bg-white border-slate-400 max-w-md rounded-xl border">
          <DialogHeader>
            <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 mb-4 border border-amber-100">
              <Info size={24} />
            </div>
            <DialogTitle className="text-xl font-black text-slate-900 tracking-tight uppercase">No Mappings Found</DialogTitle>
            <DialogDescription className="text-slate-500 leading-relaxed pt-2">
              Gemini analyzed your source definitions but could not find any confident matches for the target columns in <span className="font-bold text-slate-900">{noMappingsTable}</span>.
              <br /><br />
              This usually happens if the source definitions are incomplete, or if the column names and descriptions are too different for a logical match.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-3">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Suggestions:</h4>
            <ul className="text-xs text-slate-600 space-y-2 list-disc pl-4">
              <li>Ensure you have uploaded the correct source files (Excel, CSV, etc.).</li>
              <li>Check if the Source Definition and Special Instructions contain the expected table and column names.</li>
              <li>Try adding more descriptive text to the "Source Definition and Special Instructions" box.</li>
            </ul>
          </div>
          <DialogFooter>
            <Button 
              onClick={() => setShowNoMappingsDialog(false)} 
              className="w-full bg-primary text-white hover:bg-primary/90 rounded-xl font-bold h-11"
            >
              Got it
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={!!selectedDiagram} onOpenChange={(open) => !open && setSelectedDiagram(null)}>
        <DialogContent className="sm:max-w-[80vw] max-w-[80vw] w-[80vw] max-h-[95vh] overflow-hidden p-0 border border-slate-300 rounded-none shadow-xl bg-slate-50 flex flex-col">
          {selectedDiagram && (
            <>
              <DialogHeader className="p-8 pb-4 bg-white border-b border-slate-200 flex-shrink-0">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/5 rounded-none flex items-center justify-center text-primary border border-primary/10">
                      <Glasses size={24} />
                    </div>
                    <div>
                      <DialogTitle className="text-2xl font-black text-slate-900 tracking-tight uppercase leading-none">
                        Architecture Blueprint
                      </DialogTitle>
                      <DialogDescription className="text-slate-500 font-bold mt-1 uppercase text-[10px] tracking-widest">
                        Target State for {selectedDiagram.platform}
                      </DialogDescription>
                    </div>
                  </div>

                  {/* Toggle Mode for Blueprint vs Standard Diagram */}
                  <div className="flex bg-slate-150 p-1 rounded-none border border-slate-300">
                    <button
                      onClick={() => setDiagramViewMode("visual")}
                      className={cn(
                        "px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-none transition-all",
                        diagramViewMode === "visual" 
                          ? "bg-white text-primary shadow-sm border border-slate-200" 
                          : "text-slate-600 hover:text-slate-900"
                      )}
                    >
                      Conceptual View (Matching Documents)
                    </button>
                    <button
                      onClick={() => setDiagramViewMode("mermaid")}
                      className={cn(
                        "px-4 py-1.5 text-[10px] font-black uppercase tracking-widest rounded-none transition-all",
                        diagramViewMode === "mermaid" 
                          ? "bg-white text-primary shadow-sm border border-slate-200" 
                          : "text-slate-600 hover:text-slate-900"
                      )}
                    >
                      Standard Flow System (Mermaid)
                    </button>
                  </div>
                </div>
              </DialogHeader>
              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                {diagramViewMode === "visual" ? (
                  <div className="mb-8">
                    <ConceptualArchitecture 
                      platformName={selectedDiagram.platform} 
                      platformDetails={selectedDiagram.platformDetails}
                      inputs={selectedDiagram.inputs}
                    />
                  </div>
                ) : (
                  <div className="bg-white rounded-none p-6 shadow-sm border border-slate-200 mb-8 min-h-[400px] flex items-center justify-center">
                    <Mermaid chart={selectedDiagram.chart} />
                  </div>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {(selectedDiagram.highlights && selectedDiagram.highlights.length > 0) ? (
                    selectedDiagram.highlights.map((highlight, hIdx) => (
                      <div 
                        key={hIdx} 
                        className={cn(
                          "p-6 rounded-2xl border space-y-3 shadow-sm hover:shadow-md transition-shadow",
                          highlight.type === 'security' ? "bg-rose-50/50 border-rose-100" :
                          highlight.type === 'scalability' ? "bg-amber-50/50 border-amber-100" :
                          highlight.type === 'performance' ? "bg-emerald-50/50 border-emerald-100" :
                          "bg-blue-50/50 border-blue-100"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <div className={cn(
                            "w-1.5 h-4 rounded-full",
                            highlight.type === 'security' ? "bg-rose-500" :
                            highlight.type === 'scalability' ? "bg-amber-500" :
                            highlight.type === 'performance' ? "bg-emerald-500" :
                            "bg-blue-500"
                          )} />
                          <h4 className={cn(
                            "text-[10px] font-black uppercase tracking-widest",
                            highlight.type === 'security' ? "text-rose-700" :
                            highlight.type === 'scalability' ? "text-amber-700" :
                            highlight.type === 'performance' ? "text-emerald-700" :
                            "text-blue-700"
                          )}>
                            {highlight.type}
                          </h4>
                        </div>
                        <p className="text-sm font-black text-slate-900 leading-tight">{highlight.title}</p>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">
                          {highlight.description}
                        </p>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="p-6 bg-emerald-50/50 rounded-2xl border border-emerald-100 space-y-2">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-700">Production Ready</h4>
                        <p className="text-xs text-emerald-800 font-medium leading-relaxed">
                          This diagram represents the recommended multi-environment hop architecture following best practices for scalability and performance.
                        </p>
                      </div>
                      <div className="p-6 bg-blue-50/50 rounded-2xl border border-blue-100 space-y-2">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-blue-700">Components Mapped</h4>
                        <p className="text-xs text-blue-800 font-medium leading-relaxed">
                          All selected services (Ingestion, Storage, Processing, Semantic) are included in this end-to-end data flow.
                        </p>
                      </div>
                      <div className="p-6 bg-amber-50/50 rounded-2xl border border-amber-100 space-y-2">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-amber-700">Scaling Strategy</h4>
                        <p className="text-xs text-amber-800 font-medium leading-relaxed">
                          Architecture is designed to handle increasing workloads through horizontal compute scaling and tiered storage.
                        </p>
                      </div>
                      <div className="p-6 bg-slate-100/50 rounded-2xl border border-slate-200 space-y-2 text-center flex flex-col justify-center">
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">Architecture Reference</p>
                        <p className="text-[9px] text-slate-400 font-mono">PAR-MDP-ARCH-2026</p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <DialogFooter className="p-6 bg-white border-t border-slate-100 flex-shrink-0">
                <Button 
                  onClick={() => setSelectedDiagram(null)}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-black rounded-xl px-12 h-12 uppercase tracking-widest text-xs"
                >
                  Close Diagram
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <DocumentationDialog open={isDocumentationDialogOpen} onOpenChange={setIsDocumentationDialogOpen} />
      {/* Record Viewer Dialog */}
      <Dialog open={!!selectedGapItem} onOpenChange={(open) => !open && setSelectedGapItem(null)}>
        <DialogContent className="sm:max-w-[95vw] lg:max-w-7xl w-full max-h-[95vh] overflow-y-auto p-0 border-none rounded-3xl shadow-2xl">
          {selectedGapItem && (
            <div className="flex flex-col">
              <div className="p-8 pb-6 border-b border-slate-100 bg-slate-50/50">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Badge className={cn(
                      "text-[10px] font-black uppercase tracking-wider px-3 py-1",
                      selectedGapItem.gapType === 'Pain Point' ? "bg-red-100 text-red-600" : 
                      selectedGapItem.gapType === 'Gap' ? "bg-amber-100 text-amber-600" :
                      selectedGapItem.gapType === 'Opportunity' ? "bg-emerald-100 text-emerald-600" : "bg-blue-100 text-blue-600"
                    )}>
                      {selectedGapItem.gapType}
                    </Badge>
                    <span className="text-xs font-mono text-slate-400 tracking-widest">{selectedGapItem.id}</span>
                  </div>
                </div>
                <h2 className="text-2xl font-black text-slate-900 leading-tight tracking-tight max-w-4xl">
                  {selectedGapItem.painPoint}
                </h2>
              </div>
              
              <div className="p-8 space-y-8">
                <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-6">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Reported By</Label>
                    <p className="text-sm font-bold text-slate-800">{selectedGapItem.reportedBy}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Reported Date</Label>
                    <p className="text-sm font-medium text-slate-600">{selectedGapItem.reportedDate}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Entity</Label>
                    <p className="text-sm font-bold text-slate-800">{selectedGapItem.entity}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Category</Label>
                    <p className="text-sm font-bold text-slate-800">{selectedGapItem.category}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Maturity Area</Label>
                    <p className="text-sm font-bold text-slate-800">{selectedGapItem.dataMaturityArea}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Priority</Label>
                    <div className={cn(
                      "text-sm font-black flex items-center gap-1.5",
                      selectedGapItem.priority === 'High' ? "text-red-600" :
                      selectedGapItem.priority === 'Medium' ? "text-amber-600" : "text-emerald-600"
                    )}>
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        selectedGapItem.priority === 'High' ? "bg-red-500" :
                        selectedGapItem.priority === 'Medium' ? "bg-amber-500" : "bg-emerald-500"
                      )} />
                      {selectedGapItem.priority}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-2">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-4 bg-primary rounded-full" />
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-500">WMP Analysis & Comments</Label>
                    </div>
                    <div className="text-sm text-slate-700 leading-relaxed p-5 bg-slate-50/80 border border-slate-200 rounded-2xl shadow-sm whitespace-pre-wrap min-h-[160px]">
                      {selectedGapItem.wmpComments}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-1 h-4 bg-primary/40 rounded-full" />
                      <Label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Direct Quotations</Label>
                    </div>
                    <blockquote className="text-sm text-slate-600 leading-relaxed p-6 bg-primary/[0.03] border-l-4 border-primary rounded-r-2xl italic font-medium whitespace-pre-wrap min-h-[160px] flex items-center relative">
                      <span className="absolute top-2 left-2 text-primary/10 text-6xl font-serif leading-none">"</span>
                      <div className="relative z-10">{selectedGapItem.directQuotations}</div>
                      <span className="absolute bottom-2 right-2 text-primary/10 text-6xl font-serif leading-none">"</span>
                    </blockquote>
                  </div>
                </div>

                <div className="bg-slate-50/50 rounded-2xl border border-slate-100 p-6">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
                    <div>
                      <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Interviewee</Label>
                      <p className="text-sm font-bold text-slate-800">{selectedGapItem.interviewee}</p>
                    </div>
                    <div>
                      <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Meeting/Workshop</Label>
                      <p className="text-sm font-bold text-slate-800 italic">{selectedGapItem.meetingWorkshop}</p>
                    </div>
                    <div>
                      <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Mentions</Label>
                      <p className="text-sm font-bold text-slate-800">{selectedGapItem.mentions || "N/A"}</p>
                    </div>
                    <div>
                      <Label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Total Mentions</Label>
                      <p className="text-base font-black text-slate-900">{selectedGapItem.totalMentions || 1}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end">
                <Button 
                  onClick={() => setSelectedGapItem(null)}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl px-8"
                >
                  Close Record
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
    </TooltipProvider>
  );
}
