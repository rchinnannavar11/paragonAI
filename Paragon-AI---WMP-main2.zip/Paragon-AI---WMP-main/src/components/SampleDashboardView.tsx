import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  MapPin, 
  Building2, 
  Layers,
  ArrowRight,
} from 'lucide-react';
import { SampleDashboard } from '../types';
import { cn } from '../lib/utils';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ScatterChart,
  Scatter,
  ZAxis,
  ComposedChart,
  Line,
  Funnel,
  FunnelChart,
  LabelList,
  Treemap,
  RadialBarChart,
  RadialBar,
  Legend,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
} from 'recharts';

interface SampleDashboardViewProps {
  dashboard: SampleDashboard;
}

const colorThemes: Record<string, {
  primaryHex: string;
  fillOpacityHex: string;
  kpiColor: string;
  badgeBg: string;
  badgeText: string;
  chartColors: string[];
}> = {
  blue: {
    primaryHex: '#3b82f6',
    fillOpacityHex: '#3b82f6',
    kpiColor: 'text-blue-600',
    badgeBg: 'bg-blue-50 text-blue-700 border-blue-100',
    badgeText: 'text-blue-600',
    chartColors: ['#3b82f6', '#1d4ed8', '#60a5fa', '#93c5fd', '#bfdbfe']
  },
  emerald: {
    primaryHex: '#10b981',
    fillOpacityHex: '#10b981',
    kpiColor: 'text-emerald-600',
    badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    badgeText: 'text-emerald-600',
    chartColors: ['#10b981', '#047857', '#34d399', '#6ee7b7', '#a7f3d0']
  },
  violet: {
    primaryHex: '#8b5cf6',
    fillOpacityHex: '#8b5cf6',
    kpiColor: 'text-violet-600',
    badgeBg: 'bg-violet-50 text-violet-700 border-violet-100',
    badgeText: 'text-violet-600',
    chartColors: ['#8b5cf6', '#6d28d9', '#a78bfa', '#c4b5fd', '#ddd6fe']
  },
  amber: {
    primaryHex: '#f59e0b',
    fillOpacityHex: '#f59e0b',
    kpiColor: 'text-amber-600',
    badgeBg: 'bg-amber-50 text-amber-700 border-amber-100',
    badgeText: 'text-amber-600',
    chartColors: ['#f59e0b', '#b45309', '#fbbf24', '#fcd34d', '#fef3c7']
  },
  cyan: {
    primaryHex: '#06b6d4',
    fillOpacityHex: '#06b6d4',
    kpiColor: 'text-cyan-600',
    badgeBg: 'bg-cyan-50 text-cyan-700 border-cyan-100',
    badgeText: 'text-cyan-600',
    chartColors: ['#06b6d4', '#0e7490', '#22d3ee', '#67e8f9', '#cffafe']
  },
  rose: {
    primaryHex: '#f43f5e',
    fillOpacityHex: '#f43f5e',
    kpiColor: 'text-rose-600',
    badgeBg: 'bg-rose-50 text-rose-700 border-rose-100',
    badgeText: 'text-rose-600',
    chartColors: ['#f43f5e', '#be123c', '#fb7185', '#fda4af', '#ffe4e6']
  },
  slate: {
    primaryHex: '#475569',
    fillOpacityHex: '#475569',
    kpiColor: 'text-slate-700',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
    badgeText: 'text-slate-600',
    chartColors: ['#475569', '#1e293b', '#64748b', '#94a3b8', '#cbd5e1']
  }
};

export const SampleDashboardView: React.FC<SampleDashboardViewProps> = ({ dashboard }) => {
  const currentTheme = colorThemes[dashboard.colorScheme || 'blue'] || colorThemes.blue;

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500 flex-1 flex flex-col min-h-0">
      {/* Header */}
      <Card className="border border-slate-200 rounded-lg overflow-hidden bg-white shadow-sm shrink-0">
        <CardHeader className="bg-slate-50/20 border-b border-slate-100 p-6">
          <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="bg-primary/10 text-primary border-none px-3 py-1 text-[9px] font-black uppercase tracking-[0.15em] rounded-md">
                  {dashboard.useCaseTitle}
                </Badge>
                {dashboard.persona && (
                  <Badge className="bg-purple-15 border-purple-100 text-purple-700 bg-purple-50/50 px-3 py-1 text-[9px] font-black uppercase tracking-[0.15em] rounded-md">
                    Persona: {dashboard.persona}
                  </Badge>
                )}
                <Badge variant="outline" className="border-slate-100 text-slate-500 font-bold text-[9px] uppercase tracking-widest px-2 py-0.5 rounded-md bg-white">
                  Theme: {dashboard.theme}
                </Badge>
              </div>
              <h1 className="text-lg font-black text-slate-900 tracking-tight uppercase underline-offset-4 decoration-primary/20 underline">
                {dashboard.title}
              </h1>
              <p className="text-slate-500 text-xs font-medium max-w-4xl leading-snug">
                {dashboard.description}
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="bg-white p-3 border-b border-slate-100 flex items-center gap-4 overflow-x-auto no-scrollbar">
            <span className="text-[9px] font-black uppercase tracking-[0.1em] text-slate-400 shrink-0">Dimensions:</span>
            {dashboard.prompts.map(prompt => (
              <div key={prompt} className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-50 border border-slate-100 shrink-0">
                <span className="text-[10px] font-bold text-slate-700">{prompt}</span>
                <ArrowRight size={8} className="text-slate-300" />
                <span className="text-[10px] font-black text-slate-400">All</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* KPIs - Compact */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 shrink-0">
        {dashboard.kpis.map((kpi, i) => (
          <Card key={i} className="border border-slate-200 rounded-lg bg-white shadow-sm hover:shadow-md transition-all group p-4 relative overflow-hidden">
            <div className="relative z-10 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black uppercase tracking-[0.1em] text-slate-400">{kpi.label}</span>
                <div className={cn(
                  "flex items-center gap-1 text-[9px] font-black px-1.5 py-0.5 rounded-md",
                  kpi.trend.startsWith('+') ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                )}>
                  {kpi.trend}
                </div>
              </div>
              <h2 className={cn("text-2xl font-black tracking-tighter", kpi.color || currentTheme.kpiColor)}>
                {kpi.value}
              </h2>
              <div className="h-0.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className={cn("h-full opacity-40")} 
                  style={{ 
                    width: `${Math.floor(Math.random() * 40 + 50)}%`,
                    backgroundColor: currentTheme.primaryHex 
                  }} 
                />
              </div>
              {kpi.description && (
                <p className="text-[10px] text-slate-500 font-medium leading-normal mt-1 pt-1.5 border-t border-slate-100">
                  {kpi.description}
                </p>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Charts Grid - Dense */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 min-h-0">
        {dashboard.charts.map((chart) => (
          <Card key={chart.id} className={cn(
            "border border-slate-200 rounded-lg bg-white shadow-sm flex flex-col min-h-[320px]",
          )}>
            <CardHeader className="py-3 px-4 border-b border-slate-50 shrink-0">
              <div className="flex flex-col gap-1 w-full">
                <div className="flex items-center justify-between w-full">
                  <CardTitle className="text-[10px] font-black uppercase tracking-widest text-slate-900 flex items-center gap-2">
                    <div className="w-1 h-3 bg-primary rounded-full" />
                    {chart.title}
                  </CardTitle>
                  <div className="flex gap-1">
                    <div className="w-1 h-1 rounded-full bg-slate-100" />
                    <div className="w-1 h-1 rounded-full bg-slate-100" />
                  </div>
                </div>
                {chart.description && (
                  <p className="text-[10px] text-slate-500 font-medium leading-normal mt-0.5">
                    {chart.description}
                  </p>
                )}
              </div>
            </CardHeader>
            <CardContent className="flex-1 min-h-0 p-4">
               <ResponsiveContainer width="100%" height="100%">
                 {chart.type === 'area' ? (
                   <AreaChart data={chart.data}>
                      <defs>
                        <linearGradient id={`colorValue-${chart.id}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={currentTheme.primaryHex} stopOpacity={0.15}/>
                          <stop offset="95%" stopColor={currentTheme.primaryHex} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                      />
                      <Tooltip 
                        contentStyle={{ borderRadius: '4px', border: '1px solid #f1f5f9', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', padding: '8px' }}
                        labelStyle={{ fontWeight: 900, fontSize: '9px', textTransform: 'uppercase', color: '#0f172a' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="value" 
                        stroke={currentTheme.primaryHex} 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill={`url(#colorValue-${chart.id})`} 
                        animationDuration={1000}
                      />
                   </AreaChart>
                 ) : chart.type === 'bar' ? (
                    <BarChart data={chart.data}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 700 }}
                      />
                      <Tooltip 
                        cursor={{ fill: '#f8fafc' }}
                        contentStyle={{ borderRadius: '4px', border: '1px solid #f1f5f9', padding: '8px' }}
                      />
                      <Bar 
                        dataKey="val" 
                        fill={currentTheme.primaryHex} 
                        radius={[2, 2, 0, 0]} 
                        animationDuration={1000}
                        barSize={16}
                      />
                    </BarChart>
                 ) : chart.type === 'radar' ? (
                   <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chart.data}>
                     <PolarGrid stroke="#f1f5f9" />
                     <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 9, fontWeight: 800 }} />
                     <Radar
                       name="Value"
                       dataKey="A"
                       stroke={currentTheme.primaryHex}
                       fill={currentTheme.primaryHex}
                       fillOpacity={0.4}
                       animationDuration={1000}
                     />
                     <Tooltip />
                   </RadarChart>
                 ) : chart.type === 'scatter' ? (
                   <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                     <XAxis type="number" dataKey="x" name="Value" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                     <YAxis type="number" dataKey="y" name="Volume" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                     <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                     <Scatter name="Data" data={chart.data} fill={currentTheme.primaryHex} />
                   </ScatterChart>
                 ) : chart.type === 'composed' ? (
                   <ComposedChart data={chart.data}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                     <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                     <Tooltip />
                     <Area type="monotone" dataKey="amt" fill={currentTheme.primaryHex} stroke={currentTheme.primaryHex} fillOpacity={0.1} />
                     <Bar dataKey="val" barSize={20} fill={currentTheme.chartColors[1] || '#1e293b'} radius={[2, 2, 0, 0]} />
                     <Line type="monotone" dataKey="value" stroke={currentTheme.chartColors[2] || '#8b5cf6'} strokeWidth={2} dot={{ r: 4 }} />
                   </ComposedChart>
                 ) : chart.type === 'funnel' ? (
                   <FunnelChart>
                     <Tooltip />
                     <Funnel
                       dataKey="value"
                       data={chart.data}
                       isAnimationActive
                     >
                       <LabelList position="right" fill="#64748b" stroke="none" dataKey="name" fontSize={10} fontWeight={800} />
                     </Funnel>
                   </FunnelChart>
                 ) : chart.type === 'treemap' ? (
                   <Treemap
                     data={chart.data}
                     dataKey="value"
                     aspectRatio={4 / 3}
                     stroke="#fff"
                     fill={currentTheme.primaryHex}
                   >
                     <Tooltip />
                   </Treemap>
                 ) : chart.type === 'radial' ? (
                   <RadialBarChart cx="50%" cy="50%" innerRadius="10%" outerRadius="80%" barSize={10} data={chart.data}>
                     <RadialBar
                       background
                       dataKey="value"
                       cornerRadius={5}
                     />
                     <Tooltip />
                   </RadialBarChart>
                 ) : chart.type === 'table' ? (
                    <div className="h-full overflow-hidden flex flex-col">
                      <div className="grid grid-cols-3 gap-4 pb-2 border-b border-slate-100 mb-2">
                        {['Segment', 'Metric', 'Status'].map(h => (
                          <span key={h} className="text-[9px] font-black uppercase text-slate-400 tracking-wider font-mono">{h}</span>
                        ))}
                      </div>
                      <div className="flex-1 space-y-2 overflow-y-auto no-scrollbar">
                        {chart.data.map((row: any, ri: number) => (
                          <div key={ri} className="grid grid-cols-3 gap-4 items-center bg-slate-50/50 p-2 rounded border border-slate-100/50">
                            <span className="text-[10px] font-bold text-slate-700">{row.segment}</span>
                            <span className="text-[10px] font-black text-primary font-mono">{row.value}</span>
                            <Badge className={cn(
                              "text-[8px] font-black uppercase py-0 px-2 border-none",
                              ri % 2 === 0 ? "bg-emerald-100 text-emerald-700" : "bg-blue-100 text-blue-700"
                            )}>{row.status}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                 ) : (
                    <PieChart>
                      <Pie
                        data={chart.data}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                        animationDuration={1000}
                        stroke="none"
                      >
                        {chart.data.map((entry: any, index: number) => (
                          <Cell key={`cell-${index}`} fill={currentTheme.chartColors[index % currentTheme.chartColors.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                 )}
               </ResponsiveContainer>
            </CardContent>
            <div className="py-2 px-4 bg-slate-50/30 border-t border-slate-100 flex items-center justify-between shrink-0">
              <span className="text-[8px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-1.5">
                <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                Operational Synthesis
              </span>
              <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">v2.4.1</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
