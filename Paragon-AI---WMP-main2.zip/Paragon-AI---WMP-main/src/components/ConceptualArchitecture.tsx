import React, { useState, useMemo } from "react";
import { 
  Database, FileText, Globe, Cpu, HardDrive, ShieldCheck, Key, 
  Workflow, Layers, Sparkles, Clipboard, Users, Info, ArrowRight,
  TrendingUp, Play, Zap, HelpCircle, Laptop, Eye, Maximize2, Minimize2,
  Server, Terminal, Settings, Share2, Network, Search, Lock, Code, 
  GitBranch, Bot, Gauge, ListFilter, SlidersHorizontal, Anchor, ChevronRight, Copy
} from "lucide-react";
import { toPng } from "html-to-image";
import { toast } from "react-hot-toast";

interface DetailedCostItem {
  service: string;
  monthlyCost: number;
  assumption: string;
}

interface MermaidHighlight {
  title: string;
  description: string;
  type: 'security' | 'scalability' | 'integration' | 'performance';
}

interface PlatformEstimateResult {
  platformName: string;
  estimatedMonthlyCost: number;
  estimatedAnnualCost: number;
  currency: string;
  summaryBreakdown: {
    storage: number;
    compute: number;
    licensing: number;
  };
  detailedMonthlyBreakdown: DetailedCostItem[];
  pros: string[];
  cons: string[];
  strategicFitScore: number;
  complexity: 'Low' | 'Medium' | 'High';
  complexityJustification: string;
  timeToValue: string;
  recommendation: string;
  mermaidDiagram?: string;
  mermaidHighlights?: MermaidHighlight[];
}

interface AdvancedQuestionnaire {
  [key: string]: any;
}

interface PlatformEstimateInput {
  selectedPlatforms: string[];
  selectedComponents?: string[];
  biToolChoice?: string;
  directSources: number;
  streamingSources: number;
  streamingPayloadMB?: number;
  apiConnections: number;
  flatFiles: number;
  bronzeSizeTB: number;
  cloudProvider: string;
  batchFrequency: string;
  realtimeFrequencyMS?: number;
  environments: string[];
  specialInstructions?: string;
  advancedQuestionnaire?: AdvancedQuestionnaire;
}

interface ConceptualArchitectureProps {
  platformName: string;
  platformDetails?: PlatformEstimateResult;
  inputs?: PlatformEstimateInput;
}

export function ConceptualArchitecture({ platformName, platformDetails, inputs }: ConceptualArchitectureProps) {
  const [zoom, setZoom] = useState<number>(1);
  const [isCopying, setIsCopying] = useState<boolean>(false);

  const copyToClipboard = async () => {
    const canvasElement = document.getElementById("conceptual-architecture-canvas");
    if (!canvasElement) {
      toast.error("Architecture canvas element not found.");
      return;
    }

    setIsCopying(true);
    const toastId = toast.loading("Rendering high-quality diagram and copying to clipboard...");

    try {
      // Temporarily store zoom and set to 1 for full definition rendering
      const prevZoom = zoom;
      setZoom(1);

      // Wait briefly for React rendering cycle to finish scaling
      await new Promise((resolve) => setTimeout(resolve, 350));

      // Temporarily hide actions & zoom buttons for clean copying
      const utilityElements = canvasElement.querySelectorAll(".action-btn-copy, #btn-zoom-in, #btn-zoom-out, #btn-zoom-reset, .zoom-label");
      utilityElements.forEach((el) => {
        (el as HTMLElement).style.opacity = "0";
        (el as HTMLElement).style.pointerEvents = "none";
      });

      const dataUrl = await toPng(canvasElement, {
        backgroundColor: "#ffffff",
        quality: 1,
        pixelRatio: 2 // High Resolution capture
      });

      // Restore utility elements
      utilityElements.forEach((el) => {
        (el as HTMLElement).style.opacity = "";
        (el as HTMLElement).style.pointerEvents = "";
      });
      setZoom(prevZoom);

      const response = await fetch(dataUrl);
      const blob = await response.blob();

      if (typeof window.ClipboardItem !== "undefined") {
        const item = new ClipboardItem({ "image/png": blob });
        await navigator.clipboard.write([item]);
        toast.dismiss(toastId);
        toast.success("Architecture blueprint copied to clipboard!");
      } else {
        toast.dismiss(toastId);
        toast.error("Clipboard Image API not supported in this browser.");
      }
    } catch (err) {
      console.error("Error copy to clipboard:", err);
      toast.dismiss(toastId);
      toast.error("Failed to copy image to clipboard.");
    } finally {
      setIsCopying(false);
    }
  };

  // Parse platform type
  const lowerName = platformName.toLowerCase();
  const isFabric = lowerName.includes("fabric");
  const isDatabricks = lowerName.includes("databricks");
  const isSnowflake = lowerName.includes("snowflake");
  const isAWS = lowerName.includes("aws") || lowerName.includes("amazon");
  const isGCP = lowerName.includes("gcp") || lowerName.includes("google");

  // Determine active platform categorizer
  const platformArchetype = useMemo(() => {
    if (isFabric) return "fabric";
    if (isDatabricks) return "databricks";
    if (isSnowflake) return "snowflake";
    if (isAWS) return "aws";
    if (isGCP) return "gcp";
    return "generic";
  }, [isFabric, isDatabricks, isSnowflake, isAWS, isGCP]);

  // Find a matching cost by keywords in detailedMonthlyBreakdown
  const getCostForKeywords = (keywords: string[]): number | null => {
    if (!platformDetails?.detailedMonthlyBreakdown) return null;
    
    for (const item of platformDetails.detailedMonthlyBreakdown) {
      const lowerService = item.service.toLowerCase();
      const match = keywords.some(kw => lowerService.includes(kw.toLowerCase()));
      if (match) {
        return item.monthlyCost;
      }
    }
    return null;
  };

  // Helper to format cost pills for Lucidchart style
  const renderCostPill = (keywords: string[]) => {
    const cost = getCostForKeywords(keywords);
    if (cost === null || cost === 0) return null;
    return (
      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-none shrink-0" id={`cost-${keywords[0]}`}>
        ${Number(cost.toFixed(0)).toLocaleString()}/mo
      </span>
    );
  };

  const hasDirectSources = inputs ? inputs.directSources > 0 : true;
  const hasStreamingSources = inputs ? inputs.streamingSources > 0 : true;
  const hasApiConnections = inputs ? inputs.apiConnections > 0 : true;
  const hasFlatFiles = inputs ? inputs.flatFiles > 0 : true;

  // Filter dynamic sources based on actual input
  const dynamicSources = useMemo(() => {
    return [
      {
        id: "relational",
        label: "Operational Databases",
        sub: `${inputs?.directSources || 2} Relational DB Sinks`,
        icon: <Database className="w-5 h-5 text-indigo-500" />,
        active: hasDirectSources,
      },
      {
        id: "files",
        label: "Object & Flat Files",
        sub: "S3/Azure Object Sinks",
        icon: <FileText className="w-5 h-5 text-sky-500" />,
        active: hasFlatFiles,
      },
      {
        id: "apis",
        label: "Web & SaaS APIs",
        sub: "REST / External webhook loops",
        icon: <Globe className="w-5 h-5 text-emerald-500" />,
        active: hasApiConnections,
      },
      {
        id: "streaming",
        label: "Real-time Telemetry Logs",
        sub: "Direct High-Frequency Broker",
        icon: <Zap className="w-5 h-5 text-amber-500" />,
        active: hasStreamingSources,
      }
    ].filter(s => s.active);
  }, [hasDirectSources, hasFlatFiles, hasApiConnections, hasStreamingSources, inputs]);

  // Dynamic BI matching
  const selectedBI = useMemo(() => {
    if (inputs?.biToolChoice) {
      return inputs.biToolChoice;
    }
    if (platformDetails?.detailedMonthlyBreakdown) {
      const match = platformDetails.detailedMonthlyBreakdown.find(d => 
        d.service.toLowerCase().includes("power bi") || 
        d.service.toLowerCase().includes("tableau") || 
        d.service.toLowerCase().includes("quicksight") || 
        d.service.toLowerCase().includes("looker")
      );
      if (match) return match.service;
    }
    return isFabric ? "Power BI" : "Power BI Premium";
  }, [inputs, platformDetails, isFabric]);

  const biBranding = useMemo(() => {
    const biLower = selectedBI.toLowerCase();
    if (biLower.includes("tableau")) {
      return { name: "Tableau Enterprise", color: "text-[#E97627]", bg: "bg-orange-50 border-orange-200", icon: <Layers className="w-4 h-4 text-[#E97627]" /> };
    }
    if (biLower.includes("quicksight")) {
      return { name: "Amazon QuickSight", color: "text-[#FF9900]", bg: "bg-amber-50 border-amber-200", icon: <SlidersHorizontal className="w-4 h-4 text-[#FF9900]" /> };
    }
    if (biLower.includes("looker")) {
      return { name: "Google Looker Studio", color: "text-[#4285F4]", bg: "bg-blue-50 border-blue-200", icon: <Gauge className="w-4 h-4 text-[#4285F4]" /> };
    }
    return { name: "Microsoft Power BI", color: "text-[#F2C811]", bg: "bg-yellow-50 border-yellow-250", icon: <Gauge className="w-4 h-4 text-yellow-600" /> };
  }, [selectedBI]);

  // Dynamic elements based on cloud
  const cloudBranding = useMemo(() => {
    const pCloud = inputs?.cloudProvider || (isAWS ? 'AWS' : isGCP ? 'GCP' : 'Azure');
    if (pCloud === 'AWS') {
      return { name: pCloud, accent: "#FF9900", secondary: "#232F3E", bg: "bg-[#FF9900]/10", theme: "aws" };
    }
    if (pCloud === 'GCP') {
      return { name: pCloud, accent: "#4285F4", secondary: "#34A853", bg: "bg-[#4285F4]/10", theme: "gcp" };
    }
    return { name: pCloud, accent: "#0078D4", secondary: "#5C2D91", bg: "bg-blue-600/10", theme: "azure" };
  }, [inputs, isAWS, isGCP]);

  // Brand-specific settings for architecture
  const brand = useMemo(() => {
    switch (platformArchetype) {
      case "fabric":
        return {
          title: "Microsoft Fabric Workspace",
          tagline: "Unified SaaS data lakehouse integrating Spark runtimes, OneLake ADLS, and semantic workspace reports.",
          badgeBg: "bg-pink-50 border-pink-200 text-pink-700",
          coreColor: "pink-500",
          storage: "OneLake ADLS Gen 2 Managed Files",
          processing: "Fabric Spark Pipelines",
          queryLayer: "Fabric SQL Direct Endpoint",
          sparkNotebooks: "Fabric Spark Notebooks",
          realtime: "Fabric Flux Eventstream",
          realtimeDesc: "Fully indexed log tables with push capabilities.",
          aiAssistant: "Fabric CoPilot Helper",
          aiAssistantDesc: "Natural language query companion.",
          devops: "Azure DevOps Pipelines",
          devopsDesc: "Lakehouse object CI/CD repository triggers.",
          catalog: "Microsoft Purview Catalogue",
          catalogDesc: "End-to-end data catalog & active lineage trace.",
          logo: <Database className="w-6 h-6 text-pink-600" />
        };
      case "databricks":
        return {
          title: "Azure Databricks Platform",
          tagline: "Unified collaborative notebooks running Photon engine on secure Delta Lake storages.",
          badgeBg: "bg-orange-50 border-orange-200 text-orange-700",
          coreColor: "[#E25A28]",
          storage: "Delta Lake on ADLS Gen 2 (dbfs)",
          processing: "Databricks Delta Live Tables (DLT)",
          queryLayer: "Serverless SQL Warehouse nodes",
          sparkNotebooks: "Workspace Collaborative Notebooks",
          realtime: "Apache Spark Structured Streams",
          realtimeDesc: "Stream link pipeline linking storage blocks.",
          aiAssistant: "Databricks Assistant AI",
          aiAssistantDesc: "Workspace python context-aware assistant.",
          devops: "Databricks Workspace Git Repos",
          devopsDesc: "Code deployment pipeline mirroring git tags.",
          catalog: "Unity Catalog Governance",
          catalogDesc: "Central schema permission controls, audit tracks, and semantic catalog layers.",
          logo: <Cpu className="w-6 h-6 text-[#E25A28]" />
        };
      case "snowflake":
        return {
          title: "Snowflake Data Cloud",
          tagline: "Centralized relational database managing isolated warehouses over shared micropartitions.",
          badgeBg: "bg-sky-50 border-sky-200 text-sky-700",
          coreColor: "sky-500",
          storage: "Snowflake Micropartition Tables",
          processing: "Snowpark Engine (Python workers)",
          queryLayer: "Elastic virtual compute engines",
          sparkNotebooks: "Snowflake Worksheets studio",
          realtime: "Snowpipe Stream pipe",
          realtimeDesc: "Continuous serverless upload loading files.",
          aiAssistant: "Snowflake Cortex AI LLM",
          aiAssistantDesc: "Built-in translation and vector queries.",
          devops: "Snowflake Git Integration Actions",
          devopsDesc: "Code deployment pipeline syncing scripts.",
          catalog: "Snowflake Horizon Compliance",
          catalogDesc: "Active column masking, audit indexes, and metadata directory.",
          logo: <Layers className="w-6 h-6 text-[#29B5E8]" />
        };
      case "aws":
        return {
          title: "AWS Native Lakehouse",
          tagline: "Central S3 buckets queried serverless via Glue catalogs and Athena SQL workloads.",
          badgeBg: "bg-amber-50 border-amber-200 text-amber-800",
          coreColor: "amber-500",
          storage: "Amazon S3 Lakehouse (Parquet/Iceberg)",
          processing: "AWS Glue Spark Orchestration",
          queryLayer: "Amazon Athena Serverless Endpoint",
          sparkNotebooks: "Amazon SageMaker Code Studio",
          realtime: "Amazon Kinesis Streams",
          realtimeDesc: "Managed event stream pipe linking input sources.",
          aiAssistant: "Amazon Q Business Expert AI",
          aiAssistantDesc: "Intelligent schema query expert helper.",
          devops: "AWS CodePipeline / CloudFormation",
          devopsDesc: "Continuous delivery channel for lambdas and queries.",
          catalog: "AWS Glue Data Catalog registry",
          catalogDesc: "Active database schema crawler and Lake Formation security.",
          logo: <Layers className="w-6 h-6 text-[#FF9900]" />
        };
      case "gcp":
        return {
          title: "Google Cloud Data Platform",
          tagline: "Serverless data pipelines powering BigQuery multi-hop tables.",
          badgeBg: "bg-blue-50 border-blue-200 text-blue-700",
          coreColor: "blue-500",
          storage: "BigQuery Native Multi-Storage Sinks",
          processing: "Google Cloud Dataflow pipeline",
          queryLayer: "BigQuery Decoupled Storage Querying",
          sparkNotebooks: "Vertex AI Worksheets Colab",
          realtime: "GCP Pub/Sub Topics Messaging",
          realtimeDesc: "Global distributed pub-sub triggers.",
          aiAssistant: "Gemini in BigQuery Studio",
          aiAssistantDesc: "Intelligent SQL assistant helper.",
          devops: "Google Cloud Build / Git Ops",
          devopsDesc: "Automated triggers deploying container assets.",
          catalog: "GCP Dataplex Data Governance",
          catalogDesc: "Metadata scanning, quality assertions, and active data lineages.",
          logo: <Database className="w-6 h-6 text-[#4285F4]" />
        };
      default:
        return {
          title: "Enterprise Lakehouse Hub",
          tagline: "Decoupled medallion pipelines managing operational source data engines.",
          badgeBg: "bg-indigo-50 border-indigo-200 text-indigo-700",
          coreColor: "indigo-500",
          storage: "Cloud Object Store (Delta/Parquet files)",
          processing: "Serverless Apache Spark Workers",
          queryLayer: "Distributed SQL Query Engine",
          sparkNotebooks: "Data Developer SQL worksheets",
          realtime: "Distributed Event Stream Brokers",
          realtimeDesc: "Kafka/Stream broker parsing incoming JSON payloads.",
          aiAssistant: "Generative AI Code Assistant",
          aiAssistantDesc: "AI model generating optimised SQL queries.",
          devops: "Unified CI/CD Release workflows",
          devopsDesc: "Automated pipeline pushing branch schema configurations.",
          catalog: "Enterprise Metadata Registry catalog",
          catalogDesc: "Schema registries, column privacy tags, and active lineages.",
          logo: <Network className="w-6 h-6 text-indigo-600" />
        };
    }
  }, [platformArchetype, cloudBranding]);

  // Dynamic feature display checks to only show components that were selected or exist in budget
  const hasBITool = inputs?.selectedComponents ? inputs.selectedComponents.includes("BI Tool") : true;
  const hasSemanticLayer = inputs?.selectedComponents ? inputs.selectedComponents.includes("Semantic Layer") : false;
  const hasPurviewGovernance = inputs?.selectedComponents 
    ? (inputs.selectedComponents.includes("MS Purview") || inputs.selectedComponents.some(c => c.toLowerCase().includes("governance") || c.toLowerCase().includes("catalog")))
    : true;
  const hasDevOps = inputs?.selectedComponents 
    ? inputs.selectedComponents.includes("Code Repository (GitHub/Azure DevOps)") 
    : true;
  const hasAIWorkspace = inputs?.selectedComponents 
    ? inputs.selectedComponents.includes("AI Workspace") 
    : false;

  const isStreamingRelevant = useMemo(() => {
    return hasStreamingSources || !!(
      getCostForKeywords(["stream", "streaming", "kafka", "event", "kinesis", "pub/sub"])
    );
  }, [hasStreamingSources, platformDetails]);

  return (
    <div className="w-full flex flex-col bg-white text-slate-800 rounded-none overflow-hidden font-sans border border-slate-350 shadow-xl relative" id="conceptual-architecture-canvas">
      
      {/* Top Header: Visio / Lucidchart styled title bar */}
      <div className="p-6 border-b border-slate-200 bg-slate-50 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-none border ${brand.badgeBg}`}>
              {brand.title} Diagram Blueprint
            </span>
            <span className="text-[10px] font-black text-slate-600 bg-white border border-slate-200 uppercase px-2 py-1 rounded-none tracking-wider shadow-sm">
              {cloudBranding.name} Architecture
            </span>
          </div>
          
          <h1 className="text-md md:text-lg font-black text-slate-900 tracking-tight leading-tight max-w-[850px]">
            {brand.tagline}
          </h1>
        </div>

        {/* Zoom controls bar and Copy Action button */}
        <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
          <button
            onClick={copyToClipboard}
            className="action-btn-copy mr-3 px-4 h-8 rounded-none bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black uppercase tracking-wider flex items-center gap-2 transition-all shadow-sm cursor-pointer"
            title="Copy entire architecture blueprint to clipboard"
            disabled={isCopying}
          >
            <Copy size={13} />
            <span>{isCopying ? "Copying..." : "Copy Diagram"}</span>
          </button>

          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mr-2 zoom-label">Zoom Grid:</span>
          
          <button 
            onClick={() => setZoom(z => Math.max(z - 0.1, 0.7))} 
            className="w-8 h-8 rounded-none bg-white border border-slate-300 hover:text-primary hover:border-primary text-slate-600 flex items-center justify-center transition-all shadow-sm"
            title="Zoom Out"
            id="btn-zoom-out"
          >
            <Minimize2 size={13} />
          </button>
          
          <span className="text-xs font-black min-w-[42px] text-center text-slate-800 uppercase bg-slate-100 border border-slate-300 py-1 px-2 rounded-none">
            {Math.round(zoom * 100)}%
          </span>

          <button 
            onClick={() => setZoom(z => Math.min(z + 0.1, 1.4))}
            className="w-8 h-8 rounded-none bg-white border border-slate-300 hover:text-primary hover:border-primary text-slate-600 flex items-center justify-center transition-all shadow-sm"
            title="Zoom In"
            id="btn-zoom-in"
          >
            <Maximize2 size={13} />
          </button>

          <button 
            onClick={() => setZoom(1)}
            className="px-2.5 h-8 rounded-none bg-slate-100 border border-slate-300 text-slate-700 hover:text-slate-900 text-[10px] font-black uppercase tracking-wider flex items-center justify-center transition-all shadow-sm"
            title="Reset Zoom"
            id="btn-zoom-reset"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Main Diagram Canvas Area with Plain White Background */}
      <div 
        className="overflow-auto custom-scrollbar p-8 min-h-[520px] max-h-[750px] border-b border-slate-200 bg-white"
        style={{
          backgroundColor: "#ffffff"
        }}
      >
        
        {/* Transform scale wrapper */}
        <div 
          className="transition-all duration-300 origin-top-left"
          style={{ 
            transform: `scale(${zoom})`, 
            width: zoom < 1 ? '100%' : `${100 / zoom}%`,
            minWidth: zoom > 1 ? `${zoom * 100}%` : "1200px" 
          }}
        >
          
          {/* Header row mirroring standard pipeline blocks */}
          <div className="grid grid-cols-12 gap-6 text-center items-center mb-6 text-[10px] uppercase font-black tracking-wider text-slate-500 border-b border-slate-250 pb-3 pl-1">
            <div className="col-span-3 text-left flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-extrabold text-[10px] flex items-center justify-center shrink-0">1</span>
              <span>1. Dynamic Source Inputs</span>
            </div>
            <div className="col-span-3 text-left pl-2">Ingestion Pipelines & Bridges</div>
            <div className="col-span-4 text-left pl-4 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-extrabold text-[10px] flex items-center justify-center shrink-0">2</span>
              <span>2. Multi-hop Medallion Storage Layer</span>
            </div>
            <div className="col-span-2 text-right pr-4 flex items-center justify-end gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-extrabold text-[10px] flex items-center justify-center shrink-0">4</span>
              <span>3. Consumption Channels</span>
            </div>
          </div>

          {/* Main Pipeline pipeline grid row */}
          <div className="grid grid-cols-12 gap-6 items-stretch mb-8">
            
            {/* COLUMN 1: INPUT DATA SOURCES */}
            <div className="col-span-12 md:col-span-3 flex flex-col gap-4">
              
              <div className="bg-white border border-slate-350 rounded-none p-5 shadow-sm flex flex-col gap-4 relative">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="text-[10px] text-indigo-600 uppercase tracking-wider font-black flex items-center gap-2">
                    <Server className="w-3.5 h-3.5" /> Source Sinks
                  </span>
                  <span className="text-[8px] bg-indigo-50 border border-indigo-200 font-extrabold text-indigo-600 px-1.5 py-0.5 rounded-none">
                    Active Raw Assets
                  </span>
                </div>

                <div className="flex flex-col gap-2.5">
                  {dynamicSources.map(src => (
                    <div 
                      key={src.id}
                      className="bg-slate-50 border border-slate-200 p-3 rounded-none flex items-center gap-3.5 hover:border-slate-400 hover:bg-white transition duration-200 cursor-default"
                    >
                      <div className="w-10 h-10 rounded-none bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-sm">
                        {src.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-black text-slate-800 tracking-tight leading-tight">
                          {src.label}
                        </h4>
                        <p className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
                          {src.sub}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Arrow connector overlaying Visio link */}
                <div className="absolute -right-3.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center border-2 border-white shadow-md z-10 select-none">
                  1
                </div>
              </div>

            </div>

            {/* COLUMN 2: INGESTION PIPELINES */}
            <div className="col-span-12 md:col-span-3 flex flex-col gap-4">
              
              {/* Batch loading connector */}
              <div className="bg-white border border-slate-350 p-5 rounded-none space-y-4 shadow-sm hover:border-slate-400 transition relative">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-none bg-indigo-600 shadow-sm" />
                    <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider">Orchestrated Load</h3>
                  </div>
                  {renderCostPill(["factory", "ingest", "copier", "copy", "import", "batch"])}
                </div>

                <div className="bg-slate-50 border border-slate-200 p-4 rounded-none flex items-start gap-3">
                  <div className="p-2.5 rounded-none bg-indigo-50 border border-indigo-200 text-indigo-600 shrink-0">
                    <Workflow className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{brand.processing}</h4>
                    <p className="text-[10px] text-slate-500 mt-1 leading-normal font-medium">
                      Metadata-driven batch pipelines loaded directly to landing directory.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-100/70 p-2.5 rounded-none border border-slate-200 flex items-center justify-between text-[9px] font-black tracking-wider uppercase text-slate-600">
                  <span>Frequency: {inputs?.batchFrequency || "Nightly schedule"}</span>
                  <Terminal className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Secure Connector agents if relational direct exists */}
              {inputs && (inputs.directSources > 0 || inputs.apiConnections > 0) && (
                <div className="bg-white border border-slate-350 p-4 rounded-none space-y-3 shadow-sm hover:border-slate-400 transition">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-emerald-600" />
                      <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">Secure Connector</h4>
                    </div>
                    {renderCostPill(["bridge", "integration runtime", "gateway"])}
                  </div>
                  <p className="text-[10px] text-slate-500 leading-normal font-medium">
                    Integrated encrypted tunnels bridging private resources without port mapping.
                  </p>
                </div>
              )}

              {/* Real-time Eventstreams block */}
              {isStreamingRelevant && (
                <div className="bg-white border border-amber-300 border-l-4 border-l-amber-500 p-5 rounded-none space-y-4 shadow-sm hover:border-slate-400 transition">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 bg-amber-500 shadow-sm" />
                      <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider">Real-time Ingestion</h3>
                    </div>
                    {renderCostPill(["stream", "streaming", "kafka", "event", "kinesis", "pub/sub"])}
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-none flex items-start gap-3">
                    <div className="p-2.5 rounded-none bg-amber-50 border border-amber-200 text-amber-600 shrink-0">
                      <Zap className="w-5 h-5 text-amber-500" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{brand.realtime}</h4>
                      <p className="text-[10px] text-slate-500 mt-1 leading-normal font-medium">
                        {brand.realtimeDesc}
                      </p>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* COLUMN 3: MULTI-HOP MEDALLION STORAGE */}
            <div className="col-span-12 md:col-span-4 flex flex-col gap-4">
              
              <div className="bg-white border border-indigo-300 border-t-4 border-t-indigo-600 p-5 rounded-none shadow-md relative flex flex-col gap-4">
                
                {/* Header title */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2.5">
                    {brand.logo}
                    <div>
                      <h3 className="text-xs font-black text-slate-950 uppercase tracking-wider">{brand.title}</h3>
                      <p className="text-[9px] text-slate-500 uppercase tracking-widest font-black mt-0.5">{brand.storage}</p>
                    </div>
                  </div>
                  {renderCostPill(["storage", "lake", "onelake", "micropartition", "s3", "blob", "tables"])}
                </div>

                <div className="space-y-3">
                  
                  {/* BRONZE LAYER */}
                  <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-none flex items-start gap-3 hover:bg-white hover:border-slate-400 transition-colors">
                    <div className="w-8 h-8 rounded-none bg-amber-100 border border-amber-200 flex items-center justify-center shrink-0 font-black text-amber-800 text-xs shadow-sm">
                      BR
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-800 uppercase tracking-wider">Bronze Layer (Raw)</span>
                        <span className="text-[8px] bg-amber-50 border border-amber-200 text-amber-700 font-extrabold px-1.5 py-0.5 rounded-none uppercase">Landed</span>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal font-medium mt-1">
                        Unmodified files directly from ingestion.
                      </p>
                    </div>
                  </div>

                  {/* Connector Arrow */}
                  <div className="flex items-center justify-between px-3 text-[9px] font-black text-indigo-700 bg-indigo-50 border border-indigo-150 py-1.5 rounded-none">
                    <div className="flex items-center gap-1.5">
                      <Code className="w-3 h-3" />
                      <span>Schema & Deduplication Notebooks</span>
                    </div>
                    <ArrowRight size={10} />
                  </div>

                  {/* SILVER LAYER */}
                  <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-none flex items-start gap-3 hover:bg-white hover:border-slate-400 transition-colors relative">
                    <div className="w-8 h-8 rounded-none bg-slate-100 border border-slate-250 flex items-center justify-center shrink-0 font-black text-slate-700 text-xs shadow-sm">
                      SL
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-800 uppercase tracking-wider">Silver Layer (Cleansed)</span>
                        <span className="text-[8px] bg-slate-100 border border-slate-200 text-slate-700 font-extrabold px-1.5 py-0.5 rounded-none uppercase">Enriched</span>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal font-medium mt-1">
                        Sanitized conformed records ready for modelling.
                      </p>
                    </div>

                    {/* Ball 3 overlay on Notebook processing */}
                    <div className="absolute -right-2 top-2.5 w-5 h-5 rounded-full bg-blue-600 text-white font-black text-[9px] flex items-center justify-center border border-white shadow-md z-10 select-none">
                      3
                    </div>
                  </div>

                  {/* Connector Arrow */}
                  <div className="flex items-center justify-between px-3 text-[9px] font-black text-indigo-700 bg-indigo-50 border border-indigo-150 py-1.5 rounded-none">
                    <div className="flex items-center gap-1.5">
                      <Settings className="w-3.5 h-3.5" />
                      <span>Aggregation Star-Schema Models</span>
                    </div>
                    <ArrowRight size={10} />
                  </div>

                  {/* GOLD LAYER */}
                  <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-none flex items-start gap-3 hover:bg-white hover:border-slate-400 transition-colors">
                    <div className="w-8 h-8 rounded-none bg-amber-100 border border-amber-200 flex items-center justify-center shrink-0 font-black text-amber-700 text-xs shadow-sm">
                      GD
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-800 uppercase tracking-wider">Gold Layer (Curated)</span>
                        <span className="text-[8px] bg-amber-50 border border-amber-200 text-amber-700 font-extrabold px-1.5 py-0.5 rounded-none uppercase">Analytics Star</span>
                      </div>
                      <p className="text-[10px] text-slate-500 leading-normal font-medium mt-1">
                        Report-ready analytical star dimensional structures.
                      </p>
                    </div>
                  </div>

                </div>

                {/* Left boundary marker for Storage Ball 2 */}
                <div className="absolute -left-3.5 top-1/4 w-7 h-7 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center border-2 border-white shadow-md z-10 select-none">
                  2
                </div>
              </div>

            </div>

            {/* COLUMN 4: DATA ENRICHMENT & CONSUMPTION ENDPOINTS */}
            <div className="col-span-12 md:col-span-2 flex flex-col gap-3">
              
              {/* Optional Semantic Layer (only rendered if checked in UI requested components!) */}
              {hasSemanticLayer && (
                <div className="bg-amber-50/70 border border-amber-300 p-3 rounded-none flex flex-col gap-2 hover:border-amber-400 transition cursor-default">
                  <div className="flex items-center gap-1.5 bg-amber-100/60 p-1.5 border border-amber-200 rounded-none">
                    <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                    <span className="text-[8.5px] font-black text-amber-800 uppercase tracking-wider">Semantic Layer</span>
                  </div>
                  <p className="text-[9.5px] text-slate-600 leading-normal font-semibold">
                    Unified semantic metrics models compiling DirectLake relationships.
                  </p>
                </div>
              )}

              {/* Power BI Premium / Active BI Report Tool Card */}
              {hasBITool && (
                <div className="bg-white border border-slate-350 p-3 rounded-none flex flex-col gap-2 relative group hover:border-slate-400 transition cursor-default shadow-sm">
                  <div className={`flex items-center gap-2 p-1.5 rounded-none border ${biBranding.bg} uppercase tracking-wider font-extrabold text-[9px]`}>
                    {biBranding.icon}
                    <span className="truncate">{biBranding.name}</span>
                  </div>
                  <p className="text-[9.5px] text-slate-500 leading-normal font-semibold">
                    Interactive dashboards directly linked to gold star-schemas via DirectQuery / DirectLake.
                  </p>

                  <div className="absolute -left-2 top-2.5 w-5 h-5 rounded-full bg-blue-600 text-white font-black text-[9px] flex items-center justify-center border border-white shadow-md z-10 select-none">
                    4
                  </div>
                </div>
              )}

              {/* Distributed SQL Queries */}
              <div className="bg-white border border-slate-350 p-3 rounded-none flex flex-col gap-2 group hover:border-slate-400 transition shadow-sm cursor-default">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 bg-slate-50 p-1.5 border border-slate-200 rounded-none">
                    <Database className="w-3.5 h-3.5 text-indigo-600" />
                    <span className="text-[9px] font-black text-slate-700 uppercase tracking-wider">SQL Engine</span>
                  </div>
                  {renderCostPill(["compute", "query", "virtual", "synapse", "endpoint"])}
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal font-semibold font-medium">
                  Direct T-SQL database analytics pointing to parquet micropartitions.
                </p>
              </div>

              {/* Spark Notebooks if relevant */}
              <div className="bg-white border border-slate-350 p-3 rounded-none flex flex-col gap-2 group hover:border-slate-400 transition shadow-sm cursor-default">
                <div className="flex items-center gap-1.5 bg-slate-50 p-1.5 border border-slate-200 rounded-none">
                  <Terminal className="w-3.5 h-3.5 text-pink-600" />
                  <span className="text-[9px] font-black text-slate-700 uppercase tracking-wider">Notebook Hub</span>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal font-semibold">
                  {brand.sparkNotebooks} workspace environments.
                </p>
              </div>

              {/* API and Webhook endpoints */}
              <div className="bg-white border border-slate-350 p-3 rounded-none flex flex-col gap-2 group hover:border-slate-400 transition shadow-sm cursor-default">
                <div className="flex items-center gap-1.5 bg-slate-50 p-1.5 border border-slate-200 rounded-none">
                  <Share2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-[9px] font-black text-slate-700 uppercase tracking-wider">REST Endpoints</span>
                </div>
                <p className="text-[9.5px] text-slate-500 leading-normal font-semibold">
                  Secure application delivery gateways parsing JSON datasets.
                </p>
              </div>

            </div>

          </div>

          {/* SHARED INFRASTRUCTURE, DEVOPS & GOVERNANCE BASE ROW */}
          <div className="bg-slate-50 p-5 rounded-none border border-slate-250 mb-6 shadow-sm">
            <div className="flex items-center gap-2.5 border-b border-slate-200 pb-3 mb-4">
              <ShieldCheck size={18} className="text-emerald-700 shrink-0" />
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">Governance, Platform Security & CI/CD Pipelines</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              
              {/* Security Vault */}
              <div className="bg-white border border-slate-200 p-4 rounded-none flex items-start gap-3.5 group hover:border-slate-400 transition cursor-default relative shadow-sm">
                <div className="p-2.5 rounded-none bg-emerald-50 border border-emerald-100 text-emerald-600 shrink-0 shadow-sm">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-xs font-black text-slate-800 tracking-tight">{cloudBranding.name} Secrets Key Vault</h4>
                    {renderCostPill(["security", "vault", "kms", "key"])}
                  </div>
                  <p className="text-[10px] text-slate-500 font-medium leading-normal mt-1">
                    Encrypted metadata connection strings and secure key vault boundaries.
                  </p>
                </div>

                {/* Key vault Security ball 3 reference */}
                <div className="absolute -left-1.5 top-2.5 w-4.5 h-4.5 rounded-full bg-blue-600 text-white font-black text-[9px] flex items-center justify-center border border-white shadow-sm z-10 select-none">
                  3
                </div>
              </div>

              {/* DevOps Pipelines */}
              {hasDevOps && (
                <div className="bg-white border border-slate-200 p-4 rounded-none flex items-start gap-3.5 group hover:border-slate-400 transition cursor-default shadow-sm">
                  <div className="p-2.5 rounded-none bg-indigo-50 border border-indigo-100 text-indigo-500 shrink-0 shadow-sm">
                    <GitBranch className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-black text-slate-800 tracking-tight">{brand.devops}</h4>
                      {renderCostPill(["devops", "cicd", "bamboo", "pipeline", "actions"])}
                    </div>
                    <p className="text-[10px] text-slate-500 font-medium leading-normal mt-1">
                      {brand.devopsDesc}
                    </p>
                  </div>
                </div>
              )}

              {/* Generative AI Workplace integration */}
              {hasAIWorkspace && (
                <div className="bg-white border border-slate-200 p-4 rounded-none flex items-start gap-3.5 group hover:border-slate-400 transition cursor-default shadow-sm">
                  <div className="p-2.5 rounded-none bg-pink-50 border border-pink-100 text-pink-600 shrink-0 shadow-sm">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-black text-slate-800 tracking-tight">{brand.aiAssistant}</h4>
                      {renderCostPill(["copilot", "ai", "assistant", "openai", "mosaic", "vertex", "cortex"])}
                    </div>
                    <p className="text-[10px] text-slate-500 font-medium leading-normal mt-1">
                      {brand.aiAssistantDesc}
                    </p>
                  </div>
                </div>
              )}

              {/* Metadata Catalog Governance */}
              {hasPurviewGovernance && (
                <div className="bg-white border border-slate-200 p-4 rounded-none flex items-start gap-3.5 group hover:border-slate-400 transition cursor-default relative shadow-sm">
                  <div className="p-2.5 rounded-none bg-purple-50 border border-purple-100 text-purple-600 shrink-0 shadow-sm">
                    <Search className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-black text-slate-800 tracking-tight">{brand.catalog}</h4>
                      {renderCostPill(["purview", "catalog", "unity", "governance", "dataplex", "glue catalog"])}
                    </div>
                    <p className="text-[10px] text-slate-500 font-medium leading-normal mt-1">
                      {brand.catalogDesc}
                    </p>
                  </div>

                  {/* Governance Purview ball 5 reference */}
                  <div className="absolute -right-1.5 top-2.5 w-4.5 h-4.5 rounded-full bg-blue-600 text-white font-black text-[9px] flex items-center justify-center border border-white shadow-sm z-10 select-none">
                    5
                  </div>
                </div>
              )}

            </div>
          </div>

          {/* VISIO BLUEPRINT LEGENDS DESCRIPTION FOOTNOTES */}
          <div className="bg-slate-100/80 p-5 rounded-none border border-slate-300">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 mb-4 pb-2 border-b border-slate-250">
              Reference Architecture Callout Definition
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-5 text-slate-600">
              
              <div className="space-y-1.5 bg-white p-3 border border-slate-200 shadow-sm rounded-none">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 font-extrabold text-[10.5px] text-white flex items-center justify-center border border-blue-500 shadow-sm select-none">1</div>
                  <span className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wide">Ingestion Feed</span>
                </div>
                <p className="text-slate-500 leading-normal text-[10px] font-medium">
                  Scheduled relational connectors or streaming brokers carrying structured files cleanly into raw storage pools.
                </p>
              </div>

              <div className="space-y-1.5 bg-white p-3 border border-slate-200 shadow-sm rounded-none">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 font-extrabold text-[10.5px] text-white flex items-center justify-center border border-blue-500 shadow-sm shadow-indigo-650/10 select-none">2</div>
                  <span className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wide">Medallion Sinks</span>
                </div>
                <p className="text-slate-500 leading-normal text-[10px] font-medium">
                  Three-tier pipeline storage layer mapping raw landed files (Bronze), cleaned entities (Silver), and report-ready star dimensional schemas (Gold).
                </p>
              </div>

              <div className="space-y-1.5 bg-white p-3 border border-slate-200 shadow-sm rounded-none">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 font-extrabold text-[10.5px] text-white flex items-center justify-center border border-blue-500 shadow-sm select-none">3</div>
                  <span className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wide">Data Processing</span>
                </div>
                <p className="text-slate-500 leading-normal text-[10px] font-medium">
                  Optimized cluster computing utilizing Apache Spark or Snowpark for transformation procedures, secured via Key Vault firewalls.
                </p>
              </div>

              <div className="space-y-1.5 bg-white p-3 border border-slate-200 shadow-sm rounded-none">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 font-extrabold text-[10.5px] text-white flex items-center justify-center border border-blue-500 shadow-sm select-none">4</div>
                  <span className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wide">Reporting Layer</span>
                </div>
                <p className="text-slate-500 leading-normal text-[10px] font-medium">
                  Integrated analytical dashboards connecting directly to semantic gold datasets with zero duplication overhead.
                </p>
              </div>

              <div className="space-y-1.5 bg-white p-3 border border-slate-200 shadow-sm rounded-none">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 font-extrabold text-[10.5px] text-white flex items-center justify-center border border-blue-500 shadow-sm select-none">5</div>
                  <span className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wide">Catalog Audit</span>
                </div>
                <p className="text-slate-500 leading-normal text-[10px] font-medium">
                  Schema scanning registries, security column masks, dataset search discoverability, and active compliance tracing.
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
