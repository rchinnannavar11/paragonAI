import React, { useState, useEffect, useRef } from 'react';
import { 
  Boxes, 
  Sparkles, 
  Loader2, 
  Copy, 
  Download, 
  Save, 
  Check, 
  Plus,
  Minus,
  Building2, 
  Layers, 
  Table as TableIcon, 
  Info, 
  HelpCircle,
  Search,
  RotateCcw,
  History,
  Trash2,
  FileText,
  CheckSquare,
  Square,
  ShieldCheck,
  TrendingUp,
  Award,
  ChevronDown,
  ChevronRight,
  PieChart,
  Grid,
  X,
  Upload,
  ExternalLink,
  Sliders,
  FolderKanban,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { 
  PlatformComparisonInput, 
  PlatformComparisonMatrix, 
  PlatformComparisonAsset, 
  PlatformComparisonCell, 
  PlatformComparisonCapability,
  SubCapability,
  HarveyBallSupportLevel
} from '../types';
import { generatePlatformComparisonMatrix } from '../lib/gemini';

const ALL_PLATFORMS = [
  'Databricks',
  'Snowflake',
  'Microsoft Fabric',
  'Azure Synapse',
  'Oracle',
  'Confluent',
  'AWS Redshift',
  'Google BigQuery',
  'Starburst / Trino',
  'SAP Datasphere',
  'Teradata'
];

// Market Quadrant reference positioning records
interface GartnerSourceRecord {
  name: string;
  x: number; // Completeness of Vision (0-100)
  y: number; // Ability to Execute (0-100)
  pos: 'left' | 'right';
  quadrant: 'Leaders' | 'Challengers' | 'Visionaries' | 'Niche Players';
  sourceReport: string;
  sourceDate: string;
}

const GARTNER_REFERENCE_DATA_2025: GartnerSourceRecord[] = [
  { name: 'Databricks', x: 78, y: 84, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Snowflake', x: 85, y: 76, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Microsoft Fabric', x: 72, y: 80, pos: 'left', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Google BigQuery', x: 76, y: 66, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'AWS Redshift', x: 66, y: 58, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Oracle', x: 58, y: 68, pos: 'left', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Azure Synapse', x: 42, y: 68, pos: 'left', quadrant: 'Challengers', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Teradata', x: 34, y: 60, pos: 'left', quadrant: 'Challengers', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'SAP Datasphere', x: 26, y: 52, pos: 'left', quadrant: 'Challengers', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Confluent', x: 76, y: 38, pos: 'right', quadrant: 'Visionaries', sourceReport: 'Data Streaming / DBMS', sourceDate: '2024 / 2025' },
  { name: 'Starburst / Trino', x: 64, y: 28, pos: 'right', quadrant: 'Visionaries', sourceReport: 'Lakehouse / DBMS', sourceDate: '2024 / 2025' },
  { name: 'SingleStore', x: 32, y: 34, pos: 'left', quadrant: 'Niche Players', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
  { name: 'Cloudera', x: 22, y: 24, pos: 'left', quadrant: 'Niche Players', sourceReport: 'Cloud DBMS', sourceDate: '2024 / 2025' },
];

const GARTNER_REFERENCE_DATA_2024: GartnerSourceRecord[] = [
  { name: 'Databricks', x: 74, y: 80, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Snowflake', x: 88, y: 78, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Microsoft Fabric', x: 58, y: 62, pos: 'left', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Google BigQuery', x: 73, y: 63, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'AWS Redshift', x: 68, y: 61, pos: 'right', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Oracle', x: 55, y: 64, pos: 'left', quadrant: 'Leaders', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Azure Synapse', x: 48, y: 72, pos: 'left', quadrant: 'Challengers', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Teradata', x: 38, y: 64, pos: 'left', quadrant: 'Challengers', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'SAP Datasphere', x: 28, y: 48, pos: 'left', quadrant: 'Challengers', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Confluent', x: 70, y: 34, pos: 'right', quadrant: 'Visionaries', sourceReport: 'Data Streaming / DBMS', sourceDate: '2023 / 2024' },
  { name: 'Starburst / Trino', x: 58, y: 24, pos: 'right', quadrant: 'Visionaries', sourceReport: 'Lakehouse / DBMS', sourceDate: '2023 / 2024' },
  { name: 'SingleStore', x: 28, y: 30, pos: 'left', quadrant: 'Niche Players', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
  { name: 'Cloudera', x: 25, y: 28, pos: 'left', quadrant: 'Niche Players', sourceReport: 'Cloud DBMS', sourceDate: '2023 / 2024' },
];

const DEFAULT_SELECTED_PLATFORMS = [
  'Databricks',
  'Snowflake',
  'Microsoft Fabric',
  'Azure Synapse',
  'Oracle',
  'Confluent'
];

const DEFAULT_CAPABILITY_AREAS = [
  'Platform Foundation',
  'Lakehouse Architecture',
  'Data Ingestion',
  'Data Engineering',
  'Data Transformation',
  'Analytics & BI',
  'Security & Governance',
  'AI / ML / GenAI',
  'Operations',
  'Ecosystem'
];

const INDUSTRY_PRESETS = [
  {
    name: 'Entertainment & Media',
    context: 'Prioritizes high-volume content metadata, rights & licensing workflows, batch analytics, and media asset processing.'
  },
  {
    name: 'Financial Services & Banking',
    context: 'Requires strict multi-cloud governance, granular data lineage, sub-second event streaming, and SOC2/HIPAA auditability.'
  },
  {
    name: 'Retail & E-Commerce',
    context: 'Focuses on Customer 360, supply chain visibility, real-time inventory tracking, and scalable ad-hoc BI dashboarding.'
  },
  {
    name: 'Healthcare & Life Sciences',
    context: 'Emphasizes PHI encryption, HIPAA/FDA compliance, EHR integration, cohort analytics, and secure data sharing.'
  }
];

// Crisp Harvey Ball SVG Component for the 5 Support States
export const HarveyBallIcon: React.FC<{ rating: string; size?: number }> = ({ rating, size = 18 }) => {
  const r = (rating || '').toLowerCase();
  let state: 'full' | 'broad' | 'partial' | 'limited' | 'none' = 'none';
  if (r.includes('full')) state = 'full';
  else if (r.includes('broad')) state = 'broad';
  else if (r.includes('partial')) state = 'partial';
  else if (r.includes('limited')) state = 'limited';

  const radius = size / 2 - 1.5;
  const cx = size / 2;
  const cy = size / 2;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0 inline-block align-middle">
      <circle cx={cx} cy={cy} r={radius} fill="none" stroke="currentColor" strokeWidth="1.75" className="text-slate-700" />
      {state === 'full' && (
        <circle cx={cx} cy={cy} r={radius - 0.5} className="fill-emerald-600" />
      )}
      {state === 'broad' && (
        <path
          d={`M ${cx} ${cy} L ${cx} ${cy - radius} A ${radius} ${radius} 0 1 1 ${cx - radius} ${cy} Z`}
          className="fill-teal-600"
        />
      )}
      {state === 'partial' && (
        <path
          d={`M ${cx} ${cy} L ${cx} ${cy - radius} A ${radius} ${radius} 0 0 1 ${cx} ${cy + radius} Z`}
          className="fill-indigo-600"
        />
      )}
      {state === 'limited' && (
        <path
          d={`M ${cx} ${cy} L ${cx} ${cy - radius} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy} Z`}
          className="fill-amber-500"
        />
      )}
      {state === 'none' && null}
    </svg>
  );
};

export const getHarveyBallDetails = (rating: string) => {
  const r = (rating || '').toLowerCase();
  if (r.includes('full')) {
    return { label: 'Full Support', badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200' };
  } else if (r.includes('broad')) {
    return { label: 'Broad Support', badgeClass: 'bg-teal-50 text-teal-800 border-teal-200' };
  } else if (r.includes('partial')) {
    return { label: 'Partial Support', badgeClass: 'bg-indigo-50 text-indigo-800 border-indigo-200' };
  } else if (r.includes('limited')) {
    return { label: 'Limited Support', badgeClass: 'bg-amber-50 text-amber-800 border-amber-200' };
  } else {
    return { label: 'Not Supported', badgeClass: 'bg-slate-100 text-slate-700 border-slate-200' };
  }
};

interface Props {
  currentProjectId?: string;
  activeProjectName?: string;
  globalCompanyName?: string;
  globalIndustry?: string;
  isSidebarVisible?: boolean;
}

export const PlatformComparisonMatrixView: React.FC<Props> = ({ 
  currentProjectId = 'default',
  activeProjectName = 'Active Project',
  globalCompanyName = '',
  globalIndustry = '',
  isSidebarVisible = true
}) => {
  // Input State
  const [platformList, setPlatformList] = useState<string[]>(ALL_PLATFORMS);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(DEFAULT_SELECTED_PLATFORMS);
  const [customPlatformInput, setCustomPlatformInput] = useState<string>('');
  const [capabilityAreasList, setCapabilityAreasList] = useState<string[]>(DEFAULT_CAPABILITY_AREAS);
  const [selectedCapabilities, setSelectedCapabilities] = useState<string[]>(DEFAULT_CAPABILITY_AREAS);
  const [customCapInput, setCustomCapInput] = useState<string>('');
  const [comparisonMode, setComparisonMode] = useState<'general' | 'targeted'>('general');
  const [companyName, setCompanyName] = useState<string>(globalCompanyName);
  const [industry, setIndustry] = useState<string>(globalIndustry);
  const [businessContext, setBusinessContext] = useState<string>('');
  const [priorityCapabilitiesText, setPriorityCapabilitiesText] = useState<string>('');
  const [openPrompt, setOpenPrompt] = useState<string>('');

  // UI state
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationElapsedTime, setGenerationElapsedTime] = useState<number>(0);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [matrixResult, setMatrixResult] = useState<PlatformComparisonMatrix | null>(null);
  
  // Table state
  const [expandedRowCategory, setExpandedRowCategory] = useState<Record<string, boolean>>({});
  const [filterQuery, setFilterQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('All');

  // Modal State
  const [isGartnerModalOpen, setIsGartnerModalOpen] = useState<boolean>(false);
  const [isSavedAssetsModalOpen, setIsSavedAssetsModalOpen] = useState<boolean>(false);
  const [gartnerYear, setGartnerYear] = useState<'2025' | '2024'>('2025');

  // Saved Assets State
  const [savedAssets, setSavedAssets] = useState<PlatformComparisonAsset[]>([]);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);

  // Storage key
  const storageKey = `paragon_matrix_assets_${currentProjectId}`;

  // Selection states
  const isAllPlatformsSelected = selectedPlatforms.length === platformList.length;
  const isAllCapabilitiesSelected = selectedCapabilities.length === capabilityAreasList.length;

  const handleSelectAllPlatforms = () => {
    setSelectedPlatforms([...platformList]);
    toast.success(`Selected all ${platformList.length} platforms`);
  };

  const handleDeselectAllPlatforms = () => {
    setSelectedPlatforms([platformList[0], platformList[1] || platformList[0]]);
    toast.success('Deselected platforms (retained 2 minimum)');
  };

  const handleSelectAllCapabilities = () => {
    setSelectedCapabilities([...capabilityAreasList]);
    toast.success(`Selected all ${capabilityAreasList.length} capability areas`);
  };

  const handleDeselectAllCapabilities = () => {
    setSelectedCapabilities([capabilityAreasList[0]]);
    toast.success('Deselected capabilities (retained 1 minimum)');
  };

  // Sync global company/industry if updated
  useEffect(() => {
    if (globalCompanyName && !companyName) setCompanyName(globalCompanyName);
    if (globalIndustry && !industry) setIndustry(globalIndustry);
  }, [globalCompanyName, globalIndustry]);

  // Timer effect for generation
  useEffect(() => {
    let interval: any;
    if (isGenerating) {
      setGenerationElapsedTime(0);
      interval = setInterval(() => {
        setGenerationElapsedTime((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  // Load saved assets
  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setSavedAssets(parsed);
      }
    } catch (e) {
      console.error('Failed to load saved comparison assets:', e);
    }
  }, [storageKey]);

  // Toggle platform selection
  const handleTogglePlatform = (platform: string) => {
    if (selectedPlatforms.includes(platform)) {
      if (selectedPlatforms.length <= 2) {
        toast.error('Select at least 2 platforms for a valid comparison');
        return;
      }
      setSelectedPlatforms(selectedPlatforms.filter(p => p !== platform));
    } else {
      setSelectedPlatforms([...selectedPlatforms, platform]);
    }
  };

  // Toggle capability selection
  const handleToggleCapability = (cap: string) => {
    if (selectedCapabilities.includes(cap)) {
      if (selectedCapabilities.length <= 1) {
        toast.error('Select at least 1 capability area');
        return;
      }
      setSelectedCapabilities(selectedCapabilities.filter(c => c !== cap));
    } else {
      setSelectedCapabilities([...selectedCapabilities, cap]);
    }
  };

  // Add custom platform
  const handleAddCustomPlatform = (customName?: string) => {
    const nameToAdd = typeof customName === 'string' ? customName : customPlatformInput;
    const trimmed = nameToAdd.trim();
    if (!trimmed) return;
    if (platformList.some(p => p.toLowerCase() === trimmed.toLowerCase())) {
      toast.error('Platform already exists in the list');
      return;
    }
    const updated = [...platformList, trimmed];
    setPlatformList(updated);
    setSelectedPlatforms(prev => [...prev, trimmed]);
    setCustomPlatformInput('');
    toast.success(`Added custom platform: "${trimmed}"`);
  };

  // Remove custom platform (only allowed for custom ones not in ALL_PLATFORMS)
  const handleRemoveCustomPlatform = (platformToRemove: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (ALL_PLATFORMS.includes(platformToRemove)) {
      toast.error('Standard platforms cannot be removed');
      return;
    }
    const updatedList = platformList.filter(p => p !== platformToRemove);
    setPlatformList(updatedList);
    setSelectedPlatforms(prev => {
      const filtered = prev.filter(p => p !== platformToRemove);
      return filtered.length >= 2 ? filtered : [updatedList[0], updatedList[1]];
    });
    toast.success(`Removed custom platform: "${platformToRemove}"`);
  };

  // Add custom capability area
  const handleAddCustomCapability = () => {
    const trimmed = customCapInput.trim();
    if (!trimmed) return;
    if (capabilityAreasList.some(c => c.toLowerCase() === trimmed.toLowerCase())) {
      toast.error('Capability area already exists');
      return;
    }
    const updated = [...capabilityAreasList, trimmed];
    setCapabilityAreasList(updated);
    setSelectedCapabilities(prev => [...prev, trimmed]);
    setCustomCapInput('');
    toast.success(`Added custom capability: "${trimmed}"`);
  };

  // Expand all / Collapse all sub-capabilities
  const handleExpandAllSubCaps = () => {
    if (!matrixResult) return;
    const allExpanded: Record<string, boolean> = {};
    matrixResult.capabilities.forEach((cap) => {
      allExpanded[cap.category || cap.name] = true;
    });
    setExpandedRowCategory(allExpanded);
    toast.success('Expanded all sub-capabilities');
  };

  const handleCollapseAllSubCaps = () => {
    setExpandedRowCategory({});
    toast.success('Collapsed all sub-capabilities');
  };

  // Toggle expand/collapse for capability sub-rows
  const toggleRowExpanded = (categoryName: string) => {
    setExpandedRowCategory(prev => ({
      ...prev,
      [categoryName]: !prev[categoryName]
    }));
  };

  // Generate Comparison Action
  const handleGenerateComparison = async () => {
    if (selectedPlatforms.length < 2) {
      toast.error('Please select at least 2 platforms to compare.');
      return;
    }
    if (selectedCapabilities.length < 1) {
      toast.error('Please select at least 1 capability area.');
      return;
    }

    setGenerationError(null);
    setIsGenerating(true);
    const toastId = toast.loading('Generating platform comparison with Gemini AI...');

    try {
      const input: PlatformComparisonInput = {
        platforms: selectedPlatforms,
        capabilities: selectedCapabilities,
        mode: comparisonMode,
        companyName: comparisonMode === 'targeted' ? companyName : undefined,
        industry: comparisonMode === 'targeted' ? industry : undefined,
        businessContext: comparisonMode === 'targeted' ? businessContext : undefined,
        priorityCapabilities: priorityCapabilitiesText ? priorityCapabilitiesText.split(',').map(s => s.trim()) : undefined,
        extraRequirements: openPrompt.trim() || undefined
      };

      const result = await generatePlatformComparisonMatrix(input);
      if (!result || !result.platforms || result.platforms.length === 0) {
        throw new Error('Generated matrix data is incomplete or empty. Please retry.');
      }

      setMatrixResult(result);
      
      // Auto expand first category sub-rows
      if (result.capabilities && result.capabilities.length > 0) {
        setExpandedRowCategory({ [result.capabilities[0].category || result.capabilities[0].name]: true });
      }

      // Auto-save generated asset to BD Assets collection
      const autoAsset: PlatformComparisonAsset = {
        id: `pc_${Date.now()}`,
        projectId: currentProjectId,
        name: comparisonMode === 'targeted' && companyName
          ? `${companyName} Platform Comparison`
          : `Platform Comparison (${selectedPlatforms.slice(0, 3).join(', ')}...)`,
        createdAt: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric'
        }),
        input: {
          platforms: selectedPlatforms,
          capabilities: selectedCapabilities,
          mode: comparisonMode,
          companyName,
          industry,
          businessContext,
          extraRequirements: openPrompt
        },
        result
      };

      setSavedAssets(prev => {
        const updated = [autoAsset, ...prev.filter(a => a.id !== autoAsset.id)];
        try {
          localStorage.setItem(storageKey, JSON.stringify(updated));
        } catch (e) {
          console.error('Failed to auto-save asset:', e);
        }
        return updated;
      });
      setSelectedAssetId(autoAsset.id);

      toast.success('Platform comparison generated and saved as asset!', { id: toastId });
    } catch (err: any) {
      console.error('Failed to generate platform comparison:', err);
      const errMsg = err?.message || 'Failed to generate comparison matrix. Please verify API configuration and retry.';
      setGenerationError(errMsg);
      toast.error(`Generation failed: ${errMsg}`, { id: toastId });
    } finally {
      setIsGenerating(false);
    }
  };

  // Save Asset to Local Storage
  const handleSaveAsset = () => {
    if (!matrixResult) return;

    const newAsset: PlatformComparisonAsset = {
      id: `pc_${Date.now()}`,
      projectId: currentProjectId,
      name: comparisonMode === 'targeted' && companyName
        ? `${companyName} Platform Comparison`
        : `Platform Comparison (${selectedPlatforms.slice(0, 3).join(', ')}...)`,
      createdAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }),
      input: {
        platforms: selectedPlatforms,
        capabilities: selectedCapabilities,
        mode: comparisonMode,
        companyName,
        industry,
        businessContext,
        extraRequirements: openPrompt
      },
      result: matrixResult
    };

    const updated = [newAsset, ...savedAssets.filter(a => a.id !== newAsset.id)];
    setSavedAssets(updated);
    try {
      localStorage.setItem(storageKey, JSON.stringify(updated));
      setSelectedAssetId(newAsset.id);
      toast.success('Saved platform comparison asset!');
    } catch (e) {
      console.error('Storage error:', e);
      toast.error('Failed to save asset locally');
    }
  };

  // Load Saved Asset
  const handleLoadAsset = (asset: PlatformComparisonAsset) => {
    setSelectedAssetId(asset.id);
    const loadedPlatforms = asset.input.platforms || DEFAULT_SELECTED_PLATFORMS;
    setPlatformList(prev => Array.from(new Set([...prev, ...loadedPlatforms])));
    setSelectedPlatforms(loadedPlatforms);
    setSelectedCapabilities(asset.input.capabilities || DEFAULT_CAPABILITY_AREAS);
    setComparisonMode(asset.input.mode === 'company-targeted' ? 'targeted' : (asset.input.mode || 'general'));
    if (asset.input.companyName) setCompanyName(asset.input.companyName);
    if (asset.input.industry) setIndustry(asset.input.industry);
    if (asset.input.businessContext) setBusinessContext(asset.input.businessContext);
    if (asset.input.extraRequirements) setOpenPrompt(asset.input.extraRequirements);
    setMatrixResult(asset.result);
    toast.success(`Loaded saved comparison: "${asset.name}"`);
  };

  // Delete Saved Asset
  const handleDeleteAsset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedAssets.filter(a => a.id !== id);
    setSavedAssets(updated);
    try {
      localStorage.setItem(storageKey, JSON.stringify(updated));
      if (selectedAssetId === id) setSelectedAssetId(null);
      toast.success('Asset removed');
    } catch (err) {
      console.error('Failed to delete asset:', err);
    }
  };

  // JSON Export of Current Workspace State or All Saved Assets
  const handleExportJSON = () => {
    try {
      const exportPayload = {
        version: '1.0',
        exportedAt: new Date().toISOString(),
        currentProjectId,
        activeProjectName,
        currentWorkspace: {
          platformList,
          selectedPlatforms,
          selectedCapabilities,
          capabilityAreasList,
          openPrompt,
          matrixResult,
          selectedAssetId
        },
        savedAssets
      };

      const jsonStr = JSON.stringify(exportPayload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const filename = `platform_comparison_backup_${new Date().toISOString().slice(0, 10)}.json`;
      saveAs(blob, filename);
      toast.success('Successfully exported comparison workspace JSON!');
    } catch (err) {
      console.error('Failed to export JSON:', err);
      toast.error('Failed to export JSON backup file');
    }
  };

  // JSON Import of Workspace State
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportJSONClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        if (!text) throw new Error('File content is empty');
        const parsed = JSON.parse(text);

        // Check if it's a full export payload or a single asset or legacy format
        let importedCount = 0;
        let restoredCurrent = false;

        if (parsed.currentWorkspace) {
          // Restore current workspace configuration & result
          if (Array.isArray(parsed.currentWorkspace.platformList)) {
            setPlatformList(parsed.currentWorkspace.platformList);
          } else if (Array.isArray(parsed.currentWorkspace.selectedPlatforms)) {
            const merged = Array.from(new Set([...ALL_PLATFORMS, ...parsed.currentWorkspace.selectedPlatforms]));
            setPlatformList(merged);
          }
          if (Array.isArray(parsed.currentWorkspace.selectedPlatforms)) {
            setSelectedPlatforms(parsed.currentWorkspace.selectedPlatforms);
          }
          if (Array.isArray(parsed.currentWorkspace.capabilityAreasList)) {
            setCapabilityAreasList(parsed.currentWorkspace.capabilityAreasList);
          }
          if (Array.isArray(parsed.currentWorkspace.selectedCapabilities)) {
            setSelectedCapabilities(parsed.currentWorkspace.selectedCapabilities);
          }
          if (typeof parsed.currentWorkspace.openPrompt === 'string') {
            setOpenPrompt(parsed.currentWorkspace.openPrompt);
          }
          if (parsed.currentWorkspace.matrixResult) {
            setMatrixResult(parsed.currentWorkspace.matrixResult);
            restoredCurrent = true;
          }
        } else if (parsed.capabilities && parsed.platforms) {
          // It's a raw PlatformComparisonMatrix
          setMatrixResult(parsed);
          setSelectedPlatforms(parsed.platforms || DEFAULT_SELECTED_PLATFORMS);
          const capNames = parsed.capabilities.map((c: any) => c.category || c.name);
          setSelectedCapabilities(capNames);
          restoredCurrent = true;
        } else if (parsed.result && parsed.input) {
          // It's a single PlatformComparisonAsset
          handleLoadAsset(parsed);
          restoredCurrent = true;
        }

        // Restore saved assets if present
        if (Array.isArray(parsed.savedAssets) && parsed.savedAssets.length > 0) {
          setSavedAssets(prev => {
            const existingIds = new Set(prev.map(a => a.id));
            const merged = [...parsed.savedAssets.filter((a: any) => !existingIds.has(a.id)), ...prev];
            try {
              localStorage.setItem(storageKey, JSON.stringify(merged));
            } catch (err) {
              console.error('Storage update failed:', err);
            }
            importedCount = parsed.savedAssets.length;
            return merged;
          });
        }

        toast.success(
          restoredCurrent
            ? `Successfully imported and restored platform comparison analysis!`
            : `Successfully imported ${importedCount} saved comparison assets!`
        );
      } catch (err: any) {
        console.error('Import error:', err);
        toast.error(`Invalid JSON file: ${err.message || 'Check file format'}`);
      }
    };
    reader.readAsText(file);
  };

  // Multi-sheet Excel Export
  const handleExportExcel = async () => {
    if (!matrixResult) return;

    try {
      const workbook = new ExcelJS.Workbook();
      workbook.creator = 'Paragon AI Platform';
      workbook.created = new Date();

      // Sheet 1: Main Matrix Table
      const sheet = workbook.addWorksheet('Platform Comparison');

      // Title Banner
      sheet.mergeCells('A1', `${String.fromCharCode(66 + matrixResult.platforms.length)}1`);
      const titleCell = sheet.getCell('A1');
      titleCell.value = `PARAGON AI - Platform Comparison (${companyName || 'General Enterprise'})`;
      titleCell.font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
      titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
      titleCell.alignment = { vertical: 'middle', horizontal: 'left' };
      sheet.getRow(1).height = 30;

      // Header row
      const headers = ['Capability Area', 'Sub-Capability / Item', ...matrixResult.platforms];
      sheet.addRow([]);
      const headerRow = sheet.addRow(headers);
      headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
      headerRow.height = 24;
      headerRow.eachCell((cell) => {
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F172A' } };
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
      });

      // Data Rows
      matrixResult.capabilities.forEach((cap) => {
        // High level capability row
        const mainRowVals = [
          cap.category || cap.name,
          '[High-Level Area]',
          ...matrixResult.platforms.map((p) => {
            const cell = cap.cellByPlatform?.[p];
            if (!cell) return 'N/A';
            let str = `${cell.rating || cell.label || 'Supported'}\n${cell.explanation}`;
            if (cell.plusPoint) str += `\n+ ${cell.plusPoint}`;
            if (cell.minusPoint) str += `\n- ${cell.minusPoint}`;
            return str;
          })
        ];
        const mainRow = sheet.addRow(mainRowVals);
        mainRow.font = { bold: true };
        mainRow.alignment = { wrapText: true, vertical: 'top' };
        mainRow.height = 55;

        // Sub-capabilities rows
        if (cap.subCapabilities && cap.subCapabilities.length > 0) {
          cap.subCapabilities.forEach(sub => {
            const subRowVals = [
              cap.category || cap.name,
              sub.name,
              ...matrixResult.platforms.map((p) => {
                const cell = sub.cellByPlatform?.[p];
                if (!cell) return 'N/A';
                let str = `${cell.rating || cell.label}\n${cell.explanation}`;
                if (cell.plusPoint) str += `\n+ ${cell.plusPoint}`;
                if (cell.minusPoint) str += `\n- ${cell.minusPoint}`;
                return str;
              })
            ];
            const subRow = sheet.addRow(subRowVals);
            subRow.alignment = { wrapText: true, vertical: 'top' };
            subRow.height = 45;
          });
        }
      });

      sheet.getColumn(1).width = 24;
      sheet.getColumn(2).width = 28;
      matrixResult.platforms.forEach((_, idx) => {
        sheet.getColumn(idx + 3).width = 38;
      });

      // Sheet 2: Executive Overview
      const execSheet = workbook.addWorksheet('Executive Overview');
      execSheet.addRow(['Executive Summary']).font = { bold: true, size: 14 };
      execSheet.addRow([matrixResult.executiveSummary]);
      execSheet.addRow([]);
      if (matrixResult.recommendation) {
        execSheet.addRow(['Strategic Recommendation']).font = { bold: true, size: 14 };
        execSheet.addRow([matrixResult.recommendation]);
        execSheet.addRow([]);
      }

      // Sheet 3: Best Fit by Use Case
      if (matrixResult.bestFitByUseCase && matrixResult.bestFitByUseCase.length > 0) {
        const ucSheet = workbook.addWorksheet('Best Fit by Use Case');
        const ucHeader = ucSheet.addRow(['Use Case', 'Best Platform', 'Strategic Rationale']);
        ucHeader.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        ucHeader.eachCell(c => c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } });
        matrixResult.bestFitByUseCase.forEach(uc => {
          ucSheet.addRow([uc.useCase, uc.bestPlatform, uc.why]);
        });
        ucSheet.getColumn(1).width = 32;
        ucSheet.getColumn(2).width = 24;
        ucSheet.getColumn(3).width = 50;
      }

      // Sheet 4: Strengths & Tradeoffs
      if (matrixResult.strengthsAndTradeoffs && matrixResult.strengthsAndTradeoffs.length > 0) {
        const stSheet = workbook.addWorksheet('Strengths & Tradeoffs');
        const stHeader = stSheet.addRow(['Platform', 'Key Strategic Strength', 'Key Operational Tradeoff']);
        stHeader.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        stHeader.eachCell(c => c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } });
        matrixResult.strengthsAndTradeoffs.forEach(st => {
          stSheet.addRow([st.platform, st.biggestStrength, st.biggestLimitation]);
        });
        stSheet.getColumn(1).width = 24;
        stSheet.getColumn(2).width = 35;
        stSheet.getColumn(3).width = 45;
      }

      const buffer = await workbook.xlsx.writeBuffer();
      const fileName = companyName 
        ? `${companyName.replace(/\s+/g, '_')}_Platform_Comparison.xlsx`
        : `Enterprise_Platform_Comparison.xlsx`;
      
      saveAs(new Blob([buffer]), fileName);
      toast.success('Exported multi-sheet Excel file!');
    } catch (e) {
      console.error('Export error:', e);
      toast.error('Failed to export Excel file');
    }
  };

  // Copy Summary to Clipboard
  const handleCopySummary = () => {
    if (!matrixResult) return;

    let text = `PARAGON AI - PLATFORM COMPARISON\n`;
    text += `Target Company: ${companyName || 'General Enterprise'}\n`;
    text += `Industry: ${industry || 'General'}\n\n`;

    text += `EXECUTIVE SUMMARY:\n${matrixResult.executiveSummary}\n\n`;

    if (matrixResult.recommendation) {
      text += `STRATEGIC RECOMMENDATION:\n${matrixResult.recommendation}\n\n`;
    }

    text += `CAPABILITY EVALUATION:\n`;
    matrixResult.capabilities.forEach(cap => {
      text += `• ${cap.category || cap.name}:\n`;
      matrixResult.platforms.forEach(p => {
        const cell = cap.cellByPlatform?.[p];
        if (cell) {
          text += `  - ${p}: [${cell.rating || cell.label}] ${cell.explanation}\n`;
        }
      });
    });

    navigator.clipboard.writeText(text);
    toast.success('Comparison summary copied to clipboard!');
  };

  // Filter capabilities
  const filteredCapabilities = matrixResult?.capabilities.filter(cap => {
    if (filterCategory !== 'All' && cap.category !== filterCategory) return false;
    if (filterQuery.trim()) {
      const q = filterQuery.toLowerCase();
      const nameMatch = cap.name.toLowerCase().includes(q);
      const catMatch = (cap.category || '').toLowerCase().includes(q);
      const cellMatch = Object.values(cap.cellByPlatform || {}).some((cell: PlatformComparisonCell) => 
        (cell?.explanation || '').toLowerCase().includes(q) || (cell?.label || '').toLowerCase().includes(q)
      );
      return nameMatch || catMatch || cellMatch;
    }
    return true;
  }) || [];

  return (
    <div className="space-y-6 flex-1 min-h-[calc(100vh-12rem)] pb-12">
      {/* Main 2-Column Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT SIDEBAR PANE (Comparison Configurator / Prompt settings) */}
        {isSidebarVisible && (
          <div className="lg:col-span-4 space-y-6">
            
            {/* Card 1: Comparison Configurator Box */}
            <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl overflow-hidden">
              <CardHeader className="bg-slate-50/80 border-b border-slate-100 p-5">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <Sliders size={18} />
                  </div>
                  <div>
                    <CardTitle className="text-base font-black uppercase tracking-tight text-slate-900">
                      Comparison Configurator
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-5 space-y-5">
                
                {/* Platform Selection List */}
                <div className="space-y-2 text-left">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-black uppercase tracking-wider text-slate-700">
                      1. Select Platforms ({selectedPlatforms.length} / {platformList.length})
                    </label>
                    <div className="flex items-center gap-1.5">
                      {isAllPlatformsSelected ? (
                        <button
                          type="button"
                          onClick={handleDeselectAllPlatforms}
                          className="text-[10px] font-bold text-amber-600 hover:underline flex items-center gap-0.5"
                        >
                          <Minus size={11} />
                          Deselect All
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={handleSelectAllPlatforms}
                          className="text-[10px] font-bold text-primary hover:underline flex items-center gap-0.5"
                        >
                          <CheckSquare size={11} />
                          Select All
                        </button>
                      )}
                      <span className="text-slate-300">|</span>
                      <button
                        type="button"
                        onClick={() => setSelectedPlatforms([...DEFAULT_SELECTED_PLATFORMS])}
                        className="text-[10px] font-bold text-slate-400 hover:underline"
                      >
                        Default (6)
                      </button>
                    </div>
                  </div>

                  {/* Custom Platform Input */}
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Add custom platform (e.g. Dremio, MinIO, DuckDB)..."
                      value={customPlatformInput}
                      onChange={(e) => setCustomPlatformInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddCustomPlatform();
                        }
                      }}
                      className="text-xs h-9 bg-white flex-1"
                    />
                    <Button
                      type="button"
                      onClick={() => handleAddCustomPlatform()}
                      size="sm"
                      className="h-9 px-3 text-xs font-bold bg-primary hover:bg-primary/90 text-white shrink-0 rounded-lg gap-1"
                    >
                      <Plus size={14} />
                      Add
                    </Button>
                  </div>

                  {/* Quick Suggested Platforms Pill Row */}
                  <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Quick add:</span>
                    {['Dremio', 'MinIO', 'DuckDB', 'Hydra', 'Firebolt', 'Greenplum', 'RisingWave']
                      .filter(p => !platformList.some(pl => pl.toLowerCase() === p.toLowerCase()))
                      .slice(0, 4)
                      .map(p => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => handleAddCustomPlatform(p)}
                          className="text-[10px] font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded-md transition-colors flex items-center gap-1"
                        >
                          <span>+ {p}</span>
                        </button>
                      ))}
                  </div>

                  {/* Platform Selection List */}
                  <div className="p-2 border border-slate-200 rounded-xl max-h-[170px] overflow-y-auto space-y-1 bg-white">
                    {platformList.map((plt) => {
                      const isSelected = selectedPlatforms.includes(plt);
                      const isCustom = !ALL_PLATFORMS.includes(plt);
                      return (
                        <div
                          key={plt}
                          onClick={() => handleTogglePlatform(plt)}
                          className={cn(
                            "w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors text-left cursor-pointer",
                            isSelected
                              ? "bg-slate-100 text-slate-900 font-bold"
                              : "text-slate-600 hover:bg-slate-50"
                          )}
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="truncate">{plt}</span>
                            {isCustom && (
                              <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 bg-purple-100 text-purple-700 rounded border border-purple-200">
                                Custom
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {isCustom && (
                              <button
                                type="button"
                                title="Remove custom platform"
                                onClick={(e) => handleRemoveCustomPlatform(plt, e)}
                                className="p-0.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                              >
                                <Trash2 size={12} />
                              </button>
                            )}
                            {isSelected ? (
                              <CheckSquare size={14} className="text-primary shrink-0" />
                            ) : (
                              <Square size={14} className="text-slate-300 shrink-0" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Capability Area Selection */}
                <div className="space-y-2 text-left">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-black uppercase tracking-wider text-slate-700">
                      2. Capability Areas ({selectedCapabilities.length} / {capabilityAreasList.length})
                    </label>
                    <div className="flex items-center gap-1.5">
                      {isAllCapabilitiesSelected ? (
                        <button
                          type="button"
                          onClick={handleDeselectAllCapabilities}
                          className="text-[10px] font-bold text-amber-600 hover:underline flex items-center gap-0.5"
                        >
                          <Minus size={11} />
                          Deselect All
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={handleSelectAllCapabilities}
                          className="text-[10px] font-bold text-primary hover:underline flex items-center gap-0.5"
                        >
                          <CheckSquare size={11} />
                          Select All
                        </button>
                      )}
                      <span className="text-slate-300">|</span>
                      <button
                        type="button"
                        onClick={() => setSelectedCapabilities([...DEFAULT_CAPABILITY_AREAS])}
                        className="text-[10px] font-bold text-slate-400 hover:underline"
                      >
                        Reset
                      </button>
                    </div>
                  </div>

                  {/* Custom Capability Area Input */}
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Add custom capability area..."
                      value={customCapInput}
                      onChange={(e) => setCustomCapInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddCustomCapability();
                        }
                      }}
                      className="text-xs h-9 bg-white flex-1"
                    />
                    <Button
                      type="button"
                      onClick={handleAddCustomCapability}
                      size="sm"
                      className="h-9 px-3 text-xs font-bold bg-primary hover:bg-primary/90 text-white shrink-0 rounded-lg gap-1"
                    >
                      <Plus size={14} />
                      Add
                    </Button>
                  </div>

                  <div className="p-2 border border-slate-200 rounded-xl max-h-[170px] overflow-y-auto space-y-1 bg-white">
                    {capabilityAreasList.map((cap) => {
                      const isSelected = selectedCapabilities.includes(cap);
                      return (
                        <button
                          key={cap}
                          type="button"
                          onClick={() => handleToggleCapability(cap)}
                          className={cn(
                            "w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors text-left",
                            isSelected
                              ? "bg-indigo-50/70 text-indigo-900 font-bold"
                              : "text-slate-600 hover:bg-slate-50"
                          )}
                        >
                          <span className="truncate pr-2">{cap}</span>
                          {isSelected ? (
                            <CheckSquare size={14} className="text-primary shrink-0" />
                          ) : (
                            <Square size={14} className="text-slate-300 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Open Prompt / Specific Constraints */}
                <div className="space-y-2 text-left">
                  <label className="text-xs font-black uppercase tracking-wider text-slate-700 block">
                    3. Custom Constraints & Questions
                  </label>
                  <Textarea
                    placeholder="e.g. Focus on operational cost efficiency, multi-cloud data governance, and sub-second stream processing performance."
                    value={openPrompt}
                    onChange={(e) => setOpenPrompt(e.target.value)}
                    className="bg-white text-xs min-h-[70px] resize-y"
                  />
                </div>

                {/* Generate Button */}
                <Button
                  onClick={handleGenerateComparison}
                  disabled={isGenerating || selectedPlatforms.length < 2 || selectedCapabilities.length < 1}
                  className="w-full bg-primary hover:bg-primary/90 text-white font-bold h-11 rounded-xl text-xs gap-2 shadow-md shadow-primary/20"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Analyzing Platforms ({generationElapsedTime}s)...
                    </>
                  ) : (
                    <>
                      <Sparkles size={16} />
                      Generate Comparison
                    </>
                  )}
                </Button>

                {/* Saved Comparison Assets List under Configurator */}
                <div className="pt-4 border-t border-slate-200/80 -mx-4 px-4 bg-slate-50/50 -mb-4 pb-4 rounded-b-2xl">
                  <div className="flex items-center justify-between mb-2.5">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-1.5 text-left">
                      <FolderKanban size={13} className="text-primary" />
                      Saved Assets ({savedAssets.length})
                    </h4>
                    {savedAssets.length > 0 && (
                      <button
                        onClick={() => {
                          if (window.confirm('Delete all saved comparison assets?')) {
                            setSavedAssets([]);
                            localStorage.removeItem(storageKey);
                            setSelectedAssetId(null);
                            toast.success('Cleared all comparison assets');
                          }
                        }}
                        className="text-[10px] font-bold text-slate-400 hover:text-red-500 transition-colors"
                        title="Clear all saved assets"
                      >
                        Clear All
                      </button>
                    )}
                  </div>

                  {savedAssets.length === 0 ? (
                    <div className="text-center py-4 px-3 bg-white rounded-xl border border-dashed border-slate-200">
                      <History size={16} className="mx-auto text-slate-300 mb-1" />
                      <p className="text-[11px] font-medium text-slate-400">No saved comparison assets yet</p>
                      <p className="text-[9px] text-slate-400 mt-0.5">Generate or save comparisons to access them here</p>
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-0.5 custom-scrollbar">
                      {savedAssets.map((asset) => (
                        <div
                          key={asset.id}
                          onClick={() => handleLoadAsset(asset)}
                          className={cn(
                            "group flex items-center justify-between p-2 rounded-xl border transition-all cursor-pointer text-left",
                            selectedAssetId === asset.id
                              ? "bg-primary/10 border-primary text-primary shadow-sm"
                              : "bg-white border-slate-200 text-slate-700 hover:border-primary/40 hover:bg-slate-50"
                          )}
                        >
                          <div className="min-w-0 flex-1 pr-2">
                            <div className="flex items-center gap-1.5">
                              <FileText size={12} className={selectedAssetId === asset.id ? "text-primary shrink-0" : "text-slate-400 shrink-0"} />
                              <h5 className="text-[11px] font-bold truncate leading-tight">
                                {asset.name}
                              </h5>
                            </div>
                            <div className="flex items-center gap-2 mt-0.5 pl-4">
                              <span className="text-[9px] font-semibold text-slate-400">
                                {asset.createdAt}
                              </span>
                              <span className="text-[9px] font-bold text-primary/80">
                                {asset.input.platforms?.length || 0} platforms
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={(e) => handleDeleteAsset(asset.id, e)}
                            className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                            title="Delete Asset"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </CardContent>
            </Card>

          </div>
        )}

        {/* RIGHT MAIN OUTPUT PANE */}
        <div className={cn(isSidebarVisible ? "lg:col-span-8" : "lg:col-span-12", "space-y-6")}>

          {/* Top Header Banner - Located strictly above right evaluation pane */}
          <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 sm:gap-6 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="space-y-1.5 text-left max-w-xl">
              <div className="flex items-center gap-2.5">
                <Badge className="bg-primary text-white border-none px-2.5 py-0.5 text-[10px] font-black uppercase tracking-[0.2em] shadow-sm">
                  Business Development
                </Badge>
                <Badge variant="outline" className="border-indigo-200 bg-indigo-50 text-indigo-700 font-bold text-[10px] uppercase tracking-widest px-2.5 py-0.5">
                  Executive Evaluation
                </Badge>
              </div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase font-display">
                Platform Comparison
              </h2>
              <p className="text-slate-500 text-xs sm:text-sm font-medium leading-relaxed">
                Objective, grounded evaluation of enterprise data platforms across architectural capabilities, support levels, and strategic tradeoffs.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 shrink-0">
              {/* Hidden File Input for JSON Workspace Import */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".json,application/json"
                className="hidden"
              />

              <Button
                onClick={handleImportJSONClick}
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs gap-1.5 rounded-xl h-10 px-3.5 shadow-sm whitespace-nowrap"
                title="Import previous comparison analysis or backup JSON"
              >
                <Upload size={15} className="text-indigo-600" />
                Import JSON
              </Button>

              <Button
                onClick={handleExportJSON}
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs gap-1.5 rounded-xl h-10 px-3.5 shadow-sm whitespace-nowrap"
                title="Export entire platform comparison workspace and saved analyses to JSON"
              >
                <Download size={15} className="text-slate-600" />
                Export JSON
              </Button>

              <Button
                onClick={() => setIsSavedAssetsModalOpen(true)}
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs gap-1.5 rounded-xl h-10 px-3.5 shadow-sm whitespace-nowrap"
              >
                <History size={15} className="text-slate-600" />
                Saved Assets ({savedAssets.length})
              </Button>

              <Button
                onClick={() => setIsGartnerModalOpen(true)}
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs gap-1.5 rounded-xl h-10 px-3.5 shadow-sm whitespace-nowrap"
              >
                <PieChart size={15} className="text-primary" />
                Market Quadrant
              </Button>

              {matrixResult && (
                <Button
                  onClick={handleSaveAsset}
                  className="bg-emerald-600 text-white hover:bg-emerald-700 font-bold text-xs gap-1.5 rounded-xl h-10 px-4 shadow-sm whitespace-nowrap"
                >
                  <Save size={15} />
                  Save Asset
                </Button>
              )}
            </div>
          </div>

          {/* Error State Card */}
          {generationError && !isGenerating && (
            <Card className="shadow-sm border border-red-200 bg-red-50/50 rounded-3xl p-8 text-center flex flex-col items-center justify-center min-h-[400px]">
              <div className="w-16 h-16 rounded-2xl bg-red-100 border border-red-200 flex items-center justify-center text-red-600 mb-4 shadow-sm">
                <Info size={32} />
              </div>
              <h3 className="text-lg font-black text-red-900 uppercase tracking-tight mb-2">
                Generation Encountered an Issue
              </h3>
              <p className="text-red-700 max-w-md text-xs font-medium leading-relaxed mb-6">
                {generationError}
              </p>
              <Button
                onClick={handleGenerateComparison}
                className="bg-red-600 hover:bg-red-700 text-white font-bold h-10 px-5 rounded-xl text-xs gap-2 shadow-sm"
              >
                <Sparkles size={14} />
                Retry Comparison
              </Button>
            </Card>
          )}

          {/* If No Matrix Generated Yet */}
          {!matrixResult && !isGenerating && (
            <Card className="shadow-sm border border-slate-200 bg-white rounded-3xl p-12 text-center flex flex-col items-center justify-center min-h-[500px]">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-primary mb-5 shadow-sm">
                <Boxes size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight mb-2">
                Ready to Generate Platform Comparison
              </h3>
              <p className="text-slate-500 max-w-md text-sm font-medium leading-relaxed mb-6">
                Configure your target platforms and capability areas in the left panel, then click <span className="font-bold text-slate-900">"Generate Comparison"</span> to produce an executive evaluation.
              </p>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-slate-50 text-slate-600 text-xs py-1 px-3">
                  Default Platforms: Databricks, Snowflake, Fabric, Synapse, Oracle, Confluent
                </Badge>
              </div>
            </Card>
          )}

          {/* Loading State */}
          {isGenerating && (
            <Card className="shadow-sm border border-slate-200 bg-white rounded-3xl p-16 text-center flex flex-col items-center justify-center min-h-[500px]">
              <div className="relative mb-8">
                <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                  <Loader2 size={40} className="animate-spin text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight mb-2">
                Evaluating Platform Capabilities
              </h3>
              <p className="text-slate-500 max-w-md text-sm font-medium leading-relaxed">
                Gemini AI is analyzing platform architectures, support levels, and operational tradeoffs for {selectedPlatforms.length} platforms...
              </p>
              <div className="mt-6 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs font-bold text-slate-600">
                <span className="w-2 h-2 rounded-full bg-primary animate-ping" />
                Elapsed time: {generationElapsedTime}s
              </div>
            </Card>
          )}

          {/* Main Matrix Content when Generated */}
          {matrixResult && !isGenerating && (
            <div className="space-y-6 text-left">
              
              {/* Output Header Action Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center gap-2">
                  <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200 font-bold text-xs py-1 px-3">
                    Evaluation Complete
                  </Badge>
                  <span className="text-xs text-slate-500 font-medium">
                    {matrixResult.platforms.length} Platforms • {matrixResult.capabilities.length} Capability Areas
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    onClick={handleCopySummary}
                    variant="outline"
                    size="sm"
                    className="h-9 font-bold text-xs gap-1.5 rounded-xl border-slate-200"
                  >
                    <Copy size={14} />
                    Copy Summary
                  </Button>

                  <Button
                    onClick={handleExportJSON}
                    variant="outline"
                    size="sm"
                    className="h-9 font-bold text-xs gap-1.5 rounded-xl border-indigo-300 text-indigo-700 bg-indigo-50/50 hover:bg-indigo-100"
                    title="Export full matrix & parameters as JSON"
                  >
                    <Download size={14} />
                    Export JSON
                  </Button>

                  <Button
                    onClick={handleExportExcel}
                    variant="outline"
                    size="sm"
                    className="h-9 font-bold text-xs gap-1.5 rounded-xl border-emerald-300 text-emerald-700 bg-emerald-50/50 hover:bg-emerald-100"
                  >
                    <Download size={14} />
                    Export Excel
                  </Button>
                </div>
              </div>

              {/* HARVEY BALL SUPPORT RATING LEGEND */}
              <Card className="shadow-sm border border-slate-200 bg-slate-900 text-white rounded-2xl overflow-hidden p-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <Award size={18} className="text-teal-400 shrink-0" />
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-white">
                        Harvey Ball Rating Legend
                      </h4>
                      <p className="text-[11px] text-slate-400 font-medium">
                        Objective support-level evaluation for enterprise platform capabilities.
                      </p>
                    </div>
                  </div>

                  {/* Legend Items Grid */}
                  <div className="flex flex-wrap items-center gap-3 text-xs font-bold">
                    <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      <HarveyBallIcon rating="Full Support" size={16} />
                      <span className="text-emerald-400 text-[11px]">● Full Support</span>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      <HarveyBallIcon rating="Broad Support" size={16} />
                      <span className="text-teal-300 text-[11px]">◕ Broad Support</span>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      <HarveyBallIcon rating="Partial Support" size={16} />
                      <span className="text-indigo-300 text-[11px]">◐ Partial Support</span>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      <HarveyBallIcon rating="Limited Support" size={16} />
                      <span className="text-amber-300 text-[11px]">◔ Limited Support</span>
                    </div>

                    <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      <HarveyBallIcon rating="Not Supported" size={16} />
                      <span className="text-slate-400 text-[11px]">○ Not Supported</span>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Filter / Search Bar and Sub-Capability Expand/Collapse Controls */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="relative flex-1 w-full">
                  <Search size={15} className="absolute left-3 top-2.5 text-slate-400" />
                  <Input
                    placeholder="Filter capabilities or text..."
                    value={filterQuery}
                    onChange={(e) => setFilterQuery(e.target.value)}
                    className="pl-9 text-xs h-9 bg-white rounded-xl"
                  />
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {filterQuery && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFilterQuery('')}
                      className="h-9 text-xs font-bold text-slate-500 rounded-xl"
                    >
                      Clear Filter
                    </Button>
                  )}

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleExpandAllSubCaps}
                    className="h-9 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border-slate-200 gap-1 rounded-xl shadow-xs"
                  >
                    <ChevronDown size={13} />
                    Expand All
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCollapseAllSubCaps}
                    className="h-9 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border-slate-200 gap-1 rounded-xl shadow-xs"
                  >
                    <ChevronRight size={13} />
                    Collapse All
                  </Button>
                </div>
              </div>

              {/* MAIN GROUPED COMPARISON TABLE */}
              <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl overflow-hidden">
                <div className="overflow-auto max-h-[70vh] relative">
                  <table className="w-full border-collapse text-left">
                    <thead className="sticky top-0 z-30 bg-slate-900 shadow-sm">
                      <tr className="bg-slate-900 text-white border-b border-slate-800">
                        <th className="p-4 text-xs font-black uppercase tracking-wider sticky top-0 left-0 z-40 bg-slate-900 min-w-[220px] max-w-[260px] shadow-sm">
                          Capability Area
                        </th>
                        {matrixResult.platforms.map((platform) => (
                          <th
                            key={platform}
                            className="p-4 text-xs font-black uppercase tracking-wider text-center min-w-[220px] border-l border-slate-800 bg-slate-900 sticky top-0 z-30"
                          >
                            <span className="inline-block px-2.5 py-1 bg-white/10 rounded-lg border border-white/10 font-bold">
                              {platform}
                            </span>
                          </th>
                        ))}
                      </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-200">
                      {filteredCapabilities.map((cap) => {
                        const isExpanded = !!expandedRowCategory[cap.category || cap.name];
                        const subCaps = cap.subCapabilities || [];

                        return (
                          <React.Fragment key={cap.category || cap.name}>
                            
                            {/* High-Level Capability Row */}
                            <tr className="bg-slate-50/80 hover:bg-slate-100/80 transition-colors group">
                              
                              {/* Sticky Category Header Column */}
                              <td className="p-4 sticky left-0 z-20 bg-slate-50 group-hover:bg-slate-100 border-r border-slate-200 align-top shadow-sm">
                                <div className="space-y-1.5">
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="font-black text-xs text-slate-900 uppercase tracking-tight">
                                      {cap.category || cap.name}
                                    </span>

                                    {subCaps.length > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => toggleRowExpanded(cap.category || cap.name)}
                                        className="inline-flex items-center gap-1 text-[10px] font-bold text-primary hover:bg-primary/10 px-2 py-0.5 rounded-md transition-colors"
                                      >
                                        {isExpanded ? (
                                          <>
                                            <ChevronDown size={12} />
                                            Collapse ({subCaps.length})
                                          </>
                                        ) : (
                                          <>
                                            <ChevronRight size={12} />
                                            Sub-details ({subCaps.length})
                                          </>
                                        )}
                                      </button>
                                    )}
                                  </div>

                                  {cap.description && (
                                    <p className="text-[11px] text-slate-500 font-medium leading-snug">
                                      {cap.description}
                                    </p>
                                  )}
                                </div>
                              </td>

                              {/* Platform Cells for High-Level Capability Area */}
                              {matrixResult.platforms.map((plt) => {
                                const cell = cap.cellByPlatform?.[plt];
                                if (!cell) {
                                  return (
                                    <td key={plt} className="p-4 text-center text-xs text-slate-400 border-l border-slate-200">
                                      N/A
                                    </td>
                                  );
                                }

                                const details = getHarveyBallDetails(cell.rating || cell.label);

                                return (
                                  <td key={plt} className="p-4 align-top border-l border-slate-200 bg-white min-w-[220px]">
                                    <div className="space-y-2">
                                      {/* Support Rating Badge & Icon */}
                                      <div className="flex items-center gap-2">
                                        <HarveyBallIcon rating={cell.rating || cell.label} size={20} />
                                        <Badge variant="outline" className={cn("text-[10px] font-black uppercase tracking-wider py-0.5 px-2", details.badgeClass)}>
                                          {details.label}
                                        </Badge>
                                      </div>

                                      {/* Explanation */}
                                      <p className="text-xs text-slate-700 leading-relaxed font-medium">
                                        {cell.explanation}
                                      </p>

                                      {/* Optional Plus / Minus Callouts */}
                                      {cell.plusPoint && (
                                        <div className="flex items-start gap-1 text-[11px] text-emerald-700 bg-emerald-50/80 p-1.5 rounded-md border border-emerald-100 font-medium">
                                          <Plus size={12} className="shrink-0 mt-0.5 text-emerald-600" />
                                          <span>{cell.plusPoint}</span>
                                        </div>
                                      )}

                                      {cell.minusPoint && (
                                        <div className="flex items-start gap-1 text-[11px] text-amber-800 bg-amber-50/80 p-1.5 rounded-md border border-amber-100 font-medium">
                                          <Minus size={12} className="shrink-0 mt-0.5 text-amber-600" />
                                          <span>{cell.minusPoint}</span>
                                        </div>
                                      )}
                                    </div>
                                  </td>
                                );
                              })}
                            </tr>

                            {/* Expanded Sub-Capabilities Rows */}
                            {isExpanded && subCaps.map((sub, sIdx) => (
                              <tr key={`${cap.category}_sub_${sIdx}`} className="bg-indigo-50/30 hover:bg-indigo-50/60 transition-colors border-t border-slate-200/60">
                                
                                {/* Sub-capability Title Column */}
                                <td className="p-3 pl-8 sticky left-0 z-20 bg-indigo-50 border-r border-slate-200 align-top shadow-sm">
                                  <div className="space-y-0.5">
                                    <div className="flex items-center gap-1.5 text-slate-900 font-bold text-xs">
                                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                                      <span>{sub.name}</span>
                                    </div>
                                    {sub.description && (
                                      <p className="text-[10px] text-slate-500 leading-tight">
                                        {sub.description}
                                      </p>
                                    )}
                                  </div>
                                </td>

                                {/* Sub-capability Platform Cells */}
                                {matrixResult.platforms.map((plt) => {
                                  const cell = sub.cellByPlatform?.[plt];
                                  if (!cell) return <td key={plt} className="p-3 border-l border-slate-200 text-slate-400 text-center text-xs">N/A</td>;
                                  
                                  const details = getHarveyBallDetails(cell.rating || cell.label);

                                  return (
                                    <td key={plt} className="p-3 align-top border-l border-slate-200 text-xs">
                                      <div className="space-y-1.5">
                                        <div className="flex items-center gap-1.5">
                                          <HarveyBallIcon rating={cell.rating || cell.label} size={16} />
                                          <span className="text-[10px] font-bold text-slate-700 uppercase">
                                            {details.label}
                                          </span>
                                        </div>
                                        <p className="text-[11px] text-slate-600 leading-snug">
                                          {cell.explanation}
                                        </p>

                                        {cell.plusPoint && (
                                          <div className="flex items-start gap-1 text-[10px] text-emerald-800 bg-emerald-50/80 p-1 rounded border border-emerald-100 font-medium">
                                            <Plus size={11} className="shrink-0 mt-0.5 text-emerald-600" />
                                            <span>{cell.plusPoint}</span>
                                          </div>
                                        )}

                                        {cell.minusPoint && (
                                          <div className="flex items-start gap-1 text-[10px] text-amber-800 bg-amber-50/80 p-1 rounded border border-amber-100 font-medium">
                                            <Minus size={11} className="shrink-0 mt-0.5 text-amber-600" />
                                            <span>{cell.minusPoint}</span>
                                          </div>
                                        )}
                                      </div>
                                    </td>
                                  );
                                })}
                              </tr>
                            ))}

                          </React.Fragment>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>

              {/* EXECUTIVE SUMMARY SECTION */}
              <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl p-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <FileText size={20} className="text-primary" />
                    <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight font-display">
                      Executive Summary
                    </h3>
                  </div>

                  <p className="text-sm text-slate-700 leading-relaxed font-medium whitespace-pre-line">
                    {matrixResult.executiveSummary && matrixResult.executiveSummary.trim().length > 0
                      ? matrixResult.executiveSummary
                      : `This executive platform comparison provides an objective, capability-by-capability evaluation of ${matrixResult.platforms.join(', ')} across ${matrixResult.capabilities.length} core architectural and operational areas. The matrix establishes baseline support levels, identifying key platform strengths, native cloud ecosystem integrations, and strategic tradeoffs to guide enterprise technology selection.`
                    }
                  </p>
                </div>
              </Card>

              {/* BEST FIT BY USE CASE SECTION */}
              {matrixResult.bestFitByUseCase && matrixResult.bestFitByUseCase.length > 0 && (
                <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <TrendingUp size={20} className="text-emerald-600" />
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight font-display">
                        Best Fit by Use Case
                      </h3>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-100 text-slate-900 font-black border-b border-slate-200 uppercase">
                            <th className="p-3">Use Case</th>
                            <th className="p-3">Best Platform</th>
                            <th className="p-3">Strategic Rationale</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {matrixResult.bestFitByUseCase.map((uc, i) => (
                            <tr key={i} className="hover:bg-slate-50 transition-colors">
                              <td className="p-3 font-bold text-slate-900">{uc.useCase}</td>
                              <td className="p-3">
                                <Badge className="bg-primary text-white border-none font-bold text-[10px] px-2.5 py-0.5">
                                  {uc.bestPlatform}
                                </Badge>
                              </td>
                              <td className="p-3 text-slate-600 font-medium leading-relaxed">{uc.why}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </Card>
              )}

              {/* STRENGTHS AND TRADEOFFS GRID SECTION */}
              {matrixResult.strengthsAndTradeoffs && matrixResult.strengthsAndTradeoffs.length > 0 && (
                <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={20} className="text-indigo-600" />
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight font-display">
                        Key Strategic Strengths & Operational Tradeoffs
                      </h3>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-900 text-white font-black uppercase">
                            <th className="p-3 w-1/4">Platform</th>
                            <th className="p-3 w-3/8">Key Strategic Strength (3-5 Words)</th>
                            <th className="p-3 w-3/8">Key Operational Tradeoff</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {matrixResult.strengthsAndTradeoffs.map((st, i) => (
                            <tr key={i} className="hover:bg-slate-50 transition-colors">
                              <td className="p-3 font-black text-slate-900">{st.platform}</td>
                              <td className="p-3">
                                <span className="inline-block bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold px-2.5 py-1 rounded-md">
                                  {st.biggestStrength}
                                </span>
                              </td>
                              <td className="p-3 text-slate-600 font-medium leading-relaxed">{st.biggestLimitation}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </Card>
              )}

              {/* STRATEGIC RECOMMENDATION SECTION */}
              {matrixResult.recommendation && (
                <Card className="shadow-sm border border-indigo-200 bg-gradient-to-br from-indigo-50/80 via-white to-slate-50 p-6 rounded-2xl">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Award size={22} className="text-indigo-600" />
                      <h3 className="text-lg font-black text-indigo-950 uppercase tracking-tight font-display">
                        Strategic Recommendation
                      </h3>
                    </div>

                    <p className="text-sm text-slate-800 leading-relaxed font-medium whitespace-pre-line">
                      {matrixResult.recommendation}
                    </p>
                  </div>
                </Card>
              )}

              {/* MARKET QUADRANT REFERENCE CALLOUT SECTION */}
              <Card className="shadow-sm border border-slate-200 bg-white rounded-2xl p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <PieChart size={20} className="text-primary shrink-0" />
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight font-display">
                        Market Quadrant Reference
                      </h3>
                    </div>
                    <p className="text-xs text-slate-600 font-medium max-w-2xl leading-relaxed">
                      Review industry market quadrant positioning across Completeness of Vision and Ability to Execute for evaluated enterprise platforms.
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0">
                    <Button
                      onClick={() => setIsGartnerModalOpen(true)}
                      className="bg-primary hover:bg-primary/90 text-white font-bold text-xs gap-1.5 h-10 px-4 rounded-xl shadow-xs"
                    >
                      <PieChart size={14} />
                      Market Quadrant
                    </Button>
                  </div>
                </div>
              </Card>

            </div>
          )}

        </div>

      </div>

      {/* MARKET QUADRANT REFERENCE MODAL */}
      <Dialog open={isGartnerModalOpen} onOpenChange={setIsGartnerModalOpen}>
        <DialogContent className="max-w-[920px] w-full sm:max-w-[920px] bg-slate-50 rounded-3xl p-6 text-left space-y-5 max-h-[92vh] overflow-y-auto fixed !top-6 sm:!top-8 !-translate-y-0 shadow-2xl border border-slate-200">
          <DialogHeader className="pr-8 pb-3 border-b border-slate-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <DialogTitle className="text-xl font-black uppercase tracking-tight text-slate-900 font-display flex items-center gap-2">
                  <PieChart className="text-primary shrink-0" size={20} />
                  Market Quadrant
                </DialogTitle>
                <DialogDescription className="text-xs text-slate-500 font-medium">
                  Cloud Database Management Systems Market Quadrant positioning across Ability to Execute and Completeness of Vision.
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-5">
            {/* Year Toggle & Note */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-700">Edition:</span>
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setGartnerYear('2025')}
                    className={cn(
                      "px-3 py-1 text-xs font-bold rounded-md transition-all",
                      gartnerYear === '2025' ? "bg-primary text-white shadow-xs" : "text-slate-600 hover:bg-slate-200"
                    )}
                  >
                    2024 / 2025
                  </button>
                  <button
                    type="button"
                    onClick={() => setGartnerYear('2024')}
                    className={cn(
                      "px-3 py-1 text-xs font-bold rounded-md transition-all",
                      gartnerYear === '2024' ? "bg-primary text-white shadow-xs" : "text-slate-600 hover:bg-slate-200"
                    )}
                  >
                    2023 / 2024
                  </button>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 font-medium">
                <span className="font-bold text-slate-700">Domain:</span> Cloud DBMS Market
              </div>
            </div>

            {/* SCATTERPLOT CANVAS CARD */}
            <div className="bg-white p-6 rounded-2xl border border-slate-300 shadow-sm space-y-4">
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h4 className="font-bold text-sm text-slate-900">
                    Figure 1: Market Quadrant for Cloud Database Management Systems
                  </h4>
                  <span className="text-[10px] text-slate-400 font-medium">
                    Evaluated vendor landscape across execution capability and vision completeness.
                  </span>
                </div>
              </div>

              {/* SCATTERPLOT CANVAS BOX */}
              <div className="relative w-full max-w-[700px] mx-auto">
                {/* Left Y-Axis Label */}
                <div className="absolute -left-7 top-1/2 -translate-y-1/2 -rotate-90 text-[10px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1 shrink-0 whitespace-nowrap">
                  <span>ABILITY TO EXECUTE</span>
                  <span className="text-slate-700 font-bold">→</span>
                </div>

                {/* Scatterplot Grid Area */}
                <div className="relative w-full aspect-[4/3] bg-white border-2 border-slate-700 rounded-sm overflow-hidden shadow-xs">
                  {/* 2x2 Quadrant Grid Crosshair */}
                  <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 pointer-events-none">
                    {/* Top-Left: CHALLENGERS */}
                    <div className="border-r border-b border-slate-300 relative bg-slate-50/20">
                      <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-slate-200 text-slate-700 text-[10px] font-bold uppercase px-3 py-0.5 rounded tracking-wider shadow-2xs">
                        CHALLENGERS
                      </div>
                    </div>

                    {/* Top-Right: LEADERS */}
                    <div className="border-b border-slate-300 relative bg-slate-50/20">
                      <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-slate-200 text-slate-700 text-[10px] font-bold uppercase px-3 py-0.5 rounded tracking-wider shadow-2xs">
                        LEADERS
                      </div>
                    </div>

                    {/* Bottom-Left: NICHE PLAYERS */}
                    <div className="border-r border-slate-300 relative bg-slate-50/20">
                      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-slate-200 text-slate-700 text-[10px] font-bold uppercase px-3 py-0.5 rounded tracking-wider shadow-2xs">
                        NICHE PLAYERS
                      </div>
                    </div>

                    {/* Bottom-Right: VISIONARIES */}
                    <div className="relative bg-slate-50/20">
                      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-slate-200 text-slate-700 text-[10px] font-bold uppercase px-3 py-0.5 rounded tracking-wider shadow-2xs">
                        VISIONARIES
                      </div>
                    </div>
                  </div>

                  {/* Scatterplot Points */}
                  <div className="relative w-full h-full p-6">
                    {(gartnerYear === '2025' ? GARTNER_REFERENCE_DATA_2025 : GARTNER_REFERENCE_DATA_2024).map((item) => {
                      const isSelected = selectedPlatforms.some(sp => sp.toLowerCase() === item.name.toLowerCase() || item.name.toLowerCase().includes(sp.toLowerCase()));
                      return (
                        <div
                          key={item.name}
                          style={{ left: `${item.x}%`, top: `${100 - item.y}%` }}
                          className="absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer z-20 transition-all duration-500 ease-in-out"
                        >
                          <div className="relative flex items-center">
                            {/* Dot */}
                            <div
                              className={cn(
                                "rounded-full transition-all shrink-0",
                                isSelected
                                  ? "w-4 h-4 bg-[#1b75bc] ring-4 ring-sky-200 border-2 border-white shadow-md scale-110"
                                  : "w-3 h-3 bg-[#2073af] border border-white opacity-70 group-hover:opacity-100"
                              )}
                            />

                            {/* Label */}
                            <span
                              className={cn(
                                "absolute text-[11px] whitespace-nowrap transition-all",
                                item.pos === 'right' ? "left-4 text-left" : "right-4 text-right",
                                isSelected
                                  ? "font-extrabold text-[#1b75bc] bg-sky-50/95 px-1.5 py-0.5 rounded border border-sky-200 shadow-2xs z-30"
                                  : "font-semibold text-slate-700 group-hover:text-slate-900"
                              )}
                            >
                              {item.name}
                            </span>

                            {/* Tooltip */}
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 hidden group-hover:block z-50 shadow-2xl pointer-events-none text-left">
                              <span className="font-bold text-white text-xs block mb-0.5">{item.name}</span>
                              <span className="text-[10px] text-sky-300 block">{item.quadrant}</span>
                              <span className="text-[9px] text-slate-400 block">{item.sourceReport} ({item.sourceDate})</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Bottom X-Axis Label */}
                <div className="mt-3 flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <span>COMPLETENESS OF VISION</span>
                    <span className="text-slate-700 font-bold">→</span>
                  </div>
                  <span>Market Quadrant Reference</span>
                </div>
              </div>
            </div>

            {/* UNLISTED / EXCLUDED PLATFORMS NOTICE */}
            {(() => {
              const currentReferenceSet = (gartnerYear === '2025' ? GARTNER_REFERENCE_DATA_2025 : GARTNER_REFERENCE_DATA_2024);
              const unlistedSelected = selectedPlatforms.filter(sp => 
                !currentReferenceSet.some(item => item.name.toLowerCase() === sp.toLowerCase() || item.name.toLowerCase().includes(sp.toLowerCase()) || sp.toLowerCase().includes(item.name.toLowerCase()))
              );

              if (unlistedSelected.length === 0) return null;

              return (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle size={18} className="text-amber-700 shrink-0" />
                    <h5 className="font-black text-xs text-amber-950 uppercase tracking-tight">
                      Platforms Not Listed in Standard Quadrant ({unlistedSelected.length})
                    </h5>
                  </div>
                  <p className="text-xs text-amber-900 font-medium leading-relaxed">
                    The following selected platforms are not tracked in the standard Cloud DBMS market quadrant:
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {unlistedSelected.map(p => (
                      <Badge key={p} variant="outline" className="bg-white border-amber-300 text-amber-900 font-bold text-xs py-1 px-2.5">
                        {p}
                      </Badge>
                    ))}
                  </div>
                </div>
              );
            })()}
          </div>
        </DialogContent>
      </Dialog>

      {/* Saved Assets Modal */}
      <Dialog open={isSavedAssetsModalOpen} onOpenChange={setIsSavedAssetsModalOpen}>
        <DialogContent className="max-w-2xl bg-slate-50 border border-slate-200 p-6 rounded-3xl shadow-2xl">
          <DialogHeader className="border-b border-slate-200 pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <History className="text-primary shrink-0" size={20} />
                <div>
                  <DialogTitle className="text-lg font-black uppercase text-slate-900 tracking-tight">
                    Saved Platform Comparison Assets
                  </DialogTitle>
                  <DialogDescription className="text-xs text-slate-500 font-medium">
                    Reopen, view, or manage previously generated enterprise platform comparisons.
                  </DialogDescription>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <Button
                  onClick={handleExportJSON}
                  variant="outline"
                  size="sm"
                  className="border-slate-300 text-slate-700 hover:bg-slate-100 font-bold text-xs gap-1.5 rounded-xl h-8 px-2.5 shadow-2xs"
                  title="Export all saved comparison assets to JSON backup"
                >
                  <Download size={13} />
                  Export JSON
                </Button>
                <Button
                  onClick={handleImportJSONClick}
                  variant="outline"
                  size="sm"
                  className="border-slate-300 text-slate-700 hover:bg-slate-100 font-bold text-xs gap-1.5 rounded-xl h-8 px-2.5 shadow-2xs"
                  title="Import comparison JSON file"
                >
                  <Upload size={13} className="text-indigo-600" />
                  Import JSON
                </Button>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-3 py-2 max-h-[60vh] overflow-y-auto">
            {savedAssets.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 space-y-2">
                <FileText className="mx-auto text-slate-300" size={32} />
                <p className="text-xs font-bold text-slate-600">No saved comparison assets yet.</p>
                <p className="text-[11px] text-slate-400">
                  Generate a new comparison to automatically save it as a BD asset.
                </p>
              </div>
            ) : (
              savedAssets.map((asset) => (
                <div
                  key={asset.id}
                  className={cn(
                    "p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white",
                    selectedAssetId === asset.id ? "border-primary ring-2 ring-primary/20 shadow-sm" : "border-slate-200 hover:border-slate-300"
                  )}
                >
                  <div className="space-y-1 text-left">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-slate-900">{asset.name}</span>
                      <Badge variant="outline" className="text-[10px] font-bold text-slate-500 bg-slate-50">
                        {asset.createdAt}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500">
                      <span className="font-bold text-slate-700">Platforms:</span>
                      <span>{(asset.input?.platforms || []).join(', ')}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500">
                      <span className="font-bold text-slate-700">Capabilities:</span>
                      <span>{(asset.input?.capabilities || []).length} areas evaluated</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <Button
                      onClick={() => {
                        handleLoadAsset(asset);
                        setIsSavedAssetsModalOpen(false);
                      }}
                      size="sm"
                      className="bg-primary text-white hover:bg-primary/90 font-bold text-xs h-9 px-3 rounded-xl gap-1"
                    >
                      <RotateCcw size={13} />
                      Reopen
                    </Button>
                    <Button
                      onClick={(e) => handleDeleteAsset(asset.id, e)}
                      size="sm"
                      variant="ghost"
                      className="text-red-600 hover:bg-red-50 hover:text-red-700 h-9 px-2 rounded-xl"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
};
