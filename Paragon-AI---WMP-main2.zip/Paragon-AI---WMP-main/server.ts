import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy initialization of GoogleGenAI client to avoid crash on startup if API key is missing
function getAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not configured");
  }
  return new GoogleGenAI({ apiKey });
}

// API routes
app.post("/api/ai/generate", async (req, res) => {
  try {
    const { model, contents, config } = req.body;
    
    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({ error: "GEMINI_API_KEY environment variable is not configured." });
    }

    const ai = getAIClient();

    const selectedModel = model || "gemini-2.5-flash";

    // Build config object safely
    const reqConfig: any = {
      responseMimeType: config?.responseMimeType || "application/json",
      responseSchema: config?.responseSchema,
      maxOutputTokens: config?.maxOutputTokens,
      temperature: config?.temperature,
      topP: config?.topP,
      topK: config?.topK,
      systemInstruction: config?.systemInstruction
    };

    // Only include thinkingConfig if provided AND model is a thinking model
    if (config?.thinkingConfig && selectedModel.includes("2.5-pro")) {
      reqConfig.thinkingConfig = config.thinkingConfig;
    }

    // The @google/genai SDK uses ai.models.generateContent directly
    const result = await ai.models.generateContent({
      model: selectedModel,
      contents: Array.isArray(contents) ? contents : [{ role: 'user', parts: [{ text: contents }] }],
      config: reqConfig
    });
    
    res.json({ text: result.text });
  } catch (error: any) {
    console.error("Gemini Error:", error);
    res.status(500).json({ error: error.message || "Failed to generate AI content" });
  }
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});

