export type Persona = 'architect' | 'analyst' | 'bd' | 'data_analyst' | 'project_manager';

export interface ColumnDefinition {
  columnName: string;
  businessName: string;
  description: string;
  datatype: string;
  size: string;
  isPk: boolean;
  fkTo: string;
  isNullable: boolean;
  defaultValue: string;
  exampleValues: string;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  industry?: string;
  companyName?: string;
  companyProfile?: CompanyProfile;
  createdAt: string;
  defaultPersona?: Persona;
  platformScenarios?: PlatformScenario[];
}

export interface MDPOpportunity {
  id: string;
  title: string;
  businessCase: string;
  metrics: string[];
  roi: string;
  dimensions: string[];
  facts: string[];
  iconType: string;
  selected: boolean;
  linkedSwotIndex?: number;
  linkType?: 'direct' | 'indirect';
}

export interface TickerMatch {
  symbol: string;
  companyName: string;
}

export interface CompanyProfile {
  name: string;
  summary: string;
  linesOfBusiness: string[];
  logo?: string;
  ticker?: string;
  potentialTickers?: TickerMatch[];
  marketCap?: string;
  isPublic: boolean;
  ownershipType: 'Private' | 'Public' | 'Public Sector';
  geographicScope: 'US' | 'International';
  country: string;
  swot?: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
  opportunities: MDPOpportunity[];
}

export interface TableModel {
  id: string;
  projectId: string;
  tableName: string;
  tableType: 'Dimension' | 'Fact';
  industry: string;
  companyName: string;
  modelComplexity: 'Basic' | 'Advanced';
  subjectArea?: string;
  factType?: 'Transaction' | 'Periodic Snapshot' | 'Accumulating Snapshot' | 'Aggregate';
  aggregateGrain?: string;
  relatedDimensions?: string[];
  description: string;
  columns: ColumnDefinition[];
  createdAt: string;
  sttmStatus?: 'C' | 'P' | 'I';
}

export interface SourceColumnMapping {
  sourceSystem: string;
  sourceSchema: string;
  sourceTable: string;
  sourceFieldName: string;
  sourceDatatype: string;
  etlRules: string;
}

export interface STTMMapping {
  id: string;
  tableId: string;
  targetTableId?: string; // Added for backward compatibility/clarity
  projectId: string;
  mappings: {
    targetColumnName: string;
    source: SourceColumnMapping;
  }[];
  createdAt: string;
  isGenerating?: boolean;
}

export interface DashboardWidget {
  id: string;
  type: 'chart' | 'metric' | 'table' | 'image';
  title: string;
  chartType?: 'bar' | 'line' | 'pie' | 'area';
  metricValue?: string;
  metricLabel?: string;
  columns?: string[];
  data: any[];
  imageUrl?: string;
}

export interface DashboardFilter {
  id: string;
  label: string;
  column: string;
  options: string[];
}

export interface DashboardModel {
  id: string;
  projectId: string;
  starSchemaId: string;
  name: string;
  theme: 'Surprise Me!' | 'Custom';
  description?: string;
  widgets: DashboardWidget[];
  filters: DashboardFilter[];
  createdAt: string;
}

export interface GapRegistryAsset {
  id: string;
  projectId: string;
  title: string;
  companyName: string;
  industry: string;
  items: GapRegistryItem[];
  createdAt: string;
}

export interface GapRegistryItem {
  id: string;
  painPoint: string;
  entity: string;
  reportedBy: string;
  reportedDate: string;
  gapType: 'Gap' | 'Pain Point' | 'Opportunity' | 'Informational';
  category: string;
  wmpComments: string;
  directQuotations: string;
  interviewee: string;
  meetingWorkshop: string;
  priority: 'Low' | 'Medium' | 'High';
  dataMaturityArea: string;
  mentions?: string;
  totalMentions?: number;
}

export interface TranscriptSegment {
  speaker: string;
  timestamp: string;
  text: string;
}

export interface Transcript {
  id: string;
  projectId: string;
  companyName: string;
  industry: string;
  name: string;
  description: string;
  date: string;
  time: string;
  attendees: string[];
  segments: TranscriptSegment[];
  createdAt: string;
}

export type LakehousePlatform = 'Databricks' | 'Snowflake' | 'Microsoft Fabric' | 'AWS Native Data Services' | 'GCP Data Services' | 'Dremio' | 'Starburst/Trino' | 'ClickHouse Cloud' | 'Firebolt' | 'SingleStore' | 'Cloudera Data Platform (CDP)' | 'Oracle Autonomous Data Warehouse / HeatWave' | 'SAP Datasphere + HANA Cloud' | 'Tinybird' | 'Open Lakehouse Stack (Iceberg, Spark, Trino, dbt, Airbyte, Dagster, Grafana)';
export type CloudProvider = 'Azure' | 'AWS' | 'GCP';
export type BatchFrequency = 'Nightly (Once)' | 'Intraday (Twice)' | 'Hourly';
export type Environment = 'DEV' | 'QA' | 'PROD';

export interface AdvancedQuestionnaire {
  currentPlatforms?: string;
  hostingClouds?: string;
  centralizedOrBu?: string;
  envCount?: string;
  totalVolume?: string;
  growthRate?: string;
  activeVsArchived?: string;
  retentionBackup?: string;
  sourceSystemCount?: string;
  batchVsRealtime?: string;
  dailyIngestionVolume?: string;
  cdcStreaming?: string;
  primaryWorkloads?: string;
  peakUsage?: string;
  steadyVsVariable?: string;
  gpuAiReqs?: string;
  totalBiUsers?: string;
  userBreakdown?: string;
  dashboardCount?: string;
  refreshFrequency?: string;
  complianceReqs?: string;
  piiData?: string;
  governanceTools?: string;
  drReplication?: string;
  supportModel?: string;
  support24x7?: string;
  teamSize?: string;
  licensingAgreements?: string;
  sharedWithParent?: string;
  duplicateEnvs?: string;
  day1Data?: string;
  tsaDuration?: string;
  slas?: string;
  currentSpend?: string;
  pricingModel?: string;
}

export interface PlatformEstimateInput {
  selectedPlatforms: LakehousePlatform[];
  selectedComponents?: string[];
  biToolChoice?: 'Power BI Premium' | 'Power BI Pro (50 users)' | 'Tableau (50 users)';
  directSources: number;
  streamingSources: number;
  streamingPayloadMB: number;
  apiConnections: number;
  flatFiles: number;
  bronzeSizeTB: number;
  cloudProvider: CloudProvider;
  batchFrequency: BatchFrequency;
  realtimeFrequencyMS: number;
  environments: Environment[];
  specialInstructions?: string;
  advancedQuestionnaire?: AdvancedQuestionnaire;
}

export interface DetailedCostItem {
  service: string;
  monthlyCost: number;
  assumption: string;
}

export interface MermaidHighlight {
  title: string;
  description: string;
  type: 'security' | 'scalability' | 'integration' | 'performance';
}

export interface PlatformEstimateResult {
  platformName: string;
  estimatedMonthlyCost: number;
  estimatedAnnualCost: number;
  currency: string;
  summaryBreakdown: {
    storage: number;
    compute: number;
    licensing: number;
  };
  detailedMonthlyBreakdown: DetailedCostItem[];
  pros: string[];
  cons: string[];
  strategicFitScore: number;
  complexity: 'Low' | 'Medium' | 'High';
  complexityJustification: string;
  timeToValue: string;
  recommendation: string;
  mermaidDiagram?: string;
  mermaidHighlights?: MermaidHighlight[];
}

export interface PlatformScenario {
  id: string;
  name: string;
  projectId: string;
  inputs: PlatformEstimateInput;
  results: PlatformEstimateResult[];
  createdAt: string;
  companyName: string;
  industry: string;
  lastGeneratedAt?: string;
}

export interface PlatformEstimateAsset {
  id: string;
  projectId: string;
  companyName: string;
  industry: string;
  inputs: PlatformEstimateInput;
  results: PlatformEstimateResult[];
  createdAt: string;
  scenarioName: string;
  scenarioId?: string;
}

export interface SampleDashboard {
  id: string;
  projectId: string;
  useCaseId: string;
  useCaseTitle: string;
  title: string;
  description: string;
  theme: string;
  prompts: string[];
  kpis: { label: string; value: string; trend: string; color?: string; description?: string }[];
  charts: {
    id: string;
    type: string;
    title: string;
    data: any[];
    config?: any;
    description?: string;
  }[];
  createdAt: string;
  colorScheme?: string;
  persona?: string;
}

export interface ProjectEstimateAsset {
  id: string;
  projectId: string;
  assetName: string;
  createdAt: string;
  inputs: any; // We use any or import ProjectEstimatorInputs to keep loose coupling
  result: any;
}

export interface ProjectActionItem {
  id: string;
  description: string;
  owner: string; // Fallback: "Unassigned"
  dueDate: string; // Fallback: "TBD"
  status: 'Open' | 'In Progress' | 'Completed' | 'Blocked';
  priority: 'High' | 'Medium' | 'Low';
  category?: string;
  notes?: string;
  transcriptId?: string;
  transcriptTitle?: string;
  summaryId?: string;
}

export interface ProjectMeetingSummary {
  id: string;
  projectId?: string;
  transcriptId?: string;
  meetingTitle?: string;
  meetingDate?: string;
  meetingTime?: string;
  meetingObjective?: string;
  nextMeetingDateTime?: string;
  title?: string;
  date?: string;
  companyName?: string;
  industry?: string;
  attendees: string[];
  recapNotes?: string[];
  executiveSummary?: string;
  keyItems?: string[];
  keyDecisions?: string[];
  actionItems: ProjectActionItem[];
  nextMeeting?: string;
  nextMeetingDate?: string;
  nextSteps?: string[];
  clarificationsNeeded?: string[];
  createdAt?: string;
  isHumanConfirmed?: boolean;
}

export interface PMAssistantMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface RAIDItem {
  id: string;
  projectId?: string;
  type: 'Risk' | 'Assumption' | 'Issue' | 'Dependency';
  title: string;
  description: string;
  impact: 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Progress' | 'Mitigated' | 'Resolved';
  owner: string;
  targetDate: string;
  sourceMeetingId?: string;
  sourceMeetingTitle?: string;
}

export type HarveyBallSupportLevel = 
  | 'Not Supported' 
  | 'Limited Support' 
  | 'Partial Support' 
  | 'Broad Support' 
  | 'Full Support';

export type PlatformComparisonRatingSymbol = HarveyBallSupportLevel | '⚫ Excellent' | '◐ Good' | '◑ Fair' | '◒ Limited';

export interface PlatformComparisonCell {
  rating: HarveyBallSupportLevel | string;
  label: string;
  explanation: string;
  plusPoint?: string;
  minusPoint?: string;
}

export interface SubCapability {
  name: string;
  description?: string;
  cellByPlatform: Record<string, PlatformComparisonCell>;
}

export interface PlatformComparisonCapability {
  category: string;
  name: string;
  description?: string;
  cellByPlatform: Record<string, PlatformComparisonCell>;
  subCapabilities?: SubCapability[];
}

export interface TargetFitQuadrantNode {
  platform: string;
  xValue: number; // Implementation Ease & Operational Maturity (0-100)
  yValue: number; // Strategic Alignment & Business Fit (0-100)
  rationale: string;
}

export interface PlatformComparisonMatrix {
  platforms: string[];
  capabilities: PlatformComparisonCapability[];
  executiveSummary: string;
  bestFitByUseCase: Array<{
    useCase: string;
    bestPlatform: string;
    why: string;
  }>;
  strengthsAndTradeoffs: Array<{
    platform: string;
    biggestStrength: string; // 3-5 word Key Strategic Strength
    biggestLimitation: string; // Key Operational Tradeoff
  }>;
  recommendation?: string;
  targetFitQuadrant?: TargetFitQuadrantNode[];
}

export interface PlatformComparisonInput {
  platforms: string[];
  capabilities: string[];
  mode: 'general' | 'targeted' | 'company-targeted';
  companyName?: string;
  industry?: string;
  businessContext?: string;
  priorityCapabilities?: string[];
  extraRequirements?: string;
}

export interface PlatformComparisonAsset {
  id: string;
  projectId?: string;
  name: string;
  createdAt: string;
  input: PlatformComparisonInput;
  result: PlatformComparisonMatrix;
}
